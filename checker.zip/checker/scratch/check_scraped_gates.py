import sys, asyncio, os
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

import database.db as db

async def main():
    await db.init_db()
    try:
        # Check if table scraped_gates exists
        res = await db._db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='scraped_gates'")
        if res:
            rows = await db._db.execute("SELECT id, domain, is_active FROM scraped_gates LIMIT 10")
            print("Scraped gates:", rows)
        else:
            print("scraped_gates table does not exist")
            
        # Check if we have any other table like wc_bt_gates or custom tables
        res_all = await db._db.execute("SELECT name FROM sqlite_master WHERE type='table'")
        print("All tables in DB:", [r[0] for r in res_all])
        
    except Exception as e:
        print("Error:", e)

asyncio.run(main())
