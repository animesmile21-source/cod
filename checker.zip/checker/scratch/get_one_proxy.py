import sys, asyncio, os
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

import database.db as db

async def main():
    await db.init_db()
    proxies = await db.get_working_proxies()
    if proxies:
        p = proxies[0]
        auth = f"{p['username']}:{p['password']}" if p['username'] else ""
        print(f"PROXY={p['host']}:{p['port']}:{auth}".rstrip(":"))
    else:
        print("PROXY=None")

asyncio.run(main())
