"""
scratch/scan_custom_list.py

This script reads URLs from shpoify.txt, checks them concurrently using 20 parallel workers,
detects if they are Shopify stores with active checkout & PCI vault access, and tests them with
a test card to confirm if they are WORKING.

Working stores will be outputted to scratch/working_shopify_results.txt.
"""
import asyncio
import os
import sys
import json
import logging
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("CustomShopifyScanner")

from handlers.shopify_handler import _scan_shopify_site
import database.db as db

INPUT_FILE = "shpoify.txt"
OUTPUT_FILE = "scratch/working_shopify_results.txt"
CONCURRENCY = 20

async def scan_worker(queue, results_list, progress):
    while True:
        try:
            url = await queue.get()
        except asyncio.QueueEmpty:
            break
        
        url_clean = url.replace("https://", "").replace("http://", "").strip("/")
        
        try:
            logger.info(f"[{progress['done']}/{progress['total']}] Scanning: {url_clean}")
            res = await _scan_shopify_site(url)
            
            if res.get("status") == "WORKING":
                logger.info(f"🟢 WORKING STORE FOUND: {url} (${res.get('price')} {res.get('currency')})")
                results_list.append(res)
                
                # Append to file immediately in case of interruption
                with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
                    f.write(f"{res['url']} | Price: {res['price']} {res['currency']} | ShopID: {res['shop_id']} | Type: {res['checkout_type']}\n")
            else:
                logger.info(f"🔴 Site failed: {url_clean} - Reason: {res.get('reason')}")
        except Exception as e:
            logger.error(f"⚠️ Exception scanning {url_clean}: {e}")
        finally:
            progress["done"] += 1
            queue.task_done()

async def main():
    if not os.path.exists(INPUT_FILE):
        logger.error(f"Input file '{INPUT_FILE}' not found in workspace!")
        return

    # Read URLs
    with open(INPUT_FILE, "r", encoding="utf-8", errors="ignore") as f:
        urls = [line.strip() for line in f.readlines() if line.strip()]
    
    # Clean and filter duplicates
    cleaned_urls = []
    for u in urls:
        if not u.startswith("http"):
            u = "https://" + u
        cleaned_urls.append(u)
    cleaned_urls = list(dict.fromkeys(cleaned_urls))
    
    total_sites = len(cleaned_urls)
    logger.info(f"Loaded {total_sites} unique URLs from {INPUT_FILE}")

    # Ensure output directory exists
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    # Clear output file from previous runs
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(f"# Scan Results started at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"# Total Input Sites: {total_sites}\n")
        f.write("-" * 60 + "\n")

    # Initialize DB
    await db.init_db()

    # Fill Queue
    queue = asyncio.Queue()
    for u in cleaned_urls:
        await queue.put(u)

    progress = {"done": 1, "total": total_sites}
    results = []

    # Create workers
    workers = []
    for _ in range(CONCURRENCY):
        task = asyncio.create_task(scan_worker(queue, results, progress))
        workers.append(task)

    # Wait for queue to empty
    await queue.join()

    # Stop workers
    for w in workers:
        w.cancel()
    
    await asyncio.gather(*workers, return_exceptions=True)

    logger.info(f"Scan Finished! Total checked: {total_sites}. Working found: {len(results)}")
    logger.info(f"Results written to: {OUTPUT_FILE}")

if __name__ == "__main__":
    asyncio.run(main())
