"""
scratch/test_stripe_checkout_gate.py
TEST SCRIPT — Tests Stripe Hosted Checkout gate logic BEFORE bot integration
Usage: python scratch/test_stripe_checkout_gate.py
"""
import asyncio
import sys
import re
import random

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# ─── Test inputs ───────────────────────────────────────────────────────────────
# Paste a fresh cs_live_ URL here before running
CHECKOUT_URL = ""   # <-- paste here

# Card to test (format: number|month|year|cvv)
TEST_CARD = "4242424242424242|12|2030|123"   # Stripe test card (won't charge)

# ───────────────────────────────────────────────────────────────────────────────


def rand_uuid():
    h = "0123456789abcdef"
    return "-".join([
        "".join(random.choices(h, k=8)),
        "".join(random.choices(h, k=4)),
        "4" + "".join(random.choices(h, k=3)),
        random.choice("89ab") + "".join(random.choices(h, k=3)),
        "".join(random.choices(h, k=12)),
    ])


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: Load session via Playwright + intercept PI/SI
# ═══════════════════════════════════════════════════════════════════════════════

async def load_session(checkout_url: str) -> dict | None:
    """
    Opens the Stripe Checkout page in a headless browser,
    fills the form with a dummy card, clicks Pay,
    and intercepts the PaymentIntent confirm request to extract pi_id + client_secret.
    Returns dict with: pk, pi_id, pi_secret, si_id, si_secret, merchant, currency
    """
    from playwright.async_api import async_playwright

    result = {}
    print(f"  [Playwright] Loading: {checkout_url[:60]}...")

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"]
        )
        ctx = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
            locale="en-US",
        )
        page = await ctx.new_page()

        # ── Intercept requests ──
        async def on_req(request):
            url = request.url
            # Capture PK
            if "elements/sessions" in url:
                m = re.search(r'key=(pk_live_[^&\s]+)', url)
                if m:
                    result["pk"] = m.group(1)

            # Capture PI confirm
            if "/payment_intents/" in url and "/confirm" in url and "stripe.com" in url:
                pd = request.post_data or ""
                pi_m = re.search(r'/payment_intents/(pi_[^/]+)/confirm', url)
                cs_m = re.search(r'client_secret=(pi_[a-zA-Z0-9_]+)', pd)
                if pi_m:
                    result["pi_id"] = pi_m.group(1)
                    print(f"  [INTERCEPT] PI Confirm! pi_id={pi_m.group(1)}")
                if cs_m:
                    result["pi_secret"] = cs_m.group(1)
                    print(f"  [INTERCEPT] PI Secret captured!")

            # Capture SI confirm
            if "/setup_intents/" in url and "/confirm" in url and "stripe.com" in url:
                pd = request.post_data or ""
                si_m = re.search(r'/setup_intents/(seti_[^/]+)/confirm', url)
                cs_m = re.search(r'client_secret=(seti_[a-zA-Z0-9_]+)', pd)
                if si_m:
                    result["si_id"] = si_m.group(1)
                    print(f"  [INTERCEPT] SI Confirm! si_id={si_m.group(1)}")
                if cs_m:
                    result["si_secret"] = cs_m.group(1)

        async def on_resp(response):
            if "elements/sessions" in response.url:
                try:
                    body = await response.json()
                    result["merchant"] = body.get("business_name", "Unknown")
                    result["currency"] = body.get("merchant_currency", "usd")
                    result["amount"] = body.get("amount_total", 0)
                    print(f"  [Session] Merchant={result['merchant']} Currency={result['currency'].upper()}")
                except Exception:
                    pass

        page.on("request", on_req)
        page.on("response", on_resp)

        # Load page
        try:
            await page.goto(checkout_url, wait_until="domcontentloaded", timeout=20000)
        except Exception as e:
            print(f"  [Nav] {e}")
        await asyncio.sleep(4)

        # Check if page expired
        cur_url = page.url
        if "about:blank" in cur_url or "timed out" in (await page.title()).lower():
            print("  [ERROR] Session expired or page failed to load")
            await ctx.close(); await browser.close()
            return None

        frames = page.frames
        print(f"  [Frames] Total: {len(frames)}")

        # Find checkout-inner-origin-frame (has the actual card inputs)
        card_frame = None
        for frame in frames:
            furl = frame.url or ""
            if "checkout-inner" in furl and "js.stripe.com" in furl:
                card_frame = frame
                print(f"  [Frame] Found card iframe: {furl[:70]}")
                # Verify inputs exist
                try:
                    inputs = await frame.eval_on_selector_all(
                        "input",
                        "els => els.map(e => ({name:e.name, placeholder:e.placeholder, autocomplete:e.autocomplete}))"
                    )
                    print(f"  [Frame] Inputs: {inputs}")
                except Exception:
                    pass
                break

        # Fill fields
        print("\n  [Fill] Filling form fields...")

        async def safe_type(target, sel, value, label):
            try:
                el = target.locator(sel).first
                await el.wait_for(state="visible", timeout=3000)
                await el.click()
                await asyncio.sleep(0.2)
                for ch in value:
                    await el.type(ch, delay=50)
                print(f"  [Fill] ✅ {label}: {value}")
                return True
            except Exception as e:
                print(f"  [Fill] ⚠️ {label}: {str(e)[:60]}")
                return False

        # Card fields — try checkout-inner iframe first, then main frame
        if card_frame:
            await safe_type(card_frame,
                '[autocomplete="cc-number"], [data-elements-stable-field-name="cardNumber"], [placeholder*="1234"]',
                "4242424242424242", "Card (iframe)")
            await asyncio.sleep(0.4)
            await safe_type(card_frame,
                '[autocomplete="cc-exp"], [data-elements-stable-field-name="cardExpiry"], [placeholder*="MM"]',
                "12/30", "Expiry (iframe)")
            await asyncio.sleep(0.4)
            await safe_type(card_frame,
                '[autocomplete="cc-csc"], [data-elements-stable-field-name="cardCvc"], [placeholder*="CVC"]',
                "123", "CVC (iframe)")
        else:
            # Fallback to main frame with specific selectors
            await safe_type(page, '[name="cardNumber"]', "4242424242424242", "Card (main)")
            await asyncio.sleep(0.4)
            await safe_type(page, '[name="cardExpiry"]', "12/30", "Expiry (main)")
            await asyncio.sleep(0.4)
            await safe_type(page, '[name="cardCvc"]', "123", "CVC (main)")

        await asyncio.sleep(0.4)
        await safe_type(page, '[name="billingName"]', "John Smith", "Name")
        await asyncio.sleep(0.4)

        # Address — click "Enter manually" link
        try:
            manual = page.locator('a:has-text("Enter address manually")').first
            if await manual.is_visible(timeout=2000):
                await manual.click()
                print("  [Fill] ✅ Clicked 'Enter address manually'")
                await asyncio.sleep(1)
        except Exception:
            pass

        # Fill address directly or via JS
        addr_filled = await safe_type(page, '[name="billingAddressLine1"]', "123 Main St", "Address")
        if not addr_filled:
            try:
                await page.eval_on_selector('[name="billingAddressLine1"]',
                    'el => { el.disabled=false; el.value="123 Main St"; el.dispatchEvent(new Event("input",{bubbles:true})); }')
                print("  [Fill] ✅ Address: JS forced")
            except Exception:
                pass

        # Force city + postal via JS
        for sel, val, lbl in [('[name="billingLocality"]', "New York", "City"),
                               ('[name="billingPostalCode"]', "10001", "Postal")]:
            try:
                await page.eval_on_selector(sel,
                    f'el => {{ el.disabled=false; el.removeAttribute("aria-hidden"); '
                    f'el.value="{val}"; el.dispatchEvent(new Event("input",{{bubbles:true}})); }}')
                print(f"  [Fill] ✅ {lbl}: {val}")
            except Exception:
                pass

        await asyncio.sleep(1)

        # Screenshot before Pay
        await page.screenshot(path="scratch/before_pay_test.png")
        print("  [Screenshot] scratch/before_pay_test.png")

        # Click Pay button
        print("\n  [Pay] Looking for Submit button...")
        for sel in ['button[type="submit"]', 'button:has-text("Subscribe")',
                    'button:has-text("Pay")', 'button:has-text("Donate")']:
            try:
                btn = page.locator(sel).first
                if await btn.is_visible(timeout=1500):
                    txt = (await btn.inner_text()).strip().replace("\n", " ")
                    disabled = await btn.get_attribute("disabled")
                    print(f"  [Pay] Button: '{txt}' disabled={disabled}")
                    await btn.click(force=True)
                    print("  [Pay] ✅ Clicked!")
                    break
            except Exception:
                pass

        # Wait up to 40 seconds for confirm interception
        print("  [Wait] Waiting for PI/SI confirm call (40s)...")
        for i in range(40):
            await asyncio.sleep(1)
            if result.get("pi_id") or result.get("si_id"):
                print(f"  [Wait] ✅ Intercepted at {i+1}s!")
                break
            if i % 10 == 9:
                print(f"  [Wait] {i+1}s... frames={len(page.frames)}")

        await page.screenshot(path="scratch/after_pay_test.png")
        print("  [Screenshot] scratch/after_pay_test.png")

        await ctx.close()
        await browser.close()

    return result if result.get("pk") else None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: Tokenize card via Stripe API
# ═══════════════════════════════════════════════════════════════════════════════

async def tokenize_card(pk: str, number: str, month: str, year: str, cvv: str) -> str | None:
    """POST to Stripe API to get a pm_xxx token for the card."""
    from curl_cffi.requests import AsyncSession

    data = {
        "type": "card",
        "card[number]": number,
        "card[cvc]": cvv,
        "card[exp_year]": year.strip()[-2:] if len(year) == 4 else year,
        "card[exp_month]": month.zfill(2),
        "billing_details[address][postal_code]": "10001",
        "billing_details[address][country]": "US",
        "allow_redisplay": "unspecified",
        "payment_user_agent": "stripe.js/v3; stripe-js-v3; checkout-inner-beta",
        "referrer": "https://checkout.stripe.com",
        "time_on_page": str(random.randint(15000, 80000)),
        "guid": rand_uuid(), "muid": rand_uuid(), "sid": rand_uuid(),
        "key": pk,
        "_stripe_version": "2023-10-16",
    }
    headers = {
        "User-Agent": "Mozilla/5.0 Chrome/131.0.0.0",
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://js.stripe.com",
        "Referer": "https://js.stripe.com/",
    }

    async with AsyncSession(impersonate="chrome131") as s:
        r = await s.post("https://api.stripe.com/v1/payment_methods", headers=headers, data=data)
        if r.status_code == 200:
            pm = r.json().get("id")
            print(f"  [Tokenize] ✅ pm={pm}")
            return pm
        else:
            err = r.json().get("error", {})
            print(f"  [Tokenize] ❌ {err.get('message', r.text[:100])}")
            return None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: Confirm PI with card
# ═══════════════════════════════════════════════════════════════════════════════

async def confirm_pi(pk: str, pi_id: str, pi_secret: str, pm_id: str) -> dict:
    """Confirm a PaymentIntent with a payment method."""
    from curl_cffi.requests import AsyncSession

    headers = {
        "User-Agent": "Mozilla/5.0 Chrome/131.0.0.0",
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://js.stripe.com",
        "Referer": "https://js.stripe.com/",
    }
    data = {
        "payment_method": pm_id,
        "return_url": "https://checkout.stripe.com/c/return",
        "client_secret": pi_secret,
        "key": pk,
        "_stripe_version": "2023-10-16",
    }

    async with AsyncSession(impersonate="chrome131") as s:
        r = await s.post(f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm", headers=headers, data=data)
        try:
            resp = r.json()
            status = resp.get("status")
            if status == "succeeded":
                return {"status": "APPROVED", "msg": "Payment Succeeded!", "code": ""}
            elif status == "requires_action":
                t = resp.get("next_action", {}).get("type", "3ds")
                return {"status": "3DS", "msg": f"Requires action: {t}", "code": "3ds"}
            else:
                err = resp.get("last_payment_error") or resp.get("error") or {}
                msg = err.get("message", f"status={status}")
                code = err.get("decline_code") or err.get("code") or "declined"
                return {"status": "DECLINED", "msg": msg, "code": code}
        except Exception as e:
            return {"status": "ERROR", "msg": str(e), "code": "parse_error"}


async def confirm_si(pk: str, si_id: str, si_secret: str, pm_id: str) -> dict:
    """Confirm a SetupIntent with a payment method."""
    from curl_cffi.requests import AsyncSession

    headers = {
        "User-Agent": "Mozilla/5.0 Chrome/131.0.0.0",
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://js.stripe.com",
        "Referer": "https://js.stripe.com/",
    }
    data = {
        "payment_method": pm_id,
        "return_url": "https://checkout.stripe.com/c/return",
        "client_secret": si_secret,
        "key": pk,
        "_stripe_version": "2023-10-16",
    }

    async with AsyncSession(impersonate="chrome131") as s:
        r = await s.post(f"https://api.stripe.com/v1/setup_intents/{si_id}/confirm", headers=headers, data=data)
        try:
            resp = r.json()
            status = resp.get("status")
            if status == "succeeded":
                return {"status": "APPROVED", "msg": "SetupIntent Succeeded!", "code": ""}
            elif status == "requires_action":
                return {"status": "3DS", "msg": "Requires 3DS", "code": "3ds"}
            else:
                err = resp.get("last_payment_error") or resp.get("error") or {}
                msg = err.get("message", f"status={status}")
                code = err.get("decline_code") or err.get("code") or "declined"
                return {"status": "DECLINED", "msg": msg, "code": code}
        except Exception as e:
            return {"status": "ERROR", "msg": str(e), "code": "parse_error"}


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN TEST
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    global CHECKOUT_URL, TEST_CARD

    print("=" * 65)
    print("  STRIPE CHECKOUT GATE — TEST SCRIPT")
    print("=" * 65)

    # Ask for URL if not set
    if not CHECKOUT_URL:
        CHECKOUT_URL = input("\nPaste checkout.stripe.com URL: ").strip()
        CHECKOUT_URL = CHECKOUT_URL.lstrip('\ufeff').strip()  # strip BOM

    if not CHECKOUT_URL or "cs_live_" not in CHECKOUT_URL:
        print("❌ Invalid URL — must contain cs_live_")
        return

    print(f"\nURL: {CHECKOUT_URL[:60]}...")
    print(f"Card: {TEST_CARD}")

    # Parse card
    parts = TEST_CARD.split("|")
    if len(parts) != 4:
        print("❌ Card format must be: number|month|year|cvv")
        return
    number, month, year, cvv = parts

    # ── STEP 1: Load session ──
    print("\n[STEP 1] Loading checkout session via Playwright...")
    session = await load_session(CHECKOUT_URL)

    if not session:
        print("\n❌ Failed to load session (expired or network error)")
        return

    print(f"\n  Merchant : {session.get('merchant', 'Unknown')}")
    print(f"  Currency : {(session.get('currency') or 'usd').upper()}")
    print(f"  PK       : {(session.get('pk') or '')[:35]}...")
    print(f"  PI ID    : {session.get('pi_id')}")
    print(f"  PI Secret: {'✅ YES' if session.get('pi_secret') else '❌ NO'}")
    print(f"  SI ID    : {session.get('si_id')}")
    print(f"  SI Secret: {'✅ YES' if session.get('si_secret') else '❌ NO'}")

    pk = session.get("pk")
    pi_id = session.get("pi_id")
    pi_secret = session.get("pi_secret")
    si_id = session.get("si_id")
    si_secret = session.get("si_secret")

    if not pk:
        print("\n❌ No publishable key captured")
        return

    if not pi_id and not si_id:
        print("\n⚠️ No PI/SI captured")
        print("  Reason: hCaptcha likely blocked the form submission")
        print("  Check screenshots: scratch/before_pay_test.png, scratch/after_pay_test.png")
        return

    # ── STEP 2: Tokenize card ──
    print(f"\n[STEP 2] Tokenizing card: {number[:6]}xxxxxx{number[-4:]}")
    pm_id = await tokenize_card(pk, number, month, year, cvv)

    if not pm_id:
        print("❌ Card tokenization failed")
        return

    # ── STEP 3: Confirm ──
    print(f"\n[STEP 3] Confirming payment...")
    if pi_id and pi_secret:
        result = await confirm_pi(pk, pi_id, pi_secret, pm_id)
    else:
        result = await confirm_si(pk, si_id, si_secret, pm_id)

    print("\n" + "=" * 65)
    status_emoji = {"APPROVED": "✅", "3DS": "🔐", "DECLINED": "❌", "ERROR": "❓"}.get(result["status"], "❓")
    print(f"  RESULT  : {status_emoji} {result['status']}")
    print(f"  MESSAGE : {result['msg']}")
    if result.get("code"):
        print(f"  CODE    : {result['code']}")
    print("=" * 65)


if __name__ == "__main__":
    asyncio.run(main())
