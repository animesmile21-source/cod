"""
Test Step 5 with AJAX headers (X-Requested-With & Content-Type) on WooCommerce.
"""
import asyncio, sys, re, random, json
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from curl_cffi.requests import AsyncSession
from faker import Faker
faker = Faker()

TEST_SITE = "https://ea-courses.com"

async def test_step_5_ajax():
    print("=" * 75)
    print("🔬 Testing Step 5 with AJAX Headers")
    print("=" * 75)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    }

    async with AsyncSession(impersonate="chrome131") as s:
        # Step 1 & 2: Get page & register
        url_1 = f"{TEST_SITE}/my-account/add-payment-method/"
        r1 = await s.get(url_1, headers=headers)
        html_1 = r1.text

        reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
        if reg_match:
            reg_nonce = reg_match.group(1)
            fake_user = faker.user_name()[:10] + str(random.randint(100, 999))
            data_reg = {
                'email': faker.email(),
                'username': fake_user,
                'woocommerce-register-nonce': reg_nonce,
                'register': 'Register',
            }
            await s.post(f"{TEST_SITE}/my-account/", headers=headers, data=data_reg)
            r_auth = await s.get(url_1, headers=headers)
            html_1 = r_auth.text

        # Extract Nonce
        m = re.search(r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"', html_1)
        if not m:
            m = re.search(r'"_ajax_nonce"\s*:\s*"([^"]+)"', html_1)

        nonce = m.group(1) if m else "test_nonce"
        print(f"✅ Extracted Nonce: {nonce}")

        payload = {
            'action': 'create_and_confirm_setup_intent',
            'wc-stripe-payment-method': 'pm_1234567890abcdef',
            'wc-stripe-payment-type': 'card',
            '_ajax_nonce': nonce,
        }

        # Test POST to ?wc-ajax=wc_stripe_create_and_confirm_setup_intent with data= payload
        ajax_url = f"{TEST_SITE}/?wc-ajax=wc_stripe_create_and_confirm_setup_intent"
        r_ajax = await s.post(ajax_url, headers=headers, data=payload)
        print(f"\nAJAX Status: {r_ajax.status_code}")
        print(f"AJAX Response: {r_ajax.text}")

if __name__ == "__main__":
    asyncio.run(test_step_5_ajax())
