"""
Test registration & login flow directly on https://dilaboards.com
"""
import asyncio, sys, re, random
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from curl_cffi.requests import AsyncSession
from faker import Faker
faker = Faker()

TEST_SITE = "https://dilaboards.com"

async def test_wc_registration():
    print("=" * 75)
    print("🔬 Testing Registration & Login Behavior on WooCommerce Store")
    print("=" * 75)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    async with AsyncSession(impersonate="chrome131") as s:
        # Step 1: Get add-payment-method or my-account page
        url_1 = f"{TEST_SITE}/my-account/add-payment-method/"
        r1 = await s.get(url_1, headers=headers)
        html_1 = r1.text

        # Extract registration nonce
        reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
        if not reg_match:
            print("❌ Registration nonce not found on page!")
            return

        reg_nonce = reg_match.group(1)
        fake_user = "usr_" + str(random.randint(100000, 999999))
        fake_email = f"test_{random.randint(10000,99999)}@gmail.com"
        fake_pass = "StrongPass123!"

        print(f"📧 Attempting Registration:")
        print(f"   Email: {fake_email}")
        print(f"   Username: {fake_user}")
        print(f"   Password: {fake_pass}")

        data_reg = {
            'email': fake_email,
            'username': fake_user,
            'password': fake_pass,
            'woocommerce-register-nonce': reg_nonce,
            'register': 'Register',
        }

        r2 = await s.post(f"{TEST_SITE}/my-account/", headers=headers, data=data_reg)
        print(f"\nStatus Code on POST /my-account/: {r2.status_code}")
        
        # Check if logged in cookie set
        cookies = s.cookies.get_dict()
        print(f"Cookies after registration: {list(cookies.keys())}")
        
        logged_in = any("wordpress_logged_in" in k for k in cookies.keys())
        print(f"LoggedIn Cookie Present: {logged_in}")

        # Now test logging in with the same email and password in a fresh session!
        print("\n🔑 Testing Login in Fresh Session with Creds:")
        async with AsyncSession(impersonate="chrome131") as s2:
            r_login_page = await s2.get(f"{TEST_SITE}/my-account/", headers=headers)
            login_nonce_m = re.search('name="woocommerce-login-nonce" value="(.*?)"', r_login_page.text)
            login_nonce = login_nonce_m.group(1) if login_nonce_m else ""

            data_login = {
                'username': fake_email,
                'password': fake_pass,
                'woocommerce-login-nonce': login_nonce,
                'login': 'Log in'
            }
            r_login = await s2.post(f"{TEST_SITE}/my-account/", headers=headers, data=data_login)
            login_cookies = s2.cookies.get_dict()
            login_success = any("wordpress_logged_in" in k for k in login_cookies.keys())
            print(f"Login with Email Status: {'SUCCESS ✅' if login_success else 'FAILED ❌'}")
            
            if not login_success:
                # Try with Username
                data_login['username'] = fake_user
                r_login2 = await s2.post(f"{TEST_SITE}/my-account/", headers=headers, data=data_login)
                login_cookies2 = s2.cookies.get_dict()
                login_success2 = any("wordpress_logged_in" in k for k in login_cookies2.keys())
                print(f"Login with Username Status: {'SUCCESS ✅' if login_success2 else 'FAILED ❌'}")
                if not login_success2:
                    print("HTML Snippet on Failed Login:")
                    print(r_login.text[:300])

if __name__ == "__main__":
    asyncio.run(test_wc_registration())
