"""
Test CommonCrawl discovery specifically for WooCommerce sites!
Queries index.commoncrawl.org for WooCommerce URL patterns.
"""
import asyncio, aiohttp, json, sys, re
from urllib.parse import urlparse

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

CC_INDEXES = [
    "CC-MAIN-2025-18",
    "CC-MAIN-2024-30",
    "CC-MAIN-2024-51",
    "CC-MAIN-2024-22",
]

WC_CC_PATTERNS = [
    "*/my-account/add-payment-method/*",
    "*/wp-content/plugins/woocommerce/*",
    "*/wp-content/plugins/woocommerce-gateway-stripe/*",
]

SKIP_DOMAINS = {
    "wordpress.org", "wordpress.com", "woocommerce.com", "github.com",
    "stripe.com", "paypal.com", "google.com", "bing.com", "youtube.com"
}

def clean_domain(url_str: str) -> str:
    try:
        p = urlparse(url_str)
        domain = p.netloc.lower().lstrip("www.")
        if domain and "." in domain and domain not in SKIP_DOMAINS:
            return f"{p.scheme}://{p.netloc}"
    except Exception:
        pass
    return ""

async def test_wc_cc_discovery():
    ua = "Mozilla/5.0 (compatible; research-bot/1.0)"
    found_domains = set()

    print("=" * 75)
    print("🌐 Testing CommonCrawl CDX API for WooCommerce Sites...")
    print("=" * 75)

    async with aiohttp.ClientSession() as session:
        for idx in CC_INDEXES:
            print(f"\n🔎 Index: {idx}")
            for pattern in WC_CC_PATTERNS:
                try:
                    # Query page count
                    async with session.get(
                        f"https://index.commoncrawl.org/{idx}-index",
                        params={"url": pattern, "output": "json", "showNumPages": "true"},
                        timeout=aiohttp.ClientTimeout(total=15),
                        headers={"User-Agent": ua}, ssl=False
                    ) as r:
                        if r.status != 200:
                            print(f"  ❌ {pattern:45s} | HTTP {r.status}")
                            continue
                        data = json.loads(await r.text())
                        pages = data.get("pages", 0)
                        print(f"  ✅ {pattern:45s} | {pages} pages (~{pages*1000:,} URLs)")

                        # Fetch first 2 pages for testing
                        for p_idx in range(min(2, pages)):
                            async with session.get(
                                f"https://index.commoncrawl.org/{idx}-index",
                                params={"url": pattern, "output": "json", "limit": "1000", "page": str(p_idx), "fields": "url"},
                                timeout=aiohttp.ClientTimeout(total=20),
                                headers={"User-Agent": ua}, ssl=False
                            ) as r2:
                                if r2.status == 200:
                                    lines = (await r2.text()).strip().split("\n")
                                    for line in lines:
                                        if not line.strip(): continue
                                        try:
                                            item = json.loads(line)
                                            d = clean_domain(item.get("url", ""))
                                            if d:
                                                found_domains.add(d)
                                        except Exception:
                                            pass
                except Exception as e:
                    print(f"  ⚠️ {pattern:45s} | {type(e).__name__}: {str(e)[:40]}")
                
                await asyncio.sleep(0.5)

    print("\n" + "=" * 75)
    print(f"🎉 SUCCESS! Found {len(found_domains):,} Unique WooCommerce Domains from CommonCrawl!")
    print("=" * 75)
    if found_domains:
        print("\nSample Discovered WooCommerce Sites:")
        for dom in list(found_domains)[:15]:
            print(f"  • {dom}")

if __name__ == "__main__":
    asyncio.run(test_wc_cc_discovery())
