"""
handlers/generator.py — /gen command for card generation
"""
from pyrogram import Client, filters, enums
from pyrogram.types import Message
from core.card_gen import generate_from_bin
from core.bin_lookup import lookup_bin
from utils.formatter import format_bin_info
from utils.error_handler import notify_owner_on_error


def register_generator(app: Client):

    @app.on_message(filters.command("gen"))
    @notify_owner_on_error
    async def gen_cmd(client: Client, msg: Message):
        """
        Generate CC numbers from BIN.
        Usage:
          /gen 414720
          /gen 414720|xx|2026|xxx
          /gen 414720|xx|2026|xxx 20
        """
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply(
                "❌ **Usage:**\n"
                "`/gen 414720`\n"
                "`/gen 414720|xx|2026|xxx`\n"
                "`/gen 414720|xx|2026|xxx 20`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        # Parse BIN and optional format + count
        gen_args = parts[1]
        count = 10
        if len(parts) >= 3 and parts[2].isdigit():
            count = min(int(parts[2]), 50)  # Max 50

        gen_parts = gen_args.split("|")
        bin6 = gen_parts[0][:6]
        month = gen_parts[1] if len(gen_parts) > 1 else "xx"
        year = gen_parts[2] if len(gen_parts) > 2 else "xxxx"
        cvv = gen_parts[3] if len(gen_parts) > 3 else "xxx"

        if not bin6.isdigit() or len(bin6) < 6:
            await msg.reply("❌ Invalid BIN. Must be at least 6 digits.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        # BIN lookup for context
        bin_info = await lookup_bin(bin6)

        cards = generate_from_bin(bin6, month, year, cvv, count)

        header = (
            f"⚡ **Generated {count} Cards — BIN `{bin6}`**\n"
        )
        if bin_info:
            header += (
                f"🏦 `{bin_info.bank_name}` | "
                f"{bin_info.flag_emoji()} `{bin_info.country_name}` | "
                f"`{bin_info.scheme} {bin_info.type}`\n"
            )
        header += "━━━━━━━━━━━━━━━━━━━━━━\n"
        header += "```\n"
        header += "\n".join(cards)
        header += "\n```"

        await msg.reply(header, parse_mode=enums.ParseMode.MARKDOWN)
