import sys, asyncio, os
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

from core.parser import CardData
from gateways.stripe_wc_gate import check_stripe_wc_gate
import database.db as db

async def main():
    await db.init_db()
    # Dummy card structure to verify network and gateway parsing
    card = CardData(number="4242424242424242", month="12", year="2028", cvv="123")
    
    print("Testing Stripe WooCommerce Gate with curl_cffi impersonation...")
    print(f"Checking dummy card: {card.number}|{card.month}|{card.year}|{card.cvv}")
    
    # Check
    result = await check_stripe_wc_gate(card)
    print("\nCheck Complete!")
    print(f"Status:  {result.status.value}")
    print(f"Gateway: {result.gateway}")
    print(f"Message: {result.message}")
    print(f"Code:    {result.raw_code}")

if __name__ == "__main__":
    asyncio.run(main())
