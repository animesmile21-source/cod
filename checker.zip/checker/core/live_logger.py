"""
core/live_logger.py — Real-time Telegram scan logger

Shows live scan activity in Telegram message:
  🔍 Scanning: example.com
  ━━━━━━━━━━━━━━━━━━━━━━
  ✅ WordPress detected
  🛒 WooCommerce found
  📦 Product found: /product/widget/
  🛒 Added to cart (ID: 42)
  💳 Checkout page loaded
  🔑 pk_live_xxx found in wc_stripe_params!
  🚀 Probing payment endpoint...
  ✅ client_secret received! GATE FOUND!
"""
import asyncio
import time
import logging

try:
    from pyrogram import enums as _pyrogram_enums
    _PARSE_MODE = _pyrogram_enums.ParseMode.MARKDOWN
except ImportError:
    _PARSE_MODE = "markdown"

logger = logging.getLogger("CC-Checker.LiveLogger")

ICONS = {
    "info":    "ℹ️",
    "ok":      "✅",
    "warn":    "⚠️",
    "error":   "❌",
    "search":  "🔍",
    "key":     "🔑",
    "cart":    "🛒",
    "product": "📦",
    "js":      "📜",
    "stripe":  "💳",
    "gate":    "🚀",
    "net":     "🌐",
    "sub":     "  ╰─",
}

class LiveLogger:
    """
    Buffers log lines and periodically edits a Telegram message
    to show live scan progress.
    """

    def __init__(
        self,
        tg_msg=None,         # Telegram message to edit (optional)
        domain: str = "",
        edit_interval: float = 2.5,  # seconds between edits
        max_lines: int = 18,
    ):
        self.tg_msg     = tg_msg
        self.domain     = domain
        self._interval  = edit_interval
        self._max_lines = max_lines
        self._lines: list[str] = []
        self._last_edit = 0.0
        self._status    = "Scanning..."
        self._found_key = ""
        self._found_ep  = ""
        self._lock      = asyncio.Lock()

    # ── Public API ──────────────────────────────────────────────────────────

    async def __call__(self, text: str, level: str = "info", flush: bool = False):
        """Allow 'await log(...)' as shorthand for 'await log.log(...)'."""
        await self.log(text, level, flush)

    async def log(self, text: str, level: str = "info", flush: bool = False):
        """Add a log line and optionally flush to Telegram."""
        icon  = ICONS.get(level, "ℹ️")
        line  = f"{icon} {text}"
        logger.debug(f"[{self.domain}] {text}")

        async with self._lock:
            self._lines.append(line)
            # Keep last N lines
            if len(self._lines) > self._max_lines * 2:
                self._lines = self._lines[-self._max_lines:]

        if flush:
            await self._flush()
        elif time.monotonic() - self._last_edit >= self._interval:
            await self._flush()


    async def set_status(self, status: str):
        self._status = status
        await self._flush()

    async def found_key(self, key: str):
        self._found_key = key
        await self.log(f"pk_live key found: `{key[:25]}...`", "key", flush=True)

    async def found_gate(self, endpoint: str):
        self._found_ep = endpoint
        await self.log(f"GATE FOUND → {endpoint}", "gate", flush=True)

    async def finish(self, success: bool, message: str = ""):
        await self.log(
            message or ("Gate saved! ✅" if success else "No gate found"),
            "ok" if success else "warn",
            flush=True,
        )

    # ── Internal flush ───────────────────────────────────────────────────────
    async def _flush(self):
        if not self.tg_msg:
            return
        self._last_edit = time.monotonic()
        try:
            recent    = self._lines[-self._max_lines:]
            log_block = "\n".join(f"  {l}" for l in recent)

            # Build header
            status_icon = "🔍"
            if self._found_ep:
                status_icon = "✅"
            elif self._found_key:
                status_icon = "🔑"

            sep = "\u2501" * 22
            text = (
                f"{status_icon} **Live Scan: `{self.domain}`**\n"
                f"{sep}\n"
                + "```\n" + log_block + "\n```"
            )
            if self._found_key and not self._found_ep:
                text += f"\n\ud83d\udd11 Key: `{self._found_key[:30]}...`"
            if self._found_ep:
                text += f"\n\u2705 Gate: `{self._found_ep}`"


            await self.tg_msg.edit_text(
                text,
                parse_mode=_PARSE_MODE,
                disable_web_page_preview=True,
            )
        except Exception as e:
            # Ignore: message not modified, flood wait, etc.
            err = str(e).lower()
            if "not modified" not in err and "flood" not in err:
                logger.debug(f"LiveLogger flush error: {e}")

    # ── Convenience: plain print to terminal only ────────────────────────────
    def debug(self, text: str):
        logger.debug(f"[{self.domain}] {text}")
