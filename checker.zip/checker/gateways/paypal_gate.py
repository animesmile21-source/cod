"""
gateways/paypal_gate.py — PayPal Advanced Card Payments Gate

Uses PayPal Orders API v2 with direct card payment source.
Requires: PayPal Business account with "Advanced Credit and Debit Card" enabled.

Credentials needed (developer.paypal.com):
  PAYPAL_CLIENT_ID     = App Client ID
  PAYPAL_CLIENT_SECRET = App Client Secret
  PAYPAL_MODE          = sandbox | live (default: live)

Flow:
  1. POST /v1/oauth2/token → get Bearer access token
  2. POST /v2/checkout/orders → create order with card payment source
  3. POST /v2/checkout/orders/{id}/capture → attempt capture
  4. Parse response → CHARGED / LIVE_VBV / DEAD / ERROR

Amount: $0.10 USD (minimal to avoid fraud triggers, refundable)
"""
import asyncio
import logging
import random

import aiohttp

import config
from gateways.base import GatewayResult, CCStatus
from core.parser import CardData

logger = logging.getLogger("CC-Checker.PayPal")

TIMEOUT = aiohttp.ClientTimeout(total=30)

SANDBOX_BASE = "https://api-m.sandbox.paypal.com"
LIVE_BASE    = "https://api-m.paypal.com"

# Realistic small amounts to avoid fraud
AMOUNTS = ["0.10", "0.50", "1.00", "0.25", "0.75"]

FAKE_ADDRESSES = [
    {"line1": "123 Main St",    "city": "New York",   "state": "NY", "postal": "10001", "country": "US"},
    {"line1": "456 Oak Ave",    "city": "Los Angeles", "state": "CA", "postal": "90001", "country": "US"},
    {"line1": "789 Pine Blvd",  "city": "Chicago",    "state": "IL", "postal": "60601", "country": "US"},
    {"line1": "321 Elm Street", "city": "Houston",    "state": "TX", "postal": "77001", "country": "US"},
    {"line1": "654 Maple Dr",   "city": "Phoenix",    "state": "AZ", "postal": "85001", "country": "US"},
]

FAKE_NAMES = [
    ("John", "Smith"), ("Michael", "Johnson"), ("David", "Williams"),
    ("James", "Brown"), ("Robert", "Jones"),   ("William", "Garcia"),
    ("Richard", "Davis"), ("Thomas", "Miller"),
]


def _get_base_url() -> str:
    mode = getattr(config, "PAYPAL_MODE", "live").lower()
    return SANDBOX_BASE if mode == "sandbox" else LIVE_BASE


async def _get_access_token(session: aiohttp.ClientSession, base: str) -> str | None:
    """Step 1: OAuth2 client credentials → access token."""
    client_id     = getattr(config, "PAYPAL_CLIENT_ID", "")
    client_secret = getattr(config, "PAYPAL_CLIENT_SECRET", "")

    if not client_id or not client_secret:
        return None

    try:
        async with session.post(
            f"{base}/v1/oauth2/token",
            auth=aiohttp.BasicAuth(client_id, client_secret),
            data={"grant_type": "client_credentials"},
            headers={"Accept": "application/json", "Accept-Language": "en_US"},
        ) as r:
            if r.status != 200:
                logger.warning(f"PayPal token failed: {r.status}")
                return None
            data = await r.json()
            return data.get("access_token")
    except Exception as e:
        logger.debug(f"PayPal token error: {e}")
        return None


async def _create_order(
    session: aiohttp.ClientSession,
    base: str,
    token: str,
    card: CardData,
) -> tuple[str | None, str | None]:
    """
    Step 2 + 3: Create order with card source and capture in one flow.
    Returns (status, raw_message)
    """
    exp_year  = card.year if len(card.year) == 4 else f"20{card.year}"
    exp_month = card.month.zfill(2)
    amount    = random.choice(AMOUNTS)
    addr      = random.choice(FAKE_ADDRESSES)
    fn, ln    = random.choice(FAKE_NAMES)

    headers = {
        "Authorization":                  f"Bearer {token}",
        "Content-Type":                   "application/json",
        "PayPal-Request-Id":              f"B3-{card.number[-4:]}-{random.randint(10000,99999)}",
        "Prefer":                         "return=representation",
        "PayPal-Partner-Attribution-Id":  "PayPalCheckout_EC",
    }

    body = {
        "intent": "CAPTURE",
        "payment_source": {
            "card": {
                "number":         card.number,
                "expiry":         f"{exp_year}-{exp_month}",
                "security_code":  card.cvv,
                "name":           f"{fn} {ln}",
                "billing_address": {
                    "address_line_1": addr["line1"],
                    "admin_area_2":   addr["city"],
                    "admin_area_1":   addr["state"],
                    "postal_code":    addr["postal"],
                    "country_code":   addr["country"],
                },
                "attributes": {
                    "verification": {
                        "method": "SCA_WHEN_REQUIRED"
                    }
                },
            }
        },
        "purchase_units": [
            {
                "amount": {
                    "currency_code": "USD",
                    "value":         amount,
                },
                "description": "Purchase",
            }
        ],
    }

    try:
        # Create order
        async with session.post(
            f"{base}/v2/checkout/orders",
            headers=headers,
            json=body,
        ) as r:
            data = await r.json(content_type=None)
            status_code = r.status

        logger.debug(f"PayPal order response: {status_code} → {data.get('status', '?')}")

        order_id     = data.get("id")
        order_status = data.get("status", "").upper()

        # ── Parse Create Response ─────────────────────────────────────────────
        if status_code == 201 and order_status == "COMPLETED":
            # Directly completed (non-3DS card)
            return "CHARGED", f"Captured ${amount} USD"

        if order_status == "PAYER_ACTION_REQUIRED":
            # 3DS required
            return "LIVE_VBV", "3DS/OTP required (card is live)"

        if order_status == "CREATED" and order_id:
            # Need to capture separately
            cap_result, cap_msg = await _capture_order(session, base, token, order_id, headers)
            return cap_result, cap_msg

        # ── Error parsing ─────────────────────────────────────────────────────
        return _parse_error(data, status_code)

    except Exception as e:
        logger.debug(f"PayPal order error: {e}")
        return "ERROR", str(e)[:80]


async def _capture_order(
    session: aiohttp.ClientSession,
    base: str,
    token: str,
    order_id: str,
    headers: dict,
) -> tuple[str, str]:
    """Attempt to capture a CREATED order."""
    try:
        async with session.post(
            f"{base}/v2/checkout/orders/{order_id}/capture",
            headers=headers,
            json={},
        ) as r:
            data = await r.json(content_type=None)

        cap_status = data.get("status", "").upper()

        if cap_status == "COMPLETED":
            unit = data.get("purchase_units", [{}])[0]
            amt  = unit.get("payments", {}).get("captures", [{}])[0].get("amount", {}).get("value", "?")
            return "CHARGED", f"Captured ${amt} USD"

        if cap_status == "PAYER_ACTION_REQUIRED":
            return "LIVE_VBV", "3DS required (card is live)"

        return _parse_error(data, r.status)

    except Exception as e:
        return "ERROR", str(e)[:80]


def _parse_error(data: dict, status_code: int) -> tuple[str, str]:
    """Parse PayPal error response into CCStatus."""
    # Check details array first
    details = data.get("details", [])
    if details:
        issue    = details[0].get("issue", "")
        desc     = details[0].get("description", "")
        issue_up = issue.upper()

        # 3DS required
        if "3D_SECURE" in issue_up or "AUTHENTICATION" in issue_up:
            return "LIVE_VBV", f"3DS required | {desc[:60]}"

        # Insufficient funds — LIVE!
        if "INSUFFICIENT_FUNDS" in issue_up:
            return "INSUFFICIENT", f"Insufficient funds — card is LIVE | {desc[:50]}"

        # Card is live but declined for policy reason
        if any(x in issue_up for x in ["CARD_EXPIRED", "EXPIRED"]):
            return "DEAD", f"Expired | {desc[:60]}"

        if any(x in issue_up for x in ["CVV", "SECURITY_CODE"]):
            return "CHARGED", f"CVV mismatch — card LIVE | {desc[:50]}"

        if any(x in issue_up for x in ["AVS", "BILLING_ADDRESS"]):
            return "CHARGED", f"AVS mismatch — card LIVE | {desc[:50]}"

        # Instrument declined = dead
        if any(x in issue_up for x in [
            "INSTRUMENT_DECLINED", "TRANSACTION_REFUSED",
            "DO_NOT_HONOR", "CARD_CLOSED", "RESTRICTED_CARD",
        ]):
            return "DEAD", f"Declined | {desc[:60]}"

        if "INVALID_ACCOUNT" in issue_up or "INVALID_CARD" in issue_up:
            return "DEAD", f"Invalid card | {desc[:60]}"

        # Unknown issue with description
        return "DEAD", f"{issue} | {desc[:60]}"

    # Check top-level message
    name = data.get("name", "")
    msg  = data.get("message", "")

    if name == "UNPROCESSABLE_ENTITY":
        return "DEAD", f"Declined | {msg[:80]}"

    if name == "UNAUTHORIZED":
        return "ERROR", "PayPal API credentials invalid"

    if status_code == 422:
        return "DEAD", f"Declined | {msg[:80]}"

    return "ERROR", f"HTTP {status_code} | {name} | {msg[:60]}"


async def check_paypal_gate(card: CardData) -> GatewayResult:
    """
    Main PayPal card checker.
    Creates a real order with direct card payment source.
    Returns CHARGED / LIVE_VBV / DEAD / ERROR.
    """
    client_id     = getattr(config, "PAYPAL_CLIENT_ID", "")
    client_secret = getattr(config, "PAYPAL_CLIENT_SECRET", "")

    if not client_id or client_id in ("your_client_id", ""):
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="PayPal",
            message="PayPal not configured. Add PAYPAL_CLIENT_ID + PAYPAL_CLIENT_SECRET to .env",
            raw_code="not_configured",
        )

    base = _get_base_url()

    connector = aiohttp.TCPConnector(ssl=False, limit=5)
    try:
        async with aiohttp.ClientSession(
            timeout=TIMEOUT, connector=connector
        ) as session:

            # Step 1: Get access token
            access_token = await _get_access_token(session, base)
            if not access_token:
                return GatewayResult(
                    status=CCStatus.ERROR,
                    gateway="PayPal",
                    message="Failed to get PayPal access token — check Client ID/Secret",
                    raw_code="token_failed",
                )

            # Step 2+3: Create + capture order
            status_str, raw_msg = await _create_order(session, base, access_token, card)

    except asyncio.TimeoutError:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="PayPal",
            message="Request timed out",
            raw_code="timeout",
        )
    except Exception as e:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="PayPal",
            message=f"{type(e).__name__}: {e}",
            raw_code="exception",
        )
    finally:
        await connector.close()

    # Map string → CCStatus
    status_map = {
        "CHARGED":      CCStatus.CHARGED,
        "LIVE_VBV":     CCStatus.LIVE_VBV,
        "INSUFFICIENT": CCStatus.INSUFFICIENT,
        "DEAD":         CCStatus.DEAD,
        "ERROR":        CCStatus.ERROR,
    }
    status = status_map.get(status_str, CCStatus.ERROR)

    return GatewayResult(
        status=status,
        gateway="PayPal",
        message=raw_msg,
        raw_code=status_str,
        is_vbv=status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS),
        is_non_vbv=status == CCStatus.CHARGED,
    )
