import sys, asyncio, os
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

import database.db as db

async def main():
    await db.init_db()
    try:
        # Fetch Shopify active gates
        row_shopify = await db._db.fetchone("SELECT COUNT(*) FROM shopify_gates WHERE is_active=1")
        shopify_cnt = row_shopify[0] if row_shopify else 0
            
        # Fetch Scraped gates
        row_scraped = await db._db.fetchone("SELECT COUNT(*) FROM scraped_gates WHERE is_active=1")
        scraped_cnt = row_scraped[0] if row_scraped else 0
            
        # Fetch WooCommerce Braintree gates
        row_wcbt = await db._db.fetchone("SELECT COUNT(*) FROM wc_bt_gates WHERE is_active=1")
        wcbt_cnt = row_wcbt[0] if row_wcbt else 0
            
        print(f"Shopify Gates: {shopify_cnt}")
        print(f"Scraped Stripe Gates: {scraped_cnt}")
        print(f"WooCommerce Braintree Gates: {wcbt_cnt}")
        print("Total Gates in Database:", shopify_cnt + scraped_cnt + wcbt_cnt)
    except Exception as e:
        print("Error:", e)

asyncio.run(main())
