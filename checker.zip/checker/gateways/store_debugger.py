"""
gateways/store_debugger.py — Store Auto-Debug & Health Check System

When a Shopify store consistently fails (5+ errors), this module automatically:
1. Validates the store is actually reachable
2. Checks if the product is still in stock (and finds a new one if not)
3. Verifies the payment_method_id is still valid
4. Returns a DebugResult with updated store details if anything changed
5. Sends ONE batched summary to owner (no spam — waits 60s, collects all, sends once)
"""
import asyncio
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("StoreDebugger")

# How many consecutive failures before auto-debug triggers
AUTO_DEBUG_THRESHOLD = 5

# Don't re-debug a store more than once every 10 minutes
_debug_cooldown: dict[str, float] = {}      # base_url → last debug time
_DEBUG_COOLDOWN_SECS = 600                   # 10 minutes

# Track whether a debug is already in-flight for a store (avoid duplicate parallel runs)
_debug_in_progress: set[str] = set()

# ── Batched summary system ─────────────────────────────────────────────────────
# Instead of spamming owner with per-store alerts, we collect results for 60s
# and send ONE combined message with all findings.
_pending_results:   list["DebugResult"] = []
_batch_task:        Optional[asyncio.Task]  = None
_BATCH_WAIT_SECS    = 60          # collect for 60s before sending

# Telegram client reference (set by register_debug_notifier)
_tg_client = None
_tg_owner_ids: list[int] = []


def register_debug_notifier(client, owner_ids: list[int]):
    """Called once at bot startup to register the Telegram client for alerts."""
    global _tg_client, _tg_owner_ids
    _tg_client = client
    _tg_owner_ids = owner_ids


@dataclass
class DebugResult:
    """Result of an auto-debug run on a store."""
    store_url:          str
    reachable:          bool = False
    product_ok:         bool = False
    payment_ok:         bool = False
    # Changes detected during debug (None = no change)
    new_variant_id:     Optional[int]   = None
    new_price:          Optional[str]   = None
    new_payment_id:     Optional[str]   = None
    new_product_title:  Optional[str]   = None
    # Error info if debug failed
    error_msg:          str             = ""
    # Overall: did the store pass the debug?
    passed:             bool            = False
    # Is the store permanently broken (should be removed)?
    should_remove:      bool            = False
    # Reason for removal
    remove_reason:      str             = ""
    # DB was updated with new details?
    db_updated:         bool            = False


async def maybe_auto_debug(store: dict, fail_reason: str) -> None:
    """
    Called after a store failure is tracked.
    Checks if auto-debug threshold is reached and triggers debug if needed.
    Non-blocking — fires off as a background task.
    """
    from gateways.shopify_gate import _store_fail_counts
    url = store.get("base_url", "")
    fail_count = _store_fail_counts.get(url, 0)

    if fail_count < AUTO_DEBUG_THRESHOLD:
        return

    now = time.monotonic()
    last_debug = _debug_cooldown.get(url, 0.0)
    if now - last_debug < _DEBUG_COOLDOWN_SECS:
        return  # recently debugged, skip

    if url in _debug_in_progress:
        return  # already running

    logger.info(f"[AutoDebug] {url} triggered after {fail_count} failures ({fail_reason})")
    asyncio.ensure_future(_run_debug_and_notify(store))


async def _run_debug_and_notify(store: dict) -> DebugResult:
    """Run full store debug and notify owner via Telegram."""
    url = store.get("base_url", "")
    _debug_in_progress.add(url)
    _debug_cooldown[url] = time.monotonic()

    try:
        result = await _debug_store(store)
        await _persist_debug_result(store, result)
        await _notify_owner(store, result)
        return result
    except Exception as e:
        logger.error(f"[AutoDebug] Unhandled error for {url}: {e}", exc_info=True)
        result = DebugResult(store_url=url, error_msg=str(e))
        return result
    finally:
        _debug_in_progress.discard(url)


async def _debug_store(store: dict) -> DebugResult:
    """
    Full store debug: reachability + product check + payment method check.
    Returns a DebugResult with findings and any auto-corrections.
    """
    url = store.get("base_url", "")
    result = DebugResult(store_url=url)

    try:
        import aiohttp
        from aiohttp import CookieJar
        from gateways.shopify_gate import BROWSER_HEADERS, TIMEOUT

        jar = CookieJar(unsafe=True)
        conn = aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)

        async with aiohttp.ClientSession(connector=conn, cookie_jar=jar, timeout=TIMEOUT) as session:

            # ── Step 1: Reachability check ────────────────────────────────────
            try:
                async with session.get(url + "/", headers=BROWSER_HEADERS, allow_redirects=True) as r:
                    if r.status in (200, 301, 302, 404):
                        result.reachable = True
                    elif r.status in (503, 529):
                        result.error_msg = f"Store down (HTTP {r.status})"
                        result.should_remove = False   # temporary, don't remove
                        return result
                    else:
                        result.error_msg = f"Unexpected status {r.status}"
                        result.should_remove = r.status == 404  # 404 = store gone
                        if result.should_remove:
                            result.remove_reason = "Store returned 404 — domain likely expired or closed"
                        return result
            except Exception as e:
                result.error_msg = f"Cannot reach store: {str(e)[:80]}"
                result.should_remove = True
                result.remove_reason = f"Unreachable: {str(e)[:60]}"
                return result

            # ── Step 2: Product check ──────────────────────────────────────────
            old_variant_id = store.get("variant_id")
            try:
                # Try adding the current variant to cart
                async with session.post(
                    url + "/cart/add.js",
                    json={"id": old_variant_id, "quantity": 1},
                    headers={**BROWSER_HEADERS, "Content-Type": "application/json",
                             "Accept": "application/json", "Referer": url + "/"},
                ) as r:
                    if r.status == 200:
                        result.product_ok = True
                    elif r.status == 422:
                        # Product out of stock or unavailable — try to find a new product
                        logger.info(f"[AutoDebug] {url} product {old_variant_id} is OOS — searching for new product")
                        new_v = await _find_working_product(session, url)
                        if new_v:
                            result.new_variant_id    = new_v["variant_id"]
                            result.new_price         = new_v["price"]
                            result.new_product_title = new_v["title"]
                            result.product_ok = True
                            logger.info(f"[AutoDebug] {url} found new product: {new_v['title']} (v{new_v['variant_id']} @ ${new_v['price']})")
                        else:
                            result.error_msg = "Product OOS and no alternative found"
                            result.should_remove = True
                            result.remove_reason = "All products appear to be out of stock"
                            return result
                    else:
                        result.error_msg = f"Cart add returned {r.status}"
            except Exception as e:
                result.error_msg = f"Product check error: {str(e)[:60]}"

            # ── Step 3: Checkout + payment_method_id check ─────────────────────
            try:
                from curl_cffi.requests import AsyncSession as CurlAsyncSession
                cookies_dict = {c.key: c.value for c in session.cookie_jar}

                async with CurlAsyncSession(impersonate="chrome131", cookies=cookies_dict, timeout=12) as curl_s:
                    r = await curl_s.get(
                        url + "/checkout",
                        params={"locale": "en"},
                        headers={**BROWSER_HEADERS,
                                 "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
                                 "Referer": url + "/"},
                        allow_redirects=True
                    )
                    checkout_html = r.text

                # Extract payment method ID from checkout page
                pm_match = re.search(
                    r'"paymentMethodIdentifier"\s*:\s*"([a-f0-9]{32,64})"',
                    checkout_html
                )
                if pm_match:
                    found_pm_id = pm_match.group(1)
                    current_pm_id = store.get("payment_method_id", "")
                    if found_pm_id != current_pm_id:
                        logger.info(f"[AutoDebug] {url} payment_method_id changed: {found_pm_id[:16]}...")
                        result.new_payment_id = found_pm_id
                    result.payment_ok = True
                else:
                    # No JS-rendered payment ID — could be a JS-required checkout
                    session_token = re.search(r'"sessionToken"\s*:\s*"([^"]+)"', checkout_html)
                    if session_token:
                        result.payment_ok = True   # checkout page loaded with session token
                    else:
                        result.error_msg = "Checkout requires JavaScript (no session token)"
                        result.should_remove = True
                        result.remove_reason = "Checkout page requires full JS rendering — bot cannot process"

            except Exception as e:
                result.error_msg = f"Checkout check error: {str(e)[:60]}"
                # Not removing for checkout errors — could be transient

    except Exception as e:
        result.error_msg = f"Debug error: {str(e)[:80]}"

    # Final verdict
    result.passed = result.reachable and result.product_ok and not result.should_remove
    return result


async def _find_working_product(session, base_url: str) -> Optional[dict]:
    """
    Search the store's products JSON for an in-stock low-price item.
    Returns dict with variant_id, price, title or None.
    """
    try:
        async with session.get(
            base_url + "/products.json",
            params={"limit": 50, "page": 1},
            headers={"Accept": "application/json", "Referer": base_url + "/"},
        ) as r:
            if r.status != 200:
                return None
            data = await r.json(content_type=None)
            products = data.get("products", [])

        candidates = []
        for product in products:
            for variant in product.get("variants", []):
                if not variant.get("available", True):
                    continue
                price_str = str(variant.get("price", "9999"))
                try:
                    price_f = float(price_str)
                except Exception:
                    continue
                if 0.50 <= price_f <= 5.00:  # ideal: cheap product for checking
                    candidates.append({
                        "variant_id": variant["id"],
                        "price":      f"{price_f:.2f}",
                        "title":      f"{product['title']} - {variant.get('title', '')}".strip(" -"),
                    })

        if candidates:
            # Pick cheapest
            candidates.sort(key=lambda x: float(x["price"]))
            return candidates[0]

        # No cheap product found — try any available product under $20
        for product in products:
            for variant in product.get("variants", []):
                if not variant.get("available", True):
                    continue
                price_str = str(variant.get("price", "9999"))
                try:
                    price_f = float(price_str)
                except Exception:
                    continue
                if price_f <= 20.0:
                    return {
                        "variant_id": variant["id"],
                        "price":      f"{price_f:.2f}",
                        "title":      f"{product['title']} - {variant.get('title', '')}".strip(" -"),
                    }
    except Exception as e:
        logger.debug(f"[AutoDebug] Product search error on {base_url}: {e}")
    return None


async def _persist_debug_result(store: dict, result: DebugResult) -> None:
    """Update database with debug findings."""
    try:
        import database.db as db
        gate_id = store.get("gate_id")

        if result.should_remove:
            # Put on long cooldown instead of permanent disable
            # Sites recover after 6 hours — never permanently removed
            if gate_id:
                try:
                    import time as _t
                    from gateways.shopify_gate import _store_cooldown_until, invalidate_stores_cache
                    base_url = store.get("base_url", "")
                    _store_cooldown_until[base_url] = _t.monotonic() + 21600  # 6-hour cooldown
                    invalidate_stores_cache()
                    logger.info(f"[AutoDebug] Store {base_url} put on 6-hour cooldown (not permanently disabled)")
                except Exception:
                    pass
            return

        if not result.passed:
            return   # Not clearly broken, don't touch DB

        # Store passed debug — update changed details
        updates = []
        params  = []

        if result.new_variant_id:
            updates.append("variant_id=?")
            params.append(result.new_variant_id)
        if result.new_price:
            updates.append("price=?")
            params.append(result.new_price)
        if result.new_product_title:
            updates.append("product_title=?")
            params.append(result.new_product_title)
        if result.new_payment_id:
            # payment_method_id lives inside scan_data JSON
            import json as _json
            row = await db._db.fetchone(
                "SELECT scan_data FROM shopify_gates WHERE base_url=?", (result.store_url,)
            )
            if row:
                try:
                    sd = _json.loads(row[0] or "{}")
                except Exception:
                    sd = {}
                sd["payment_method_id"] = result.new_payment_id
                updates.append("scan_data=?")
                params.append(_json.dumps(sd))

        if updates:
            params.append(result.store_url)
            sql = f"UPDATE shopify_gates SET {', '.join(updates)} WHERE base_url=?"
            await db._db.execute(sql, tuple(params))
            result.db_updated = True
            logger.info(f"[AutoDebug] DB updated for {result.store_url}: {', '.join(updates)}")

            # Force store cache refresh so workers pick up new details
            from gateways.shopify_gate import invalidate_stores_cache
            invalidate_stores_cache()

    except Exception as e:
        logger.error(f"[AutoDebug] DB persist error: {e}", exc_info=True)


async def _notify_owner(store: dict, result: DebugResult) -> None:
    """Queue result into batch — ONE summary will be sent after 60s of inactivity."""
    global _batch_task
    _pending_results.append((store, result))

    # Start/reset the batch timer — sends combined summary after 60s
    if _batch_task and not _batch_task.done():
        _batch_task.cancel()
    _batch_task = asyncio.ensure_future(_send_batched_summary())


async def _send_batched_summary() -> None:
    """Wait 60s for more results, then send ONE consolidated summary to owner."""
    await asyncio.sleep(_BATCH_WAIT_SECS)

    if not _pending_results or not _tg_client or not _tg_owner_ids:
        _pending_results.clear()
        return

    try:
        from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
        from pyrogram import enums as _enums

        batch = list(_pending_results)
        _pending_results.clear()

        # Categorise results
        broken   = [(s, r) for s, r in batch if r.should_remove]
        fixed    = [(s, r) for s, r in batch if r.passed and r.db_updated]
        healthy  = [(s, r) for s, r in batch if r.passed and not r.db_updated]
        failed   = [(s, r) for s, r in batch if not r.passed and not r.should_remove]

        lines = [f"<b>🔍 Store Health Report — {len(batch)} stores debugged</b>\n"]

        # ── Broken stores ──────────────────────────────────────────────────────
        if broken:
            lines.append(f"🔴 <b>Broken / Disabled ({len(broken)})</b>")
            for store, r in broken:
                url = r.store_url.replace("https://www.", "").replace("https://", "")[:40]
                reason = (r.remove_reason or r.error_msg or "Unknown")[:60]
                lines.append(f"  • <code>{url}</code> — {reason}")
            lines.append("")

        # ── Auto-fixed stores ──────────────────────────────────────────────────
        if fixed:
            lines.append(f"✅ <b>Auto-Fixed ({len(fixed)})</b>")
            for store, r in fixed:
                url = r.store_url.replace("https://www.", "").replace("https://", "")[:40]
                changes = []
                if r.new_variant_id:
                    changes.append(f"product→{r.new_product_title or r.new_variant_id}")
                if r.new_payment_id:
                    changes.append("paymethod updated")
                if r.new_price:
                    changes.append(f"price→${r.new_price}")
                lines.append(f"  • <code>{url}</code> — {', '.join(changes) or 'OK'}")
            lines.append("")

        # ── Debug failed (transient) ───────────────────────────────────────────
        if failed:
            lines.append(f"⚠️ <b>Debug Failed / Unclear ({len(failed)})</b>")
            for store, r in failed:
                url = r.store_url.replace("https://www.", "").replace("https://", "")[:40]
                err = (r.error_msg or "Unknown")[:55]
                lines.append(f"  • <code>{url}</code> — {err}")
            lines.append("")

        # ── Healthy (no issues) ────────────────────────────────────────────────
        if healthy:
            lines.append(f"🟢 <b>Healthy / Transient Fail ({len(healthy)})</b>")
            for store, r in healthy:
                url = r.store_url.replace("https://www.", "").replace("https://", "")[:40]
                lines.append(f"  • <code>{url}</code>")

        text = "\n".join(lines)

        # Build buttons only for broken stores (max 5 rows to avoid Telegram limits)
        buttons = []
        for store, r in broken[:5]:
            gid = store.get("gate_id", "?")
            short = r.store_url.replace("https://www.", "").replace("https://", "")[:20]
            buttons.append([
                InlineKeyboardButton(f"🗑 {short}", callback_data=f"store_remove_{gid}"),
                InlineKeyboardButton("♻️ Keep",    callback_data=f"store_reenable_{gid}"),
            ])
        markup = InlineKeyboardMarkup(buttons) if buttons else None

        for owner_id in _tg_owner_ids:
            try:
                await _tg_client.send_message(
                    chat_id=owner_id,
                    text=text,
                    parse_mode=_enums.ParseMode.HTML,
                    reply_markup=markup,
                )
            except Exception as e:
                logger.error(f"[AutoDebug] Failed to notify owner {owner_id}: {e}")

    except Exception as e:
        logger.error(f"[AutoDebug] Batch notify error: {e}", exc_info=True)

