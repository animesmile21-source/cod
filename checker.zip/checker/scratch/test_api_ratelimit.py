"""
Test rate limit of randomuser API:
- Send requests rapidly and see when it fails
- Check response headers for rate limit info
- Check if there's a daily/total limit
"""
import asyncio
import aiohttp
import time
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

API_URL = "https://key-blossom-hub.lovable.app/api/v1/randomuser"
API_KEY = "ah_0a48a21f33ca413ab06e077e21e56cf5"

async def test_rate_limit():
    total_users = 0
    total_requests = 0
    errors = 0
    
    print("=" * 60)
    print("API RATE LIMIT TEST")
    print("=" * 60)
    
    async with aiohttp.ClientSession() as s:
        
        # Test 1: Check headers on first request
        print("\n[1] Checking response headers...")
        async with s.get(API_URL, params={"results": "1", "api_key": API_KEY}, ssl=False) as r:
            print(f"    Status: {r.status}")
            print(f"    Headers:")
            for k, v in r.headers.items():
                if any(x in k.lower() for x in ["rate", "limit", "remain", "quota", "retry", "x-", "ratelimit"]):
                    print(f"      {k}: {v}")
            data = await r.json(content_type=None)
            info = data.get("info", {})
            print(f"    Info: {info}")
        
        # Test 2: Rapid burst - 50 requests as fast as possible
        print("\n[2] Rapid burst test (50 requests, results=100 each)...")
        start = time.monotonic()
        
        tasks = []
        results_per_req = []
        
        async def single_req(n):
            nonlocal total_users, total_requests, errors
            try:
                async with s.get(API_URL, params={"results": "100", "nat": "US", "api_key": API_KEY}, 
                                 ssl=False, timeout=aiohttp.ClientTimeout(total=15)) as r:
                    total_requests += 1
                    if r.status == 200:
                        data = await r.json(content_type=None)
                        us_count = sum(1 for u in data.get("results", []) if u.get("nat") == "US")
                        total_users += us_count
                        results_per_req.append((r.status, us_count, dict(r.headers)))
                        if n % 10 == 0:
                            print(f"    Req #{n}: OK | US users in batch: {us_count} | Total so far: {total_users}")
                    elif r.status == 429:
                        errors += 1
                        body = await r.text()
                        results_per_req.append((r.status, 0, dict(r.headers)))
                        print(f"    Req #{n}: RATE LIMITED (429) | {body[:100]}")
                    else:
                        errors += 1
                        body = await r.text()
                        results_per_req.append((r.status, 0, {}))
                        print(f"    Req #{n}: ERROR {r.status} | {body[:100]}")
            except Exception as e:
                errors += 1
                print(f"    Req #{n}: EXCEPTION | {e}")
        
        # Send 50 concurrent requests
        await asyncio.gather(*[single_req(i) for i in range(1, 51)])
        
        elapsed = time.monotonic() - start
        
        print(f"\n[3] Results:")
        print(f"    Total requests sent: {total_requests}")
        print(f"    Successful: {total_requests - errors}")
        print(f"    Errors/Rate limited: {errors}")
        print(f"    Total US users fetched: {total_users}")
        print(f"    Time: {elapsed:.1f}s")
        
        # Check rate limit headers from last successful response
        for status, count, headers in results_per_req:
            rl_headers = {k: v for k, v in headers.items() 
                         if any(x in k.lower() for x in ["rate", "limit", "remain", "quota", "x-ratelimit"])}
            if rl_headers:
                print(f"\n    Rate-limit headers found:")
                for k, v in rl_headers.items():
                    print(f"      {k}: {v}")
                break
        
        # Test 3: Try results=1000 (max per request)
        print("\n[4] Testing max results per request...")
        for n in [100, 500, 1000, 5000]:
            try:
                async with s.get(API_URL, params={"results": str(n), "nat": "US", "api_key": API_KEY},
                                ssl=False, timeout=aiohttp.ClientTimeout(total=20)) as r:
                    if r.status == 200:
                        data = await r.json(content_type=None)
                        got = len(data.get("results", []))
                        us = sum(1 for u in data.get("results", []) if u.get("nat") == "US")
                        print(f"    results={n}: Got {got} total, {us} US | Status: {r.status}")
                    else:
                        body = await r.text()
                        print(f"    results={n}: FAILED {r.status} | {body[:80]}")
            except Exception as e:
                print(f"    results={n}: ERROR | {e}")
    
    print("\n" + "=" * 60)
    print("SUMMARY:")
    print(f"  Max US users per batch (results=100): ~{total_users // max(total_requests-errors, 1)} avg")
    print(f"  Rate limit hit: {'YES' if errors > 0 else 'NO - API seems unlimited or high limit'}")
    print(f"  Total users generated in test: {total_users}")
    print("=" * 60)

asyncio.run(test_rate_limit())
