import sys, asyncio
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import database.db as db

async def check():
    await db.init_db()
    gates = await db.get_active_stripe_wc_gates()
    print(f'Total stripe_wc_gates: {len(gates)}')
    for g in gates[:15]:
        status = g.get('status', 'active')
        added  = str(g.get('added_at', ''))[:10]
        url    = g.get('base_url', '?')
        print(f'  [{status:6}] {url}  ({added})')
    if len(gates) > 15:
        print(f'  ...and {len(gates)-15} more')

asyncio.run(check())
