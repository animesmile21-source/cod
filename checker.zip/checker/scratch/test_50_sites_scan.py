"""
Comprehensive 50-site discovery and verification test script.
Discovers WooCommerce sites using dorks/seeds and verifies them with the new multi-gateway logic.
"""
import asyncio, sys, logging
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from core.auto_discover import discover_stripe_sites
from database.db import get_working_proxies, init_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

async def test_full_flow():
    await init_db()
    print("=" * 70)
    print("🚀 Running 50-Site WooCommerce Multi-Gateway Discovery & Verification Test")
    print("=" * 70)

    # Fetch proxy from DB
    proxies = await get_working_proxies()
    proxy = None
    if proxies:
        p = proxies[0]
        proxy = {
            "host": p["host"],
            "port": p["port"],
            "username": p.get("username", ""),
            "password": p.get("password", ""),
            "protocol": p.get("protocol", "http")
        }
        print(f"📡 Using Proxy: {p['host']}:{p['port']}")
    else:
        print("⚠️ No proxies in DB, using direct connection for seeds...")

    async def progress_cb(found, target):
        print(f"  [Discovery Progress] Found {found}/{target} candidate domains...")

    # Step 1: Discover
    print("\n🔍 Step 1: Harvesting 50 candidate WooCommerce sites...")
    domains = await discover_stripe_sites(count=50, proxy=proxy, progress_cb=progress_cb)
    print(f"✅ Total Discovered: {len(domains)} domains\n")

    if not domains:
        print("❌ No domains discovered.")
        return

    # Step 2: Verify each site using the new smart multi-gateway logic
    print("🔬 Step 2: Verifying candidates (WooCommerce + Gateway presence)...")
    verified = []
    
    # Mock message context
    class MockMsg:
        class User:
            id = 12345
        from_user = User()
        
    msg = MockMsg()

    import aiohttp
    from aiohttp import ClientTimeout as _CT, CookieJar as _CJ

    _WC_INDICATORS = [
        "woocommerce", "wc-ajax", "WooCommerce", "wc_cart_hash",
        "woocommerce-checkout", "wc_checkout_params",
    ]
    _GATEWAY_INDICATORS = [
        "pk_live_", "stripe.js", "Stripe(", "woocommerce-gateway-stripe",
        "braintree", "Braintree", "braintree-dropin", "braintree_checkout",
        "adyen", "Adyen", "adyen-component", "adyen_checkout",
        "square", "Square", "sq-card", "square-credit-card",
        "paypal", "PayPal", "paypal-button", "wc-paypal-payments",
        "authorizenet", "authnet", "Accept.js",
        "cybersource", "nmi", "moneris"
    ]
    _HDR = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
        "Accept-Language": "en-US,en;q=0.9",
    }
    _PATHS_TO_CHECK = [
        "/my-account/add-payment-method/",
        "/my-account/",
        "/shop/",
        "/",
    ]

    async def verify_site(site_url):
        if not site_url.startswith("http"):
            site_url = "https://" + site_url
        site_url = site_url.rstrip("/")

        wc_ok = False
        gate_ok = False
        detected_gateways = []

        jar = _CJ(unsafe=True)
        try:
            async with aiohttp.ClientSession(
                cookie_jar=jar,
                connector=aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)
            ) as sess:
                for path in _PATHS_TO_CHECK:
                    url = site_url + path
                    try:
                        async with sess.get(url, headers=_HDR, ssl=False, timeout=_CT(total=8), allow_redirects=True) as r:
                            if r.status != 200:
                                continue
                            txt = await r.text(errors="ignore")

                            if not wc_ok and any(ind in txt for ind in _WC_INDICATORS):
                                wc_ok = True

                            for ind in _GATEWAY_INDICATORS:
                                if ind in txt and ind not in detected_gateways:
                                    detected_gateways.append(ind)
                                    gate_ok = True

                    except Exception:
                        pass

                    if wc_ok and gate_ok:
                        break
        except Exception:
            pass

        return {
            "url": site_url,
            "wc_ok": wc_ok,
            "gate_ok": gate_ok,
            "gateways": detected_gateways
        }

    tasks = [verify_site(d) for d in domains[:50]]
    results = await asyncio.gather(*tasks)

    print("\n" + "=" * 70)
    print("📊 VERIFICATION RESULTS PREVIEW")
    print("=" * 70)

    wc_count = 0
    gate_count = 0

    for res in results:
        status_icon = "✅ VERIFIED" if (res["wc_ok"] and res["gate_ok"]) else "❌ FAILED"
        if res["wc_ok"]: wc_count += 1
        if res["gate_ok"]: gate_count += 1

        wc_str = "WC✓" if res["wc_ok"] else "WC✗"
        gate_str = f"Gateways: {', '.join(res['gateways'][:3])}" if res["gate_ok"] else "No Gateway"

        print(f"{status_icon} | {res['url'][:40]:40s} | {wc_str} | {gate_str}")

    print("\n" + "=" * 70)
    print(f"🎯 SUMMARY: {len(domains)} Candidates Discovered")
    print(f"🛒 WooCommerce Detected: {wc_count}/{len(domains)}")
    print(f"💳 Payment Gateway Detected: {gate_count}/{len(domains)}")
    print(f"⭐ Fully Verified Gates Ready for DB: {sum(1 for r in results if r['wc_ok'] and r['gate_ok'])}/{len(domains)}")
    print("=" * 70)

if __name__ == "__main__":
    asyncio.run(test_full_flow())
