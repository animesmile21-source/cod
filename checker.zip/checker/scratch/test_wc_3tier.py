"""
Test the new 3-tier WC+Stripe site verification logic.
Tests both previously working sites and new candidate sites.
"""
import asyncio, sys
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import aiohttp
from aiohttp import ClientTimeout as _CT, CookieJar as _CJ

_WC_INDICATORS = [
    "woocommerce", "wc-ajax", "WooCommerce", "wc_cart_hash",
    "woocommerce-checkout", "wc_checkout_params",
]
_STRIPE_INDICATORS = ["pk_live_", "stripe.js", "Stripe(", "woocommerce-gateway-stripe"]
_HDR = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
}
_PATHS = [
    "/my-account/add-payment-method/",
    "/my-account/",
    "/shop/",
    "/",
]

TEST_SITES = [
    # Already known working
    "https://ea-courses.com",
    "https://dilaboards.com",
    # Common dork results (charity/nonprofit)
    "https://worldrelief.org",
    "https://compassion.com",
    "https://feedmyflock.co",
    # WordPress.org WC stores
    "https://yoast.com",
    "https://seedprod.com",
    "https://woocommerce.com",
    # Generic WC stores from seeds
    "https://onlinelabels.com",
    "https://themeforest.net",
]

async def verify(site_url: str) -> dict:
    if not site_url.startswith("http"):
        site_url = "https://" + site_url
    site_url = site_url.rstrip("/")
    
    wc_ok = stripe_ok = reg_open = False
    pages_checked = 0

    jar = _CJ(unsafe=True)
    try:
        async with aiohttp.ClientSession(
            cookie_jar=jar,
            connector=aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)
        ) as sess:
            for path in _PATHS:
                url = site_url + path
                try:
                    async with sess.get(url, headers=_HDR, ssl=False, timeout=_CT(total=8), allow_redirects=True) as r:
                        if r.status != 200:
                            continue
                        txt = await r.text(errors="ignore")
                        pages_checked += 1

                        if not wc_ok and any(i in txt for i in _WC_INDICATORS):
                            wc_ok = True
                        if not stripe_ok and any(i in txt for i in _STRIPE_INDICATORS):
                            stripe_ok = True
                        if not reg_open and ('woocommerce-register-nonce' in txt or 'action="register"' in txt):
                            reg_open = True
                except Exception:
                    pass
                if wc_ok and stripe_ok and reg_open:
                    break
    except Exception:
        pass

    qualifies = wc_ok and stripe_ok and reg_open
    return {
        "url": site_url,
        "qualifies": qualifies,
        "wc": wc_ok, "stripe": stripe_ok, "reg": reg_open,
        "pages": pages_checked,
    }

async def main():
    print("=" * 65)
    print("  3-Tier WC+Stripe Verification Test")
    print("  WC✓ + Stripe✓ + Registration Open✓ = GATE QUALIFIED")
    print("=" * 65)
    
    results = await asyncio.gather(*[verify(s) for s in TEST_SITES])
    
    passed = []
    for r in results:
        icon = "✓ PASS" if r["qualifies"] else "✗ FAIL"
        wc  = "WC✓" if r["wc"]     else "WC✗"
        st  = "St✓" if r["stripe"] else "St✗"
        rg  = "Rg✓" if r["reg"]    else "Rg✗"
        print(f"  {icon} | {wc} {st} {rg} | {r['url']}")
        if r["qualifies"]:
            passed.append(r["url"])
    
    print(f"\n  {'=' * 62}")
    print(f"  Qualified gates: {len(passed)}/{len(TEST_SITES)}")
    for u in passed:
        print(f"    → {u}")

asyncio.run(main())
