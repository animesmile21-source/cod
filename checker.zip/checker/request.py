#add to cart request

import requests

cookies = {
    'localization': 'US',
    'cart_currency': 'USD',
    '_shopify_y': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '_shopify_s': '34c04ebc-916c-411b-81ed-a96eb4254660',
    '_gcl_au': '1.1.977159562.1783047675',
    '__thoughtmetric_uid': '9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d',
    'shopify_client_id': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '__kla_id': 'eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==',
    '_ga': 'GA1.1.1085245625.1783047676',
    '_clck': 'i29uxr%5E2%5Eg7f%5E0%5E2375',
    '_rsession': '1c1bdadc8fb138dd',
    '_ruid': 'eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D',
    '_fbp': 'fb.1.1783047675744.654578204850518711',
    '_scid': 'xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H',
    '_omappvp': 'vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1',
    '_shopify_analytics': ':AZ8l7F8VAAEAAhhxN3TZgY9elPeLodkoQORKmHHn9Nlbzj2gmfe9vXDzanThvxdiTBKoVJJSaH1mN-g6aCiiPnOebvH8pkYlqH4WoMcbffuih0sDvhVoajCmvYFPGEOsH5Bntq6GKXsuGw:',
    '_shopify_marketing': ':AZ8l7F8VAAEAt8y-xedx9dno-SCXO44RdLHAYtBkl5StyBW65n5HKAVVzVUv5ytgLM_xReh4KPrkWVL_8OB7k-qVFoIjVnZ6kzlebvZP061XvSzOs7rpGeBLhhgep2Jzig:',
    'cart': 'hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092',
    '_scsrid_r': '',
    '_scid_r': '34yEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYjNnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbo',
    '_scida': 'Jecy_1f-AsKtpCDBaSBEe0H9_naJGMY-',
    '_ga_LYEFQV8SJD': 'GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0',
    '_ga_CBJJ1LQ15S': 'GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0',
    '_clsk': '1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect',
    '_omappvs': '1783047681588',
    '_shopify_essential': ':AZ8l7F6aAAEAMSFSeBi90OtzR2eI_OGFyw4rzWIRqc9-9XzYvheZbOYZLxe0a_deZ67jPSwFMvPys8Mp5-MIQBWYn5n0MhL_pD0SpMm9Bscn4mt2UQiS14DMKUkxmC_EOao6u6ZG13vBdvLLyVUiBXqPAC9yecJa-mQRZNCXvatw7FwbKDX9_Ifa8dphATDEiD97qjyD4BSaZB7F2X3UjtSYvxxvZRmbGxEDV2iLnCqWT0D8elIJsSkNYLyNgT29pg1OebRvukfhxO5EIJhBfKkeUKW_5Ec3y7rtrIcYbx6pes3VXt7-DM9JaohKs-2LohDP2I7sXyq1vnx3UCeF_7fOBEvi_Ve0ifLDFZB7h3P8YR_HNnAbqZdftLwfXMNjI_ElU5bq2Y9LaEW9SwNcoFENhkzE293yC4mv2tcaKSs2K-jaiSvvvZljEg-IDw9fQ16RT5FL_eUePbftF2YfvaqeCqMP-L7k0uxfX8M5uhDuZJOMwybpnL5cGUXqjOJxe8HRksgh44Ztclht0QNzLNVdUsBn3qDqQRJBEJqVmuNXcot8OOcuJJ-3xZO8AjQ3UA9U3Wzv2nraturd8dwfZXDIC30veLAgfgMxib0JmjRZ7rBCPkmIiRKoHxUBD69hFn1svUWh20b04BAp:',
}

headers = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://www.brio4life.com',
    'priority': 'u=1, i',
    'referer': 'https://www.brio4life.com/products/raze-shaver',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
    # 'cookie': 'localization=US; cart_currency=USD; _shopify_y=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; _shopify_s=34c04ebc-916c-411b-81ed-a96eb4254660; _gcl_au=1.1.977159562.1783047675; __thoughtmetric_uid=9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d; shopify_client_id=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; __kla_id=eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==; _ga=GA1.1.1085245625.1783047676; _clck=i29uxr%5E2%5Eg7f%5E0%5E2375; _rsession=1c1bdadc8fb138dd; _ruid=eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D; _fbp=fb.1.1783047675744.654578204850518711; _scid=xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H; _omappvp=vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1; _shopify_analytics=:AZ8l7F8VAAEAAhhxN3TZgY9elPeLodkoQORKmHHn9Nlbzj2gmfe9vXDzanThvxdiTBKoVJJSaH1mN-g6aCiiPnOebvH8pkYlqH4WoMcbffuih0sDvhVoajCmvYFPGEOsH5Bntq6GKXsuGw:; _shopify_marketing=:AZ8l7F8VAAEAt8y-xedx9dno-SCXO44RdLHAYtBkl5StyBW65n5HKAVVzVUv5ytgLM_xReh4KPrkWVL_8OB7k-qVFoIjVnZ6kzlebvZP061XvSzOs7rpGeBLhhgep2Jzig:; cart=hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092; _scsrid_r=; _scid_r=34yEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYjNnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbo; _scida=Jecy_1f-AsKtpCDBaSBEe0H9_naJGMY-; _ga_LYEFQV8SJD=GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0; _ga_CBJJ1LQ15S=GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0; _clsk=1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect; _omappvs=1783047681588; _shopify_essential=:AZ8l7F6aAAEAMSFSeBi90OtzR2eI_OGFyw4rzWIRqc9-9XzYvheZbOYZLxe0a_deZ67jPSwFMvPys8Mp5-MIQBWYn5n0MhL_pD0SpMm9Bscn4mt2UQiS14DMKUkxmC_EOao6u6ZG13vBdvLLyVUiBXqPAC9yecJa-mQRZNCXvatw7FwbKDX9_Ifa8dphATDEiD97qjyD4BSaZB7F2X3UjtSYvxxvZRmbGxEDV2iLnCqWT0D8elIJsSkNYLyNgT29pg1OebRvukfhxO5EIJhBfKkeUKW_5Ec3y7rtrIcYbx6pes3VXt7-DM9JaohKs-2LohDP2I7sXyq1vnx3UCeF_7fOBEvi_Ve0ifLDFZB7h3P8YR_HNnAbqZdftLwfXMNjI_ElU5bq2Y9LaEW9SwNcoFENhkzE293yC4mv2tcaKSs2K-jaiSvvvZljEg-IDw9fQ16RT5FL_eUePbftF2YfvaqeCqMP-L7k0uxfX8M5uhDuZJOMwybpnL5cGUXqjOJxe8HRksgh44Ztclht0QNzLNVdUsBn3qDqQRJBEJqVmuNXcot8OOcuJJ-3xZO8AjQ3UA9U3Wzv2nraturd8dwfZXDIC30veLAgfgMxib0JmjRZ7rBCPkmIiRKoHxUBD69hFn1svUWh20b04BAp:',
}

data = {
    'form_type': 'product',
    'utf8': '✓',
    'id': '39980963135565',
    'product-id': '6828962775117',
    'section-id': 'template--19302794625101__main',
}

response = requests.post('https://www.brio4life.com/cart/add.js', cookies=cookies, headers=headers, data=data)

# cart.js

import requests

cookies = {
    'localization': 'US',
    'cart_currency': 'USD',
    '_shopify_y': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '_shopify_s': '34c04ebc-916c-411b-81ed-a96eb4254660',
    '_gcl_au': '1.1.977159562.1783047675',
    '__thoughtmetric_uid': '9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d',
    'shopify_client_id': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '__kla_id': 'eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==',
    '_ga': 'GA1.1.1085245625.1783047676',
    '_clck': 'i29uxr%5E2%5Eg7f%5E0%5E2375',
    '_rsession': '1c1bdadc8fb138dd',
    '_ruid': 'eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D',
    '_fbp': 'fb.1.1783047675744.654578204850518711',
    '_scid': 'xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H',
    '_omappvp': 'vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1',
    '_shopify_analytics': ':AZ8l7F8VAAEAAhhxN3TZgY9elPeLodkoQORKmHHn9Nlbzj2gmfe9vXDzanThvxdiTBKoVJJSaH1mN-g6aCiiPnOebvH8pkYlqH4WoMcbffuih0sDvhVoajCmvYFPGEOsH5Bntq6GKXsuGw:',
    '_shopify_marketing': ':AZ8l7F8VAAEAt8y-xedx9dno-SCXO44RdLHAYtBkl5StyBW65n5HKAVVzVUv5ytgLM_xReh4KPrkWVL_8OB7k-qVFoIjVnZ6kzlebvZP061XvSzOs7rpGeBLhhgep2Jzig:',
    'cart': 'hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092',
    '_scsrid_r': '',
    '_scid_r': '34yEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYjNnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbo',
    '_scida': 'Jecy_1f-AsKtpCDBaSBEe0H9_naJGMY-',
    '_ga_LYEFQV8SJD': 'GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0',
    '_ga_CBJJ1LQ15S': 'GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0',
    '_clsk': '1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect',
    '_omappvs': '1783047681588',
    '_shopify_essential': ':AZ8l7F6aAAEAVNsZsUCdGJ_LRD_frs2McxeNyAwFAI0QRjKUdO9xvh6jZ4IlA1agZad5hxfoP2K7xVHbfYBp1mgs436iI8qD8WdCtF4F11Wa5-NIN0PtonLNBCx4GljDgVhA7qJrwKCOJkK_1bpqg4U25KRGg_6rep79blTJQrSvL0r2a3XDAssiqBjx7RiXu1zifNjMbnwioIKFD4CcwVAbymm3WgjxNS64-gDS1DOTS-xeGW4q86RBeTtCrMP2YNGekGJfNOCZupUKxUpXsUrqFiQ7TYtGs6ibWTVvPSn5fQFNwnVs7sqMKYNhRwQcsGDInhvV3_1qvxnTneJNjdIQQerU5c6DpsW1J_pdFnOvhN8vK8HYxrIgeCnF62MOXj0AmLPsJcE22S_5gKeALzMI9sW_-MefrGxr2Tz48EpzEKtzIhtffjZzqGJFLatz5vV35zJMtnIzYH2aouDfZOinmMkZSvJDcM_arPM346Uh43a1kg6HVPciF3c7nPlAhirx6sDP6L-IZZGD2v0LyMp2TVQvrDT3Tfu0zgwhbEJiGVKE4IgTgYns-V3uzOcaht3vrpF0GmkjFOdw-HusL4heV5BvRied8eYKmuZa1byWlZWHnRyGEMaLaiDnlW43AsL9AkWTPCrtTf1isg:',
}

headers = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'priority': 'u=1, i',
    'referer': 'https://www.brio4life.com/products/raze-shaver',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
    # 'cookie': 'localization=US; cart_currency=USD; _shopify_y=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; _shopify_s=34c04ebc-916c-411b-81ed-a96eb4254660; _gcl_au=1.1.977159562.1783047675; __thoughtmetric_uid=9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d; shopify_client_id=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; __kla_id=eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==; _ga=GA1.1.1085245625.1783047676; _clck=i29uxr%5E2%5Eg7f%5E0%5E2375; _rsession=1c1bdadc8fb138dd; _ruid=eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D; _fbp=fb.1.1783047675744.654578204850518711; _scid=xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H; _omappvp=vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1; _shopify_analytics=:AZ8l7F8VAAEAAhhxN3TZgY9elPeLodkoQORKmHHn9Nlbzj2gmfe9vXDzanThvxdiTBKoVJJSaH1mN-g6aCiiPnOebvH8pkYlqH4WoMcbffuih0sDvhVoajCmvYFPGEOsH5Bntq6GKXsuGw:; _shopify_marketing=:AZ8l7F8VAAEAt8y-xedx9dno-SCXO44RdLHAYtBkl5StyBW65n5HKAVVzVUv5ytgLM_xReh4KPrkWVL_8OB7k-qVFoIjVnZ6kzlebvZP061XvSzOs7rpGeBLhhgep2Jzig:; cart=hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092; _scsrid_r=; _scid_r=34yEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYjNnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbo; _scida=Jecy_1f-AsKtpCDBaSBEe0H9_naJGMY-; _ga_LYEFQV8SJD=GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0; _ga_CBJJ1LQ15S=GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0; _clsk=1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect; _omappvs=1783047681588; _shopify_essential=:AZ8l7F6aAAEAVNsZsUCdGJ_LRD_frs2McxeNyAwFAI0QRjKUdO9xvh6jZ4IlA1agZad5hxfoP2K7xVHbfYBp1mgs436iI8qD8WdCtF4F11Wa5-NIN0PtonLNBCx4GljDgVhA7qJrwKCOJkK_1bpqg4U25KRGg_6rep79blTJQrSvL0r2a3XDAssiqBjx7RiXu1zifNjMbnwioIKFD4CcwVAbymm3WgjxNS64-gDS1DOTS-xeGW4q86RBeTtCrMP2YNGekGJfNOCZupUKxUpXsUrqFiQ7TYtGs6ibWTVvPSn5fQFNwnVs7sqMKYNhRwQcsGDInhvV3_1qvxnTneJNjdIQQerU5c6DpsW1J_pdFnOvhN8vK8HYxrIgeCnF62MOXj0AmLPsJcE22S_5gKeALzMI9sW_-MefrGxr2Tz48EpzEKtzIhtffjZzqGJFLatz5vV35zJMtnIzYH2aouDfZOinmMkZSvJDcM_arPM346Uh43a1kg6HVPciF3c7nPlAhirx6sDP6L-IZZGD2v0LyMp2TVQvrDT3Tfu0zgwhbEJiGVKE4IgTgYns-V3uzOcaht3vrpF0GmkjFOdw-HusL4heV5BvRied8eYKmuZa1byWlZWHnRyGEMaLaiDnlW43AsL9AkWTPCrtTf1isg:',
}

params = {
    'v': '1783047696322',
}

response = requests.get('https://www.brio4life.com/cart.js', params=params, cookies=cookies, headers=headers)


#checkout

import requests

cookies = {
    'localization': 'US',
    'cart_currency': 'USD',
    '_shopify_y': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '_shopify_s': '34c04ebc-916c-411b-81ed-a96eb4254660',
    '_gcl_au': '1.1.977159562.1783047675',
    '__thoughtmetric_uid': '9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d',
    'shopify_client_id': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '__kla_id': 'eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==',
    '_ga': 'GA1.1.1085245625.1783047676',
    '_clck': 'i29uxr%5E2%5Eg7f%5E0%5E2375',
    '_rsession': '1c1bdadc8fb138dd',
    '_ruid': 'eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D',
    '_fbp': 'fb.1.1783047675744.654578204850518711',
    '_scid': 'xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H',
    '_omappvp': 'vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1',
    '_shopify_analytics': ':AZ8l7F8VAAEAAhhxN3TZgY9elPeLodkoQORKmHHn9Nlbzj2gmfe9vXDzanThvxdiTBKoVJJSaH1mN-g6aCiiPnOebvH8pkYlqH4WoMcbffuih0sDvhVoajCmvYFPGEOsH5Bntq6GKXsuGw:',
    '_shopify_marketing': ':AZ8l7F8VAAEAt8y-xedx9dno-SCXO44RdLHAYtBkl5StyBW65n5HKAVVzVUv5ytgLM_xReh4KPrkWVL_8OB7k-qVFoIjVnZ6kzlebvZP061XvSzOs7rpGeBLhhgep2Jzig:',
    'cart': 'hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092',
    '_scsrid_r': '',
    '_scid_r': '34yEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYjNnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbo',
    '_ga_LYEFQV8SJD': 'GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0',
    '_ga_CBJJ1LQ15S': 'GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0',
    '_clsk': '1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect',
    '_omappvs': '1783047681588',
    '_shopify_essential': ':AZ8l7F6aAAEA9FJMPsSY9KZr8c5cY_qgv_oP7ySdmRU5JuBdTdtGljQIOICxRLLEcxhGadJUm4u_iqKMV-J2CIueWnt4yI7E6U4B02RBQKyYgXVi5Ax86GfRk54JIUmjaujsxvnYja1E1hzdJ5JlRGQKLNg3rzRfsZFAZMDYEOJl7_aMIk7XLr18mghz0eR786RCKXgQ5-cOEBilQ4iPz5gW9HjsahIGAq15Tn1K3JyqeY7LqHB16iHTjSzPtxsH096yHHcq1LA6a7hIuai9wZFAAOKkKECSvTw18uuV_uQOiOVDw9A3E4fgvHlffcdgiiaG9ZxZ7UQ9DcItFK0d1UVu6wbdGUe51_q_kscjkyxkgNd7uls-UAn00vXkJJ67O6R2wIlGxAy_uqFJDcbsmHJgMjyNUQJaoNJ7kp0PxxgsJg9lPcxp0Z8fAoZYsXpjbQiASbi1Fga8oZFRxvfE8BvcYvLqYmZ9DZ1pHAgGhd2oKOGESLzvENFgi5aishy8Gs29qN0Rb2tJQuy8Wks6MZG8ttwPI4__d95O2RxdGyVSq3a1TKHGkmPpV3TUvJXZhp30dfjvXOodGSqE09nWA02OpiaHCegsHRDp1pitwzm5Y8v6JmBKXInq8USJUI_AYeNRJnzXcH30LRVHtKes:',
    '_scida': 'Qucy_1f-AsKtpCDBaSBEe0H9_naJGAYZ',
}

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'priority': 'u=0, i',
    'referer': 'https://www.brio4life.com/products/raze-shaver',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
    # 'cookie': 'localization=US; cart_currency=USD; _shopify_y=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; _shopify_s=34c04ebc-916c-411b-81ed-a96eb4254660; _gcl_au=1.1.977159562.1783047675; __thoughtmetric_uid=9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d; shopify_client_id=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; __kla_id=eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==; _ga=GA1.1.1085245625.1783047676; _clck=i29uxr%5E2%5Eg7f%5E0%5E2375; _rsession=1c1bdadc8fb138dd; _ruid=eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D; _fbp=fb.1.1783047675744.654578204850518711; _scid=xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H; _omappvp=vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1; _shopify_analytics=:AZ8l7F8VAAEAAhhxN3TZgY9elPeLodkoQORKmHHn9Nlbzj2gmfe9vXDzanThvxdiTBKoVJJSaH1mN-g6aCiiPnOebvH8pkYlqH4WoMcbffuih0sDvhVoajCmvYFPGEOsH5Bntq6GKXsuGw:; _shopify_marketing=:AZ8l7F8VAAEAt8y-xedx9dno-SCXO44RdLHAYtBkl5StyBW65n5HKAVVzVUv5ytgLM_xReh4KPrkWVL_8OB7k-qVFoIjVnZ6kzlebvZP061XvSzOs7rpGeBLhhgep2Jzig:; cart=hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092; _scsrid_r=; _scid_r=34yEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYjNnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbo; _ga_LYEFQV8SJD=GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0; _ga_CBJJ1LQ15S=GS2.1.s1783047675$o1$g1$t1783047680$j55$l0$h0; _clsk=1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect; _omappvs=1783047681588; _shopify_essential=:AZ8l7F6aAAEA9FJMPsSY9KZr8c5cY_qgv_oP7ySdmRU5JuBdTdtGljQIOICxRLLEcxhGadJUm4u_iqKMV-J2CIueWnt4yI7E6U4B02RBQKyYgXVi5Ax86GfRk54JIUmjaujsxvnYja1E1hzdJ5JlRGQKLNg3rzRfsZFAZMDYEOJl7_aMIk7XLr18mghz0eR786RCKXgQ5-cOEBilQ4iPz5gW9HjsahIGAq15Tn1K3JyqeY7LqHB16iHTjSzPtxsH096yHHcq1LA6a7hIuai9wZFAAOKkKECSvTw18uuV_uQOiOVDw9A3E4fgvHlffcdgiiaG9ZxZ7UQ9DcItFK0d1UVu6wbdGUe51_q_kscjkyxkgNd7uls-UAn00vXkJJ67O6R2wIlGxAy_uqFJDcbsmHJgMjyNUQJaoNJ7kp0PxxgsJg9lPcxp0Z8fAoZYsXpjbQiASbi1Fga8oZFRxvfE8BvcYvLqYmZ9DZ1pHAgGhd2oKOGESLzvENFgi5aishy8Gs29qN0Rb2tJQuy8Wks6MZG8ttwPI4__d95O2RxdGyVSq3a1TKHGkmPpV3TUvJXZhp30dfjvXOodGSqE09nWA02OpiaHCegsHRDp1pitwzm5Y8v6JmBKXInq8USJUI_AYeNRJnzXcH30LRVHtKes:; _scida=Qucy_1f-AsKtpCDBaSBEe0H9_naJGAYZ',
}

params = {
    'locale': 'en',
}

response = requests.get('https://www.brio4life.com/checkout', params=params, cookies=cookies, headers=headers)



#session

import requests

headers = {
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/json',
    'origin': 'https://checkout.pci.shopifyinc.com',
    'priority': 'u=1, i',
    'referer': 'https://checkout.pci.shopifyinc.com/build/52416cb/number-ltr.html?identifier=&locationURL=',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-storage-access': 'active',
    'shopify-identification-signature': 'eyJraWQiOiJ2MSIsImFsZyI6IkhTMjU2In0.eyJjbGllbnRfaWQiOiIyIiwiY2xpZW50X2FjY291bnRfaWQiOiI2NjIzNTM3IiwidW5pcXVlX2lkIjoiOTY4YWYwNTNmYzEyMDY3YmZjZjRjZjE3MzA3ODczMzUiLCJpYXQiOjE3ODMwNDc3MDN9._s0Dz8RkF8itkCEvPjbDMh9fOREe-VhaawLMAik0CPk',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
}

json_data = {
    'credit_card': {
        'number': '5137 7082 0281 5448',
        'month': 2,
        'year': 2028,
        'verification_value': '563',
        'start_month': None,
        'start_year': None,
        'issue_number': '',
        'name': 'surya rawat',
    },
    'payment_session_scope': 'brio4life.com',
}

response = requests.post('https://checkout.pci.shopifyinc.com/sessions', headers=headers, json=json_data)

# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"credit_card":{"number":"5137 7082 0281 5448","month":2,"year":2028,"verification_value":"563","start_month":null,"start_year":null,"issue_number":"","name":"surya rawat"},"payment_session_scope":"brio4life.com"}'
#response = requests.post('https://checkout.pci.shopifyinc.com/sessions', headers=headers, data=data)

#submitforcompletion

import requests

cookies = {
    'localization': 'US',
    'cart_currency': 'USD',
    '_shopify_y': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '_shopify_s': '34c04ebc-916c-411b-81ed-a96eb4254660',
    '_gcl_au': '1.1.977159562.1783047675',
    '__thoughtmetric_uid': '9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d',
    'shopify_client_id': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '__kla_id': 'eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==',
    '_ga': 'GA1.1.1085245625.1783047676',
    '_clck': 'i29uxr%5E2%5Eg7f%5E0%5E2375',
    '_rsession': '1c1bdadc8fb138dd',
    '_ruid': 'eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D',
    '_fbp': 'fb.1.1783047675744.654578204850518711',
    '_scid': 'xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H',
    '_omappvp': 'vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1',
    'cart': 'hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092',
    '_clsk': '1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect',
    '_scsrid_r': '',
    '_scid_r': '0IyEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYzRnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbs',
    '_shopify_analytics': ':AZ8l7F8VAAEA2bE0RDxBgZoyj6Ne-fp7kYaUe9oBelA0j6Y7N-Dq6y0LSQ5TzEeu3hpSFV9X1q4ddNkuYzqc3rQLvQYeRdqeMhm19U71PsYbuePTvVb5bUA663y5tZF-H5Dp8UouXLgP-ioDw73oR-v7c0W4lay3B574i5OskI8LOA:',
    '_shopify_marketing': ':AZ8l7F8VAAEAeA1IwBAVAl4atfOYlkh1QVY63cXz_WpUEgHArhG9jG7ka-dgOmLl_Y8AwinzJtDSxZYXJ444aHdobefqKVkEFt6x74jGFj3CFSFrs--OqNJwhMioqrYlzjUB-Pqg8u99YffOg08rdloBwT6nNp94wQ:',
    '_omappvs': '1783047705050',
    '_shopify_essential': ':AZ8l7F6aAAEAkPiUqCNH8cjSXQwyaY_QQAW6_XhhKWrwRZkBnwvVXYxGTFp6zGke63PIlPl7uQ2gJEYqfNvyObW-LtxVodn5tXsp5pJi2LNx--6_vF8zNtA0xkSFrEz41sPC44CzpMdrDzAPCL4EYQOOSK78302DDNNrk_wzkrGsNK8SgFOnm_VUc5TzMlPvXKOPzcjNJEpzRMFzJaJ8Rjyqx1AONOF9FMjyHnlKVxeWCY8vTePIQ8cP26NlWkuJiTydPclHq_ENqv10UdmXUCD7VAHJQgu3R1JBTLPy-ke_9Pvmhv-aUjzboiRqiXw5jIkwk83YHWnezMvTi_oO8A1Z2K3Ez-XuotmIxYUTT0JubAMZvSADjW12XyDuO6nS1NmhqDSyR-bAxCcq6nmkLZu-WFGRSSX7-nIcvdkuxP04oTW9NhJWqnep6jAt8cjBAWUbDGCpay2S56t0U2NOS1Cgd_qMOf8EzQILr4hSkxhDUNdvuq9uxj_PlKuf3d13k5f3PTj-QX4SiHm_OBdK2UENCY3oDX8YdpxfEcnn3iWksv2jd_Do3CtdIl5PKwFxhpuoMrDGicQKpEGebZ371icKFuw3Igz3a59CdxTTw5oqENxbujR-o-Pyj97MJpTVJySVtjSI2J5Kfr1WB-nJy3Jm2ZLRncG7NzRd0xyONxZDTlTE1fxtoTbaOyse0NcdO9-bLc9CD2oUPOuFhw-0rC_-gYXJeE-XbsIHJ3oGSQt7kzeOgOShyUee4YE1eoGhp0j5BUI4VhMUCCMylMY5_dh-IQ:',
    '_ga_LYEFQV8SJD': 'GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0',
    '_ga_CBJJ1LQ15S': 'GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0',
    '_scida': 'KOcy_1f-AsKtpCDBaSBEe0H9_naJLhVy',
}

headers = {
    'accept': 'application/json',
    'accept-language': 'en',
    'content-type': 'application/json',
    'origin': 'https://www.brio4life.com',
    'priority': 'u=1, i',
    'referer': 'https://www.brio4life.com/checkouts/cn/hWNE2Hrh560Q8HwlQTSiDY9s/en/payment?_r=AQABNpjBWiBAR8qEiDMSzRsoRR1Etwq0DWMYomH_bFjvQyI&skip_shop_pay=true',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'shopify-checkout-client': 'checkout-web/1.0',
    'shopify-checkout-source': 'id="hWNE2Hrh560Q8HwlQTSiDY9s", type="cn"',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
    'x-checkout-one-session-token': 'AAEBCiTqdD2ALpe35PiKKtth2nUbTkueF6ndbGoGg9Wmhfu3ExjXckFuXI8FHWe0iBL9_Cv46_mnoB7orcEN5EuKntRxNkAyVGQ1btU4FOG4VBYJkvFQQ3eKrxJ4DKBDK8zjrx5UTM22qzbBDP4mfzGUVhYT2vQO4UZuAQjjsQlFrrZiFhIr8c3FhxgKKrzGPqZ7C0CJhokxQLfcF3ULFe1quJPF3fnzjQ',
    'x-checkout-web-build-id': '629a7d0a1d675e5c3b08a3e62d6818fb3e014528',
    'x-checkout-web-deploy-stage': 'production',
    'x-checkout-web-server-handling': 'fast',
    'x-checkout-web-server-rendering': 'yes',
    'x-checkout-web-source-id': 'hWNE2Hrh560Q8HwlQTSiDY9s',
    # 'cookie': 'localization=US; cart_currency=USD; _shopify_y=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; _shopify_s=34c04ebc-916c-411b-81ed-a96eb4254660; _gcl_au=1.1.977159562.1783047675; __thoughtmetric_uid=9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d; shopify_client_id=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; __kla_id=eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==; _ga=GA1.1.1085245625.1783047676; _clck=i29uxr%5E2%5Eg7f%5E0%5E2375; _rsession=1c1bdadc8fb138dd; _ruid=eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D; _fbp=fb.1.1783047675744.654578204850518711; _scid=xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H; _omappvp=vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1; cart=hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092; _clsk=1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect; _scsrid_r=; _scid_r=0IyEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYzRnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbs; _shopify_analytics=:AZ8l7F8VAAEA2bE0RDxBgZoyj6Ne-fp7kYaUe9oBelA0j6Y7N-Dq6y0LSQ5TzEeu3hpSFV9X1q4ddNkuYzqc3rQLvQYeRdqeMhm19U71PsYbuePTvVb5bUA663y5tZF-H5Dp8UouXLgP-ioDw73oR-v7c0W4lay3B574i5OskI8LOA:; _shopify_marketing=:AZ8l7F8VAAEAeA1IwBAVAl4atfOYlkh1QVY63cXz_WpUEgHArhG9jG7ka-dgOmLl_Y8AwinzJtDSxZYXJ444aHdobefqKVkEFt6x74jGFj3CFSFrs--OqNJwhMioqrYlzjUB-Pqg8u99YffOg08rdloBwT6nNp94wQ:; _omappvs=1783047705050; _shopify_essential=:AZ8l7F6aAAEAkPiUqCNH8cjSXQwyaY_QQAW6_XhhKWrwRZkBnwvVXYxGTFp6zGke63PIlPl7uQ2gJEYqfNvyObW-LtxVodn5tXsp5pJi2LNx--6_vF8zNtA0xkSFrEz41sPC44CzpMdrDzAPCL4EYQOOSK78302DDNNrk_wzkrGsNK8SgFOnm_VUc5TzMlPvXKOPzcjNJEpzRMFzJaJ8Rjyqx1AONOF9FMjyHnlKVxeWCY8vTePIQ8cP26NlWkuJiTydPclHq_ENqv10UdmXUCD7VAHJQgu3R1JBTLPy-ke_9Pvmhv-aUjzboiRqiXw5jIkwk83YHWnezMvTi_oO8A1Z2K3Ez-XuotmIxYUTT0JubAMZvSADjW12XyDuO6nS1NmhqDSyR-bAxCcq6nmkLZu-WFGRSSX7-nIcvdkuxP04oTW9NhJWqnep6jAt8cjBAWUbDGCpay2S56t0U2NOS1Cgd_qMOf8EzQILr4hSkxhDUNdvuq9uxj_PlKuf3d13k5f3PTj-QX4SiHm_OBdK2UENCY3oDX8YdpxfEcnn3iWksv2jd_Do3CtdIl5PKwFxhpuoMrDGicQKpEGebZ371icKFuw3Igz3a59CdxTTw5oqENxbujR-o-Pyj97MJpTVJySVtjSI2J5Kfr1WB-nJy3Jm2ZLRncG7NzRd0xyONxZDTlTE1fxtoTbaOyse0NcdO9-bLc9CD2oUPOuFhw-0rC_-gYXJeE-XbsIHJ3oGSQt7kzeOgOShyUee4YE1eoGhp0j5BUI4VhMUCCMylMY5_dh-IQ:; _ga_LYEFQV8SJD=GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0; _ga_CBJJ1LQ15S=GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0; _scida=KOcy_1f-AsKtpCDBaSBEe0H9_naJLhVy',
}

params = {
    'operationName': 'SubmitForCompletion',
}

json_data = {
    'variables': {
        'input': {
            'sessionInput': {
                'sessionToken': 'AAEBCiTqdD2ALpe35PiKKtth2nUbTkueF6ndbGoGg9Wmhfu3ExjXckFuXI8FHWe0iBL9_Cv46_mnoB7orcEN5EuKntRxNkAyVGQ1btU4FOG4VBYJkvFQQ3eKrxJ4DKBDK8zjrx5UTM22qzbBDP4mfzGUVhYT2vQO4UZuAQjjsQlFrrZiFhIr8c3FhxgKKrzGPqZ7C0CJhokxQLfcF3ULFe1quJPF3fnzjQ',
            },
            'queueToken': 'A0lIw3_QOrl6hLWpMHs_OeYysjazx0WhZ_G4TbjrxX_jU71VV0-Zlbx7AZgywnZVvYgrfGHBRnKt_Y_JRdfEdhGF_BfzSxxCf6jGWddjNJhGimotYRe3EGlpkj5g',
            'discounts': {
                'lines': [],
                'acceptUnexpectedDiscounts': True,
            },
            'delivery': {
                'deliveryLines': [
                    {
                        'destination': {
                            'streetAddress': {
                                'address1': 'New York Ave',
                                'address2': '',
                                'city': 'Hudson',
                                'countryCode': 'US',
                                'postalCode': '82515',
                                'firstName': 'surya',
                                'lastName': 'rawat',
                                'zoneCode': 'WY',
                                'phone': '7584578457',
                                'oneTimeUse': False,
                            },
                        },
                        'selectedDeliveryStrategy': {
                            'deliveryStrategyByHandle': {
                                'handle': '968af053fc12067bfcf4cf1730787335-478a829601c831f110ee5ea50948d593',
                                'customDeliveryRate': False,
                            },
                            'options': {
                                'phone': '7584578457',
                            },
                        },
                        'targetMerchandiseLines': {
                            'lines': [
                                {
                                    'stableId': '2d42c337-27f0-497f-af4b-10894fa1757e',
                                },
                            ],
                        },
                        'deliveryMethodTypes': [
                            'SHIPPING',
                        ],
                        'expectedTotalPrice': {
                            'value': {
                                'amount': '0.00',
                                'currencyCode': 'USD',
                            },
                        },
                        'destinationChanged': False,
                    },
                ],
                'noDeliveryRequired': [],
                'useProgressiveRates': True,
                'prefetchShippingRatesStrategy': None,
                'interfaceFlow': 'SHOPIFY',
                'supportsSplitShipping': True,
            },
            'deliveryExpectations': {
                'deliveryExpectationLines': [
                    {
                        'signedHandle': 'Y8SissjmF7oXr4KNz0wv+t8V8gnYJqMUgFVNo6jVgHlKCtJVYROrQDalKljMK+lR2ahKUT7JG7UtgKRRUgNqW+gH2RH73cf4q6vSYsuQROGDRsdoXqbk2bBfLzGR5hVNdL9aTC4XcLs3a4X8k+OQFyb+PD1N/PoFVHcv3h8/6y/y8tYgxwQsPNwUuMuYZMfL9GjS8FVLr5xnyb8RNZFbPndnndLY4r7ra1Xfd+/wzv4eUyZTkxcg4wEbHlCPyerBhH949mE6owpCJqnfwY7Sv0AEe5m3131U5ZrMBppDHmRC3wSj3pdHTZx8VRIr3XrN7L88tvfPmAijaB8Ga35vqoa7Op9VVfwmOkpF7SwAHbtdAj+k8ScF8Gq1JeOjzf7gwZnssHPPE4BLRlP3e3eNMpfj4CwDd0jMSYmMjFcTnmgEKqYiME0VVcJo6kyjGXorJrmb8BNb6Dn5DZP31+15afPYs8A4NnLo3uNWEKrGqUhpUOFNQDZgjuVVo5zX1sWek9u5Trr9EbQ8ymVEs6QT6ASDjj3vZUqT/kwFkUz/vBKGCd2K09cP0jJp2MORfRxlGy4pzfJYmOS/BnBUFtqJKhnv3752HnojyAf4uJEbZDHU3gPs0py3Fkrn+qi8StMy3y0Mpj/emFTGwMwSH/ofyoC5pXWqZ3S91+m59E9eF488WjDKbLOceGHi1NPYt9JXTvo9bSNhwpAV9ujUTR8iVAvtP79JN0PkaPQes6oanwJrXoWaxXR+dgGNxiZQB4r2u0lunVXKRaXTMUMXRrDADLJMRUPxWa2zrT5BiaBWzVz5jzNFNHe9z/6iS9Ac1SS9cNGp/QYGeXKaH/ix3wJaKQYGmcj1EU3erIjnyusaW8FEhKuaFXJrHeTnVhXABTpEB+DSWTct9oEXx/rbpxLfrjJNWoj1jhd7aBE4O6lUHqsQA5V0ko5dHwPPv8s+jSPpqL3MvAUw5l/U0D2zG28CYtEkuZmwZZrEzq5Ztxfq98O+xakLSMNTfP5Wl9CyDFOFpFRMpPelR5wy0HaXzzVznO7J5+Eh8w6faA0Jl4kyONtd0kgqneZM88mr8SaBvCaj8CbqZEFovV0lA6G0X0XX4f47tsc0Qz1T7ijk8WZPPlaBny0Qpoi7yiaXQ/UerDI1WBt/rkPsL4/Q1I5JlAgiB24lbhRTEzjl9r/3NWtnFtTbwm6HJrukJOr+dbW8sWt7TvWIWhhUrH/+LYPSxd/mq0ADTAvz60y8LU26V4j++MORZ5Q1sft+7KJ27YIjTvclyYKtxnU3bzbxPFq7Og+KLXEIYMT5ZZXm1tbcYxG280ceKGLIr2GxgHqSvqJ2D7fOD/UfSAP54MFVCYpnMSzE7ViL4N5L1DtfgF2BaB8wPzkGd9l6a1KV6zdr2CCbFoxUUbz5CJ/G4hDjShUXtlGVjYops9Q/P0hwj+Fbnd4BkSNePCfH508y2WvGaNTwaNarIeZuizslzFi+y7PT5o8QUBp1IQpuvDHIu5sYKNPWaKbzDkJqYx+0Tw5AUSL4QkWpCZmfgFb0KpwW0OYO4y1ub9MBe8RKVBj6r9aMUiHcHGcvJUi/xgRb/LqeW2oBJeKkqS0H+0hgbeu+52TvhlXX1f6HC4AqWu0XSxfcLhCgkaQ2AO5gBBYhri0xaXFcMpd4ND8hpaGSud/vUvm7wW7KhHKpOTh/HGHH/XwepEo4IolaCcjXSjRwDPV73Ex9PA01OoBkNNoHKDKFGKPAUnPbb1U4MbpgszPWe0THBAPq09Ux0W+03HE/SJR2RnPL0mjuRPPlHDjdwaeZZLXuwTdCaPnppo6LhfJJcU/rhgbJlZLXtG5zTNDH0ngq1bJ9Ox42zH9XsFmb18/4YI1TKlTGG9cH/vKcNBLsZKXyPvbAPdeQY/wcwjIg0SAyaNgy3pPRt5VCs4cj1fuNwPSxf+lWFaDTXA6S8X/E5tHoPJcUkrq3WZeVxtKhwWltqD6KHzl2jfKcscQ7Eq5kaBKZxIEHcjckxzAUEdc8CK44xwa6Ik0xPD96r4voUYYSaG+391EQhH1WkitGNK5JLE7rkrJDJYhPuv+YxR+uvdXbnDoyvoLpXg1ypTUT2+0aSoGHzvo3RDgJ9LCOZHYt35Qj67j15/4utdHodKbqt5B7KroLsABx9h4OwGq52/wTYvPf7U6gL69sIxc1Lt1VTsLEYmkVXIwsJF4MmO2xk7xv+nC/MHz+I2aMPMLLdhSwganZ+dyYqWp0FUXxppySPlZgMGoCf54NfTtytaU7l3oLdpZuUL4AShe+RWrGvT22ECt3Z5a+/2te1ovA+GFnogGf70ClJMJJwoRUhFhCXAm/ioWnZbYq+x7z2Vce+c1f7MbQiWHc3aRQivSK3hUvIG4+LfPnuzdl3Na1UjK61ofWbeeHOG8RNUz2N5BvWswe2Llcr1CR/3u4zzCRpcLv/lEQ7gDakRDK8DOwmwjtbLqVb7HDvW15jmOUUquQUC+o9kTc2OfdckjicZS4d2XrXmfEtRAchhrg3jGWfB4SVFyYGWNpfNxotryH7CPoTbjapjjfCUvyD930iIDmkELntsyWELx/jRxi6H2yA3j+HFeaZUtvXmUktIkyvuzhZh4BTqTpO7lDtHd1JsQBA/+0EHhGvBrDNm0Ad4wIq3xZ37YGyWeWjLeV11/DOmXXPyzbIQyLvF1b43zfAvLjxgU3Mc6YVnzpJ5CRYH0x6Dim7KJq5OXKHTWrnirnIQXMuDm8QqMM+6DAfSSShT3m+TwgbxshPL3Vv1doLrAi0cJRJU35jL84EM8O5W6t9W8oTBnZXoYNO8RtiJKbUViviURoP87gmBoWB363Tp6Kw97obin2uTl1BEc8A+ZQg8bwfM8twMNbRgUgUqxqsUxEASyDPK+Ey7DAbfq0TXoIZMFBornaFNPpgQzkJQobwYjzyGLWRZN7R0S+LEE5woHYi+QZ6fU5w6N4N5SLrG/nD01qUrfUX4zO5T1gH9oRddKJqgyMrs1PFO7gE+yF4BVX+ZqNVIqg5pq5SHeswsJBatnT2MNn1mJrR2x21WU+0X3VaEx+/nvR+19DUxmjhsSwvWsSVFeT1ghXEGz+7I5btRI7jllGBJBLEJUESDKdScSMotb9DJorbFap9UoUNqLf+Ao7EjBc0tJE6GwcmXe9aLWG6Lgv69guRZBclw2MzTk89onpBgGPM00xIcXymFBfz0ERAwoYIX0KPNi20HSuZUcM4hPMUHj2YJqjfu16QtXwYyn8wUT2yEyVY71CkOWY59/44dxdOpMHKksCZH5Hn9kwWjoHMnPE1EjyGWbPog2FI4E1UdLT60c+gNdn75JJNCFobrbxz6bGftUcJeyGWI6p6VtRupOhnfnI41GF/an6Z4REV8v+uQaXBwizU6+vtrADkAz9RYf3WaEkwuTL31vU5Bx/OhipU+bSBYG+/NJHNKHeaZiuw9kYwXf69pb56fzowfp8yDYgLiKLYDcnpaghXAYq+ouxtjwJjB2w2nc+uS0Kp5zAb6xK4nfXgMrAX/sHLkLbv6nDSjLpZGdg6ER118GADEwq1yrmspMCNT6h3gHcuu9nIZoMB/b9/h5IYKv81qIR8YxYzgpJV4uK/dbUkhHKk43tQ7FIhC8I0rp5jexxHj0dA8TBJDnR03KJZGa4e+gbeHPrFsce9qmU7+9xrDA+5FvQNdZzbDE803RpHvrsqDcbleMafRy5IYgRn0QgCUU7bz32+BvOXgBtpPbsIpEqjzsduyLKJFxYenjbNVZ2VF/mzG3d+7HUcZd4VY7QKdFgX0A8VY/pgaWcU29OGfFH6iHj0AxHSJ27upmdZpmyId6pT/CT0fFwN+TaqthzO0s9WsyMNtNzgoJogYVPc8N2SVI7lGWAXilLuyGKjzwMNzZxml2STpKCR66Mmo1s3Bddslqs7wCqQBGmA5T8TkjubZKriVcLcsuV5i43sLrnLVhM1ep+zkMSuGCyTLMiWgEsgfjOlxjMvzjmbVxJfJfwRW1sbfkP9vqWoParqZKk+jvfxISJD3ygUhmQZWdr9Ezm2Tx0JlWAVWX8tUQaYqo7XoT2Q6idrYFUedOwxz46o8tDhycCFbgyv7UJ3FMIJn30qQ+BLJJ12Yc0Kxh0yxiDKHJlrekhbANe2qpvsw6uy39zos0i0hmv8XTvoxLfN/X5RnJ7b0CzJ+DMFSpdopnyyZjPiHgO3xKiY0zt1nWjKz2ZdUcWeDCAeKDQbwyaIfoZZdcm+K7llDqFoA6cDBUYNsEcIcUP5vkyUm7aeXV2bKaHbeAYMwIPRYQ/HR7T+di75+Nn5Md0a/hL9E5Aklt4NeiW33xwBJpPUvawOc5xNe//rl9Fy43IMPy/iYs9thUrCyo3uMZtfwnJ0mt3+cf/icqAtdNVDQjb6wdBO1aG4OMpKo6DTGz69r1+aWeLIxvwoCMps7iCOLuwehlwQkIFs8rf19+CmMKzMEpA1nVxlu3yxn/O6LRJipPkvtp1rLWGFeW8xjKcdvznODqKvDPEQS7QpnRbmfs0MvsjQgiaiUH2uZGEda42ZfTAQp3NGws4xihI2jF75ctQTlBSujqP+mvtCf/Pz6hO5EZj8im1FGxYhRhjArLoxRAwD2nwHuPkK+NSDGMrNXvd5v5q0HiyzAfo21GWTWMt9xWtiN3AM6eD70VDePQ7SqmfhSGwJMd0Kq2zFxIBXK3eXfVcwX46l2HU0CFa6UYY69TVj21o0Hv6L4RHDSYdMhoDCjS7J798iuigPtSv9GtpzoupR3wnQhwq3BypUGBBR4FGicv8oMZxXtytML0EtXCEfTnnVsP2pU0wOoYrp5/XXjkV37fya/6vEAhkSDsMa6Ltfft1aU7WQ6neTHI0Bd8M1cCNG4ENQymNit+OWcGxlEpaDZx6dH9QPhAgJGTJbApVY3TWVyBVOJqAi4AVqoL0knIHoFlUQRzDTgbhKPwEXHDJ7V3cmvF+iSae2Q==--MeVeU9nkloVwxWuL--ozP/TpaT5cBNs/3IwBtb8A==',
                    },
                    {
                        'signedHandle': 'ps2tG7gKuyLOuq7ZOxLLLpyVLga5FENPYxsv6YX3mA2hQkjl26inzPCl3knI7mdghHeHHLw6VLXffj6Ao3D0pNBRmyXa3RK892mTjW6UXfa1na5qIjkKqoYQg0/yZdEtN5SpO/Mtgog5AEYxdmojf/lShpWfeNnkG66Cki57a0BmIFQ88ubLQjHuQIoXKDo71Q8Ub4XKMhg4ce1VRyg50ula5d3C6j2+H1GKnvK6StVOKLEqae0WwgWa/w8nzAdjzlYIOY17eeDkZtKGj3xWdgzv6gswhhlfOzCn3sMQENP3srIyGBl7SFRik0mYOr2CyYzw/UKJKlbgnt9Fcmvi/d4F//sh6n+SwWGkJ12dBhBTKiWcnNfG2spT/WkzA4fe4f4z4nguUXzxbOGmbqXEwe/9EBNkKBaZ6Cd26PoddbGNnryuYATBQ1AIXOUoNuq2NAwvebNIYISYPeNSDX7C/zqrhqcgELSfUpAgrxRXNUrcY51ZwL65hI5P2Ex/LfcsXvBvkKcHqIO8fM91pTQ/4mHrEx/IK3vrTzJTi2WqZBX5L5cWwOcxzapKXvvsFpzY9w4paL3PAFAWNZ1HGt5eviPWKopijupBVrSr4dd5V5W8xmkGxsUmDip7WeeSvGxdbdloRSdtgo6z8s5l+KXejOi2BYEemWAeNg2ogEqJIMetVEi/2Gr+zKgbFTFTIsiFSqgGj+uEZw3PMMaycrSR34VWNTIxJ29cJu9YdB3oo5nzywHkuCnn/l/Im26zXJE5oSenePP16OH6JeO4df0ALIV8Oj3KEVaIunXI6AklqTUeaZprHbT+yxkFYCMPbXWDny1ZReOaur2+sbL73VjRasrK1ZEFVnW65bqHFaRZUoVRVO+XKF2q6w3oBGjaHCJtteeHLwhT6FwBJuNeaReXw90/Mz5o5bhxvY4k/mvz9O3Rk24AjXaR0xUA3w+MaFn+I1ll2o/cFHEXHF8SPhZ6zLTvo4BvZHPqFgimjHKZ9efM6jNiiD0ouVUkFiCLKy6c374uHzOUixY0HRXNIhk1pg5YeFRlNNe59T/GXO2MbunwYSyGQ44nVd/HZiZFf71CT9LWPch8LudppvHzKjkmSEh5457VBNrrudEuc4jPpRVKFVE+I2sAFO9dcwSGxekkH9WWtkPL7VPmN9B0/l1uOIZSDQZrG66U+I1JYLFnwm0ikgZp9BpRcS9Yw4JA6uMunycNhKnJVtYYKrQBBrHLY2F1P1V4feSHKO7RET5r3FQPBXKayC6XLlGGA1gFOO+mmDeAGj5Zch35s4UKRNyg2aBjSzNc//7+Ptg6j8OGG65JLU0CO3bo3XK4VrBIizoDXwLp5bpLkO9u3ENy7DbKrWs8uOi6TbC2HSGP84VK7X0n8o2GBomHAliLd7UdDMhBHSqWnuJspGE/s5ncsEzKKDOMs1E0E4ko9qQB9i1WsKxuK0cDsmYEtDCa3AaTc2CrbJBJge+4/fSaNKLnofIVhr1HNsaZX97AbT/zboFQhFqNdFPNnT0IL6cLv/OWlyRsV/uCLqMvosOILXX19YFceTr2HGc/K+awMsIU8qb/6Pav9GteUbWPRbRd6vfPDdur65doIi+WKuK/GvT3MZQLjef8I3j2Z5W0CU0iDFo0zq6P2xGgxYotUvUOizIlbV3Fv/r30CCbX1lRQ0xbBRxJcnZ4ne4EzJz9wz3am7TC3WSxA5xKHmNV6dNGyKey6RuM2INSp99t8wpgWA+LQu8Yxx/uYdzLo3/dC5lTHMQTjtCOdHYbjuvNlCZ8HX2fsHdHrMak1quCJoSmvbQYjIpvTcL7GQCBfhzJiclLJw7YaVCIMBhAsEO2RT5S7mtVz4XtRpYcm2zdoEEpzne2X2UREvbRX6Lk0CTDpAnPCiqRIDTTnTum8AZy08cXWOo6hV1Xahd6vlpCqhpA82F+bGUcPtr02XqwOZ3+XX6AmJ0osmm1fUgpq/BiwnUixrZQ02oWHcrztD8Anx3EJV0SsRsHn/+Vv2ghYMoA5BRglMVWdJvigJXuZV+bFn5dJa1wadeLJfDXbeB5IJbrMP7ouqgRZUvG5Ot6+3X5c5a4bjZrQ61FJlmgMO/TMm/0XygWDcFaba5lKPuPcIoAqNHWJY4xA6uUyxhofQ8QZuDaPzVdWZ0fFEYvAnSktbhfoAjBBrgNQ2oU/OIReeWR3dCw595qZviIygTn5mydS2VLnPa9jOzZT4lFt1J1K5leS/3I+l4ZHI9x1NyxjBq7nWtC5t0BmPeVXP8UGHOAupW4XRu139yfGRNIRswXWU7N7DPbXGY3yARRtl1TzoVYmvbX2KQEkslxxH3/WF9gOH+g1POIU8eb5tr3ax+F/cf5g9BsnSxQbjr/apQ2arwM5uJAzKCHaoKk6JNRAwo3qsYsrbsQTTr5Ub2dLmb5TM5EHsNsqO3ZAIpR+Q/VqI4xCdCMLqpnKLIelacbix2EvOhUxSDar+7NSd8HpIYVoLdetXmjzupgMmmnvouGdvn/A25XgWEGm7T13732Ta8wRihr3cnEhNxMCjEZ08wJCbPW6AA1dr8ToltgFWyGrQv45ISe5p0yjwaf7o38gdD4ltWlqSG9cPdTheJQJTmPEqoMlg6IUK1PQWqBpDHmqP9dYeIOAfsFcHN0fzUPqv5iJFWp1CBgivFPvzeEbXJ3iK3Wq4ZPgwbGcZRUjFHE/sFZTDfc3t/0m3UjkgiQD4YWQJmtiOZKUFtZY3kDvAMgJsNwI2FIpga4cagkmXEKvteD1kleZnALrk68/FzxmcaK5xrJyHH12cLlt3PVdmt4wm1b82MgkZEwfecS6pg24mHayWQa+4NBnMj9pjIM4b1a5La7PIgLVAlvr5+bqdEFcIOIDjf72DnlA90T8MseU4Frtd+FMJVcfl3DG3HLEb/4RcpJ0Iok9Wd2r0Vc481+QUUajaMFdYPifFn2FI52pIHclCVa7xCQ++UELQs9SL3L2nHEs4KGES8MuDJMDWyl0Q7TvkV/7jcUiSO8k7Udnl5aAAY9AL+dZI9GhxLoHyaqS0UFBjGA81aF3+WNJgGo7Q1KS0To/FPLTGGrXLLW8523KpKjQKExAJP80wI5xqdKa9iHZq/Lsxn2H3Yoi4t0+bg4agMxjC/XZLGXqqVLKYUQ8HNda2W1krZrmi31Hz2LUknm43+EYqbOQHdnpdcPsE28IjnMS5Vns15R7V1SQ+wTf7obdOVltmfXjDud3TXI7d8ZaabVYaoqRJ7qj5yPBeJrAeiZ2kkU9wBjabexryPyRkTmfN/2aQTSezqCUYWMju0V6+2U1bFwvXeEhVkguJdsApHYUxHPFHKoxhMPMh4yon6Hi/mZy2kXwXAZtihqt6xAw4+VTj22kYQSFKb0O+squUsoLhnwC97vWhsWgb6UHd7rBeAvo05Kid8BCzxoRBNzhyDj7eVF55x8SOObF44sJyRAu62c4zmjTunAfCc5by5Dv1DDfGcoH97F1DdMKUdBg1UYNPxnRjRJmEZMObKS29V8E/tDb5mCK+phPuaeumaTTSaKIcYPA+ExLogrHAoqp09MSCujj259tEvg0MPGxCISOQ7Lg7CcsyO/LfLb9a+rf/2dmXSizKqnoskPpoQZK9K5QhBhQzrWSpn12kXgKUNkpY1BsCjLzb1w0hPaM0vCu9F9y3IHbd4hIBpezcjGnqztmnrsIvwiHI2rcjfcPz+pq6wYDUVKWDkGHeCf43aPu+LHsiQ4HxThY/y0h8brEEuAYK8SuqFbXgCEvz6mkCcbblDUxD/5LE2AkQklE7G9Qz0oemjPxVfw7dvfjdmGT6YJJxG6F7deBHoYWa8HXcQXvjaIjqcszPJiBgs1I3a4QUZ4I/KiWwUoe+aDrSd6mEdjYxrfQD20ArE3LufRrQwlzpWNCrmakMDkd12IqCTdDE3CDzF662lhVqjtlxOEtAbGOscW965JsRVum2nUFhL1BIjTigITiu8KyDiZaXk/9G7INlbSjS89PBGRZfIvqlyJu6zP9D2IdswcqeFYgGyxB5nJYc9FsEzkbBKcz+gHHwPkZVyU7pqDuckKmgpoCBvLZT1ds5n1jLOSM8B8RUBpiAsfGjYsXk+ljmbp1vGfvlyPL5nwcYLwSuYrgFoQgNhF3VCgjVdYo4nypI5e0IEeCUQXfOJn+tsmRjoyqU7hZtsB6E2PBgMoJSXi0dM+sAwoBMVUY1ZRDOCzZd6Tgop3C1CVVaXhDpABna3Pe5Nkc+3qD3xc8z3N9A0E+yrtFCJxiRiyx42+rt7DrEoGiiQLSwSsBIFYUBBK2LHIOzmTUHkoeYgT8bWQZY48H+6mKoG6rbfeZ5IEa4UOdVZYyDdSY7OCbmxzoe5uc5C1ehxtWTryDIWsUneSA93Tw7p5r9Itt0/hNQQeLozuS3IuuM4P9S1y5qzvOS153lCGIEf+ZhSYkFj6WLTOQlTJOB3FPkhbIc/SiFycIoyKHaJa5GVT/ZVqvfTJ5hSAA7raWFz1xWieZiys4/lu8AqDFH71LCx4tvqC97cJ3EydI0gz0klvCy+QrL02/xypcaz7zPvt7NuLUfcMPnzHm1Nia1xpqLuxwR5MscE8xHOfrDvASwbc7uEhx8R897hziz+Bsx2b+b/xVjWpIsvNdGzwyITe0GOBAXDtIhmyfsplc0FdIWwIfheND6zGWQjIvKk+rrWRMob6WGhowhfU67kV1iVyiHNtOPdDi8WFauSqkIRf94fqI8QFicOtOPHO1uH9++Gho2fxKRoH2E2QctoKIh9Hb++gZ++KqjKTAuAsKXEaTa12BULN13Kw0pM1/KiXVHzi3czKwHlXUgq0zfZApVT+6sgtiCI1IQtr/+BEADVOGS756SLW1IczUfJhrLEWo3YIP0PshdMtYoX7aUfqmbURk2KxAHzADqS9fZ6DnKieYkzdL1XeDEFIOfjbaf7qVMWWzsSPIFmYnT0Vy6m8EURrbl3U--WliOrAzwvrjOGYWP--rCkJgq/5Vtb+AAQcAJIswA==',
                    },
                ],
            },
            'merchandise': {
                'merchandiseLines': [
                    {
                        'stableId': '2d42c337-27f0-497f-af4b-10894fa1757e',
                        'merchandise': {
                            'productVariantReference': {
                                'id': 'gid://shopify/ProductVariantMerchandise/39980963135565',
                                'variantId': 'gid://shopify/ProductVariant/39980963135565',
                                'properties': [],
                                'sellingPlanId': None,
                                'sellingPlanDigest': None,
                            },
                        },
                        'quantity': {
                            'items': {
                                'value': 1,
                            },
                        },
                        'expectedTotalPrice': {
                            'value': {
                                'amount': '89.95',
                                'currencyCode': 'USD',
                            },
                        },
                        'lineComponentsSource': None,
                        'lineComponents': [],
                    },
                ],
            },
            'memberships': {
                'memberships': [],
            },
            'payment': {
                'totalAmount': {
                    'any': True,
                },
                'paymentLines': [
                    {
                        'paymentMethod': {
                            'directPaymentMethod': {
                                'paymentMethodIdentifier': 'dc2c83c064fc75ebc5dfa2b5bee4f873',
                                'sessionId': 'west-0aa1f7ca996ee5192f1b06a160e6dfc1',
                                'billingAddress': {
                                    'streetAddress': {
                                        'address1': 'New York Ave',
                                        'address2': '',
                                        'city': 'Hudson',
                                        'countryCode': 'US',
                                        'postalCode': '82515',
                                        'firstName': 'surya',
                                        'lastName': 'rawat',
                                        'zoneCode': 'WY',
                                        'phone': '7584578457',
                                    },
                                },
                                'cardSource': None,
                            },
                            'giftCardPaymentMethod': None,
                            'redeemablePaymentMethod': None,
                            'walletPaymentMethod': None,
                            'walletsPlatformPaymentMethod': None,
                            'localPaymentMethod': None,
                            'paymentOnDeliveryMethod': None,
                            'paymentOnDeliveryMethod2': None,
                            'manualPaymentMethod': None,
                            'customPaymentMethod': None,
                            'offsitePaymentMethod': None,
                            'customOnsitePaymentMethod': None,
                            'deferredPaymentMethod': None,
                            'customerCreditCardPaymentMethod': None,
                            'paypalBillingAgreementPaymentMethod': None,
                            'remotePaymentInstrument': None,
                        },
                        'amount': {
                            'value': {
                                'amount': '89.95',
                                'currencyCode': 'USD',
                            },
                        },
                    },
                ],
                'billingAddress': {
                    'streetAddress': {
                        'address1': 'New York Ave',
                        'address2': '',
                        'city': 'Hudson',
                        'countryCode': 'US',
                        'postalCode': '82515',
                        'firstName': 'surya',
                        'lastName': 'rawat',
                        'zoneCode': 'WY',
                        'phone': '7584578457',
                    },
                },
                'creditCardBin': '51377082',
            },
            'buyerIdentity': {
                'customer': {
                    'presentmentCurrency': 'USD',
                    'countryCode': 'US',
                },
                'email': 'rdx54545@gmail.com',
                'emailChanged': False,
                'phoneCountryCode': 'US',
                'marketingConsent': [
                    {
                        'email': {
                            'consentState': 'GRANTED',
                            'value': 'rdx54545@gmail.com',
                        },
                    },
                ],
                'shopPayOptInPhone': {
                    'number': '7584578457',
                    'countryCode': 'US',
                },
                'rememberMe': False,
                'setShippingAddressAsDefault': False,
            },
            'tip': {
                'tipLines': [],
            },
            'taxes': {
                'proposedAllocations': None,
                'proposedTotalAmount': {
                    'value': {
                        'amount': '0',
                        'currencyCode': 'USD',
                    },
                },
                'proposedTotalIncludedAmount': None,
                'proposedMixedStateTotalAmount': None,
                'proposedExemptions': [],
            },
            'note': {
                'message': None,
                'customAttributes': [
                    {
                        'key': '_source',
                        'value': 'Rebuy',
                    },
                    {
                        'key': '_attribution',
                        'value': 'Smart Cart',
                    },
                    {
                        'key': '_barId',
                        'value': '25649-1',
                    },
                ],
            },
            'localizationExtension': {
                'fields': [],
            },
            'shopPayArtifact': {
                'optIn': {
                    'vaultEmail': '',
                    'vaultPhone': '+17584578457',
                    'optInSource': 'REMEMBER_ME',
                },
            },
            'nonNegotiableTerms': None,
            'scriptFingerprint': {
                'signature': None,
                'signatureUuid': None,
                'lineItemScriptChanges': [],
                'paymentScriptChanges': [],
                'shippingScriptChanges': [],
            },
            'optionalDuties': {
                'buyerRefusesDuties': False,
            },
            'cartMetafields': [],
        },
        'attemptToken': 'hWNE2Hrh560Q8HwlQTSiDY9s-rf4sa65wnsh',
        'metafields': [
            {
                'key': 'views',
                'namespace': 'checkoutblocks',
                'value': '{"blocks":["65e74cec223370b17e7c4573"]}',
                'valueType': 'JSON_STRING',
                'appId': 'gid://shopify/App/4748640257',
            },
        ],
        'postPurchaseInquiryResult': 'DECLINED',
        'analytics': {
            'requestUrl': 'https://www.brio4life.com/checkouts/cn/hWNE2Hrh560Q8HwlQTSiDY9s/en/payment?_r=AQABNpjBWiBAR8qEiDMSzRsoRR1Etwq0DWMYomH_bFjvQyI&skip_shop_pay=true',
            'pageId': '25ecd9a2-B7A5-45CF-2761-B2E5DD320612',
        },
    },
    'operationName': 'SubmitForCompletion',
    'id': 'd175350fa2abc713b3171bd7eee3d6443861a7c884298fde2bea9d60abbebcf6',
}

response = requests.post(
    'https://www.brio4life.com/checkouts/internal/graphql/persisted',
    params=params,
    cookies=cookies,
    headers=headers,
    json=json_data,
)

# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"variables":{"input":{"sessionInput":{"sessionToken":"AAEBCiTqdD2ALpe35PiKKtth2nUbTkueF6ndbGoGg9Wmhfu3ExjXckFuXI8FHWe0iBL9_Cv46_mnoB7orcEN5EuKntRxNkAyVGQ1btU4FOG4VBYJkvFQQ3eKrxJ4DKBDK8zjrx5UTM22qzbBDP4mfzGUVhYT2vQO4UZuAQjjsQlFrrZiFhIr8c3FhxgKKrzGPqZ7C0CJhokxQLfcF3ULFe1quJPF3fnzjQ"},"queueToken":"A0lIw3_QOrl6hLWpMHs_OeYysjazx0WhZ_G4TbjrxX_jU71VV0-Zlbx7AZgywnZVvYgrfGHBRnKt_Y_JRdfEdhGF_BfzSxxCf6jGWddjNJhGimotYRe3EGlpkj5g","discounts":{"lines":[],"acceptUnexpectedDiscounts":true},"delivery":{"deliveryLines":[{"destination":{"streetAddress":{"address1":"New York Ave","address2":"","city":"Hudson","countryCode":"US","postalCode":"82515","firstName":"surya","lastName":"rawat","zoneCode":"WY","phone":"7584578457","oneTimeUse":false}},"selectedDeliveryStrategy":{"deliveryStrategyByHandle":{"handle":"968af053fc12067bfcf4cf1730787335-478a829601c831f110ee5ea50948d593","customDeliveryRate":false},"options":{"phone":"7584578457"}},"targetMerchandiseLines":{"lines":[{"stableId":"2d42c337-27f0-497f-af4b-10894fa1757e"}]},"deliveryMethodTypes":["SHIPPING"],"expectedTotalPrice":{"value":{"amount":"0.00","currencyCode":"USD"}},"destinationChanged":false}],"noDeliveryRequired":[],"useProgressiveRates":true,"prefetchShippingRatesStrategy":null,"interfaceFlow":"SHOPIFY","supportsSplitShipping":true},"deliveryExpectations":{"deliveryExpectationLines":[{"signedHandle":"Y8SissjmF7oXr4KNz0wv+t8V8gnYJqMUgFVNo6jVgHlKCtJVYROrQDalKljMK+lR2ahKUT7JG7UtgKRRUgNqW+gH2RH73cf4q6vSYsuQROGDRsdoXqbk2bBfLzGR5hVNdL9aTC4XcLs3a4X8k+OQFyb+PD1N/PoFVHcv3h8/6y/y8tYgxwQsPNwUuMuYZMfL9GjS8FVLr5xnyb8RNZFbPndnndLY4r7ra1Xfd+/wzv4eUyZTkxcg4wEbHlCPyerBhH949mE6owpCJqnfwY7Sv0AEe5m3131U5ZrMBppDHmRC3wSj3pdHTZx8VRIr3XrN7L88tvfPmAijaB8Ga35vqoa7Op9VVfwmOkpF7SwAHbtdAj+k8ScF8Gq1JeOjzf7gwZnssHPPE4BLRlP3e3eNMpfj4CwDd0jMSYmMjFcTnmgEKqYiME0VVcJo6kyjGXorJrmb8BNb6Dn5DZP31+15afPYs8A4NnLo3uNWEKrGqUhpUOFNQDZgjuVVo5zX1sWek9u5Trr9EbQ8ymVEs6QT6ASDjj3vZUqT/kwFkUz/vBKGCd2K09cP0jJp2MORfRxlGy4pzfJYmOS/BnBUFtqJKhnv3752HnojyAf4uJEbZDHU3gPs0py3Fkrn+qi8StMy3y0Mpj/emFTGwMwSH/ofyoC5pXWqZ3S91+m59E9eF488WjDKbLOceGHi1NPYt9JXTvo9bSNhwpAV9ujUTR8iVAvtP79JN0PkaPQes6oanwJrXoWaxXR+dgGNxiZQB4r2u0lunVXKRaXTMUMXRrDADLJMRUPxWa2zrT5BiaBWzVz5jzNFNHe9z/6iS9Ac1SS9cNGp/QYGeXKaH/ix3wJaKQYGmcj1EU3erIjnyusaW8FEhKuaFXJrHeTnVhXABTpEB+DSWTct9oEXx/rbpxLfrjJNWoj1jhd7aBE4O6lUHqsQA5V0ko5dHwPPv8s+jSPpqL3MvAUw5l/U0D2zG28CYtEkuZmwZZrEzq5Ztxfq98O+xakLSMNTfP5Wl9CyDFOFpFRMpPelR5wy0HaXzzVznO7J5+Eh8w6faA0Jl4kyONtd0kgqneZM88mr8SaBvCaj8CbqZEFovV0lA6G0X0XX4f47tsc0Qz1T7ijk8WZPPlaBny0Qpoi7yiaXQ/UerDI1WBt/rkPsL4/Q1I5JlAgiB24lbhRTEzjl9r/3NWtnFtTbwm6HJrukJOr+dbW8sWt7TvWIWhhUrH/+LYPSxd/mq0ADTAvz60y8LU26V4j++MORZ5Q1sft+7KJ27YIjTvclyYKtxnU3bzbxPFq7Og+KLXEIYMT5ZZXm1tbcYxG280ceKGLIr2GxgHqSvqJ2D7fOD/UfSAP54MFVCYpnMSzE7ViL4N5L1DtfgF2BaB8wPzkGd9l6a1KV6zdr2CCbFoxUUbz5CJ/G4hDjShUXtlGVjYops9Q/P0hwj+Fbnd4BkSNePCfH508y2WvGaNTwaNarIeZuizslzFi+y7PT5o8QUBp1IQpuvDHIu5sYKNPWaKbzDkJqYx+0Tw5AUSL4QkWpCZmfgFb0KpwW0OYO4y1ub9MBe8RKVBj6r9aMUiHcHGcvJUi/xgRb/LqeW2oBJeKkqS0H+0hgbeu+52TvhlXX1f6HC4AqWu0XSxfcLhCgkaQ2AO5gBBYhri0xaXFcMpd4ND8hpaGSud/vUvm7wW7KhHKpOTh/HGHH/XwepEo4IolaCcjXSjRwDPV73Ex9PA01OoBkNNoHKDKFGKPAUnPbb1U4MbpgszPWe0THBAPq09Ux0W+03HE/SJR2RnPL0mjuRPPlHDjdwaeZZLXuwTdCaPnppo6LhfJJcU/rhgbJlZLXtG5zTNDH0ngq1bJ9Ox42zH9XsFmb18/4YI1TKlTGG9cH/vKcNBLsZKXyPvbAPdeQY/wcwjIg0SAyaNgy3pPRt5VCs4cj1fuNwPSxf+lWFaDTXA6S8X/E5tHoPJcUkrq3WZeVxtKhwWltqD6KHzl2jfKcscQ7Eq5kaBKZxIEHcjckxzAUEdc8CK44xwa6Ik0xPD96r4voUYYSaG+391EQhH1WkitGNK5JLE7rkrJDJYhPuv+YxR+uvdXbnDoyvoLpXg1ypTUT2+0aSoGHzvo3RDgJ9LCOZHYt35Qj67j15/4utdHodKbqt5B7KroLsABx9h4OwGq52/wTYvPf7U6gL69sIxc1Lt1VTsLEYmkVXIwsJF4MmO2xk7xv+nC/MHz+I2aMPMLLdhSwganZ+dyYqWp0FUXxppySPlZgMGoCf54NfTtytaU7l3oLdpZuUL4AShe+RWrGvT22ECt3Z5a+/2te1ovA+GFnogGf70ClJMJJwoRUhFhCXAm/ioWnZbYq+x7z2Vce+c1f7MbQiWHc3aRQivSK3hUvIG4+LfPnuzdl3Na1UjK61ofWbeeHOG8RNUz2N5BvWswe2Llcr1CR/3u4zzCRpcLv/lEQ7gDakRDK8DOwmwjtbLqVb7HDvW15jmOUUquQUC+o9kTc2OfdckjicZS4d2XrXmfEtRAchhrg3jGWfB4SVFyYGWNpfNxotryH7CPoTbjapjjfCUvyD930iIDmkELntsyWELx/jRxi6H2yA3j+HFeaZUtvXmUktIkyvuzhZh4BTqTpO7lDtHd1JsQBA/+0EHhGvBrDNm0Ad4wIq3xZ37YGyWeWjLeV11/DOmXXPyzbIQyLvF1b43zfAvLjxgU3Mc6YVnzpJ5CRYH0x6Dim7KJq5OXKHTWrnirnIQXMuDm8QqMM+6DAfSSShT3m+TwgbxshPL3Vv1doLrAi0cJRJU35jL84EM8O5W6t9W8oTBnZXoYNO8RtiJKbUViviURoP87gmBoWB363Tp6Kw97obin2uTl1BEc8A+ZQg8bwfM8twMNbRgUgUqxqsUxEASyDPK+Ey7DAbfq0TXoIZMFBornaFNPpgQzkJQobwYjzyGLWRZN7R0S+LEE5woHYi+QZ6fU5w6N4N5SLrG/nD01qUrfUX4zO5T1gH9oRddKJqgyMrs1PFO7gE+yF4BVX+ZqNVIqg5pq5SHeswsJBatnT2MNn1mJrR2x21WU+0X3VaEx+/nvR+19DUxmjhsSwvWsSVFeT1ghXEGz+7I5btRI7jllGBJBLEJUESDKdScSMotb9DJorbFap9UoUNqLf+Ao7EjBc0tJE6GwcmXe9aLWG6Lgv69guRZBclw2MzTk89onpBgGPM00xIcXymFBfz0ERAwoYIX0KPNi20HSuZUcM4hPMUHj2YJqjfu16QtXwYyn8wUT2yEyVY71CkOWY59/44dxdOpMHKksCZH5Hn9kwWjoHMnPE1EjyGWbPog2FI4E1UdLT60c+gNdn75JJNCFobrbxz6bGftUcJeyGWI6p6VtRupOhnfnI41GF/an6Z4REV8v+uQaXBwizU6+vtrADkAz9RYf3WaEkwuTL31vU5Bx/OhipU+bSBYG+/NJHNKHeaZiuw9kYwXf69pb56fzowfp8yDYgLiKLYDcnpaghXAYq+ouxtjwJjB2w2nc+uS0Kp5zAb6xK4nfXgMrAX/sHLkLbv6nDSjLpZGdg6ER118GADEwq1yrmspMCNT6h3gHcuu9nIZoMB/b9/h5IYKv81qIR8YxYzgpJV4uK/dbUkhHKk43tQ7FIhC8I0rp5jexxHj0dA8TBJDnR03KJZGa4e+gbeHPrFsce9qmU7+9xrDA+5FvQNdZzbDE803RpHvrsqDcbleMafRy5IYgRn0QgCUU7bz32+BvOXgBtpPbsIpEqjzsduyLKJFxYenjbNVZ2VF/mzG3d+7HUcZd4VY7QKdFgX0A8VY/pgaWcU29OGfFH6iHj0AxHSJ27upmdZpmyId6pT/CT0fFwN+TaqthzO0s9WsyMNtNzgoJogYVPc8N2SVI7lGWAXilLuyGKjzwMNzZxml2STpKCR66Mmo1s3Bddslqs7wCqQBGmA5T8TkjubZKriVcLcsuV5i43sLrnLVhM1ep+zkMSuGCyTLMiWgEsgfjOlxjMvzjmbVxJfJfwRW1sbfkP9vqWoParqZKk+jvfxISJD3ygUhmQZWdr9Ezm2Tx0JlWAVWX8tUQaYqo7XoT2Q6idrYFUedOwxz46o8tDhycCFbgyv7UJ3FMIJn30qQ+BLJJ12Yc0Kxh0yxiDKHJlrekhbANe2qpvsw6uy39zos0i0hmv8XTvoxLfN/X5RnJ7b0CzJ+DMFSpdopnyyZjPiHgO3xKiY0zt1nWjKz2ZdUcWeDCAeKDQbwyaIfoZZdcm+K7llDqFoA6cDBUYNsEcIcUP5vkyUm7aeXV2bKaHbeAYMwIPRYQ/HR7T+di75+Nn5Md0a/hL9E5Aklt4NeiW33xwBJpPUvawOc5xNe//rl9Fy43IMPy/iYs9thUrCyo3uMZtfwnJ0mt3+cf/icqAtdNVDQjb6wdBO1aG4OMpKo6DTGz69r1+aWeLIxvwoCMps7iCOLuwehlwQkIFs8rf19+CmMKzMEpA1nVxlu3yxn/O6LRJipPkvtp1rLWGFeW8xjKcdvznODqKvDPEQS7QpnRbmfs0MvsjQgiaiUH2uZGEda42ZfTAQp3NGws4xihI2jF75ctQTlBSujqP+mvtCf/Pz6hO5EZj8im1FGxYhRhjArLoxRAwD2nwHuPkK+NSDGMrNXvd5v5q0HiyzAfo21GWTWMt9xWtiN3AM6eD70VDePQ7SqmfhSGwJMd0Kq2zFxIBXK3eXfVcwX46l2HU0CFa6UYY69TVj21o0Hv6L4RHDSYdMhoDCjS7J798iuigPtSv9GtpzoupR3wnQhwq3BypUGBBR4FGicv8oMZxXtytML0EtXCEfTnnVsP2pU0wOoYrp5/XXjkV37fya/6vEAhkSDsMa6Ltfft1aU7WQ6neTHI0Bd8M1cCNG4ENQymNit+OWcGxlEpaDZx6dH9QPhAgJGTJbApVY3TWVyBVOJqAi4AVqoL0knIHoFlUQRzDTgbhKPwEXHDJ7V3cmvF+iSae2Q==--MeVeU9nkloVwxWuL--ozP/TpaT5cBNs/3IwBtb8A=="},{"signedHandle":"ps2tG7gKuyLOuq7ZOxLLLpyVLga5FENPYxsv6YX3mA2hQkjl26inzPCl3knI7mdghHeHHLw6VLXffj6Ao3D0pNBRmyXa3RK892mTjW6UXfa1na5qIjkKqoYQg0/yZdEtN5SpO/Mtgog5AEYxdmojf/lShpWfeNnkG66Cki57a0BmIFQ88ubLQjHuQIoXKDo71Q8Ub4XKMhg4ce1VRyg50ula5d3C6j2+H1GKnvK6StVOKLEqae0WwgWa/w8nzAdjzlYIOY17eeDkZtKGj3xWdgzv6gswhhlfOzCn3sMQENP3srIyGBl7SFRik0mYOr2CyYzw/UKJKlbgnt9Fcmvi/d4F//sh6n+SwWGkJ12dBhBTKiWcnNfG2spT/WkzA4fe4f4z4nguUXzxbOGmbqXEwe/9EBNkKBaZ6Cd26PoddbGNnryuYATBQ1AIXOUoNuq2NAwvebNIYISYPeNSDX7C/zqrhqcgELSfUpAgrxRXNUrcY51ZwL65hI5P2Ex/LfcsXvBvkKcHqIO8fM91pTQ/4mHrEx/IK3vrTzJTi2WqZBX5L5cWwOcxzapKXvvsFpzY9w4paL3PAFAWNZ1HGt5eviPWKopijupBVrSr4dd5V5W8xmkGxsUmDip7WeeSvGxdbdloRSdtgo6z8s5l+KXejOi2BYEemWAeNg2ogEqJIMetVEi/2Gr+zKgbFTFTIsiFSqgGj+uEZw3PMMaycrSR34VWNTIxJ29cJu9YdB3oo5nzywHkuCnn/l/Im26zXJE5oSenePP16OH6JeO4df0ALIV8Oj3KEVaIunXI6AklqTUeaZprHbT+yxkFYCMPbXWDny1ZReOaur2+sbL73VjRasrK1ZEFVnW65bqHFaRZUoVRVO+XKF2q6w3oBGjaHCJtteeHLwhT6FwBJuNeaReXw90/Mz5o5bhxvY4k/mvz9O3Rk24AjXaR0xUA3w+MaFn+I1ll2o/cFHEXHF8SPhZ6zLTvo4BvZHPqFgimjHKZ9efM6jNiiD0ouVUkFiCLKy6c374uHzOUixY0HRXNIhk1pg5YeFRlNNe59T/GXO2MbunwYSyGQ44nVd/HZiZFf71CT9LWPch8LudppvHzKjkmSEh5457VBNrrudEuc4jPpRVKFVE+I2sAFO9dcwSGxekkH9WWtkPL7VPmN9B0/l1uOIZSDQZrG66U+I1JYLFnwm0ikgZp9BpRcS9Yw4JA6uMunycNhKnJVtYYKrQBBrHLY2F1P1V4feSHKO7RET5r3FQPBXKayC6XLlGGA1gFOO+mmDeAGj5Zch35s4UKRNyg2aBjSzNc//7+Ptg6j8OGG65JLU0CO3bo3XK4VrBIizoDXwLp5bpLkO9u3ENy7DbKrWs8uOi6TbC2HSGP84VK7X0n8o2GBomHAliLd7UdDMhBHSqWnuJspGE/s5ncsEzKKDOMs1E0E4ko9qQB9i1WsKxuK0cDsmYEtDCa3AaTc2CrbJBJge+4/fSaNKLnofIVhr1HNsaZX97AbT/zboFQhFqNdFPNnT0IL6cLv/OWlyRsV/uCLqMvosOILXX19YFceTr2HGc/K+awMsIU8qb/6Pav9GteUbWPRbRd6vfPDdur65doIi+WKuK/GvT3MZQLjef8I3j2Z5W0CU0iDFo0zq6P2xGgxYotUvUOizIlbV3Fv/r30CCbX1lRQ0xbBRxJcnZ4ne4EzJz9wz3am7TC3WSxA5xKHmNV6dNGyKey6RuM2INSp99t8wpgWA+LQu8Yxx/uYdzLo3/dC5lTHMQTjtCOdHYbjuvNlCZ8HX2fsHdHrMak1quCJoSmvbQYjIpvTcL7GQCBfhzJiclLJw7YaVCIMBhAsEO2RT5S7mtVz4XtRpYcm2zdoEEpzne2X2UREvbRX6Lk0CTDpAnPCiqRIDTTnTum8AZy08cXWOo6hV1Xahd6vlpCqhpA82F+bGUcPtr02XqwOZ3+XX6AmJ0osmm1fUgpq/BiwnUixrZQ02oWHcrztD8Anx3EJV0SsRsHn/+Vv2ghYMoA5BRglMVWdJvigJXuZV+bFn5dJa1wadeLJfDXbeB5IJbrMP7ouqgRZUvG5Ot6+3X5c5a4bjZrQ61FJlmgMO/TMm/0XygWDcFaba5lKPuPcIoAqNHWJY4xA6uUyxhofQ8QZuDaPzVdWZ0fFEYvAnSktbhfoAjBBrgNQ2oU/OIReeWR3dCw595qZviIygTn5mydS2VLnPa9jOzZT4lFt1J1K5leS/3I+l4ZHI9x1NyxjBq7nWtC5t0BmPeVXP8UGHOAupW4XRu139yfGRNIRswXWU7N7DPbXGY3yARRtl1TzoVYmvbX2KQEkslxxH3/WF9gOH+g1POIU8eb5tr3ax+F/cf5g9BsnSxQbjr/apQ2arwM5uJAzKCHaoKk6JNRAwo3qsYsrbsQTTr5Ub2dLmb5TM5EHsNsqO3ZAIpR+Q/VqI4xCdCMLqpnKLIelacbix2EvOhUxSDar+7NSd8HpIYVoLdetXmjzupgMmmnvouGdvn/A25XgWEGm7T13732Ta8wRihr3cnEhNxMCjEZ08wJCbPW6AA1dr8ToltgFWyGrQv45ISe5p0yjwaf7o38gdD4ltWlqSG9cPdTheJQJTmPEqoMlg6IUK1PQWqBpDHmqP9dYeIOAfsFcHN0fzUPqv5iJFWp1CBgivFPvzeEbXJ3iK3Wq4ZPgwbGcZRUjFHE/sFZTDfc3t/0m3UjkgiQD4YWQJmtiOZKUFtZY3kDvAMgJsNwI2FIpga4cagkmXEKvteD1kleZnALrk68/FzxmcaK5xrJyHH12cLlt3PVdmt4wm1b82MgkZEwfecS6pg24mHayWQa+4NBnMj9pjIM4b1a5La7PIgLVAlvr5+bqdEFcIOIDjf72DnlA90T8MseU4Frtd+FMJVcfl3DG3HLEb/4RcpJ0Iok9Wd2r0Vc481+QUUajaMFdYPifFn2FI52pIHclCVa7xCQ++UELQs9SL3L2nHEs4KGES8MuDJMDWyl0Q7TvkV/7jcUiSO8k7Udnl5aAAY9AL+dZI9GhxLoHyaqS0UFBjGA81aF3+WNJgGo7Q1KS0To/FPLTGGrXLLW8523KpKjQKExAJP80wI5xqdKa9iHZq/Lsxn2H3Yoi4t0+bg4agMxjC/XZLGXqqVLKYUQ8HNda2W1krZrmi31Hz2LUknm43+EYqbOQHdnpdcPsE28IjnMS5Vns15R7V1SQ+wTf7obdOVltmfXjDud3TXI7d8ZaabVYaoqRJ7qj5yPBeJrAeiZ2kkU9wBjabexryPyRkTmfN/2aQTSezqCUYWMju0V6+2U1bFwvXeEhVkguJdsApHYUxHPFHKoxhMPMh4yon6Hi/mZy2kXwXAZtihqt6xAw4+VTj22kYQSFKb0O+squUsoLhnwC97vWhsWgb6UHd7rBeAvo05Kid8BCzxoRBNzhyDj7eVF55x8SOObF44sJyRAu62c4zmjTunAfCc5by5Dv1DDfGcoH97F1DdMKUdBg1UYNPxnRjRJmEZMObKS29V8E/tDb5mCK+phPuaeumaTTSaKIcYPA+ExLogrHAoqp09MSCujj259tEvg0MPGxCISOQ7Lg7CcsyO/LfLb9a+rf/2dmXSizKqnoskPpoQZK9K5QhBhQzrWSpn12kXgKUNkpY1BsCjLzb1w0hPaM0vCu9F9y3IHbd4hIBpezcjGnqztmnrsIvwiHI2rcjfcPz+pq6wYDUVKWDkGHeCf43aPu+LHsiQ4HxThY/y0h8brEEuAYK8SuqFbXgCEvz6mkCcbblDUxD/5LE2AkQklE7G9Qz0oemjPxVfw7dvfjdmGT6YJJxG6F7deBHoYWa8HXcQXvjaIjqcszPJiBgs1I3a4QUZ4I/KiWwUoe+aDrSd6mEdjYxrfQD20ArE3LufRrQwlzpWNCrmakMDkd12IqCTdDE3CDzF662lhVqjtlxOEtAbGOscW965JsRVum2nUFhL1BIjTigITiu8KyDiZaXk/9G7INlbSjS89PBGRZfIvqlyJu6zP9D2IdswcqeFYgGyxB5nJYc9FsEzkbBKcz+gHHwPkZVyU7pqDuckKmgpoCBvLZT1ds5n1jLOSM8B8RUBpiAsfGjYsXk+ljmbp1vGfvlyPL5nwcYLwSuYrgFoQgNhF3VCgjVdYo4nypI5e0IEeCUQXfOJn+tsmRjoyqU7hZtsB6E2PBgMoJSXi0dM+sAwoBMVUY1ZRDOCzZd6Tgop3C1CVVaXhDpABna3Pe5Nkc+3qD3xc8z3N9A0E+yrtFCJxiRiyx42+rt7DrEoGiiQLSwSsBIFYUBBK2LHIOzmTUHkoeYgT8bWQZY48H+6mKoG6rbfeZ5IEa4UOdVZYyDdSY7OCbmxzoe5uc5C1ehxtWTryDIWsUneSA93Tw7p5r9Itt0/hNQQeLozuS3IuuM4P9S1y5qzvOS153lCGIEf+ZhSYkFj6WLTOQlTJOB3FPkhbIc/SiFycIoyKHaJa5GVT/ZVqvfTJ5hSAA7raWFz1xWieZiys4/lu8AqDFH71LCx4tvqC97cJ3EydI0gz0klvCy+QrL02/xypcaz7zPvt7NuLUfcMPnzHm1Nia1xpqLuxwR5MscE8xHOfrDvASwbc7uEhx8R897hziz+Bsx2b+b/xVjWpIsvNdGzwyITe0GOBAXDtIhmyfsplc0FdIWwIfheND6zGWQjIvKk+rrWRMob6WGhowhfU67kV1iVyiHNtOPdDi8WFauSqkIRf94fqI8QFicOtOPHO1uH9++Gho2fxKRoH2E2QctoKIh9Hb++gZ++KqjKTAuAsKXEaTa12BULN13Kw0pM1/KiXVHzi3czKwHlXUgq0zfZApVT+6sgtiCI1IQtr/+BEADVOGS756SLW1IczUfJhrLEWo3YIP0PshdMtYoX7aUfqmbURk2KxAHzADqS9fZ6DnKieYkzdL1XeDEFIOfjbaf7qVMWWzsSPIFmYnT0Vy6m8EURrbl3U--WliOrAzwvrjOGYWP--rCkJgq/5Vtb+AAQcAJIswA=="}]},"merchandise":{"merchandiseLines":[{"stableId":"2d42c337-27f0-497f-af4b-10894fa1757e","merchandise":{"productVariantReference":{"id":"gid://shopify/ProductVariantMerchandise/39980963135565","variantId":"gid://shopify/ProductVariant/39980963135565","properties":[],"sellingPlanId":null,"sellingPlanDigest":null}},"quantity":{"items":{"value":1}},"expectedTotalPrice":{"value":{"amount":"89.95","currencyCode":"USD"}},"lineComponentsSource":null,"lineComponents":[]}]},"memberships":{"memberships":[]},"payment":{"totalAmount":{"any":true},"paymentLines":[{"paymentMethod":{"directPaymentMethod":{"paymentMethodIdentifier":"dc2c83c064fc75ebc5dfa2b5bee4f873","sessionId":"west-0aa1f7ca996ee5192f1b06a160e6dfc1","billingAddress":{"streetAddress":{"address1":"New York Ave","address2":"","city":"Hudson","countryCode":"US","postalCode":"82515","firstName":"surya","lastName":"rawat","zoneCode":"WY","phone":"7584578457"}},"cardSource":null},"giftCardPaymentMethod":null,"redeemablePaymentMethod":null,"walletPaymentMethod":null,"walletsPlatformPaymentMethod":null,"localPaymentMethod":null,"paymentOnDeliveryMethod":null,"paymentOnDeliveryMethod2":null,"manualPaymentMethod":null,"customPaymentMethod":null,"offsitePaymentMethod":null,"customOnsitePaymentMethod":null,"deferredPaymentMethod":null,"customerCreditCardPaymentMethod":null,"paypalBillingAgreementPaymentMethod":null,"remotePaymentInstrument":null},"amount":{"value":{"amount":"89.95","currencyCode":"USD"}}}],"billingAddress":{"streetAddress":{"address1":"New York Ave","address2":"","city":"Hudson","countryCode":"US","postalCode":"82515","firstName":"surya","lastName":"rawat","zoneCode":"WY","phone":"7584578457"}},"creditCardBin":"51377082"},"buyerIdentity":{"customer":{"presentmentCurrency":"USD","countryCode":"US"},"email":"rdx54545@gmail.com","emailChanged":false,"phoneCountryCode":"US","marketingConsent":[{"email":{"consentState":"GRANTED","value":"rdx54545@gmail.com"}}],"shopPayOptInPhone":{"number":"7584578457","countryCode":"US"},"rememberMe":false,"setShippingAddressAsDefault":false},"tip":{"tipLines":[]},"taxes":{"proposedAllocations":null,"proposedTotalAmount":{"value":{"amount":"0","currencyCode":"USD"}},"proposedTotalIncludedAmount":null,"proposedMixedStateTotalAmount":null,"proposedExemptions":[]},"note":{"message":null,"customAttributes":[{"key":"_source","value":"Rebuy"},{"key":"_attribution","value":"Smart Cart"},{"key":"_barId","value":"25649-1"}]},"localizationExtension":{"fields":[]},"shopPayArtifact":{"optIn":{"vaultEmail":"","vaultPhone":"+17584578457","optInSource":"REMEMBER_ME"}},"nonNegotiableTerms":null,"scriptFingerprint":{"signature":null,"signatureUuid":null,"lineItemScriptChanges":[],"paymentScriptChanges":[],"shippingScriptChanges":[]},"optionalDuties":{"buyerRefusesDuties":false},"cartMetafields":[]},"attemptToken":"hWNE2Hrh560Q8HwlQTSiDY9s-rf4sa65wnsh","metafields":[{"key":"views","namespace":"checkoutblocks","value":"{\\"blocks\\":[\\"65e74cec223370b17e7c4573\\"]}","valueType":"JSON_STRING","appId":"gid://shopify/App/4748640257"}],"postPurchaseInquiryResult":"DECLINED","analytics":{"requestUrl":"https://www.brio4life.com/checkouts/cn/hWNE2Hrh560Q8HwlQTSiDY9s/en/payment?_r=AQABNpjBWiBAR8qEiDMSzRsoRR1Etwq0DWMYomH_bFjvQyI&skip_shop_pay=true","pageId":"25ecd9a2-B7A5-45CF-2761-B2E5DD320612"}},"operationName":"SubmitForCompletion","id":"d175350fa2abc713b3171bd7eee3d6443861a7c884298fde2bea9d60abbebcf6"}'
#response = requests.post(
#    'https://www.brio4life.com/checkouts/internal/graphql/persisted',
#    params=params,
#    cookies=cookies,
#    headers=headers,
#    data=data,
#)


#pollforreceipt

import requests

cookies = {
    'localization': 'US',
    'cart_currency': 'USD',
    '_shopify_y': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '_shopify_s': '34c04ebc-916c-411b-81ed-a96eb4254660',
    '_gcl_au': '1.1.977159562.1783047675',
    '__thoughtmetric_uid': '9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d',
    'shopify_client_id': '32ff57fe-02c2-4ea4-a4c1-6920447b41fd',
    '__kla_id': 'eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==',
    '_ga': 'GA1.1.1085245625.1783047676',
    '_clck': 'i29uxr%5E2%5Eg7f%5E0%5E2375',
    '_rsession': '1c1bdadc8fb138dd',
    '_ruid': 'eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D',
    '_fbp': 'fb.1.1783047675744.654578204850518711',
    '_scid': 'xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H',
    '_omappvp': 'vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1',
    'cart': 'hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092',
    '_clsk': '1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect',
    '_scsrid_r': '',
    '_scid_r': '0IyEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYzRnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbs',
    '_shopify_analytics': ':AZ8l7F8VAAEA2bE0RDxBgZoyj6Ne-fp7kYaUe9oBelA0j6Y7N-Dq6y0LSQ5TzEeu3hpSFV9X1q4ddNkuYzqc3rQLvQYeRdqeMhm19U71PsYbuePTvVb5bUA663y5tZF-H5Dp8UouXLgP-ioDw73oR-v7c0W4lay3B574i5OskI8LOA:',
    '_shopify_marketing': ':AZ8l7F8VAAEAeA1IwBAVAl4atfOYlkh1QVY63cXz_WpUEgHArhG9jG7ka-dgOmLl_Y8AwinzJtDSxZYXJ444aHdobefqKVkEFt6x74jGFj3CFSFrs--OqNJwhMioqrYlzjUB-Pqg8u99YffOg08rdloBwT6nNp94wQ:',
    '_omappvs': '1783047705050',
    '_ga_LYEFQV8SJD': 'GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0',
    '_ga_CBJJ1LQ15S': 'GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0',
    '_shopify_essential': ':AZ8l7F6aAAEAXirGy9WdvVlDs8ii9NSW7sc83Gkuk184zyWeqICqtqMhGrIwFkHTwueHnSSHVjgftQJ7tksMvlglKs5xa-nAkDxCPDLPtQv4aVR-3Ma3CzdQS_v4shF9xRC9GNmKwZpuwbLvtMBAm7TaT7bYJgQ-5lZ5FhdHIdBnhAY4oR1jvA8UX8eCJkoP_iC6UUGXBXi4In2L3CIg6Ay5HTpvKj8b-lb89HDMK_FP3wRONJyIFGRZ0SP5YLr4i1gT5tDnPiE9vHm-wlRErk6XwIZVO_iXpftKbaPAJdBbm3M3h6pnNYjd8k5xcG3VPeTwe9dkZzb7BxrnMjuhJH4ah2B6Nqctye5Vd9Kz20LRcbRdB1-LuUgYJJWkvlGG-oFj0pFCv8NjKVdqTtDDDKWcc6VikRuA5Wb4FxDJpcJkACpVShO2g1TUtPo3H_XOhYXkCO6WoGKZx_j0M9u141f1Os93kSuwDb2l_xZpo9I9PvcLamng7ZmCmpCci9wtbfMmvJZbrp_aMruygtcxPudASQJCKKXsyZWH9EKta9wG8V-oFGj6l9Zy46fbmHHq2oGmAIr6tWIz-KNFGt1VAV78LrRKp9LFnbpAMQg9vU-Nm7qkYSrBHznRJtj_-2WJL2uHaZk5SV4znRXKMkIasgiHNsrzSU9Cn_FRNGWqxjLUChEpDWewl8dnNVtF3ggjC31oerYWr8mhYas6MGVW1rL1UCeS0KTOebt7Z3VwqeNlxNRI-ImrssGXTytWY-xJwoNvoT7OBY1vVzFkufgks-tz3BZrMhxk9DSDFu1EBS1IQDH5zqyen_kdXboikK27Kwg:',
    'shopify_pay': 'WitRZmtHaUNnMWtueHR4MXdSUDZSK0EybGJ2VC9LQjRVc3M1NlVLN0p1Q2lkRjI3U1ZxSTUrb2FmMmRBakNzNldLZ2VGaW1YZS9QcmhGTTd1VVVEUTZzd3hUZTVIR2NWWWlwcCt4a0ZDMUFrWkVUS1I3TEJDZmR5NG9NczE2Y3BMZjVOVElPRkV4MVZEN01YS05ZcWIwSkRXbjhwVlhWNmgwODBjWmg5by9pVFpSRndhMUMxTVY0REZ3dEl5aitSdTlxekhOL2FQcGNaNG9CdnNMY1F2Rnloa2ZBc0dKN1N0enpmWHV6a01XdW5VZHAwcFVZYzlxbmZUWGN3ZzRZdC0tN2E2QWg1SmVGZmFaUGgwcEV5QU5yZz09--af6223169eb35cd939a2e33f6b620e88085a7501',
    '_scida': 'MOcy_1f-AsKtpCDBaSBEe0H9_naJILHc',
}

headers = {
    'accept': 'application/json',
    'accept-language': 'en',
    'content-type': 'application/json',
    'origin': 'https://www.brio4life.com',
    'priority': 'u=1, i',
    'referer': 'https://www.brio4life.com/checkouts/cn/hWNE2Hrh560Q8HwlQTSiDY9s/en/payment?_r=AQABNpjBWiBAR8qEiDMSzRsoRR1Etwq0DWMYomH_bFjvQyI&skip_shop_pay=true',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'shopify-checkout-client': 'checkout-web/1.0',
    'shopify-checkout-source': 'id="hWNE2Hrh560Q8HwlQTSiDY9s", type="cn"',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
    'x-checkout-one-session-token': 'AAEBCiTqdD2ALpe35PiKKtth2nUbTkueF6ndbGoGg9Wmhfu3ExjXckFuXI8FHWe0iBL9_Cv46_mnoB7orcEN5EuKntRxNkAyVGQ1btU4FOG4VBYJkvFQQ3eKrxJ4DKBDK8zjrx5UTM22qzbBDP4mfzGUVhYT2vQO4UZuAQjjsQlFrrZiFhIr8c3FhxgKKrzGPqZ7C0CJhokxQLfcF3ULFe1quJPF3fnzjQ',
    'x-checkout-web-build-id': '629a7d0a1d675e5c3b08a3e62d6818fb3e014528',
    'x-checkout-web-deploy-stage': 'production',
    'x-checkout-web-server-handling': 'fast',
    'x-checkout-web-server-rendering': 'yes',
    'x-checkout-web-source-id': 'hWNE2Hrh560Q8HwlQTSiDY9s',
    # 'cookie': 'localization=US; cart_currency=USD; _shopify_y=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; _shopify_s=34c04ebc-916c-411b-81ed-a96eb4254660; _gcl_au=1.1.977159562.1783047675; __thoughtmetric_uid=9f1eb1e2-10bd-486c-ae31-4c4a65a6f84d; shopify_client_id=32ff57fe-02c2-4ea4-a4c1-6920447b41fd; __kla_id=eyJjaWQiOiJOMll4TnpWalptWXRaVFpoTlMwMFpUTmxMV0l4TUdZdE9UTTFOVE0zTnpaa1pqVXcifQ==; _ga=GA1.1.1085245625.1783047676; _clck=i29uxr%5E2%5Eg7f%5E0%5E2375; _rsession=1c1bdadc8fb138dd; _ruid=eyJ1dWlkIjoiODAyYTBmN2ItMThhMS00ZjRkLWJlNjItN2MxYTAyYTdhNmRiIn0%3D; _fbp=fb.1.1783047675744.654578204850518711; _scid=xgyEwGZeS5m9t6pSiWkII_ARQEeYeP4H; _omappvp=vVfWx9xwuxX0TDwwChni98fdmYdVAWe8NxH2XXQB7BouQJRJdoa4akcXZHMycnwVnUhUAfDozA2f3astUQILfGMelCZgj8K1; cart=hWNE2Hrh560Q8HwlQTSiDY9s%3Fkey%3D67147df031a867a059214c51619bf092; _clsk=1j7scj5%5E1783047681584%5E2%5E1%5Ey.clarity.ms%2Fcollect; _scsrid_r=; _scid_r=0IyEwGZeS5m9t6pSiWkII_ARQEeYeP4HRFEVYzRnMv9X_gLCraQgwWkgRHtB_f52iRi1nyQYUbs; _shopify_analytics=:AZ8l7F8VAAEA2bE0RDxBgZoyj6Ne-fp7kYaUe9oBelA0j6Y7N-Dq6y0LSQ5TzEeu3hpSFV9X1q4ddNkuYzqc3rQLvQYeRdqeMhm19U71PsYbuePTvVb5bUA663y5tZF-H5Dp8UouXLgP-ioDw73oR-v7c0W4lay3B574i5OskI8LOA:; _shopify_marketing=:AZ8l7F8VAAEAeA1IwBAVAl4atfOYlkh1QVY63cXz_WpUEgHArhG9jG7ka-dgOmLl_Y8AwinzJtDSxZYXJ444aHdobefqKVkEFt6x74jGFj3CFSFrs--OqNJwhMioqrYlzjUB-Pqg8u99YffOg08rdloBwT6nNp94wQ:; _omappvs=1783047705050; _ga_LYEFQV8SJD=GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0; _ga_CBJJ1LQ15S=GS2.1.s1783047675$o1$g1$t1783048093$j51$l0$h0; _shopify_essential=:AZ8l7F6aAAEAXirGy9WdvVlDs8ii9NSW7sc83Gkuk184zyWeqICqtqMhGrIwFkHTwueHnSSHVjgftQJ7tksMvlglKs5xa-nAkDxCPDLPtQv4aVR-3Ma3CzdQS_v4shF9xRC9GNmKwZpuwbLvtMBAm7TaT7bYJgQ-5lZ5FhdHIdBnhAY4oR1jvA8UX8eCJkoP_iC6UUGXBXi4In2L3CIg6Ay5HTpvKj8b-lb89HDMK_FP3wRONJyIFGRZ0SP5YLr4i1gT5tDnPiE9vHm-wlRErk6XwIZVO_iXpftKbaPAJdBbm3M3h6pnNYjd8k5xcG3VPeTwe9dkZzb7BxrnMjuhJH4ah2B6Nqctye5Vd9Kz20LRcbRdB1-LuUgYJJWkvlGG-oFj0pFCv8NjKVdqTtDDDKWcc6VikRuA5Wb4FxDJpcJkACpVShO2g1TUtPo3H_XOhYXkCO6WoGKZx_j0M9u141f1Os93kSuwDb2l_xZpo9I9PvcLamng7ZmCmpCci9wtbfMmvJZbrp_aMruygtcxPudASQJCKKXsyZWH9EKta9wG8V-oFGj6l9Zy46fbmHHq2oGmAIr6tWIz-KNFGt1VAV78LrRKp9LFnbpAMQg9vU-Nm7qkYSrBHznRJtj_-2WJL2uHaZk5SV4znRXKMkIasgiHNsrzSU9Cn_FRNGWqxjLUChEpDWewl8dnNVtF3ggjC31oerYWr8mhYas6MGVW1rL1UCeS0KTOebt7Z3VwqeNlxNRI-ImrssGXTytWY-xJwoNvoT7OBY1vVzFkufgks-tz3BZrMhxk9DSDFu1EBS1IQDH5zqyen_kdXboikK27Kwg:; shopify_pay=WitRZmtHaUNnMWtueHR4MXdSUDZSK0EybGJ2VC9LQjRVc3M1NlVLN0p1Q2lkRjI3U1ZxSTUrb2FmMmRBakNzNldLZ2VGaW1YZS9QcmhGTTd1VVVEUTZzd3hUZTVIR2NWWWlwcCt4a0ZDMUFrWkVUS1I3TEJDZmR5NG9NczE2Y3BMZjVOVElPRkV4MVZEN01YS05ZcWIwSkRXbjhwVlhWNmgwODBjWmg5by9pVFpSRndhMUMxTVY0REZ3dEl5aitSdTlxekhOL2FQcGNaNG9CdnNMY1F2Rnloa2ZBc0dKN1N0enpmWHV6a01XdW5VZHAwcFVZYzlxbmZUWGN3ZzRZdC0tN2E2QWg1SmVGZmFaUGgwcEV5QU5yZz09--af6223169eb35cd939a2e33f6b620e88085a7501; _scida=MOcy_1f-AsKtpCDBaSBEe0H9_naJILHc',
}

params = {
    'operationName': 'PollForReceipt',
}

json_data = {
    'variables': {
        'receiptId': 'gid://shopify/ProcessedReceipt/b841f7e10d6d33725a37d3da61bbe6f0',
        'sessionToken': 'AAEBCiTqdD2ALpe35PiKKtth2nUbTkueF6ndbGoGg9Wmhfu3ExjXckFuXI8FHWe0iBL9_Cv46_mnoB7orcEN5EuKntRxNkAyVGQ1btU4FOG4VBYJkvFQQ3eKrxJ4DKBDK8zjrx5UTM22qzbBDP4mfzGUVhYT2vQO4UZuAQjjsQlFrrZiFhIr8c3FhxgKKrzGPqZ7C0CJhokxQLfcF3ULFe1quJPF3fnzjQ',
    },
    'operationName': 'PollForReceipt',
    'id': 'cb31a1b2197416d7441bf789defc306069c385c558764a58648f18cba899a29a',
}

response = requests.post(
    'https://www.brio4life.com/checkouts/internal/graphql/persisted',
    params=params,
    cookies=cookies,
    headers=headers,
    json=json_data,
)

# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '{"variables":{"receiptId":"gid://shopify/ProcessedReceipt/b841f7e10d6d33725a37d3da61bbe6f0","sessionToken":"AAEBCiTqdD2ALpe35PiKKtth2nUbTkueF6ndbGoGg9Wmhfu3ExjXckFuXI8FHWe0iBL9_Cv46_mnoB7orcEN5EuKntRxNkAyVGQ1btU4FOG4VBYJkvFQQ3eKrxJ4DKBDK8zjrx5UTM22qzbBDP4mfzGUVhYT2vQO4UZuAQjjsQlFrrZiFhIr8c3FhxgKKrzGPqZ7C0CJhokxQLfcF3ULFe1quJPF3fnzjQ"},"operationName":"PollForReceipt","id":"cb31a1b2197416d7441bf789defc306069c385c558764a58648f18cba899a29a"}'
#response = requests.post(
#    'https://www.brio4life.com/checkouts/internal/graphql/persisted',
#    params=params,
#    cookies=cookies,
#    headers=headers,
#    data=data,
#)

# shipping method

import requests

headers = {
    'Origin': 'https://www.brio4life.com',
    'sec-ch-ua-platform': '"Windows"',
    'Referer': 'https://www.brio4life.com/checkouts/cn/hWNE2Hrh560Q8HwlQTSiDY9s/en/shipping?_r=AQABPxVAQEZHjrhHQLonrKUOfcOPHsNMMA6kzHqRmW2I-gM&skip_shop_pay=true',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    'sec-ch-ua-mobile': '?0',
}

response = requests.get(
    'https://www.brio4life.com/cdn/shopifycloud/checkout-web/assets/c1/ShippingMethodRateLabel.CKXnnXQr.js',
    headers=headers,
)

#addres form

import requests

headers = {
    'Origin': 'https://www.brio4life.com',
    'Referer': 'https://www.brio4life.com/checkouts/cn/hWNE2Hrh560Q8HwlQTSiDY9s/en/information?_r=AQABPxVAQEZHjrhHQLonrKUOfcOPHsNMMA6kzHqRmW2I-gM&skip_shop_pay=true',
}

response = requests.get(
    'https://www.brio4life.com/cdn/shopifycloud/checkout-web/assets/c1/BillingAddressForm.BJfgHHbt.js',
    headers=headers,
)