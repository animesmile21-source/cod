import sys, asyncio, os, re
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

import requests
import database.db as db

CANDIDATES = [
    "https://dilaboards.com",
    "https://www.meriwetherwatchband.com",
    "https://shop.gremlinshop.com",
    "https://store.ransomed.org",
    "https://buildyourbundle.com",
    "https://www.trinityoncampus.com",
    "https://www.firstbaptistdecatur.org",
    "https://www.gvbaptist.com",
    "https://give.realchurch.org",
]

def test_site(site_url, proxy_dict):
    user_ag = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    
    url = f"{site_url}/my-account/add-payment-method/"
    if "dilaboards" in site_url:
        url = f"{site_url}/en/moj-racun/add-payment-method/"
        
    try:
        r = requests.get(url, headers={'User-Agent': user_ag}, proxies=proxy_dict, timeout=10)
        
        # Check if WooCommerce + Stripe key exists
        pk = None
        pk_match = re.search('"key":"(.*?)"', r.text)
        if pk_match:
            pk = pk_match.group(1)
        else:
            pk_fallback = re.search(r'pk_live_[a-zA-Z0-9]{24,}', r.text)
            if pk_fallback:
                pk = pk_fallback.group(0)
                
        if pk:
            nonce_match = re.search('"createAndConfirmSetupIntentNonce":"(.*?)"', r.text)
            if not nonce_match:
                nonce_match = re.search(r'\"_ajax_nonce\"\s*:\s*\"([a-f0-9]+)\"', r.text)
            nonce = nonce_match.group(1) if nonce_match else "None"
            
            return {
                "url": site_url,
                "status": "WORKING",
                "pk": pk,
                "nonce": nonce,
                "details": f"Stripe key found: {pk[:25]}... | Nonce: {nonce}"
            }
        else:
            return {"url": site_url, "status": f"FAILED (HTTP {r.status_code}, no key found)"}
    except Exception as e:
        return {"url": site_url, "status": f"ERROR: {str(e)[:40]}"}

async def main():
    await db.init_db()
    proxies = await db.get_working_proxies()
    print(f"Loaded {len(proxies)} working proxies from DB.")
    
    # Try with first 5 proxies
    for i, p in enumerate(proxies[:5]):
        p_url = f"http://{p['username']}:{p['password']}@{p['host']}:{p['port']}" if p['username'] else f"http://{p['host']}:{p['port']}"
        proxy_dict = {"http": p_url, "https": p_url}
        
        print(f"\n--- Testing with Proxy #{i+1} ({p['host']}:{p['port']}) ---")
        for c in CANDIDATES:
            res = test_site(c, proxy_dict)
            if res["status"] == "WORKING":
                print(f"  [OK] {res['url']} -> {res['details']}")
            else:
                if "dilaboards" in c:
                    print(f"  [FAIL] {res['url']} -> {res['status']}")

if __name__ == "__main__":
    asyncio.run(main())
