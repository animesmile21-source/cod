"""
Test WordPress.org Support Forum + Public Sources Mining for WooCommerce Sites.
Harvests real WooCommerce shop domains submitted by merchants on WP.org plugin support forums!
"""
import asyncio, aiohttp, json, sys, re
from urllib.parse import urlparse, unquote

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

WP_FORUM_URLS = [
    "https://wordpress.org/support/plugin/woocommerce-gateway-stripe/",
    "https://wordpress.org/support/plugin/woocommerce/",
    "https://wordpress.org/support/plugin/woocommerce-gateway-paypal-express-checkout/",
    "https://wordpress.org/support/plugin/woo-stripe-payment/",
    "https://wordpress.org/support/plugin/woocommerce-payments/",
    "https://wordpress.org/support/plugin/give/",
    "https://wordpress.org/support/plugin/give-stripe/",
]

# Generate 10 pages for each plugin support forum
EXTENDED_FORUM_PAGES = []
for base in WP_FORUM_URLS:
    EXTENDED_FORUM_PAGES.append(base)
    for p in range(2, 11):
        EXTENDED_FORUM_PAGES.append(f"{base}page/{p}/")

SKIP_DOMAINS = {
    "wordpress.org", "wordpress.com", "woocommerce.com", "github.com",
    "stripe.com", "paypal.com", "google.com", "bing.com", "youtube.com",
    "gravatar.com", "w.org", "schema.org", "twitter.com", "facebook.com"
}

def clean_domain(url_str: str) -> str:
    try:
        p = urlparse(url_str)
        domain = p.netloc.lower().lstrip("www.")
        if domain and "." in domain and domain not in SKIP_DOMAINS:
            return f"{p.scheme}://{p.netloc}"
    except Exception:
        pass
    return ""

async def test_wp_forum_harvesting():
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    found_domains = set()

    print("=" * 80)
    print(f"🚀 Mining WooCommerce Merchant Sites from WordPress.org Support Forums ({len(EXTENDED_FORUM_PAGES)} pages)...")
    print("=" * 80)

    connector = aiohttp.TCPConnector(ssl=False, limit=20)
    async with aiohttp.ClientSession(connector=connector) as session:

        async def fetch_forum_page(url):
            try:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=12),
                    headers={"User-Agent": ua}
                ) as r:
                    if r.status == 200:
                        html = await r.text(errors="ignore")
                        # Extract external domain URLs posted by shop owners seeking support
                        for m in re.finditer(r'href=["\']?(https?://[^"\'\s<>&]+)', html):
                            raw_url = unquote(m.group(1).rstrip("&"))
                            dom = clean_domain(raw_url)
                            if dom:
                                found_domains.add(dom)
            except Exception as e:
                pass

        tasks = [fetch_forum_page(u) for u in EXTENDED_FORUM_PAGES]
        await asyncio.gather(*tasks)

    print("\n" + "=" * 80)
    print(f"🎉 SUCCESS! Harvested {len(found_domains):,} Unique WooCommerce Merchant Domains!")
    print("=" * 80)

    if found_domains:
        print("\nSample Discovered WooCommerce Sites:")
        for dom in list(found_domains)[:25]:
            print(f"  • {dom}")

if __name__ == "__main__":
    asyncio.run(test_wp_forum_harvesting())
