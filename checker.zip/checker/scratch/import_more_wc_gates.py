import sys, asyncio, os, re
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

from curl_cffi.requests import AsyncSession
import database.db as db
from core.site_seeds import US_WOOCOMMERCE_SEEDS

CANDIDATES = list(set(US_WOOCOMMERCE_SEEDS + [
    "https://dilaboards.com",
    "https://ea-courses.com",
    "https://shop.spreadshirt.com",
    "https://www.christopherward.com",
    "https://www.tentree.com",
    "https://www.unionmadegoods.com",
    "https://www.goodwillfinds.com",
    "https://store.dftba.com",
    "https://www.threadless.com",
    "https://www.meriwetherwatchband.com",
    "https://www.ugmonk.com",
    "https://shop.gremlinshop.com",
    "https://www.fathomevents.com",
    "https://buildyourbundle.com",
    "https://www.trinityoncampus.com",
    "https://www.firstbaptistdecatur.org",
    "https://www.gvbaptist.com",
    "https://give.realchurch.org",
    "https://give.crosslifechurch.org",
    "https://give.northwestchurch.net",
    "https://give.fellowshipchurch.com",
    "https://give.cornerstone.cc",
    "https://onlinegiving.lakewoodchurch.com",
    "https://shop.ligonier.org",
    "https://store.ransomed.org",
    "https://www.lifewaychristian.com",
    "https://store.desiringgod.org",
    "https://www.crossway.org"
]))

# WooCommerce add-payment-method path candidates
path_candidates = [
    "/my-account/add-payment-method/",
    "/en/moj-racun/add-payment-method/",
    "/moj-racun/add-payment-method/",
]

async def verify_and_add(site_url, proxy_url):
    proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
    user_ag = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    
    async with AsyncSession(impersonate="chrome131") as session:
        headers = {"User-Agent": user_ag}
        
        for path in path_candidates:
            url = f"{site_url.rstrip('/')}{path}"
            try:
                r = await session.get(url, headers=headers, proxies=proxies, timeout=10)
                if r.status_code == 200:
                    if "pk_live_" in r.text or '"key":' in r.text:
                        # Found working Stripe WooCommerce site!
                        ok = await db.add_stripe_wc_gate(site_url)
                        if ok:
                            print(f"[+] ADDED -> {site_url} (Path: {path})")
                            return True
            except Exception:
                pass
    return False

async def main():
    await db.init_db()
    
    # Get a working proxy from proxy pool
    proxies = await db.get_working_proxies()
    if not proxies:
        print("No working proxies in database. Cannot run verification scan.")
        return
        
    p = proxies[0]
    proxy_url = f"http://{p['username']}:{p['password']}@{p['host']}:{p['port']}" if p['username'] else f"http://{p['host']}:{p['port']}"
    print(f"Starting seed validation scan using proxy: {p['host']}:{p['port']}...\n")
    
    count = 0
    tasks = []
    
    # Run in batches of 5 to avoid overloading/blocking
    for i in range(0, len(CANDIDATES), 5):
        batch = CANDIDATES[i:i+5]
        batch_tasks = [verify_and_add(site, proxy_url) for site in batch]
        results = await asyncio.gather(*batch_tasks)
        count += sum(1 for r in results if r)
        await asyncio.sleep(1.0)
        
    print(f"\nScan completed. Added {count} new verified Stripe WooCommerce sites to database pool!")

if __name__ == "__main__":
    asyncio.run(main())
