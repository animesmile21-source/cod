"""
handlers/subscription.py — /redeem, /status, /genkey, /hit, /leaderboard
CLEAN REWRITE — minimal deps, explicit logging, no circular imports.
"""
import logging
import random
import re
import string
from datetime import datetime

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

import config
import database.db as db

logger = logging.getLogger("CC-Checker")


def register_subscription(app: Client):

    # ══════════════════════════════════════════════════════════════════════════
    # /genkey — Owner only key generation
    # ══════════════════════════════════════════════════════════════════════════
    @app.on_message(filters.command("genkey") & filters.private)
    async def genkey_cmd(client: Client, msg: Message):
        logger.info(f"[genkey] called by {msg.from_user.id}")
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("❌ Owner only command.")
            return

        parts = msg.text.strip().split()
        if len(parts) < 4:
            await msg.reply(
                "**Usage:** `/genkey <plan> <days> <count>`\n"
                "**Example:** `/genkey pro 30 5`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        plan = parts[1].lower()
        try:
            days = int(parts[2])
            count = int(parts[3])
            if days <= 0 or count <= 0:
                raise ValueError
        except ValueError:
            await msg.reply("❌ Days and count must be positive integers.")
            return

        # Validate plan exists
        all_plans = await db.get_all_plans()
        valid = [p["plan_name"] for p in all_plans if p["plan_name"] != "free"]
        if plan not in valid:
            plist = ", ".join(f"`{p}`" for p in valid) or "`pro`, `vip`"
            await msg.reply(
                f"❌ Invalid plan `{plan}`.\nAvailable: {plist}",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        keys = []
        for _ in range(count):
            rand = "".join(random.choices(string.ascii_uppercase + string.digits, k=16))
            keys.append({"key": f"KEY-{plan.upper()}-{rand}", "plan": plan, "days": days})

        await db.save_redeem_keys(keys)

        lines = "\n".join(f"`{k['key']}`" for k in keys)
        await msg.reply(
            f"**Keys Generated!**\n"
            f"Plan: `{plan.upper()}` | Days: `{days}` | Count: `{count}`\n\n"
            + lines,
            parse_mode=enums.ParseMode.MARKDOWN
        )


    # ══════════════════════════════════════════════════════════════════════════
    # /redeem — Works in group (reply to key msg) or private (direct key)
    # ══════════════════════════════════════════════════════════════════════════
    @app.on_message(filters.command("redeem"))
    async def redeem_cmd(client: Client, msg: Message):
        user_id  = msg.from_user.id
        is_group = msg.chat.type in (enums.ChatType.GROUP, enums.ChatType.SUPERGROUP)
        logger.info(f"[redeem] called by {user_id} in {'group' if is_group else 'private'}")

        try:
            await db.upsert_user(
                user_id,
                msg.from_user.username or "",
                msg.from_user.first_name or "",
            )
        except Exception as e:
            logger.warning(f"[redeem] upsert_user failed: {e}")

        # ── Source of key text ──────────────────────────────────────────
        target_text = ""
        parts = msg.text.strip().split(maxsplit=1)
        if len(parts) > 1:
            target_text = parts[1].strip()

        # Reply to a message that contains a key (group flow: owner posts key, user replies)
        if not target_text and msg.reply_to_message:
            target_text = (
                msg.reply_to_message.text or
                msg.reply_to_message.caption or ""
            ).strip()

        if not target_text:
            hint = (
                "<b>How to redeem:</b>\n"
                "<blockquote>"
                "\u2022 <b>Group:</b> Reply to the key message with <code>/redeem</code>\n"
                "\u2022 <b>Private:</b> <code>/redeem KEY-PLAN-XXXXXXXXXXXXXXXX</code>"
                "</blockquote>"
            )
            await msg.reply(hint, parse_mode=enums.ParseMode.HTML)
            return

        # Find all valid keys in text (handles multi-key messages)
        found = re.findall(r"KEY-[A-Za-z0-9]+-[A-Za-z0-9]{16}", target_text)
        found = list(set(k.upper() for k in found))

        if not found:
            await msg.reply(
                "\u274c <b>No valid key found.</b>\n"
                "<i>Format: <code>KEY-PLAN-XXXXXXXXXXXXXXXX</code></i>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        plan_badges = {
            "pro":  "\U0001f4a0 PRO",
            "vip":  "\U0001f451 VIP",
            "elite": "\U0001f525 ELITE",
        }

        for key in found:
            try:
                result = await db.check_and_redeem_key(user_id, key)
            except Exception as e:
                logger.error(f"[redeem] error: {e}")
                await msg.reply(
                    f"\u274c <b>Error redeeming key:</b> <code>{e}</code>",
                    parse_mode=enums.ParseMode.HTML
                )
                continue

            if result["success"]:
                plan   = result.get("plan", "").lower()
                days   = result.get("days", 0)
                expiry = result.get("expiry", "N/A")
                badge  = plan_badges.get(plan, f"\u2b50 {plan.upper()}")
                uname  = f"@{msg.from_user.username}" if msg.from_user.username else msg.from_user.first_name

                success_text = (
                    f"\u2705 <b>Key Activated!</b>\n"
                    f"<blockquote>"
                    f"{badge}\n"
                    f"\U0001f464 <b>User:</b> {uname}\n"
                    f"\U0001f4c5 <b>Plan:</b> <code>{plan.upper()}</code>\n"
                    f"\u23f3 <b>Duration:</b> <code>{days} days</code>\n"
                    f"\U0001f4cc <b>Expires:</b> <code>{expiry}</code>\n"
                    f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
                    f"<i>Use /status to check your plan.</i>"
                    f"</blockquote>"
                )

                if is_group:
                    await msg.reply(
                        f"\u2705 <b>{uname} activated a key!</b>\n"
                        f"<blockquote>{badge} \u2014 <code>{days} days</code>\n"
                        f"Expires: <code>{expiry}</code></blockquote>\n"
                        f"<i>Check your DM for details.</i>",
                        parse_mode=enums.ParseMode.HTML
                    )
                    try:
                        await client.send_message(chat_id=user_id, text=success_text, parse_mode=enums.ParseMode.HTML)
                    except Exception:
                        pass
                else:
                    await msg.reply(success_text, parse_mode=enums.ParseMode.HTML)
            else:
                await msg.reply(
                    f"\u274c <b>Redeem Failed</b>\n<code>{result.get('msg', 'Unknown error')}</code>",
                    parse_mode=enums.ParseMode.HTML
                )


    # ══════════════════════════════════════════════════════════════════════════
    # /status — Any user
    # ══════════════════════════════════════════════════════════════════════════
    @app.on_message(filters.command("status"))
    async def status_cmd(client: Client, msg: Message):
        user_id = msg.from_user.id
        logger.info(f"[status] called by {user_id}")

        try:
            await db.upsert_user(
                user_id,
                msg.from_user.username or "",
                msg.from_user.first_name or "",
            )
        except Exception as e:
            logger.warning(f"[status] upsert_user failed: {e}")

        try:
            status = await db.get_user_full_status(user_id)
        except Exception as e:
            logger.error(f"[status] get_user_full_status error: {e}")
            await msg.reply(f"❌ Error fetching status: {e}")
            return

        is_owner = user_id in config.OWNER_IDS
        plan = (status.get("plan") or "free").upper()

        if is_owner:
            plan_badge = "Owner"
            expiry_line = "Never Expires"
            workers = str(config.OWNER_WORKERS)
            cards = "Unlimited"
        elif plan == "FREE":
            plan_badge = "Free"
            expiry_line = "No Active Plan"
            workers = str(status.get("max_workers", 5))
            cards = str(status.get("max_cards", 500))
        else:
            plan_badge = plan
            remaining = status.get("remaining_days", 0)
            expiry = status.get("expiry", "N/A")
            if status.get("is_expired"):
                expiry_line = f"EXPIRED"
            else:
                expiry_line = f"{expiry} ({remaining} days left)"
            workers = str(status.get("max_workers", 5))
            cards = str(status.get("max_cards", 500))

        user_display = f"@{status.get('username')}" if status.get("username") else status.get("first_name", "User")
        total_checks = status.get("total_checks", 0)
        hits = status.get("hits", 0)
        joined = str(status.get("joined_at", "Unknown"))[:10]

        text = (
            f"**User Status**\n"
            f"{'=' * 22}\n"
            f"User: {user_display}\n"
            f"Plan: {plan_badge}\n"
            f"Expiry: {expiry_line}\n"
            f"Workers: {workers} | Max CC: {cards}\n"
            f"{'=' * 22}\n"
            f"Total Checks: {total_checks}\n"
            f"Total Hits: {hits}\n"
            f"Joined: {joined}"
        )

        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("Refresh", callback_data=f"status_refresh_{user_id}")
        ]])
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN, reply_markup=markup)


    # ── Status refresh callback ────────────────────────────────────────────────
    @app.on_callback_query(filters.regex(r"^status_refresh_"))
    async def status_refresh_cb(client: Client, cb):
        user_id = cb.from_user.id
        logger.info(f"[status_refresh] by {user_id}")

        try:
            status = await db.get_user_full_status(user_id)
        except Exception as e:
            await cb.answer(f"Error: {e}", show_alert=True)
            return

        is_owner = user_id in config.OWNER_IDS
        plan = (status.get("plan") or "free").upper()

        if is_owner:
            plan_badge = "Owner"
            expiry_line = "Never Expires"
            workers = str(config.OWNER_WORKERS)
            cards = "Unlimited"
        elif plan == "FREE":
            plan_badge = "Free"
            expiry_line = "No Active Plan"
            workers = str(status.get("max_workers", 5))
            cards = str(status.get("max_cards", 500))
        else:
            plan_badge = plan
            remaining = status.get("remaining_days", 0)
            expiry = status.get("expiry", "N/A")
            if status.get("is_expired"):
                expiry_line = "EXPIRED"
            else:
                expiry_line = f"{expiry} ({remaining} days left)"
            workers = str(status.get("max_workers", 5))
            cards = str(status.get("max_cards", 500))

        user_display = f"@{status.get('username')}" if status.get("username") else status.get("first_name", "User")
        total_checks = status.get("total_checks", 0)
        hits = status.get("hits", 0)
        joined = str(status.get("joined_at", "Unknown"))[:10]

        text = (
            f"**User Status**\n"
            f"{'=' * 22}\n"
            f"User: {user_display}\n"
            f"Plan: {plan_badge}\n"
            f"Expiry: {expiry_line}\n"
            f"Workers: {workers} | Max CC: {cards}\n"
            f"{'=' * 22}\n"
            f"Total Checks: {total_checks}\n"
            f"Total Hits: {hits}\n"
            f"Joined: {joined}"
        )

        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("Refresh", callback_data=f"status_refresh_{user_id}")
        ]])
        try:
            await cb.message.edit_text(text, parse_mode=enums.ParseMode.MARKDOWN, reply_markup=markup)
            await cb.answer("Refreshed!")
        except Exception:
            await cb.answer("Already up to date.")


    # ══════════════════════════════════════════════════════════════════════════
    # /hit — Recent hits of a user
    # ══════════════════════════════════════════════════════════════════════════
    @app.on_message(filters.command("hit"))
    async def hit_cmd(client: Client, msg: Message):
        user_id = msg.from_user.id
        logger.info(f"[hit] called by {user_id}")

        # Check plan — free users only in group
        is_private = msg.chat.type == enums.ChatType.PRIVATE
        if is_private:
            plan_info = await db.get_user_plan(user_id)
            if plan_info["plan"] in ("free", None, "") and user_id not in config.OWNER_IDS:
                await msg.reply(
                    "❌ Free users cannot check hits in DM.\n"
                    "Please go to the official group.",
                    parse_mode=enums.ParseMode.MARKDOWN
                )
                return

        hits_list = await db.get_user_hits(user_id, limit=10)
        if not hits_list:
            await msg.reply("❌ No hits logged yet for your account.")
            return

        lines = []
        for idx, h in enumerate(hits_list, 1):
            lines.append(
                f"{idx}. `{h['card']}`\n"
                f"   Gate: `{h['gateway']}` | Msg: `{h['message']}`"
            )

        await msg.reply(
            f"**Your Recent Hits ({len(hits_list)})**\n\n"
            + "\n\n".join(lines),
            parse_mode=enums.ParseMode.MARKDOWN
        )


    # ══════════════════════════════════════════════════════════════════════════
    # /leaderboard — Top users by hits
    # ══════════════════════════════════════════════════════════════════════════
    @app.on_message(filters.command("leaderboard"))
    async def leaderboard_cmd(client: Client, msg: Message):
        logger.info(f"[leaderboard] called by {msg.from_user.id}")
        leaders = await db.get_leaderboard(limit=10)
        if not leaders:
            await msg.reply("❌ Leaderboard is empty.")
            return

        medals = ["1.", "2.", "3.", "4.", "5.", "6.", "7.", "8.", "9.", "10."]
        lines = []
        for idx, l in enumerate(leaders):
            mention = f"@{l['username']}" if l["username"] != "No Username" else l["first_name"]
            lines.append(f"{medals[idx]} {mention} — `{l['hits']} Hits`")

        await msg.reply(
            "**Hits Leaderboard**\n\n"
            + "\n".join(lines),
            parse_mode=enums.ParseMode.MARKDOWN
        )
