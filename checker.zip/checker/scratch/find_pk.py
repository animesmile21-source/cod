from curl_cffi.requests import Session
import re

url = 'https://checkout.stripe.com/c/pay/cs_live_b1FFOsXPgteyPTqWunDPF03PG7JGluk57U210GMRsllBu5xc7MFNEjHrdS'
with Session(impersonate='chrome131') as s:
    r = s.get(url, headers={'User-Agent': 'Mozilla/5.0 Chrome/131.0.0.0'})
    html = r.text

pks = re.findall(r'pk_[a-z]+_[a-zA-Z0-9]{20,}', html)
print('PKs found:', pks)

keys = re.findall(r'"key"\s*:\s*"(pk_[a-zA-Z0-9_]+)"', html)
print('JSON keys:', keys)

# Search all script content
scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL)
for i, sc in enumerate(scripts[:10]):
    if 'pk_' in sc or 'publishable' in sc.lower():
        print(f'Script[{i}]: {sc[:400]}')

print('Total HTML len:', len(html))
print('First 2000 chars:', html[:2000])
