"""
utils/formatter.py — Beautiful result message formatter
"""
from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
from core.bin_lookup import BinInfo
from core.validator import detect_card_brand
from datetime import datetime


def _bar(done: int, total: int, length: int = 10) -> str:
    """Progress bar for mass check."""
    if total == 0:
        return "░" * length
    filled = int((done / total) * length)
    return "█" * filled + "░" * (length - filled)


def _status_header(result: GatewayResult) -> str:
    """Top header line based on status."""
    s = result.status
    if s == CCStatus.CHARGED:
        return "𝐂𝐡𝐚𝐫𝐠𝐞𝐝 ✅"
    elif s in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS):
        return "𝐋𝐢𝐯𝐞 🔐 𝐕𝐁𝐕"
    elif s == CCStatus.INSUFFICIENT:
        return "𝐋𝐢𝐯𝐞 ⚠️ 𝐈𝐧𝐬𝐮𝐟𝐟𝐢𝐜𝐢𝐞𝐧𝐭"
    elif s == CCStatus.EXPIRED:
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
    elif s == CCStatus.INVALID:
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
    elif s in (CCStatus.DO_NOT_HONOR, CCStatus.PICKUP):
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
    elif s == CCStatus.ERROR:
        return "𝐄𝐫𝐫𝐨𝐫 ❓"
    else:
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"


def _vbv_label(result: GatewayResult, bin_info: BinInfo | None = None) -> tuple[str, str]:
    if result.is_vbv or result.status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS):
        return "🔐", "VBV"
    elif result.is_non_vbv or result.status == CCStatus.CHARGED:
        return "✅", "Non-VBV"
    elif result.status == CCStatus.INSUFFICIENT:
        return "✅", "Non-VBV"
    elif bin_info is not None:
        if bin_info.vbv:
            return "🔐", "VBV"
        else:
            return "✅", "Non-VBV"
    return "❓", "Unknown"


def format_single_result(
    card: CardData,
    result: GatewayResult,
    bin_info: BinInfo | None,
    elapsed: float,
    username: str = "user",
    quota: int = 0,
) -> str:
    """Format a single CC check result into a premium HTML message."""

    # Base values from BIN lookup
    flag    = bin_info.flag_emoji()  if bin_info else "🌐"
    country = bin_info.country_name  if bin_info else "Unknown"
    bank    = bin_info.bank_name     if bin_info else "Unknown"
    ctype   = bin_info.type          if bin_info else "Unknown"
    scheme  = bin_info.scheme        if bin_info else detect_card_brand(card.number)
    vbv_emoji, vbv_val = _vbv_label(result, bin_info)

    extra = result.extra or {}
    gw_network   = (extra.get("network") or "").upper()
    gw_issuer    = extra.get("issuer") or ""
    gw_card_type = (extra.get("card_type") or "").capitalize()

    # Network label map
    net_map = {
        "RUPAY": "RuPay", "VISA": "Visa",
        "MASTERCARD": "Mastercard", "AMEX": "Amex",
        "UNIONPAY": "UnionPay", "JCB": "JCB",
    }

    if scheme == "Unknown" and gw_network:
        scheme = net_map.get(gw_network, gw_network.capitalize())
    if ctype == "Unknown" and gw_card_type:
        ctype = gw_card_type
    if (bank == "Unknown" or not bank) and gw_issuer:
        bank = gw_issuer

    full_type = f"{scheme} {ctype}".strip() if scheme and ctype else (scheme or ctype or "Unknown")

    header = _status_header(result)
    # Stripe-WC gateway-specific header overrides
    if result.gateway == "Stripe-WC":
        if result.status == CCStatus.CHARGED:
            header = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
        elif result.status == CCStatus.DO_NOT_HONOR:
            header = "𝐋𝐢𝐯𝐞 ⚠️"

    charge_amount = getattr(result, "charge_amount", 0.0) or 0.0
    currency = extra.get("currency") or "USD"
    if result.gateway == "Stripe-WC":
        amount_str = "No Charge"
    else:
        amount_str = f"{charge_amount:.2f}" if charge_amount > 0 else "N/A"

    # Format username: show @username if available, else just the name
    user_display = f"@{username}" if username and username not in ("user", "") else username

    # Stylish response code (raw representation preferred)
    response_styled = result.raw_code.upper() if result.raw_code else (result.message.upper().replace(" ", "_") if result.message else "UNKNOWN")

    receipt_url = extra.get("receipt_url", "")
    receipt_line = f"🧾 <b>𝐑𝐞𝐜𝐞𝐢𝐩𝐭</b> ➜ <a href='{receipt_url}'>Click Here</a>\n" if receipt_url else ""

    site_url = extra.get("site", "")
    site_line = f"🌐 <b>𝐒𝐢𝐭𝐞</b> ➜ <code>{site_url}</code>\n" if site_url else ""
    
    email_str = extra.get("email", "")
    pass_str = extra.get("password", "")
    creds_line = f"🔑 <b>𝐂𝐫𝐞𝐝𝐬</b> ➜ <code>{email_str}:{pass_str}</code>\n" if (email_str and pass_str) else ""

    text = (
        f"<b>⚡ 𝗦𝗺𝗶𝗹𝗲 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 — {header}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<blockquote>"
        f"💳 <b>𝐂𝐚𝐫𝐝</b> ➜ <code>{card.number}|{card.month}|{card.year}|{card.cvv}</code>\n"
        f"⛩️ <b>𝐆𝐚𝐭𝐞</b> ➜ <code>{result.gateway}</code>\n"
        f"📋 <b>𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞</b> ➜ <code>{response_styled}</code>\n"
        f"💰 <b>𝐀𝐦𝐨𝐮𝐧𝐭</b> ➜ <code>{amount_str} {currency}</code>\n"
        f"{receipt_line}"
        f"{site_line}"
        f"{creds_line}"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"ℹ️ <b>𝐓𝐲𝐩𝐞</b> ➜ <code>{full_type}</code>\n"
        f"🏦 <b>𝐁𝐚𝐧𝐤</b> ➜ <code>{bank}</code>\n"
        f"🌍 <b>𝐂𝐨𝐮𝐧𝐭𝐫𝐲</b> ➜ <code>{country} {flag}</code>\n"
        f"🔒 <b>𝟑𝐃𝐒</b> ➜ {vbv_emoji} <code>{vbv_val}</code>\n"
        f"📊 <b>𝐐𝐮𝐨𝐭𝐚</b> ➜ <code>{quota}</code>"
        f"</blockquote>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"✍️ <b>𝐁𝐲</b> ➜ {user_display}\n"
        f"🤖 <b>𝐁𝐨𝐭</b> ➜ 𝕊𝕞𝕚𝕝𝕖 ℂ𝕙𝕖𝕔𝕜𝕖𝕣"
    )
    return text



def format_mass_progress(
    done: int,
    total: int,
    live: int,
    dead: int,
    vbv: int,
    non_vbv: int,
    errors: int,
) -> str:
    """Format mass check progress update using HTML and double-struck fonts."""
    pct = int((done / total) * 100) if total > 0 else 0
    bar = _bar(done, total)
    return (
        f"<b>⚡ 𝕊𝕞𝕚𝕝𝕖 ℂ𝕙𝕖𝕔𝕜𝕖𝕣 ℙ𝕣𝕠𝕘𝕣𝕖𝕤𝕤 ⚡</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>Progress:</b> <code>{bar}</code> {pct}%\n"
        f"🔢 <b>Checked:</b> <code>{done}/{total}</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"✅ <b>Charged (Non-VBV):</b> <code>{non_vbv}</code>\n"
        f"🔐 <b>Live (VBV/3DS):</b> <code>{vbv}</code>\n"
        f"❌ <b>Dead:</b> <code>{dead}</code>\n"
        f"❓ <b>Error:</b> <code>{errors}</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━"
    )


def format_mass_complete(
    total: int,
    live: int,
    dead: int,
    vbv: int,
    non_vbv: int,
    errors: int,
    elapsed: float,
    live_cards: list[str],
) -> str:
    """Format mass check completion summary using HTML and double-struck fonts."""
    pct = round((live / total) * 100, 1) if total > 0 else 0
    speed = round(total / elapsed, 1) if elapsed > 0 else 0
    summary = (
        f"<b>🏁 𝕊𝕞𝕚𝕝𝕖 ℂ𝕙𝕖𝕔𝕜𝕖𝕣 ℂ𝕠𝕞𝕡𝕝𝕖𝕥𝕖! 🏁</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔢 <b>Total Checked:</b> <code>{total}</code>\n"
        f"✅ <b>Charged (Non-VBV):</b> <code>{non_vbv}</code>\n"
        f"🔐 <b>Live (VBV):</b> <code>{vbv}</code>\n"
        f"❌ <b>Dead:</b> <code>{dead}</code>\n"
        f"❓ <b>Errors:</b> <code>{errors}</code>\n"
        f"📈 <b>Hit Rate:</b> <code>{pct}%</code>\n"
        f"⚡ <b>Speed:</b> <code>{speed} cards/s</code>\n"
        f"⏱️ <b>Total Time:</b> <code>{elapsed:.1f}s</code>\n"
    )
    if live_cards:
        summary += f"\n━━━━━━━━━━━━━━━━━━━━━━\n"
        summary += f"🔥 <b>Live Cards ({len(live_cards)}):</b>\n"
        summary += "<pre>\n"
        summary += "\n".join(live_cards[:20])  # Max 20 shown inline
        if len(live_cards) > 20:
            summary += f"\n... +{len(live_cards) - 20} more (see file)"
        summary += "\n</pre>"
    return summary


def format_bin_info(bin_info: BinInfo) -> str:
    """Format BIN lookup result."""
    flag = bin_info.flag_emoji()
    vbv_text = "Yes 🔐" if bin_info.vbv else "No ✅"
    prepaid_text = "Yes 💰" if bin_info.prepaid else "No"
    return (
        f"🔍 **BIN Lookup: `{bin_info.bin}`**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💳 **Scheme:** `{bin_info.scheme}`\n"
        f"💎 **Type:** `{bin_info.type}`\n"
        f"🏷️ **Brand:** `{bin_info.brand}`\n"
        f"💰 **Prepaid:** `{prepaid_text}`\n"
        f"🛡️ **VBV/3DS:** `{vbv_text}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"{flag} **Country:** `{bin_info.country_name}`\n"
        f"🏦 **Bank:** `{bin_info.bank_name}`\n"
    )
