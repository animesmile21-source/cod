"""
rescan_standalone.py — Standalone Shopify Rescan Script
Usage: python rescan_standalone.py [workers] [input_file]

Defaults:
  workers    = 20
  input_file = rescan_candidates.txt

Reads URLs, scans each with full Shopify checkout flow,
adds working ones to DB, saves report to rescan_results.txt
"""
import asyncio
import sys
import os
import time
from datetime import datetime

# ── Windows event loop fix ─────────────────────────────────────────────────────
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# ── Config ─────────────────────────────────────────────────────────────────────
INPUT_FILE   = sys.argv[2] if len(sys.argv) > 2 else "rescan_candidates.txt"
WORKERS      = int(sys.argv[1]) if len(sys.argv) > 1 else 20
RESULTS_FILE = "rescan_results.txt"
OWNER_ID     = 0  # no telegram owner for standalone

# ── ANSI colors ────────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

def clr(text, color): return f"{color}{text}{RESET}"

# ── Load URLs ──────────────────────────────────────────────────────────────────
if not os.path.exists(INPUT_FILE):
    print(clr(f"❌ File not found: {INPUT_FILE}", RED))
    sys.exit(1)

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    raw_urls = [l.strip() for l in f if l.strip() and l.strip().startswith("http")]

if not raw_urls:
    print(clr("❌ No URLs found in file!", RED))
    sys.exit(1)

print(clr(f"\n{'='*60}", CYAN))
print(clr(f"  🔍 Shopify Rescan — Standalone", BOLD))
print(clr(f"{'='*60}", CYAN))
print(f"  📄 Input : {INPUT_FILE}")
print(f"  🌐 URLs  : {len(raw_urls)}")
print(f"  ⚙️  Workers: {WORKERS}")
print(f"  💾 Output: {RESULTS_FILE}")
print(clr(f"{'='*60}\n", CYAN))

# ── Main scan ──────────────────────────────────────────────────────────────────
async def main():
    import config
    import database.db as db
    await db.init_db()

    from core.proxy_manager import refresh_proxy_pool
    await refresh_proxy_pool()

    from handlers.shopify_handler import _scan_shopify_site

    urls        = list(raw_urls)
    total       = len(urls)
    working     = []
    failed      = []
    done        = 0
    start_time  = time.monotonic()

    sem  = asyncio.Semaphore(WORKERS)
    lock = asyncio.Lock()

    async def scan_one(url: str):
        nonlocal done
        async with sem:
            try:
                res = await _scan_shopify_site(url)
            except Exception as e:
                res = {"status": "FAILED", "url": url, "reason": str(e)}

            async with lock:
                done += 1
                elapsed  = time.monotonic() - start_time
                rate     = done / elapsed if elapsed > 0 else 0
                eta_sec  = (total - done) / rate if rate > 0 else 0
                eta_str  = f"{int(eta_sec//60)}m{int(eta_sec%60)}s" if eta_sec < 3600 else "???"
                pct      = int(done / total * 100)
                bar_fill = int(pct / 5)
                bar      = "█" * bar_fill + "░" * (20 - bar_fill)

                if res.get("status") == "WORKING":
                    try:
                        gate_id = await db.add_shopify_gate(
                            base_url      = res["url"],
                            variant_id    = res["variant_id"],
                            price         = res["price"],
                            product_title = res["product_title"],
                            shop_domain   = res["shop_domain"],
                            shop_id       = res["shop_id"],
                            currency      = res["currency"],
                            checkout_type = res["checkout_type"],
                            added_by      = OWNER_ID,
                            scan_data     = res.get("scan_data", {}),
                        )
                        try:
                            from gateways.shopify_gate import invalidate_stores_cache
                            invalidate_stores_cache()
                        except Exception:
                            pass
                        working.append({"gate_id": gate_id, **res})
                        print()
                        print(clr(f"  ✅ ADDED #{gate_id} | {res['url']} (${res['price']})", GREEN))
                    except Exception as e:
                        working.append({"gate_id": "?", **res})
                        print()
                        print(clr(f"  ✅ WORKING (DB err: {e}) | {res['url']}", YELLOW))
                else:
                    reason = res.get("reason", "unknown")[:60]
                    failed.append({"url": url, "reason": reason})

                print(
                    f"\r  [{'█' * int(pct/5)}{'░' * (20 - int(pct/5))}] {pct}% | {done}/{total} | "
                    f"✅{len(working)} ❌{len(failed)} | ETA:{eta_str}   ",
                    end="", flush=True
                )

    await asyncio.gather(*[scan_one(url) for url in urls])
    print()

    # Summary
    elapsed_total = time.monotonic() - start_time
    print(clr(f"\n{'='*60}", CYAN))
    print(clr(f"  ✅ SCAN COMPLETE", BOLD))
    print(clr(f"{'='*60}", CYAN))
    print(f"  🌐 Total Scanned : {total}")
    print(f"  ✅ Working Added  : {len(working)}")
    print(f"  ❌ Failed         : {len(failed)}")
    print(f"  ⏱️  Time Taken    : {int(elapsed_total//60)}m {int(elapsed_total%60)}s")
    print(clr(f"{'='*60}", CYAN))

    if working:
        print(clr(f"\n  🛍️  Working Gates:", GREEN))
        for w in working:
            print(f"    #{w.get('gate_id','?')} | {w['url']} | ${w['price']} | {w['checkout_type']}")

    # Save report
    with open(RESULTS_FILE, "w", encoding="utf-8") as rf:
        rf.write("=" * 70 + "\n")
        rf.write(f"RESCAN REPORT — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        rf.write(f"Input: {INPUT_FILE} | Total: {total} | Working: {len(working)} | Failed: {len(failed)}\n")
        rf.write("=" * 70 + "\n\n")
        rf.write(f"WORKING GATES ({len(working)})\n")
        rf.write("-" * 70 + "\n")
        for w in working:
            rf.write(f"\nURL      : {w['url']}\n")
            rf.write(f"Gate ID  : #{w.get('gate_id','?')}\n")
            rf.write(f"Price    : ${w['price']} {w.get('currency','')}\n")
            rf.write(f"Product  : {w.get('product_title','')}\n")
            rf.write(f"Checkout : {w.get('checkout_type','')}\n")
            sd = w.get("scan_data", {})
            rf.write(f"Card Test: {sd.get('card_test','')}\n")
            rf.write("-" * 50 + "\n")
        rf.write(f"\nFAILED SITES ({len(failed)})\n")
        rf.write("-" * 70 + "\n")
        for fsite in failed:
            rf.write(f"x {fsite['url']}  ->  {fsite['reason']}\n")

    print(clr(f"\n  💾 Report saved: {RESULTS_FILE}", CYAN))


if __name__ == "__main__":
    asyncio.run(main())
