import sqlite3

conn = sqlite3.connect('database/checker.db')
conn.execute("DELETE FROM stripe_wc_gates WHERE base_url LIKE '%charitywater%'")
conn.commit()

rows = conn.execute("SELECT * FROM stripe_wc_gates").fetchall()
print(f"Cleaned stripe_wc_gates count: {len(rows)}")
for r in rows:
    print(r)
conn.close()
