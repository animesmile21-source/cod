"""
gateways/router.py — Smart Multi-Gateway Router

Gate Priority (default order):
  0. 🎯 Scraped Gates    — User-scanned Stripe endpoints (auto-added)
  1. 🟣 Stripe         — SetupIntent flow (primary gate)
  2. 🔵 Braintree      — Transaction auth (optional)
  3. 🏦 Authorize.net  — Direct processor auth (optional)
  4. 🟦 Square         — Square payments auth (optional)
  5. 🛍️ Shopify        — Storefront checkout (optional)
  6. 🔶 Razorpay       — INR Order+Payment auth (optional)

Priority can be changed via GATE_PRIORITY in .env.
"""
import asyncio
import time as _time
from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
import config

# ── Route config cache ────────────────────────────────────────────────────────
# Cache b3_is_configured and scraped gates to avoid 2x DB round-trips per card.
# In a 100-card mass check, these calls would otherwise make 200+ DB requests.
_ROUTE_CACHE_TTL = 30.0  # seconds
_b3_configured_cache: bool = False
_b3_configured_ts: float = 0.0
_scraped_gates_cache: list = []
_scraped_gates_ts: float = 0.0


async def _get_b3_configured() -> bool:
    global _b3_configured_cache, _b3_configured_ts
    now = _time.monotonic()
    if now - _b3_configured_ts < _ROUTE_CACHE_TTL:
        return _b3_configured_cache
    import database.db as db
    _b3_configured_cache = await db.b3_is_configured()
    _b3_configured_ts = now
    return _b3_configured_cache


async def _get_scraped_gates() -> list:
    global _scraped_gates_cache, _scraped_gates_ts
    now = _time.monotonic()
    if now - _scraped_gates_ts < _ROUTE_CACHE_TTL:
        return _scraped_gates_cache
    import database.db as db
    _scraped_gates_cache = await db.get_active_gates()
    _scraped_gates_ts = now
    return _scraped_gates_cache


def invalidate_route_cache():
    """Call this after adding/removing scraped gates or b3 config changes."""
    global _b3_configured_ts, _scraped_gates_ts
    _b3_configured_ts = 0.0
    _scraped_gates_ts = 0.0


# ── Lazy imports to avoid circular ────────────────────────────────────────────
def _get_gate_map():
    from gateways.shopify_gate import check_shopify
    from gateways.authnet_gate import check_authnet
    from gateways.square_gate import check_square
    from gateways.stripe_gate import check_stripe
    from gateways.braintree_gate import check_braintree
    from gateways.razorpay_gate import check_razorpay

    return {
        "shopify":    ("🛍️ Shopify",       check_shopify,    True),
        "authnet":    ("🏦 Authorize.net",  check_authnet,    False),
        "square":     ("🟦 Square",         check_square,     False),
        "stripe":     ("🟣 Stripe",         check_stripe,     False),
        "braintree":  ("🔵 Braintree",      check_braintree,  False),
        "razorpay":   ("🔶 Razorpay",       check_razorpay,   False),
    }


def _is_gate_configured(gate_name: str) -> bool:
    """Check if a gate has the required credentials."""
    if gate_name == "shopify":
        return True
    if gate_name == "authnet":
        return bool(config.AUTHNET_LOGIN_ID and config.AUTHNET_TRANSACTION_KEY
                    and config.AUTHNET_LOGIN_ID != "your_api_login_id")
    if gate_name == "square":
        return bool(config.SQUARE_ACCESS_TOKEN and config.SQUARE_LOCATION_ID
                    and config.SQUARE_ACCESS_TOKEN != "your_square_access_token")
    if gate_name == "stripe":
        return bool(config.STRIPE_PK_KEYS)
    if gate_name == "braintree":
        return all([config.BT_MERCHANT_ID, config.BT_PUBLIC_KEY, config.BT_PRIVATE_KEY,
                    config.BT_MERCHANT_ID != "your_merchant_id"])
    if gate_name == "razorpay":
        return bool(config.RAZORPAY_KEY_ID and config.RAZORPAY_KEY_SECRET
                    and config.RAZORPAY_KEY_ID != "rzp_live_your_key_id")
    return False


def get_active_gates() -> list[tuple[str, str]]:
    """
    Returns list of (gate_name, display_name) for all configured gates
    in priority order.
    """
    gate_map = _get_gate_map()
    active = []
    for gate_name in config.GATE_PRIORITY:
        if gate_name in gate_map and _is_gate_configured(gate_name):
            display_name = gate_map[gate_name][0]
            active.append((gate_name, display_name))
    return active


async def route_and_check(card: CardData) -> GatewayResult:
    """
    Route CC through 2-stage pipeline.
    Uses cached DB lookups to avoid hammering DB on every card during mass checks.
    """
    import database.db as db

    # ── Stage 1: B3 WooCommerce Gate (if configured) ──────────────────────────
    # Use cached check — avoids 1 DB round-trip per card
    if await _get_b3_configured():
        from gateways.b3_gate import check_b3_gate
        b3_result = await check_b3_gate(card)

        if b3_result.status not in (CCStatus.ERROR,) and not b3_result.is_live:
            return b3_result

        if b3_result.is_live:
            b3_extra = {
                "b3_status":  b3_result.status.value,
                "b3_message": b3_result.message,
                "b3_pair":    b3_result.extra.get("pair_id", ""),
                "b3_site":    b3_result.extra.get("site", ""),
            }
        else:
            b3_extra = {"b3_error": b3_result.message}
    else:
        b3_extra = {}

    # ── Step 1.5: Try scraped gates first ─────────────────────────────────────
    # Use cached check — avoids 1 DB round-trip per card
    scraped_gates = await _get_scraped_gates()
    if scraped_gates:
        from gateways.scraped_gate import check_scraped_gate
        for gate in scraped_gates:
            result = await check_scraped_gate(card, gate)
            if result.status != CCStatus.ERROR:
                await db.update_gate_stats(gate["id"], success=(result.status != CCStatus.ERROR))
                if b3_extra:
                    result.extra.update(b3_extra)
                return result
            await db.update_gate_stats(gate["id"], success=False)
            await asyncio.sleep(0.3)

    # ── Stage 2: Configured gateways (Razorpay, Stripe, etc.) ─────────────────
    gate_map = _get_gate_map()

    gateways_to_try = []
    for gate_name in config.GATE_PRIORITY:
        if gate_name not in gate_map:
            continue
        if not _is_gate_configured(gate_name):
            continue
        display_name, checker, _ = gate_map[gate_name]
        gateways_to_try.append((display_name, checker))

    if not gateways_to_try:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="None",
            message=(
                "❌ No payment gateways configured!\n"
                "Use /b3site + /b3addpair for B3 gate, or add credentials in .env"
            ),
            raw_code="no_gateway",
        )

    last_result: GatewayResult | None = None

    for name, checker in gateways_to_try:
        result = await checker(card)
        last_result = result

        if result.status != CCStatus.ERROR:
            if b3_extra:
                result.extra.update(b3_extra)
            return result

        await asyncio.sleep(0.5)

    if last_result and b3_extra:
        last_result.extra.update(b3_extra)

    return last_result or GatewayResult(
        status=CCStatus.ERROR,
        gateway="All",
        message="All gateways failed or returned errors",
        raw_code="all_failed",
    )

