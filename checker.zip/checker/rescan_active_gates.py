import asyncio
import sys
import os

sys.path.insert(0, ".")

import database.db as db
from handlers.shopify_handler import _scan_shopify_site

async def main():
    await db.init_db()
    
    # Let's get all gates from the DB
    # We will fetch directly from SQLite database since we want both active and inactive gates
    rows = await db._db.fetchall("SELECT id, base_url, variant_id, product_title, is_active FROM shopify_gates")
    
    print(f"Loaded {len(rows)} shopify gates from DB.")
    for row in rows:
        gate_id, base_url, old_variant, old_title, is_active = row
        # Only scan store.dftba.com and builtforamerica.store
        if "dftba.com" in base_url or "builtforamerica" in base_url:
            print(f"\nRescanning gate #{gate_id}: {base_url} (Current Active: {is_active})")
            print(f"Old Variant: {old_variant} | Old Title: {old_title}")
            
            result = await _scan_shopify_site(base_url)
            
            if result["status"] == "WORKING":
                print(f"  [+] Scan succeeded! Found new variant: {result['variant_id']} | Price: {result['price']} | Title: {result['product_title']}")
                # Update DB and set is_active=1
                await db._db.execute("""
                    UPDATE shopify_gates
                    SET variant_id=?, price=?, product_title=?, shop_domain=?, shop_id=?, currency=?, checkout_type=?, scan_data=?, is_active=1, fail_count=0
                    WHERE id=?
                """, (
                    result["variant_id"],
                    result["price"],
                    result["product_title"],
                    result["shop_domain"],
                    result["shop_id"],
                    result["currency"],
                    result["checkout_type"],
                    import_json_dumps(result.get("scan_data", {})),
                    gate_id
                ))
                print(f"  [+] Gate #{gate_id} updated and activated in DB.")
            else:
                print(f"  [-] Scan failed: {result['reason']}")

def import_json_dumps(data):
    import json
    return json.dumps(data)

if __name__ == "__main__":
    asyncio.run(main())
