﻿import asyncio, sys, aiohttp, re
from urllib.parse import urlencode, unquote, quote
sys.path.insert(0, r"c:\Users\rdx27\Desktop\all bots\checker")

PROXIES = [
    {"user": "3364",   "pass": "y0a3zi1hkcd9",  "host": "p105.instantproxies.com", "port": 8937},
    {"user": "3350",   "pass": "i63n2pm5Tt2v",  "host": "p105.instantproxies.com", "port": 8927},
    {"user": "207657", "pass": "qeyWpB6yZ",     "host": "66.212.23.107",           "port": 8800},
    {"user": "2906",   "pass": "XANpZWO45A2U",  "host": "p101.instantproxies.com", "port": 9091},
    {"user": "2906",   "pass": "XANpZWO45A2U",  "host": "p103.instantproxies.com", "port": 9090},
]

async def test_proxy(p):
    # Try both with embedded creds and explicit proxy_auth
    purl = f"http://{p['host']}:{p['port']}"
    auth = aiohttp.BasicAuth(p['user'], p['pass'])
    tests = [
        ("embedded", f"http://{p['user']}:{p['pass']}@{p['host']}:{p['port']}", None),
        ("proxy_auth", purl, auth),
        ("https_proxy", f"https://{p['host']}:{p['port']}", auth),
    ]
    for label, url, pa in tests:
        try:
            kwargs = {"proxy": url, "ssl": False, "timeout": aiohttp.ClientTimeout(total=8)}
            if pa:
                kwargs["proxy_auth"] = pa
            async with aiohttp.ClientSession() as s:
                async with s.get("http://httpbin.org/ip", **kwargs) as r:
                    if r.status == 200:
                        body = await r.text()
                        return True, f"[{label}] {body[:50].strip()}"
                    elif r.status == 407:
                        continue  # try next method
                    else:
                        return False, f"[{label}] HTTP {r.status}"
        except Exception as e:
            continue
    return False, "All auth methods failed"

async def test_google(p):
    purl = f"http://{p['host']}:{p['port']}"
    auth = aiohttp.BasicAuth(p['user'], p['pass'])
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(
                "https://www.bing.com/search?" + urlencode({"q": "site:myshopify.com cheap buy", "count": "10"}),
                proxy=purl, proxy_auth=auth, ssl=False,
                timeout=aiohttp.ClientTimeout(total=20),
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
                         "Accept": "text/html,*/*", "Accept-Language": "en-US,en;q=0.9"}
            ) as r:
                body = await r.text(errors="ignore")
                body_l = body.lower()
                if "captcha" in body_l or "blocked" in body_l:
                    return f"CAPTCHA/Blocked (status={r.status})"
                elif "myshopify.com" in body_l:
                    shops = re.findall(r"(https?://[\w\-]+\.myshopify\.com)", body, re.I)
                    return f"SUCCESS! {len(shops)} myshopify URLs found"
                else:
                    return f"OK but no myshopify (status={r.status}, size={len(body)})"
    except Exception as e:
        return f"ERROR: {e}"[:80]

async def main():
    print("="*60)
    print("STEP 1: Testing proxy connectivity (3 auth methods)")
    print("="*60)
    working = []
    for p in PROXIES:
        ok, msg = await test_proxy(p)
        status = "LIVE" if ok else "DEAD"
        print(f"  [{status}] {p['host']}:{p['port']} | {msg}")
        if ok:
            working.append(p)

    if not working:
        print("\nAll proxies dead! Check credentials.")
        return

    print(f"\n{'='*60}")
    print(f"STEP 2: Testing Bing search with {len(working)} working proxies")
    print(f"{'='*60}")
    best = None
    for p in working:
        r = await test_google(p)
        print(f"  {p['host']}:{p['port']} --> {r}")
        if "SUCCESS" in r and not best:
            best = p

    best = best or working[0]
    print(f"\nUsing: {best['host']}:{best['port']}")

    print(f"\n{'='*60}")
    print("STEP 3: Running Shopify discovery (30 sites)")
    print(f"{'='*60}")

    proxy_dict = {"host": best["host"], "port": best["port"],
                  "username": best["user"], "password": best["pass"], "protocol": "http"}

    found_count = [0]
    async def progress(found, target):
        if found != found_count[0]:
            found_count[0] = found
            print(f"  >> Found: {found} Shopify URLs")

    from core.auto_discover import discover_shopify_sites
    results = await discover_shopify_sites(count=30, proxy=proxy_dict, progress_cb=progress)

    print(f"\nDONE! Found {len(results)} Shopify sites:")
    for i, u in enumerate(results, 1):
        print(f"  {i:2d}. {u}")

asyncio.run(main())
