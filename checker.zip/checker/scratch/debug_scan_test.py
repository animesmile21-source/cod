import sys
sys.stdout.reconfigure(encoding='utf-8')
import asyncio, aiohttp, json
from aiohttp import CookieJar, ClientTimeout

TIMEOUT = ClientTimeout(total=25)
BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

async def test_one(url):
    jar = CookieJar(unsafe=True)
    conn = aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)
    try:
        async with aiohttp.ClientSession(connector=conn, cookie_jar=jar, timeout=TIMEOUT) as s:
            # Homepage
            async with s.get(url, headers=BROWSER_HEADERS, allow_redirects=True) as r:
                text = await r.text(errors="ignore")
                is_shopify = any(x in text.lower() for x in ("shopify", "myshopify.com", "cdn.shopify.com"))
                print(f"  Status: {r.status} | Shopify: {is_shopify} | Size: {len(text)}")
            
            if not is_shopify:
                print("  -> FAIL: Not Shopify")
                return

            # Products
            async with s.get(url + "/products.json?limit=5", headers={"Accept": "application/json"}) as r2:
                try:
                    pj = await r2.json(content_type=None)
                    products = pj.get("products", [])
                    print(f"  Products: {len(products)}")
                    if products:
                        v = products[0]["variants"][0]
                        print(f"  First variant: id={v['id']} price={v['price']} available={v.get('available')}")
                except Exception as e:
                    print(f"  Products error: {e}")
                    return

            # Cart add
            if products:
                vid = products[0]["variants"][0]["id"]
                async with s.post(
                    url + "/cart/add.js",
                    data=f"id={vid}&quantity=1",
                    headers={"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"},
                ) as r3:
                    print(f"  Cart add status: {r3.status}")
    except Exception as e:
        print(f"  Error: {e}")

async def main():
    test_urls = [
        "https://seoulceuticals.com",
        "https://paradoxbrewery.com",
        "https://tymobeauty.com",
        "https://sachfoods.com",
    ]
    for url in test_urls:
        print(f"\n[TEST] {url}")
        await test_one(url)

asyncio.run(main())
