"""
handlers/admin.py — Admin-only commands (/broadcast, /addkey, /userlist)
"""
from pyrogram import Client, filters, enums
from pyrogram.types import Message
import config
import database.db as db
from utils.error_handler import notify_owner_on_error



import functools

def owner_only(func):
    """Decorator to restrict commands to bot owner."""
    @functools.wraps(func)
    async def wrapper(client, msg: Message):
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("❌ Owner only command.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        await func(client, msg)
    return wrapper


def register_admin(app: Client):

    @app.on_message(filters.command("addkey"))
    @owner_only
    @notify_owner_on_error
    async def addkey_cmd(client: Client, msg: Message):
        """Add a new Stripe key at runtime."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/addkey sk_live_...`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        key = parts[1]
        if not key.startswith("sk_"):
            await msg.reply("❌ Invalid Stripe key format.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        if key not in config.STRIPE_KEYS:
            config.STRIPE_KEYS.append(key)
            await msg.reply(
                f"✅ Key added! Total keys: `{len(config.STRIPE_KEYS)}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
        else:
            await msg.reply("⚠️ Key already exists.", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("removekey"))
    @owner_only
    @notify_owner_on_error
    async def removekey_cmd(client: Client, msg: Message):
        """Remove a Stripe key at runtime."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/removekey sk_live_...`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        key = parts[1]
        if key in config.STRIPE_KEYS:
            config.STRIPE_KEYS.remove(key)
            await msg.reply(
                f"✅ Key removed. Remaining: `{len(config.STRIPE_KEYS)}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
        else:
            await msg.reply("❌ Key not found.", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("keys"))
    @owner_only
    @notify_owner_on_error
    async def keys_cmd(client: Client, msg: Message):
        """List loaded Stripe keys (masked)."""
        if not config.STRIPE_KEYS:
            await msg.reply("❌ No keys loaded.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        masked = [f"`{k[:8]}...{k[-4:]}`" for k in config.STRIPE_KEYS]
        text = f"🔑 **Stripe Keys ({len(config.STRIPE_KEYS)}):**\n" + "\n".join(masked)
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("gstats"))
    @owner_only
    @notify_owner_on_error
    async def gstats_cmd(client: Client, msg: Message):
        """Global bot stats."""
        stats = await db.get_global_stats()
        text = (
            f"📊 **Global Stats**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👥 Users: `{stats['users']}`\n"
            f"🔢 Total Checks: `{stats['total_checks']}`\n"
            f"✅ Live: `{stats['live']}`\n"
            f"❌ Dead: `{stats['dead']}`\n"
        )
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("setgate"))
    @owner_only
    @notify_owner_on_error
    async def setgate_cmd(client: Client, msg: Message):
        """
        Set gate priority order at runtime.
        Usage: /setgate shopify,stripe,authnet
        Available gates: shopify, authnet, square, stripe, braintree
        """
        VALID_GATES = {"shopify", "authnet", "square", "stripe", "braintree"}
        parts = msg.text.strip().split(maxsplit=1)
        if len(parts) < 2:
            current = ",".join(config.GATE_PRIORITY)
            await msg.reply(
                f"📋 **Gate Priority Manager**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**Current order:** `{current}`\n\n"
                f"**Usage:** `/setgate shopify,authnet,stripe`\n\n"
                f"**Available gates:**\n"
                f"• `shopify` — No key needed\n"
                f"• `authnet` — Authorize.net\n"
                f"• `square` — Square\n"
                f"• `stripe` — Stripe\n"
                f"• `braintree` — Braintree",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        raw = parts[1].strip().lower()
        new_gates = [g.strip() for g in raw.split(",") if g.strip()]

        # Validate
        invalid = [g for g in new_gates if g not in VALID_GATES]
        if invalid:
            await msg.reply(
                f"❌ Invalid gates: `{', '.join(invalid)}`\n"
                f"Valid options: `shopify, authnet, square, stripe, braintree`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        if not new_gates:
            await msg.reply("❌ Must provide at least one gate.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        # Apply new priority
        config.GATE_PRIORITY = new_gates
        await msg.reply(
            f"✅ **Gate priority updated!**\n"
            f"New order: `{' → '.join(new_gates)}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("gateon"))
    @owner_only
    @notify_owner_on_error
    async def gateon_cmd(client: Client, msg: Message):
        """Enable a specific gate (move to front of priority)."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/gateon shopify`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        gate = parts[1].lower()
        if gate not in {"shopify", "authnet", "square", "stripe", "braintree"}:
            await msg.reply("❌ Unknown gate.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        if gate not in config.GATE_PRIORITY:
            config.GATE_PRIORITY.insert(0, gate)
        else:
            config.GATE_PRIORITY.remove(gate)
            config.GATE_PRIORITY.insert(0, gate)
        await msg.reply(
            f"✅ `{gate}` moved to **first priority**!\n"
            f"Order: `{' → '.join(config.GATE_PRIORITY)}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("gateoff"))
    @owner_only
    @notify_owner_on_error
    async def gateoff_cmd(client: Client, msg: Message):
        """Disable a specific gate (remove from priority)."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/gateoff stripe`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        gate = parts[1].lower()
        if gate == "shopify":
            await msg.reply("❌ Cannot disable Shopify gate (it's the base gate).", parse_mode=enums.ParseMode.MARKDOWN)
            return
        if gate in config.GATE_PRIORITY:
            config.GATE_PRIORITY.remove(gate)
            await msg.reply(
                f"✅ `{gate}` **disabled**!\n"
                f"Active: `{' → '.join(config.GATE_PRIORITY)}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
        else:
            await msg.reply(f"⚠️ `{gate}` was not in priority list.", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("setworkers"))
    @owner_only
    @notify_owner_on_error
    async def setworkers_cmd(client: Client, msg: Message):
        """Set concurrent checking workers count at runtime."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply(
                f"🛠️ **Worker Configuration**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"• Current Owner Workers: `{config.OWNER_WORKERS}`\n"
                f"• Current Admin Workers: `{config.MAX_CONCURRENT}`\n\n"
                f"**Usage:** `/setworkers <num>` (sets both to `<num>`)\n"
                f"**Example:** `/setworkers 30`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return
            
        try:
            num = int(parts[1])
            if num < 1 or num > 100:
                await msg.reply("❌ Worker count must be between 1 and 100.", parse_mode=enums.ParseMode.MARKDOWN)
                return
        except ValueError:
            await msg.reply("❌ Invalid number.", parse_mode=enums.ParseMode.MARKDOWN)
            return
            
        config.OWNER_WORKERS = num
        config.MAX_CONCURRENT = num
        await msg.reply(
            f"✅ **Workers Updated!**\n\n"
            f"• Owner Workers: `{config.OWNER_WORKERS}`\n"
            f"• Admin Workers: `{config.MAX_CONCURRENT}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("forcesub"))
    @owner_only
    @notify_owner_on_error
    async def forcesub_cmd(client: Client, msg: Message):
        """Set force subscribe channel. Usage: /forcesub @channelname or /forcesub off"""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            current = await db.get_setting("force_sub_channel", "Disabled")
            await msg.reply(
                f"📢 **Force Subscribe Configuration**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"• Current Channel: `{current}`\n\n"
                f"**Usage:** `/forcesub @channelusername` or `/forcesub off` to disable.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        target = parts[1].strip()
        if target.lower() == "off":
            await db.set_setting("force_sub_channel", "")
            await msg.reply("✅ **Force Subscribe Disabled!**", parse_mode=enums.ParseMode.MARKDOWN)
        else:
            if not target.startswith("@") and not target.replace("-", "").isdigit():
                await msg.reply("❌ Invalid format. Must start with `@` or be a numeric ID.", parse_mode=enums.ParseMode.MARKDOWN)
                return
            await db.set_setting("force_sub_channel", target)
            await msg.reply(f"✅ **Force Subscribe Channel set to:** `{target}`", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("setgroup"))
    @owner_only
    @notify_owner_on_error
    async def setgroup_cmd(client: Client, msg: Message):
        """Set free group chat ID. Usage: /setgroup -100... or /setgroup off"""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            current = await db.get_setting("free_group_id", "Disabled")
            await msg.reply(
                f"👥 **Free Group Chat Configuration**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"• Current Group: `{current}`\n\n"
                f"**Usage:** `/setgroup -1001234567890` or `/setgroup off` to disable.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        target = parts[1].strip()
        if target.lower() == "off":
            await db.set_setting("free_group_id", "")
            await msg.reply("✅ **Free Group Check Disabled!**", parse_mode=enums.ParseMode.MARKDOWN)
        else:
            await db.set_setting("free_group_id", target)
            await msg.reply(f"✅ **Free Group Chat set to:** `{target}`", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("addplan"))
    @owner_only
    @notify_owner_on_error
    async def addplan_cmd(client: Client, msg: Message):
        """Add or update subscription plan. Usage: /addplan <name> <workers> <cards_cap>"""
        parts = msg.text.strip().split()
        if len(parts) < 4:
            await msg.reply(
                "❌ **Usage:** `/addplan <name> <workers> <cards_cap>`\n"
                "**Example:** `/addplan pro 10 2000`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return
        
        name = parts[1].lower().strip()
        try:
            workers = int(parts[2])
            cards = int(parts[3])
            if workers <= 0 or cards <= 0:
                raise ValueError
        except ValueError:
            await msg.reply("❌ Workers and cards cap must be positive integers.", parse_mode=enums.ParseMode.MARKDOWN)
            return
            
        await db.add_plan(name, workers, cards)
        await msg.reply(
            f"✅ **Plan Added / Updated!**\n\n"
            f"• Plan Name: `{name.upper()}`\n"
            f"• Max Workers: `{workers}`\n"
            f"• Card Limit: `{cards}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("delplan"))
    @owner_only
    @notify_owner_on_error
    async def delplan_cmd(client: Client, msg: Message):
        """Delete a plan. Usage: /delplan <name>"""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("❌ **Usage:** `/delplan <name>`", parse_mode=enums.ParseMode.MARKDOWN)
            return
            
        name = parts[1].lower().strip()
        if name == "free":
            await msg.reply("❌ Cannot delete default 'free' plan.", parse_mode=enums.ParseMode.MARKDOWN)
            return
            
        await db.delete_plan(name)
        await msg.reply(f"✅ **Plan '{name.upper()}' deleted successfully!**", parse_mode=enums.ParseMode.MARKDOWN)


    @app.on_message(filters.command("plans"))
    @owner_only
    @notify_owner_on_error
    async def plans_cmd(client: Client, msg: Message):
        """List all plans with inline Edit/Delete buttons."""
        from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

        all_plans = await db.get_all_plans()
        if not all_plans:
            await msg.reply(
                "❌ **No plans configured.**\n\n"
                "Add one with:\n`/addplan <name> <workers> <cards_limit>`\n"
                "Example: `/addplan pro 10 2000`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        text = (
            "<b>📋 𝗣𝗹𝗮𝗻 𝗠𝗮𝗻𝗮𝗴𝗲𝗿</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "<blockquote>"
        )
        buttons = []
        for p in all_plans:
            pname = p["plan_name"].upper()
            workers = p["max_workers"]
            cards = p["max_cards"]
            text += (
                f"💎 <b>{pname}</b>\n"
                f"   ⚙️ Workers: <code>{workers}</code> | 🃏 Cards: <code>{cards}</code>\n"
            )
            row = []
            if p["plan_name"] != "free":
                row.append(InlineKeyboardButton(
                    f"✏️ Edit {pname}",
                    callback_data=f"plan_edit_{p['plan_name']}"
                ))
                row.append(InlineKeyboardButton(
                    f"🗑️ Del {pname}",
                    callback_data=f"plan_del_{p['plan_name']}"
                ))
            else:
                row.append(InlineKeyboardButton(
                    f"✏️ Edit FREE",
                    callback_data=f"plan_edit_{p['plan_name']}"
                ))
            buttons.append(row)

        text += "</blockquote>\n━━━━━━━━━━━━━━━━━━━━━━\n"
        text += "➕ Add: <code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards&gt;</code>"

        buttons.append([InlineKeyboardButton("➕ Add New Plan", callback_data="plan_add_help")])

        await msg.reply(
            text,
            reply_markup=InlineKeyboardMarkup(buttons),
            parse_mode=enums.ParseMode.HTML
        )


    @app.on_message(filters.command("editplan"))
    @owner_only
    @notify_owner_on_error
    async def editplan_cmd(client: Client, msg: Message):
        """Edit an existing plan. Usage: /editplan <name> <workers> <cards>"""
        parts = msg.text.strip().split()
        if len(parts) < 4:
            await msg.reply(
                "❌ **Usage:** `/editplan <name> <workers> <cards>`\n"
                "**Example:** `/editplan pro 15 3000`\n\n"
                "This edits an existing plan in-place.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        name = parts[1].lower().strip()
        try:
            workers = int(parts[2])
            cards = int(parts[3])
            if workers <= 0 or cards <= 0:
                raise ValueError
        except ValueError:
            await msg.reply("❌ Workers and cards must be positive integers.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        # Check if plan exists
        all_plans = await db.get_all_plans()
        existing = [p for p in all_plans if p["plan_name"] == name]
        if not existing:
            plan_names = ", ".join(f"`{p['plan_name']}`" for p in all_plans)
            await msg.reply(
                f"❌ Plan `{name}` not found.\n"
                f"Existing plans: {plan_names}\n\n"
                f"Use `/addplan {name} {workers} {cards}` to create it.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        # add_plan does upsert, so it also works for edit
        await db.add_plan(name, workers, cards)
        await msg.reply(
            f"✅ **Plan Updated Successfully!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💎 **Plan:** `{name.upper()}`\n"
            f"⚙️ **Workers:** `{workers}`\n"
            f"🃏 **Card Limit:** `{cards}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )


    @app.on_callback_query(filters.create(
        lambda _, __, cb: cb.data and (
            cb.data.startswith("plan_edit_") or
            cb.data.startswith("plan_del_") or
            cb.data == "plan_add_help" or
            cb.data.startswith("plan_confirm_del_")
        )
    ))
    async def plan_manager_callback(client: Client, cb):
        """Handle plan edit/delete inline buttons from /plans command."""
        from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("❌ Owner only!", show_alert=True)
            return

        data = cb.data

        # ── Edit plan → show instructions ────────────────────────────────────
        if data.startswith("plan_edit_"):
            plan_name = data[10:]
            plans = await db.get_all_plans()
            plan = next((p for p in plans if p["plan_name"] == plan_name), None)
            if not plan:
                await cb.answer("Plan not found!", show_alert=True)
                return

            text = (
                f"<b>✏️ 𝗘𝗱𝗶𝘁 𝗣𝗹𝗮𝗻: {plan_name.upper()}</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"⚙️ Current Workers: <code>{plan['max_workers']}</code>\n"
                f"🃏 Current Cards: <code>{plan['max_cards']}</code>"
                f"</blockquote>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Send this command to update:\n"
                f"<code>/editplan {plan_name} {plan['max_workers']} {plan['max_cards']}</code>\n\n"
                f"Example (double workers, 5000 cards):\n"
                f"<code>/editplan {plan_name} 20 5000</code>"
            )
            markup = InlineKeyboardMarkup([[
                InlineKeyboardButton("⬅️ Back to Plans", callback_data="plan_refresh")
            ]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Delete plan → confirm ─────────────────────────────────────────────
        elif data.startswith("plan_del_"):
            plan_name = data[9:]
            if plan_name == "free":
                await cb.answer("❌ Cannot delete free plan!", show_alert=True)
                return
            text = (
                f"<b>⚠️ Confirm Delete Plan</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Are you sure you want to delete plan:\n"
                f"💎 <b>{plan_name.upper()}</b>?\n\n"
                f"⚠️ All users on this plan will revert to <b>FREE</b>."
            )
            markup = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(f"✅ Yes, Delete", callback_data=f"plan_confirm_del_{plan_name}"),
                    InlineKeyboardButton("❌ Cancel", callback_data="plan_refresh"),
                ]
            ])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Confirm delete ────────────────────────────────────────────────────
        elif data.startswith("plan_confirm_del_"):
            plan_name = data[17:]
            if plan_name == "free":
                await cb.answer("❌ Cannot delete free plan!", show_alert=True)
                return
            await db.delete_plan(plan_name)
            await cb.answer(f"✅ Plan '{plan_name.upper()}' deleted!", show_alert=True)
            # Refresh plans list
            await _refresh_plans_message(cb.message)

        # ── Add plan help ─────────────────────────────────────────────────────
        elif data == "plan_add_help":
            text = (
                f"<b>➕ 𝗔𝗱𝗱 𝗡𝗲𝘄 𝗣𝗹𝗮𝗻</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Send this command in chat:\n\n"
                f"<code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards&gt;</code>\n\n"
                f"<b>Examples:</b>\n"
                f"<code>/addplan pro 10 2000</code>\n"
                f"<code>/addplan vip 25 10000</code>\n"
                f"<code>/addplan basic 5 500</code>\n\n"
                f"<b>Fields:</b>\n"
                f"• <code>name</code> — Plan name (e.g. pro, vip)\n"
                f"• <code>workers</code> — Concurrent check threads\n"
                f"• <code>cards</code> — Max cards per /mchk batch"
            )
            markup = InlineKeyboardMarkup([[
                InlineKeyboardButton("⬅️ Back to Plans", callback_data="plan_refresh")
            ]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Refresh plan list ─────────────────────────────────────────────────
        elif data == "plan_refresh":
            await _refresh_plans_message(cb.message)
            await cb.answer()


async def _refresh_plans_message(message):
    """Rebuild and edit the plans list message."""
    from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    import database.db as db

    all_plans = await db.get_all_plans()
    if not all_plans:
        await message.edit_text(
            "❌ <b>No plans configured.</b>\n\n"
            "Add one with:\n<code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards_limit&gt;</code>",
            parse_mode=enums.ParseMode.HTML
        )
        return

    text = (
        "<b>📋 𝗣𝗹𝗮𝗻 𝗠𝗮𝗻𝗮𝗴𝗲𝗿</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "<blockquote>"
    )
    buttons = []
    for p in all_plans:
        pname = p["plan_name"].upper()
        text += (
            f"💎 <b>{pname}</b>\n"
            f"   ⚙️ Workers: <code>{p['max_workers']}</code> | 🃏 Cards: <code>{p['max_cards']}</code>\n"
        )
        row = [InlineKeyboardButton(f"✏️ Edit {pname}", callback_data=f"plan_edit_{p['plan_name']}")]
        if p["plan_name"] != "free":
            row.append(InlineKeyboardButton(f"🗑️ Del {pname}", callback_data=f"plan_del_{p['plan_name']}"))
        buttons.append(row)

    text += "</blockquote>\n━━━━━━━━━━━━━━━━━━━━━━\n"
    text += "➕ Add: <code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards&gt;</code>"
    buttons.append([InlineKeyboardButton("➕ Add New Plan", callback_data="plan_add_help")])

    await message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(buttons),
        parse_mode=enums.ParseMode.HTML
    )
