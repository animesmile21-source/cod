# CC Checker Pro Bot — Setup Guide

## 📁 Project Structure
```
cc chexiker/
├── bot.py              ← Main entry point
├── config.py           ← Config loader
├── requirements.txt
├── .env                ← Your secrets (create from .env.example)
├── core/
│   ├── parser.py       ← CC string parser
│   ├── validator.py    ← Luhn + expiry check
│   ├── bin_lookup.py   ← BIN info (bank, country)
│   ├── card_gen.py     ← Card generator
│   └── queue_manager.py← Async queue + rate limit
├── gateways/
│   ├── base.py         ← Status types
│   ├── stripe_gate.py  ← Stripe auth (primary)
│   ├── braintree_gate.py← Braintree auth (secondary)
│   └── router.py       ← Smart gateway selector
├── handlers/
│   ├── commands.py     ← /start /help /bin /stats /gates
│   ├── checker.py      ← /chk /mchk
│   ├── generator.py    ← /gen
│   └── admin.py        ← /addkey /keys /gstats
├── utils/
│   └── formatter.py    ← Message formatter
└── database/
    └── db.py           ← SQLite manager
```

## ⚙️ Setup Steps

### Step 1: Create .env file
```
copy .env.example .env
```
Then edit `.env` and fill in:
- `BOT_TOKEN` — from @BotFather
- `API_ID` + `API_HASH` — from my.telegram.org
- `OWNER_IDS` — your Telegram user ID
- `STRIPE_KEYS` — your Stripe secret key(s)

### Step 2: Install dependencies
```
pip install -r requirements.txt
```

### Step 3: Run the bot
```
python bot.py
```

## 🔑 Getting API Keys

### Telegram Bot Token
1. Open @BotFather on Telegram
2. Send `/newbot`
3. Copy the token → `BOT_TOKEN`

### Telegram API ID & Hash
1. Go to https://my.telegram.org
2. Log in → API Development Tools
3. Create app → copy `api_id` and `api_hash`

### Your Telegram ID
1. Start the bot
2. Send `/id` → it shows your user ID
3. Put that in `OWNER_IDS`

### Stripe API Key
1. Go to https://dashboard.stripe.com
2. Developers → API Keys
3. Copy **Secret key** (`sk_live_...`)
4. Put in `STRIPE_KEYS`

## 🤖 Bot Commands

| Command | Usage |
|---------|-------|
| `/chk` | `/chk 4111111111111111\|12\|2026\|123` |
| `/mchk` | Reply to .txt file with `/mchk` |
| `/gen` | `/gen 414720` or `/gen 414720\|xx\|2026\|xxx 20` |
| `/bin` | `/bin 414720` |
| `/gates` | Shows active gateways |
| `/stats` | Your check stats |
| `/id` | Your Telegram ID |
| `/addkey` | (Owner) Add Stripe key live |
| `/keys` | (Owner) List loaded keys |
| `/gstats` | (Owner) Global stats |

## 📊 VBV/Non-VBV Results

| Result | Meaning |
|--------|---------|
| ✅ CHARGED | Live, Non-VBV, auth passed |
| 🔐 LIVE VBV | Live, VBV/3DS verification required |
| ⚠️ INSUFFICIENT | Card live but no balance |
| ❌ DEAD | Invalid/declined |
| 🚫 DO NOT HONOR | Bank explicitly blocked |
| 🚫 PICK UP/STOLEN | Card reported lost/stolen |
