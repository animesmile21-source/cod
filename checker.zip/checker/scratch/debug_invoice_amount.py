"""
scratch/debug_invoice_amount.py
Find the EXACT expected_amount Stripe uses for confirm
Dump all amount-related fields from payment_pages response
"""
import asyncio, sys, json, re
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SESSION_ID = "cs_live_b1YfZ33sNDqcQG1eGwEOWxnahjdUhQbh3XXmzeQIs857Un665eqAFYWrqw"
PK = "pk_live_515YpNsJAmnYVOvfnvSNdvO8CE8JjpFDxuoyJMSpRaLUwuAQzfXEdKkvtBoW6uOSjzIa2VQkHfdR17r5eWmM15Z8f00qYlxqIFD"

HEADERS = {
    "accept": "application/json",
    "content-type": "application/x-www-form-urlencoded",
    "origin": "https://checkout.stripe.com",
    "referer": "https://checkout.stripe.com/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
}

def find_amounts(obj, path=""):
    """Recursively find all fields with numeric values > 100 (likely amounts)"""
    results = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            new_path = f"{path}.{k}" if path else k
            if isinstance(v, (int, float)) and v > 100 and "amount" in k.lower() or \
               isinstance(v, (int, float)) and v > 10000 and k.lower() in ("due","total","subtotal","cost","price","value","sum","charge"):
                results.append((new_path, v))
            results.extend(find_amounts(v, new_path))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            results.extend(find_amounts(v, f"{path}[{i}]"))
    return results


async def main():
    from curl_cffi.requests import AsyncSession

    async with AsyncSession(impersonate="chrome131") as s:

        # 1. GET payment_pages
        print("[1] GET /v1/payment_pages...")
        r = await s.get(
            f"https://api.stripe.com/v1/payment_pages/{SESSION_ID}?key={PK}&eid=NA",
            headers=HEADERS
        )
        data = r.json()
        with open("scratch/pp_debug.json", "w") as f:
            json.dump(data, f, indent=2)
        print("  Saved: scratch/pp_debug.json")

        print("\n  ALL AMOUNT FIELDS (from GET):")
        amounts = find_amounts(data)
        for path, val in sorted(set(amounts)):
            print(f"    {path}: {val}")

        print("\n  invoice field:")
        print(json.dumps(data.get("invoice"), indent=2)[:500] if data.get("invoice") else "  (null)")

        print("\n  total_summary:")
        print(json.dumps(data.get("total_summary"), indent=2)[:300])

        print("\n  checkout_items:")
        items = data.get("checkout_items") or []
        for item in items[:3]:
            print(f"  {json.dumps(item)[:200]}")

        # 2. POST with tax_region (DL)
        print("\n[2] POST with tax_region...")
        r2 = await s.post(
            f"https://api.stripe.com/v1/payment_pages/{SESSION_ID}",
            headers=HEADERS,
            data={
                "eid": "NA",
                "tax_region[country]": "IN",
                "tax_region[state]": "DL",
                "tax_region[postal_code]": "110080",
                "tax_region[line1]": "615 Main Road",
                "tax_region[city]": "New Delhi",
                "key": PK,
            }
        )
        data2 = r2.json()
        with open("scratch/pp_tax_debug.json", "w") as f:
            json.dump(data2, f, indent=2)
        print("  Saved: scratch/pp_tax_debug.json")

        print("\n  ALL AMOUNT FIELDS (after tax POST):")
        amounts2 = find_amounts(data2)
        for path, val in sorted(set(amounts2)):
            print(f"    {path}: {val}")

        print("\n  total_summary (after tax):")
        print(json.dumps(data2.get("total_summary"), indent=2)[:500])

        print("\n  invoice (after tax):")
        inv = data2.get("invoice")
        if inv:
            print(json.dumps(inv, indent=2)[:500])
        else:
            print("  (null)")

        # 3. Try confirm with 236314 and see full error
        print("\n[3] Test confirm with 236314...")
        r3 = await s.post(
            f"https://api.stripe.com/v1/payment_pages/{SESSION_ID}/confirm",
            headers=HEADERS,
            data={
                "eid": "NA",
                "payment_method": "pm_1TvpxoJAmnYVOvfnoAnmCdJ6",  # already created earlier
                "expected_amount": "236314",
                "tax_id_collection[purchasing_as_business]": "false",
                "expected_payment_method_type": "card",
                "key": PK,
                "version": "fe3c872f40",
            }
        )
        print(f"  Status: {r3.status_code}")
        print(f"  Response: {json.dumps(r3.json())[:500]}")


if __name__ == "__main__":
    asyncio.run(main())
