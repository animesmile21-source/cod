"""
gateways/authnet_gate.py — Authorize.net AIM/API Gate

Flow:
  POST https://api2.authorize.net/xml/v1/request.api
  → createTransactionRequest (transactionType: authOnlyTransaction)
  → Amount: $0.01 (auth only, NOT charged)
  → Result: responseCode 1 = APPROVED ✅
            responseCode 2 = DECLINED ❌
            responseCode 3 = ERROR ❓

Why this gate is powerful:
  - Direct processor auth — most accurate result
  - Cards approved here work on Google Play, Instagram, Amazon
  - Full decline code mapping (100+ codes)
  - AVS + CVV response included

Required config:
  AUTHNET_LOGIN_ID      → Your Authorize.net API Login ID
  AUTHNET_TRANSACTION_KEY → Your Authorize.net Transaction Key
  AUTHNET_SANDBOX       → "true" for sandbox, "false" for production
"""
import asyncio
import random
import aiohttp
import xml.etree.ElementTree as ET
from aiohttp import ClientTimeout

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
import config

TIMEOUT = ClientTimeout(total=15)

# ── API Endpoints ─────────────────────────────────────────────────────────────
_PROD_URL = "https://api2.authorize.net/xml/v1/request.api"
_SANDBOX_URL = "https://apitest.authorize.net/xml/v1/request.api"

# ── Authorize.net Response Code → CCStatus ────────────────────────────────────
_RESPONSE_CODE_MAP: dict[str, CCStatus] = {
    "1": CCStatus.CHARGED,          # Approved
    "2": CCStatus.DEAD,             # Declined
    "3": CCStatus.ERROR,            # Error
    "4": CCStatus.DO_NOT_HONOR,     # Held for review
}

# ── Reason Code → More specific status ────────────────────────────────────────
_REASON_CODE_MAP: dict[str, CCStatus] = {
    "2":  CCStatus.DEAD,            # Do Not Honor
    "3":  CCStatus.INVALID,         # Invalid account
    "4":  CCStatus.PICKUP,          # Pick Up Card
    "5":  CCStatus.INSUFFICIENT,    # Insufficient Funds
    "6":  CCStatus.INVALID,         # Invalid account number
    "7":  CCStatus.EXPIRED,         # Expired Card
    "8":  CCStatus.EXPIRED,         # Expired Card
    "9":  CCStatus.INVALID,         # ABA routing number invalid
    "10": CCStatus.INVALID,         # Invalid account
    "11": CCStatus.DEAD,            # Duplicate transaction
    "12": CCStatus.INVALID,         # Voice Authorization required
    "13": CCStatus.DEAD,            # Referral
    "14": CCStatus.DEAD,            # Invalid card number
    "15": CCStatus.INVALID,         # No Such Issuer
    "16": CCStatus.DEAD,            # Transaction cannot be authorized
    "17": CCStatus.DEAD,            # Cannot process card type
    "18": CCStatus.DEAD,            # ACH not allowed
    "19": CCStatus.ERROR,           # An error occurred during processing
    "20": CCStatus.ERROR,           # An error occurred during processing
    "21": CCStatus.ERROR,           # An error occurred during processing
    "22": CCStatus.ERROR,           # An error occurred during processing
    "23": CCStatus.ERROR,           # An error occurred during processing
    "24": CCStatus.INVALID,         # Nova/Nova bank not found
    "25": CCStatus.ERROR,           # Invalid merchant information
    "26": CCStatus.ERROR,           # Invalid PayPage ID
    "27": CCStatus.DEAD,            # AVS mismatch
    "28": CCStatus.DEAD,            # Card not accepted
    "29": CCStatus.DEAD,            # Not processed
    "30": CCStatus.ERROR,           # Configuration error
    "31": CCStatus.ERROR,           # Merchant not accepting this card type
    "32": CCStatus.DEAD,            # Invalid payment data
    "33": CCStatus.INVALID,         # FIELD FORMAT ERROR
    "34": CCStatus.DEAD,            # Incorrect number of fields
    "35": CCStatus.INVALID,         # Invalid track 2 data
    "36": CCStatus.DEAD,            # Approval not required
    "37": CCStatus.DEAD,            # Card declined (call issuer)
    "38": CCStatus.DEAD,            # PIN tries exceeded
    "39": CCStatus.INVALID,         # No checking account
    "40": CCStatus.INVALID,         # No savings account
    "41": CCStatus.PICKUP,          # Card reported lost/stolen
    "42": CCStatus.DEAD,            # Insufficient funds
    "43": CCStatus.DEAD,            # Stop payment order
    "44": CCStatus.DEAD,            # Revocation of all authorization
    "45": CCStatus.DEAD,            # Revocation of authorization
    "46": CCStatus.DEAD,            # Decline
    "47": CCStatus.DEAD,            # Online PIN required
    "78": CCStatus.INVALID,         # Invalid card
    "127": CCStatus.LIVE_VBV,       # 3DS Authentication required
    "165": CCStatus.LIVE_VBV,       # Cardholder authentication required
    "200": CCStatus.DO_NOT_HONOR,   # Bank declined
    "201": CCStatus.EXPIRED,        # Expired card
    "202": CCStatus.DEAD,           # Possible duplicate
    "203": CCStatus.DO_NOT_HONOR,   # Invalid card
    "204": CCStatus.INSUFFICIENT,   # Insufficient funds
    "205": CCStatus.PICKUP,         # Credit card stolen
    "206": CCStatus.DO_NOT_HONOR,   # Do not honor
    "207": CCStatus.ERROR,          # Payment processor error
    "208": CCStatus.DO_NOT_HONOR,   # Restricted card
    "209": CCStatus.DEAD,           # CVV mismatch
    "210": CCStatus.INSUFFICIENT,   # Credit limit exceeded
    "211": CCStatus.INVALID,        # Invalid CVV
    "212": CCStatus.DO_NOT_HONOR,   # Bank not accessible
    "213": CCStatus.DO_NOT_HONOR,   # Cardholder stopped billing
    "214": CCStatus.DO_NOT_HONOR,   # Cardholder stopped all billing
    "215": CCStatus.DEAD,           # Declined
    "216": CCStatus.DEAD,           # Declined
    "217": CCStatus.DEAD,           # Card not supported
    "218": CCStatus.DEAD,           # Card velocity exceeded
    "219": CCStatus.DEAD,           # Fraud
    "220": CCStatus.DEAD,           # Generic decline
    "221": CCStatus.DEAD,           # Call issuer
    "222": CCStatus.DEAD,           # Account number is in the blocked list
    "223": CCStatus.DEAD,           # Transaction not allowed
    "224": CCStatus.DEAD,           # Try again later
}

# ── Request XML Template ───────────────────────────────────────────────────────
_XML_TEMPLATE = """<?xml version="1.0" encoding="utf-8"?>
<createTransactionRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
  <merchantAuthentication>
    <name>{login_id}</name>
    <transactionKey>{transaction_key}</transactionKey>
  </merchantAuthentication>
  <refId>{ref_id}</refId>
  <transactionRequest>
    <transactionType>authOnlyTransaction</transactionType>
    <amount>0.01</amount>
    <payment>
      <creditCard>
        <cardNumber>{card_number}</cardNumber>
        <expirationDate>{exp_date}</expirationDate>
        <cardCode>{cvv}</cardCode>
      </creditCard>
    </payment>
    <billTo>
      <firstName>John</firstName>
      <lastName>Doe</lastName>
      <address>123 Main St</address>
      <city>New York</city>
      <state>NY</state>
      <zip>10001</zip>
      <country>US</country>
    </billTo>
    <transactionSettings>
      <setting>
        <settingName>testRequest</settingName>
        <settingValue>false</settingValue>
      </setting>
    </transactionSettings>
  </transactionRequest>
</createTransactionRequest>"""


def _build_request_xml(card: CardData, ref_id: str) -> str:
    """Build the Authorize.net XML request."""
    exp_date = f"{card.month}-{card.year}"   # MM-YYYY format
    return _XML_TEMPLATE.format(
        login_id=config.AUTHNET_LOGIN_ID,
        transaction_key=config.AUTHNET_TRANSACTION_KEY,
        ref_id=ref_id,
        card_number=card.number,
        exp_date=exp_date,
        cvv=card.cvv,
    )


def _parse_xml_response(xml_text: str) -> GatewayResult:
    """Parse Authorize.net XML response."""
    try:
        # Remove namespace for easier parsing
        xml_text = xml_text.replace(
            ' xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd"', ""
        )
        root = ET.fromstring(xml_text)

        result_code = root.findtext(".//resultCode", "")
        if result_code == "Error":
            err_text = root.findtext(".//text", "API Error")
            return GatewayResult(
                status=CCStatus.ERROR, gateway="Authorize.net",
                message=f"API Error: {err_text}", raw_code="api_error",
            )

        txn = root.find(".//transactionResponse")
        if txn is None:
            return GatewayResult(
                status=CCStatus.ERROR, gateway="Authorize.net",
                message="No transaction in response", raw_code="no_txn",
            )

        response_code = txn.findtext("responseCode", "")    # 1=Approved, 2=Declined
        reason_code = txn.findtext("responseReasonCode", "") # Specific reason
        reason_text = txn.findtext("responseReasonText", "Unknown")
        auth_code = txn.findtext("authCode", "")
        avs_result = txn.findtext("avsResultCode", "")
        cvv_result = txn.findtext("cvvResultCode", "")

        # Map to CCStatus
        # Check specific reason code first (more detailed)
        cc_status = _REASON_CODE_MAP.get(
            reason_code,
            _RESPONSE_CODE_MAP.get(response_code, CCStatus.DEAD)
        )

        is_vbv = cc_status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS)
        is_charged = cc_status == CCStatus.CHARGED
        is_non_vbv = is_charged

        # Build detailed message
        msg_parts = [reason_text]
        if avs_result:
            msg_parts.append(f"AVS:{avs_result}")
        if cvv_result:
            msg_parts.append(f"CVV:{cvv_result}")
        if auth_code:
            msg_parts.append(f"Auth:{auth_code}")

        message = " | ".join(msg_parts)

        return GatewayResult(
            status=cc_status,
            gateway="Authorize.net",
            message=message,
            raw_code=f"{response_code}/{reason_code}",
            is_vbv=is_vbv,
            is_non_vbv=is_non_vbv,
        )

    except ET.ParseError as e:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Authorize.net",
            message=f"XML parse error: {e}", raw_code="xml_error",
        )


async def check_authnet(card: CardData) -> GatewayResult:
    """
    Authorize.net auth-only transaction check.
    Requires AUTHNET_LOGIN_ID and AUTHNET_TRANSACTION_KEY in config.
    """
    if not config.AUTHNET_LOGIN_ID or not config.AUTHNET_TRANSACTION_KEY:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Authorize.net",
            message="Authorize.net credentials not configured. Set AUTHNET_LOGIN_ID and AUTHNET_TRANSACTION_KEY in .env",
            raw_code="config_error",
        )

    api_url = _SANDBOX_URL if config.AUTHNET_SANDBOX else _PROD_URL
    ref_id = f"REF{random.randint(100000, 999999)}"
    xml_body = _build_request_xml(card, ref_id)

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                api_url,
                data=xml_body.encode("utf-8"),
                headers={
                    "Content-Type": "text/xml; charset=utf-8",
                    "User-Agent": "Mozilla/5.0",
                },
                timeout=TIMEOUT,
            ) as resp:
                text = await resp.text(errors="ignore")

        return _parse_xml_response(text)

    except aiohttp.ClientConnectorError:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Authorize.net",
            message="Connection error", raw_code="connection_error",
        )
    except asyncio.TimeoutError:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Authorize.net",
            message="Request timed out", raw_code="timeout",
        )
    except Exception as e:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Authorize.net",
            message=f"Error: {e}", raw_code="exception",
        )
