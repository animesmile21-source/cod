"""rebuild_gateway.py — Rebuilds razorpay_gate.py cleanly"""
import ast

# Read current file
with open("gateways/razorpay_gate.py", encoding="utf-8") as f:
    content = f.read()

# Keep only lines 1-435 (clean header + helpers)
lines = content.split("\n")
clean_top = "\n".join(lines[:435])

new_function = '''

async def check_razorpay(card: CardData, proxy: dict | None = None) -> GatewayResult:
    """
    Main Razorpay CC checker via checkout ajax endpoint.
    Handles: OTP flow (RuPay/Indian cards), 3DS redirect, direct auth, errors.
    """
    if not config.RAZORPAY_KEY_ID or not config.RAZORPAY_KEY_SECRET:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Razorpay",
            message="Razorpay credentials not configured! Set in .env",
            raw_code="config_error",
        )

    amount_paise = _pick_amount()
    amount_inr   = amount_paise // 100
    connector    = _build_connector(proxy)
    proxy_kwargs = _build_proxy_kwargs(proxy)

    try:
        session_kwargs = {"timeout": TIMEOUT}
        if connector:
            session_kwargs["connector"] = connector

        async with aiohttp.ClientSession(**session_kwargs) as session:

            order = await _create_order(session, amount_paise, proxy_kwargs)
            if not order:
                return GatewayResult(
                    status=CCStatus.ERROR, gateway="Razorpay",
                    message="Failed to create order",
                    raw_code="order_create_failed",
                )

            order_id = order["id"]
            http_status, resp = await _submit_payment(
                session, order_id, amount_paise, card, proxy_kwargs
            )

            # ── Hard error object ────────────────────────────────────────────
            if "error" in resp:
                return _parse_error(resp, amount_inr, http_status=http_status)

            # ── HTTP 500 no error key = unsupported card ─────────────────────
            if http_status == 500:
                return GatewayResult(
                    status=CCStatus.DEAD, gateway="Razorpay",
                    message=f"Declined | Card Not Supported | INR {amount_inr}",
                    raw_code="server_error_500",
                )

            # ── CASE A: OTP flow — RuPay / Indian domestic cards ────────────
            # Response has type="otp" and next=["otp_submit","otp_resend"]
            # This means OTP was sent to cardholder's phone -> card is LIVE VBV
            if resp.get("type") == "otp" or (
                "payment_id" in resp
                and "next" in resp
                and isinstance(resp.get("next"), list)
            ):
                meta      = resp.get("metadata", {})
                pid       = resp.get("payment_id", "")
                network   = (meta.get("network") or "").upper()
                issuer    = meta.get("issuer") or "Unknown"
                card_type = (meta.get("card_type") or "").capitalize()
                last4     = meta.get("last4", "")
                net_label = {
                    "RUPAY": "RuPay", "VISA": "Visa",
                    "MASTERCARD": "Mastercard", "AMEX": "Amex",
                }.get(network, network or "Card")

                return GatewayResult(
                    status=CCStatus.LIVE_VBV, gateway="Razorpay",
                    message=f"OTP Sent | INR {amount_inr} | {net_label} LIVE (VBV)",
                    raw_code="otp_sent", is_vbv=True,
                    extra={
                        "order_id": order_id, "payment_id": pid,
                        "issuer": issuer, "network": network,
                        "card_type": card_type, "last4": last4,
                    },
                )

            # ── CASE B: Standard payment object (id + status) ───────────────
            pid = resp.get("id") or resp.get("razorpay_payment_id") or ""
            if http_status == 200 and pid:
                pay_status  = resp.get("status", "")
                next_action = resp.get("next_action") or resp.get("next")

                if pay_status in ("authorized", "captured"):
                    return GatewayResult(
                        status=CCStatus.CHARGED, gateway="Razorpay",
                        message=f"Authorized | INR {amount_inr} | Non-VBV LIVE",
                        raw_code=pay_status, is_non_vbv=True,
                        charge_amount=float(amount_inr),
                        extra={"order_id": order_id, "payment_id": pid},
                    )
                if pay_status == "created" and next_action:
                    return GatewayResult(
                        status=CCStatus.LIVE_VBV, gateway="Razorpay",
                        message=f"3DS Required | INR {amount_inr} | Card LIVE (VBV)",
                        raw_code="3ds_redirect", is_vbv=True,
                        extra={"order_id": order_id, "payment_id": pid},
                    )
                if pay_status == "created":
                    return GatewayResult(
                        status=CCStatus.LIVE_VBV, gateway="Razorpay",
                        message=f"Auth Pending | INR {amount_inr} | Card possibly LIVE",
                        raw_code="created_no_action", is_vbv=True,
                        extra={"order_id": order_id, "payment_id": pid},
                    )
                if pay_status == "failed":
                    err_desc = resp.get("error_description") or resp.get("error_reason", "Declined")
                    return GatewayResult(
                        status=CCStatus.DEAD, gateway="Razorpay",
                        message=f"Payment Failed | {err_desc} | INR {amount_inr}",
                        raw_code=resp.get("error_code", "failed"),
                        extra={"order_id": order_id, "payment_id": pid},
                    )

            # ── Unknown / unhandled response ─────────────────────────────────
            raw_preview = str(resp)[:150]
            return GatewayResult(
                status=CCStatus.ERROR, gateway="Razorpay",
                message=f"Unknown response [HTTP {http_status}] | {raw_preview}",
                raw_code=f"http_{http_status}",
                extra={"order_id": order_id},
            )

    except ValueError as e:
        return GatewayResult(status=CCStatus.ERROR, gateway="Razorpay",
                             message=str(e), raw_code="config_error")
    except Exception as e:
        return GatewayResult(status=CCStatus.ERROR, gateway="Razorpay",
                             message=f"Exception: {type(e).__name__}: {e}",
                             raw_code="exception")
'''

final = clean_top + new_function

# Verify syntax
try:
    ast.parse(final)
    print("Syntax OK!")
except SyntaxError as e:
    print(f"SYNTAX ERROR: {e}")
    exit(1)

with open("gateways/razorpay_gate.py", "w", encoding="utf-8") as f:
    f.write(final)

print(f"Written {len(final.splitlines())} lines")
