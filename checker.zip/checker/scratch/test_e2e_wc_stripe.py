"""
Full End-to-End Test of Step 4 (Stripe Tokenize) + Step 5 (WooCommerce Confirm)
"""
import asyncio, sys, re, random, json
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from curl_cffi.requests import AsyncSession
from faker import Faker
faker = Faker()

TEST_SITE = "https://ea-courses.com"

async def test_full_wc_stripe_flow():
    print("=" * 75)
    print("🔬 Testing End-to-End WooCommerce Stripe Flow (Step 4 Tokenize + Step 5 Confirm)")
    print("=" * 75)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        "Accept": "*/*",
    }

    async with AsyncSession(impersonate="chrome131") as s:
        # Step 1 & 2: Get page & register
        url_1 = f"{TEST_SITE}/my-account/add-payment-method/"
        r1 = await s.get(url_1, headers=headers)
        html_1 = r1.text

        # Extract PK
        pk_m = re.search(r'pk_live_[a-zA-Z0-9]{24,}', html_1)
        pk = pk_m.group(0) if pk_m else None
        print(f"🔑 Stripe PK: {pk}")

        reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
        if reg_match:
            reg_nonce = reg_match.group(1)
            fake_user = faker.user_name()[:10] + str(random.randint(100, 999))
            data_reg = {
                'email': faker.email(),
                'username': fake_user,
                'woocommerce-register-nonce': reg_nonce,
                'register': 'Register',
            }
            await s.post(f"{TEST_SITE}/my-account/", headers=headers, data=data_reg)
            r_auth = await s.get(url_1, headers=headers)
            html_1 = r_auth.text

        # Extract Nonce
        m = re.search(r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"', html_1)
        if not m:
            m = re.search(r'"_ajax_nonce"\s*:\s*"([^"]+)"', html_1)

        nonce = m.group(1) if m else "test_nonce"
        print(f"🎫 Extracted Nonce: {nonce}")

        # Step 4: Tokenize test card on Stripe API
        stripe_url = "https://api.stripe.com/v1/payment_methods"
        muid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
        sid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
        guid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
        client_id = "src_" + "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=16))

        # Standard test card number
        card_num = "4000000000000002"
        data_3 = {
            'type': 'card',
            'card[number]': card_num,
            'card[cvc]': '123',
            'card[exp_year]': '2028',
            'card[exp_month]': '12',
            'allow_redisplay': 'unspecified',
            'billing_details[address][postal_code]': '10001',
            'billing_details[address][country]': 'US',
            'payment_user_agent': 'stripe.js/c1fbe29896; stripe-js-v3/c1fbe29896; payment-element; deferred-intent',
            'referrer': TEST_SITE,
            'time_on_page': '25000',
            'guid': guid, 'muid': muid, 'sid': sid, 'key': pk,
            '_stripe_version': '2024-06-20',
        }

        r3 = await s.post(stripe_url, headers=headers, data=data_3)
        print(f"\nStep 4 Stripe Tokenize Status: {r3.status_code}")
        print(f"Step 4 Stripe Response: {r3.text[:250]}")

        if r3.status_code == 200:
            pm = json.loads(r3.text).get('id')
            print(f"💳 Created PaymentMethod ID: {pm}")

            # Step 5: Submit to WooCommerce AJAX
            ajax_url = f"{TEST_SITE}/?wc-ajax=wc_stripe_create_and_confirm_setup_intent"
            ajax_headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
            }
            payload_5 = {
                'action': 'create_and_confirm_setup_intent',
                'wc-stripe-payment-method': pm,
                'wc-stripe-payment-type': 'card',
                '_ajax_nonce': nonce,
            }

            r5 = await s.post(ajax_url, headers=ajax_headers, data=payload_5)
            print(f"\nStep 5 WC Confirm Status: {r5.status_code}")
            print(f"Step 5 WC Response: {r5.text}")

if __name__ == "__main__":
    asyncio.run(test_full_wc_stripe_flow())
