import sys, asyncio, os
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

import database.db as db

async def main():
    await db.init_db()
    # List tables
    try:
        tables_res = await db._db.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in tables_res]
        print("Database tables:", tables)
        for t in ["shopify_gates", "proxies", "users", "hits", "wc_bt_gates"]:
            if t in tables:
                cnt_res = await db._db.execute(f"SELECT COUNT(*) FROM {t}")
                print(f"  Table '{t}' has {cnt_res[0][0]} rows")
                if t == "wc_bt_gates":
                    sample = await db._db.execute(f"SELECT id, base_url, is_active FROM {t} LIMIT 5")
                    print("  Sample:", sample)
    except Exception as e:
        print("Error:", e)

asyncio.run(main())
