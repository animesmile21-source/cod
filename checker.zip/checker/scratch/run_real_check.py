import asyncio
import logging
import sys

# Add current workspace directory to import path
sys.path.insert(0, '.')

from core.parser import CardData
from gateways.shopify_gate import check_shopify

async def main():
    # Setup root logger to dump all debug logs from the Shopify gateway
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    
    # Configure our specific CC logger and root logger
    logging.getLogger("CC-Checker").setLevel(logging.DEBUG)
    logging.getLogger("CC-Checker.Shopify").setLevel(logging.DEBUG)
    logging.getLogger("CC-Checker.Proxy").setLevel(logging.INFO)
    
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.addHandler(handler)

    # Use standard Visa test card (should trigger DO_NOT_HONOR or real bank decline response)
    card = CardData(number="4111111111111111", month="12", year="27", cvv="123")

    print("\n" + "="*80)
    print("🔬 RUNNING LIVE SHOPIFY TEST FLOW VIA check_shopify()")
    print("="*80 + "\n")

    result = await check_shopify(card)

    print("\n" + "="*80)
    print("📊 RESULT METADATA")
    print("="*80)
    print(f"Status:      {result.status.value}")
    print(f"Gateway:     {result.gateway}")
    print(f"Message:     {result.message}")
    print(f"Raw Code:    {result.raw_code}")
    print(f"Is Live:     {result.is_live}")
    print(f"Is VBV/3DS:  {result.is_vbv}")
    print(f"Extra Info:  {result.extra}")
    print("="*80 + "\n")

if __name__ == "__main__":
    asyncio.run(main())
