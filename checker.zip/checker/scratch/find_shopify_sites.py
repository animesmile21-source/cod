﻿"""
Shopify Sites Finder - No Proxy Required
Uses Bing + DDG + Yahoo with 30+ dork queries
Saves results to shopify_sites_found.txt in real-time
Target: 2000 unique Shopify sites
"""
import asyncio, sys, aiohttp, re, time, random
from urllib.parse import urlencode, unquote, urlparse
sys.path.insert(0, r"c:\Users\rdx27\Desktop\all bots\checker")

OUTPUT_FILE = r"c:\Users\rdx27\Desktop\all bots\checker\shopify_sites_found.txt"
TARGET = 2000

UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
]

# 50+ Shopify dork queries for maximum coverage
DORKS = [
    # myshopify.com direct
    "site:myshopify.com",
    "site:myshopify.com cheap buy",
    "site:myshopify.com clothing",
    "site:myshopify.com jewelry",
    "site:myshopify.com electronics",
    "site:myshopify.com home garden",
    "site:myshopify.com beauty skincare",
    "site:myshopify.com shoes sneakers",
    "site:myshopify.com phone accessories",
    "site:myshopify.com gifts",
    "site:myshopify.com sports fitness",
    "site:myshopify.com pet supplies",
    "site:myshopify.com art prints",
    "site:myshopify.com food supplements",
    "site:myshopify.com baby kids",
    "site:myshopify.com tools hardware",
    "site:myshopify.com books stationery",
    "site:myshopify.com toys games",
    "site:myshopify.com automotive",
    "site:myshopify.com outdoor camping",
    # Shopify signals on custom domains
    '"powered by shopify" "add to cart" shop',
    '"powered by shopify" cheap usa buy now',
    '"cdn.shopify.com" "add to cart" cheap',
    '"cdn.shopify.com" shop usa online store',
    '"shopify.com/s/files" buy online cheap',
    '"shopify" checkout "add to cart" usa shop',
    '"Shopify.theme" online store usa',
    '"myshopify.com" products buy',
    # Category specific
    '"powered by shopify" women clothing usa',
    '"powered by shopify" men shoes usa',
    '"powered by shopify" skincare usa buy',
    '"powered by shopify" supplements usa',
    '"powered by shopify" home decor usa buy',
    '"powered by shopify" phone case usa',
    '"powered by shopify" jewelry necklace',
    '"powered by shopify" baby clothing',
    '"powered by shopify" fitness gym',
    '"powered by shopify" gaming accessories',
    '"powered by shopify" hair products',
    '"powered by shopify" candles wax',
    '"powered by shopify" tshirt hoodie',
    '"powered by shopify" stickers art',
    '"powered by shopify" coffee tea',
    '"powered by shopify" books ebooks',
    '"powered by shopify" plants seeds',
    '"powered by shopify" crystals gems',
    '"powered by shopify" soap handmade',
    '"powered by shopify" prints posters',
    '"powered by shopify" watches usa',
    '"powered by shopify" bags purse',
]

JUNK_DOMAINS = {
    "shopify.com", "google.com", "bing.com", "yahoo.com", "duckduckgo.com",
    "amazon.com", "facebook.com", "twitter.com", "instagram.com", "youtube.com",
    "reddit.com", "stackoverflow.com", "github.com", "wikipedia.org",
    "medium.com", "linkedin.com", "tiktok.com", "etsy.com", "ebay.com",
}

def extract_shopify_urls(html, seen):
    found = []
    # Direct myshopify.com URLs
    for m in re.finditer(r'(https?://[\w\-]+\.myshopify\.com)', html, re.I):
        try:
            p = urlparse(m.group(1))
            base = f"{p.scheme}://{p.netloc}".lower()
            if base not in seen and ".myshopify.com" in base and base != "https://myshopify.com":
                seen.add(base)
                found.append(base)
        except: pass

    # Bing result links
    for m in re.finditer(r'<a[^>]+href="(https?://[^"]+)"[^>]*>', html, re.I):
        raw = m.group(1)
        if "bing.com" in raw or "microsoft.com" in raw: continue
        try:
            p = urlparse(raw)
            domain = p.netloc.lower().lstrip("www.")
            base = f"{p.scheme}://{p.netloc}".lower()
            if base in seen: continue
            if any(domain == j or domain.endswith("."+j) for j in JUNK_DOMAINS): continue
            if domain.endswith(".myshopify.com"):
                seen.add(base); found.append(base)
            elif p.scheme.startswith("http") and "." in domain and len(domain) > 4:
                # Only add if has shopify signal in URL or text around it
                if "shopify" in raw.lower():
                    seen.add(base); found.append(base)
        except: pass

    # DDG/Yahoo result URLs
    for m in re.finditer(r'uddg=(https?%3A%2F%2F[^&"]+)', html, re.I):
        try:
            raw = unquote(m.group(1))
            p = urlparse(raw)
            domain = p.netloc.lower().lstrip("www.")
            base = f"{p.scheme}://{p.netloc}".lower()
            if base not in seen and not any(domain == j or domain.endswith("."+j) for j in JUNK_DOMAINS):
                if domain.endswith(".myshopify.com") or "shopify" in raw.lower():
                    seen.add(base); found.append(base)
        except: pass

    # Generic href extraction for any shopify signals
    for m in re.finditer(r'href=["\']?(https?://[\w\-\.]+\.myshopify\.com[^"\'>\s]*)', html, re.I):
        try:
            p = urlparse(m.group(1))
            base = f"{p.scheme}://{p.netloc}".lower()
            if base not in seen and ".myshopify.com" in base:
                seen.add(base); found.append(base)
        except: pass

    return found

async def search_bing(session, query, page, seen):
    url = "https://www.bing.com/search?" + urlencode({
        "q": query, "first": str(page * 10 + 1), "count": "10", "mkt": "en-US"
    })
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15),
                               headers={"User-Agent": random.choice(UA_LIST),
                                        "Accept": "text/html,*/*",
                                        "Accept-Language": "en-US,en;q=0.9"},
                               ssl=False, allow_redirects=True) as r:
            if r.status == 200:
                html = await r.text(errors="ignore")
                return extract_shopify_urls(html, seen)
    except Exception as e:
        pass
    return []

async def search_ddg(session, query, page, seen):
    url = "https://html.duckduckgo.com/html/?" + urlencode({"q": query, "s": str(page * 30)})
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15),
                               headers={"User-Agent": random.choice(UA_LIST),
                                        "Accept": "text/html,*/*"},
                               ssl=False, allow_redirects=True) as r:
            if r.status == 200:
                html = await r.text(errors="ignore")
                return extract_shopify_urls(html, seen)
    except: pass
    return []

async def search_yahoo(session, query, page, seen):
    url = "https://search.yahoo.com/search?" + urlencode({"p": query, "b": str(page * 10 + 1), "pz": "10"})
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15),
                               headers={"User-Agent": random.choice(UA_LIST),
                                        "Accept": "text/html,*/*",
                                        "Accept-Language": "en-US,en;q=0.9"},
                               ssl=False, allow_redirects=True) as r:
            if r.status == 200:
                html = await r.text(errors="ignore")
                return extract_shopify_urls(html, seen)
    except: pass
    return []

async def main():
    seen = set()
    all_urls = []
    start_time = time.time()

    # Open output file
    f = open(OUTPUT_FILE, "w", encoding="utf-8")
    f.write(f"# Shopify Sites Found - {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.flush()

    print(f"Target: {TARGET} Shopify sites")
    print(f"Output: {OUTPUT_FILE}")
    print(f"Dorks: {len(DORKS)} queries x 3 engines x 5 pages = ~{len(DORKS)*3*5*10} potential results")
    print("="*60)

    connector = aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)
    async with aiohttp.ClientSession(connector=connector) as session:
        dork_idx = 0
        for dork in DORKS:
            if len(all_urls) >= TARGET:
                break

            dork_idx += 1
            dork_found = 0

            for page in range(5):  # 5 pages per dork
                if len(all_urls) >= TARGET:
                    break

                # Bing
                new = await search_bing(session, dork, page, seen)
                for u in new:
                    all_urls.append(u)
                    f.write(u + "\n")
                    f.flush()
                    dork_found += 1
                await asyncio.sleep(random.uniform(1.5, 3.0))

                # DDG
                new = await search_ddg(session, dork, page, seen)
                for u in new:
                    all_urls.append(u)
                    f.write(u + "\n")
                    f.flush()
                    dork_found += 1
                await asyncio.sleep(random.uniform(1.5, 3.0))

                # Yahoo (every 2nd dork to avoid rate limit)
                if dork_idx % 2 == 0:
                    new = await search_yahoo(session, dork, page, seen)
                    for u in new:
                        all_urls.append(u)
                        f.write(u + "\n")
                        f.flush()
                        dork_found += 1
                    await asyncio.sleep(random.uniform(1.5, 2.5))

            elapsed = time.time() - start_time
            print(f"[{dork_idx:2d}/{len(DORKS)}] '{dork[:50]}' -> +{dork_found} | Total: {len(all_urls)} | {elapsed:.0f}s")

            # Longer delay between dorks to avoid IP ban
            await asyncio.sleep(random.uniform(3.0, 6.0))

    f.write(f"\n# Total: {len(all_urls)} sites\n")
    f.close()

    elapsed = time.time() - start_time
    print("="*60)
    print(f"DONE! Found {len(all_urls)} unique Shopify sites in {elapsed:.0f}s")
    print(f"Saved to: {OUTPUT_FILE}")
    print(f"\nNext step: /massaddshopify (send the txt file to your bot)")

asyncio.run(main())
