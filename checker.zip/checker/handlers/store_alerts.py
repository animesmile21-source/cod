"""
handlers/store_alerts.py — Store Auto-Debug Alert Callbacks

Handles owner inline keyboard callbacks for:
- store_remove_{gate_id}   → Permanently delete store from DB
- store_reenable_{gate_id} → Re-enable a disabled store
- store_redebug_{gate_id}  → Manually trigger fresh debug run
"""
import logging
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram import enums

import config

logger = logging.getLogger("StoreAlerts")


def register_store_alerts(app: Client):
    """Register all store alert callback handlers."""

    @app.on_callback_query(filters.create(
        lambda _, __, cb: cb.data and cb.data.startswith("store_remove_")
    ))
    async def _store_remove_cb(client: Client, cb):
        """Owner pressed [Remove Permanently] on a broken store alert."""
        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("❌ Owner only.", show_alert=True)
            return

        try:
            gate_id = int(cb.data.split("_")[-1])
        except (ValueError, IndexError):
            await cb.answer("Invalid gate ID.", show_alert=True)
            return

        try:
            import database.db as db
            from gateways.shopify_gate import invalidate_stores_cache
            # Get base_url before deleting (for feedback message)
            row = await db._db.fetchone(
                "SELECT base_url FROM shopify_gates WHERE id=?", (gate_id,)
            )
            base_url = row[0] if row else f"ID={gate_id}"
            short_url = base_url.replace("https://www.", "").replace("https://", "")[:50]

            await db._db.execute("DELETE FROM shopify_gates WHERE id=?", (gate_id,))
            invalidate_stores_cache()
            logger.info(f"[StoreAlerts] Owner {cb.from_user.id} removed store: {base_url}")

            await cb.answer(f"✅ Store removed: {short_url}", show_alert=True)
            # Update the message to reflect removal
            try:
                await cb.message.edit_text(
                    cb.message.text.html + f"\n\n<b>🗑 Removed by {cb.from_user.first_name}</b>",
                    parse_mode=enums.ParseMode.HTML,
                    reply_markup=None,
                )
            except Exception:
                pass
        except Exception as e:
            logger.error(f"[StoreAlerts] Remove error: {e}", exc_info=True)
            await cb.answer(f"❌ Error: {str(e)[:60]}", show_alert=True)

    @app.on_callback_query(filters.create(
        lambda _, __, cb: cb.data and cb.data.startswith("store_reenable_")
    ))
    async def _store_reenable_cb(client: Client, cb):
        """Owner pressed [Re-Enable] on a disabled store alert."""
        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("❌ Owner only.", show_alert=True)
            return

        try:
            gate_id = int(cb.data.split("_")[-1])
        except (ValueError, IndexError):
            await cb.answer("Invalid gate ID.", show_alert=True)
            return

        try:
            import database.db as db
            from gateways.shopify_gate import invalidate_stores_cache

            row = await db._db.fetchone(
                "SELECT base_url FROM shopify_gates WHERE id=?", (gate_id,)
            )
            base_url = row[0] if row else f"ID={gate_id}"
            short_url = base_url.replace("https://www.", "").replace("https://", "")[:50]

            await db._db.execute(
                "UPDATE shopify_gates SET is_active=1 WHERE id=?", (gate_id,)
            )
            invalidate_stores_cache()
            logger.info(f"[StoreAlerts] Owner {cb.from_user.id} re-enabled store: {base_url}")

            await cb.answer(f"✅ Store re-enabled: {short_url}", show_alert=True)
            try:
                await cb.message.edit_text(
                    cb.message.text.html + f"\n\n<b>✅ Re-enabled by {cb.from_user.first_name}</b>",
                    parse_mode=enums.ParseMode.HTML,
                    reply_markup=None,
                )
            except Exception:
                pass
        except Exception as e:
            logger.error(f"[StoreAlerts] Re-enable error: {e}", exc_info=True)
            await cb.answer(f"❌ Error: {str(e)[:60]}", show_alert=True)

    @app.on_callback_query(filters.create(
        lambda _, __, cb: cb.data and cb.data.startswith("store_redebug_")
    ))
    async def _store_redebug_cb(client: Client, cb):
        """Owner pressed [Re-Debug] — manually trigger a fresh debug run."""
        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("❌ Owner only.", show_alert=True)
            return

        try:
            gate_id = int(cb.data.split("_")[-1])
        except (ValueError, IndexError):
            await cb.answer("Invalid gate ID.", show_alert=True)
            return

        try:
            import database.db as db
            import asyncio
            from gateways.store_debugger import _run_debug_and_notify, _debug_cooldown

            row = await db._db.fetchone(
                "SELECT id, base_url, variant_id, price, scan_data FROM shopify_gates WHERE id=?",
                (gate_id,)
            )
            if not row:
                await cb.answer("❌ Store not found in DB.", show_alert=True)
                return

            import json as _json
            sd = {}
            try:
                sd = _json.loads(row[4] or "{}")
            except Exception:
                pass

            store = {
                "gate_id":           row[0],
                "base_url":          row[1],
                "variant_id":        row[2],
                "price":             row[3],
                "payment_method_id": sd.get("payment_method_id", ""),
            }
            short_url = row[1].replace("https://www.", "").replace("https://", "")[:50]

            # Reset cooldown so debug can run immediately
            _debug_cooldown.pop(row[1], None)

            await cb.answer(f"🔄 Re-debugging {short_url}...", show_alert=True)
            asyncio.ensure_future(_run_debug_and_notify(store))
            logger.info(f"[StoreAlerts] Owner {cb.from_user.id} triggered re-debug for {row[1]}")

        except Exception as e:
            logger.error(f"[StoreAlerts] Re-debug error: {e}", exc_info=True)
            await cb.answer(f"❌ Error: {str(e)[:60]}", show_alert=True)
