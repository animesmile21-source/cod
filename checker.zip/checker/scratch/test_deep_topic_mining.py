"""
Test Deep Topic Mining from WordPress.org Support Forums for Real Merchant Store URLs.
"""
import asyncio, aiohttp, json, sys, re
from urllib.parse import urlparse, unquote

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

PLUGIN_FORUMS = [
    "https://wordpress.org/support/plugin/woocommerce-gateway-stripe/",
    "https://wordpress.org/support/plugin/woocommerce/",
    "https://wordpress.org/support/plugin/woo-stripe-payment/",
    "https://wordpress.org/support/plugin/woocommerce-payments/",
    "https://wordpress.org/support/plugin/give/",
]

SKIP_DOMAINS = {
    "wordpress.org", "wordpress.com", "woocommerce.com", "github.com",
    "stripe.com", "paypal.com", "google.com", "bing.com", "youtube.com",
    "gravatar.com", "w.org", "schema.org", "twitter.com", "facebook.com",
    "x.com", "linkedin.com", "tumblr.com", "tiktok.com", "googleapis.com",
    "gstatic.com", "buddypress.org", "bbpress.org", "openverse.org",
    "bsky.app", "threads.net", "mastodon.world", "w3.org", "automattic.com"
}

def clean_domain(url_str: str) -> str:
    try:
        p = urlparse(url_str)
        domain = p.netloc.lower().lstrip("www.")
        if domain and "." in domain and domain not in SKIP_DOMAINS:
            return f"{p.scheme}://{p.netloc}"
    except Exception:
        pass
    return ""

async def test_deep_topic_mining():
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    topic_urls = set()
    merchant_domains = set()

    print("=" * 80)
    print("🔍 Phase 1: Harvesting Topic Thread Links from WordPress.org Forums...")
    print("=" * 80)

    connector = aiohttp.TCPConnector(ssl=False, limit=20)
    async with aiohttp.ClientSession(connector=connector) as session:

        # Step 1: Collect topic threads
        async def fetch_forum_listing(url):
            try:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=12), headers={"User-Agent": ua}) as r:
                    if r.status == 200:
                        html = await r.text(errors="ignore")
                        for m in re.finditer(r'href="(https://wordpress.org/support/topic/[^"/]+/)', html):
                            topic_urls.add(m.group(1))
            except Exception:
                pass

        # Check first 5 pages per forum
        listing_urls = []
        for forum in PLUGIN_FORUMS:
            listing_urls.append(forum)
            for p in range(2, 6):
                listing_urls.append(f"{forum}page/{p}/")

        await asyncio.gather(*[fetch_forum_listing(u) for u in listing_urls])
        print(f"✅ Harvested {len(topic_urls)} support topic threads!\n")

        print("🔍 Phase 2: Deep Mining Merchant Store URLs from Support Topics...")
        
        async def fetch_topic_content(topic_url):
            try:
                async with session.get(topic_url, timeout=aiohttp.ClientTimeout(total=10), headers={"User-Agent": ua}) as r:
                    if r.status == 200:
                        html = await r.text(errors="ignore")
                        for m in re.finditer(r'href=["\']?(https?://[^"\'\s<>&]+)', html):
                            raw_url = unquote(m.group(1).rstrip("&"))
                            dom = clean_domain(raw_url)
                            if dom:
                                merchant_domains.add(dom)
            except Exception:
                pass

        # Mine all collected topics in parallel
        await asyncio.gather(*[fetch_topic_content(t) for t in list(topic_urls)[:200]])

    print("\n" + "=" * 80)
    print(f"🎉 SUCCESS! Discovered {len(merchant_domains):,} REAL WooCommerce Merchant Store Domains!")
    print("=" * 80)

    if merchant_domains:
        print("\nSample Discovered Real WooCommerce Shops:")
        for dom in list(merchant_domains)[:30]:
            print(f"  • {dom}")

if __name__ == "__main__":
    asyncio.run(test_deep_topic_mining())
