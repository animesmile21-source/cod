import sys, asyncio, os, re, random
sys.path.append(r'c:\Users\rdx27\Desktop\all bots\checker')
from dotenv import load_dotenv
load_dotenv(r'c:\Users\rdx27\Desktop\all bots\checker\.env')

from curl_cffi.requests import AsyncSession
import database.db as db
from core.auto_discover import discover_stripe_sites
from gateways.stripe_wc_gate import _check_stripe_wc_on_site
from core.parser import CardData
from gateways.base import CCStatus

# Candidates subpaths
path_candidates = [
    "/my-account/add-payment-method/",
    "/en/moj-racun/add-payment-method/",
    "/moj-racun/add-payment-method/",
]

async def verify_and_add(site_url, proxy_url):
    proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
    user_ag = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    
    # Format the URL
    if not site_url.startswith("http"):
        site_url = "https://" + site_url
    site_url = site_url.rstrip("/")
    
    async with AsyncSession(impersonate="chrome131") as session:
        headers = {"User-Agent": user_ag}
        for path in path_candidates:
            url = f"{site_url}{path}"
            try:
                r = await session.get(url, headers=headers, proxies=proxies, timeout=10)
                if r.status_code == 200:
                    if "pk_live_" in r.text or '"key":' in r.text:
                        # Found working Stripe WooCommerce site!
                        ok = await db.add_stripe_wc_gate(site_url)
                        if ok:
                            print(f"[+] FOUND & ADDED -> {site_url} (Path: {path})")
                            return True
            except Exception:
                pass
    return False

async def main():
    await db.init_db()
    
    # Fetch a working proxy from proxy pool
    proxies = await db.get_working_proxies()
    if not proxies:
        print("No working proxies in database. Cannot run auto-discovery scan.")
        return
        
    p = proxies[0]
    p_dict = {
        "host": p["host"],
        "port": p["port"],
        "username": p.get("username", ""),
        "password": p.get("password", ""),
        "protocol": p.get("protocol", "http")
    }
    proxy_url = f"http://{p['username']}:{p['password']}@{p['host']}:{p['port']}" if p['username'] else f"http://{p['host']}:{p['port']}"
    
    print("=============================================================")
    print("⚡ WooCommerce Stripe Auto-Discovery Engine Running...")
    print(f"Proxy chosen for search queries: {p['host']}:{p['port']}")
    print("=============================================================\n")
    
    # Step 1: Discover potential sites using Google, Bing, Yahoo, DDG, Yandex dorks
    print("🔍 Harvesting sites from search engines via residential dorks...")
    try:
        discovered_domains = await discover_stripe_sites(count=80, proxy=p_dict)
        print(f"-> Harvested {len(discovered_domains)} candidate WooCommerce domains!\n")
    except Exception as e:
        print(f"Search engines harvest failed: {e}")
        return
        
    if not discovered_domains:
        print("No domains found during search engines query.")
        return
        
    # Step 2: Validate and add the working WooCommerce Stripe domains
    print("🚀 Probing harvested domains for WooCommerce Stripe SetupIntent...")
    count = 0
    
    # Process in batches of 5 to avoid connection limits
    for i in range(0, len(discovered_domains), 5):
        batch = discovered_domains[i:i+5]
        batch_tasks = [verify_and_add(site, proxy_url) for site in batch]
        results = await asyncio.gather(*batch_tasks)
        count += sum(1 for r in results if r)
        await asyncio.sleep(0.5)
        
    print("\n=============================================================")
    print(f"✅ Auto-Discovery Done! Added {count} new verified sites to database pool.")
    print("=============================================================")

if __name__ == "__main__":
    asyncio.run(main())
