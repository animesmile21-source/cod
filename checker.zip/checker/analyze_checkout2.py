import re, json

with open('shopify_checkout_store_dftba_com.html', 'r', encoding='utf-8', errors='ignore') as f:
    html = f.read()

print('=== FULL SESSION TOKEN ===')
m = re.search(r'sessionToken["\s:=]+content=["\']([^"\']{20,})["\']', html, re.I)
if not m:
    m = re.search(r'sessionToken[^"\']*["\']([A-Za-z0-9_\-+=/]{30,})["\']', html, re.I)
if not m:
    # Look in meta tags
    m = re.search(r'<meta[^>]+name=["\']sessionToken["\'][^>]+content=["\']([^"\']+)["\']', html, re.I)
if not m:
    # Look for any long base64-ish token near sessionToken
    m = re.search(r'sessionToken.{0,30}?([A-Za-z0-9_\-+=/]{50,})', html, re.I)
if m:
    print('Token:', m.group(1)[:200])
else:
    print('Not found via regex, searching raw...')
    idx = html.find('sessionToken')
    if idx > 0:
        print('Context:', html[idx:idx+300])

print()
print('=== PCI SHOPIFY ENDPOINTS ===')
pci = re.findall(r'https://checkout\.pci\.shopifyinc\.com[^\s"\'&<>]{0,100}', html)
for p in sorted(set(pci)):
    print(' ', p)

print()
print('=== CHECKOUT.SHOPIFY.COM ENDPOINTS ===')
co = re.findall(r'https://checkout\.shopify\.com[^\s"\'&<>]{0,100}', html)
for c in sorted(set(co)):
    print(' ', c)

print()
print('=== HTML ENCODED JSON BLOCKS (decoded) ===')
# The HTML is HTML-entity encoded, decode it
import html as html_module
# Find the large &quot; encoded JSON
blocks = re.findall(r'content=&quot;(\{.{50,5000}?\})&quot;', html[:50000])
for b in blocks[:5]:
    try:
        decoded = html_module.unescape(b)
        j = json.loads(decoded)
        print(json.dumps(j, indent=2)[:800])
        print()
    except Exception as e:
        print('Parse error:', e)
        print(b[:300])
        print()

print()
print('=== META TAGS ===')
metas = re.findall(r'<meta[^>]+>', html)
for meta in metas:
    if any(kw in meta.lower() for kw in ['csrf', 'token', 'session', 'checkout', 'payment', 'shopify']):
        print(' ', meta[:200])

print()
print('=== CHECKOUT STATE / INITIAL DATA ===')
# Look for serialized JSON in the page
state_m = re.search(r'initialData["\s:=]+(\{.{100,}?\})\s*[,;]', html[:100000], re.S)
if state_m:
    try:
        j = json.loads(state_m.group(1))
        print(json.dumps(j, indent=2)[:1500])
    except:
        print(state_m.group(1)[:500])

# Look for __NEXT_DATA__ style
next_m = re.search(r'<script id=["\']([^"\']+)["\'][^>]*type=["\']application/json["\'][^>]*>(.+?)</script>', html, re.S)
if next_m:
    print('Script data block id:', next_m.group(1))
    try:
        j = json.loads(next_m.group(2))
        print(json.dumps(j, indent=2)[:1500])
    except:
        print(next_m.group(2)[:500])

print()
print('=== PAYMENT MUTATION HINTS ===')
for kw in ['submitPayment', 'PaymentSubmit', 'completePayment', 'paymentIntent',
           'paymentSession', 'completeCheckout', 'checkoutComplete']:
    m2 = re.search(kw + r'.{0,150}', html, re.I)
    if m2:
        print(kw + ':', m2.group(0)[:150])
        print()
