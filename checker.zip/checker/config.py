"""
config.py — Central configuration loader
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ── Telegram ──────────────────────────────────────────────────────────────────
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
API_ID: int = int(os.getenv("API_ID", "0"))
API_HASH: str = os.getenv("API_HASH", "")
OWNER_IDS: list[int] = [
    int(x.strip()) for x in os.getenv("OWNER_IDS", "0").split(",") if x.strip()
]
# Telegram channel or group ID where hit cards will be forwarded automatically
HIT_CHANNEL_ID: int = int(os.getenv("HIT_CHANNEL_ID", "0"))


# ── Stripe ────────────────────────────────────────────────────────────────────
STRIPE_KEYS: list[str] = [
    k.strip() for k in os.getenv("STRIPE_KEYS", "").split(",") if k.strip()
]
# Publishable keys (pk_live_...) — needed for Android SDK tokenization
STRIPE_PK_KEYS: list[str] = [
    k.strip() for k in os.getenv("STRIPE_PK_KEYS", "").split(",") if k.strip()
]

# ── Braintree ─────────────────────────────────────────────────────────────────
BT_MERCHANT_ID: str = os.getenv("BT_MERCHANT_ID", "")
BT_PUBLIC_KEY: str = os.getenv("BT_PUBLIC_KEY", "")
BT_PRIVATE_KEY: str = os.getenv("BT_PRIVATE_KEY", "")

# ── Shopify Gate ──────────────────────────────────────────────────────────────
# Public Shopify stores for checkout testing (comma-separated)
# Leave empty to use built-in public stores list
SHOPIFY_STORES: list[str] = [
    s.strip() for s in os.getenv("SHOPIFY_STORES", "").split(",") if s.strip()
]

# ── Authorize.net Gate ────────────────────────────────────────────────────────
AUTHNET_LOGIN_ID: str = os.getenv("AUTHNET_LOGIN_ID", "")
AUTHNET_TRANSACTION_KEY: str = os.getenv("AUTHNET_TRANSACTION_KEY", "")
# Use sandbox for testing: set to "true"
AUTHNET_SANDBOX: bool = os.getenv("AUTHNET_SANDBOX", "false").lower() == "true"

# ── Square Gate ───────────────────────────────────────────────────────────────
SQUARE_ACCESS_TOKEN: str = os.getenv("SQUARE_ACCESS_TOKEN", "")
SQUARE_LOCATION_ID: str = os.getenv("SQUARE_LOCATION_ID", "")
# Use sandbox for testing: set to "true"
SQUARE_SANDBOX: bool = os.getenv("SQUARE_SANDBOX", "false").lower() == "true"

# ── Razorpay Gate ─────────────────────────────────────────────────────────────
RAZORPAY_KEY_ID: str = os.getenv("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET: str = os.getenv("RAZORPAY_KEY_SECRET", "")

# ── Gate Priority Order (comma-separated gate names) ──────────────────────────
# Available: shopify, authnet, square, stripe, braintree, razorpay
GATE_PRIORITY: list[str] = [
    g.strip().lower()
    for g in os.getenv("GATE_PRIORITY", "stripe,authnet,square,braintree,razorpay").split(",")
    if g.strip()
]

# ── Bot Settings ──────────────────────────────────────────────────────────────
# MAX_CONCURRENT: workers for regular admins (default 5)
MAX_CONCURRENT: int = int(os.getenv("MAX_CONCURRENT", "5"))

# OWNER_WORKERS: workers for owner — no rate limits, maximum speed (default 50)
OWNER_WORKERS: int = int(os.getenv("OWNER_WORKERS", "50"))

RATE_LIMIT: int = int(os.getenv("RATE_LIMIT", "30"))   # checks per minute
DB_PATH: str = os.getenv("DB_PATH", "database/checker.db")

# ── Proxies ───────────────────────────────────────────────────────────────────
_proxy_raw = os.getenv("PROXY_LIST", "")
PROXY_LIST: list[str] = [p.strip() for p in _proxy_raw.split(",") if p.strip()]

# ── Bot Meta ──────────────────────────────────────────────────────────────────
BOT_NAME = "⚡ CC Checker Pro"
BOT_VERSION = "3.1"
START_TIME = None   # set at runtime
