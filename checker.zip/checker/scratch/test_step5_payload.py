"""
Test Step 5 payload delivery (params vs data) on WooCommerce Stripe SetupIntent confirmation.
Compares params= payload vs data= payload on real WC site.
"""
import asyncio, sys, re, random, json
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from curl_cffi.requests import AsyncSession
from faker import Faker
faker = Faker()

TEST_SITE = "https://ea-courses.com"

async def test_step_5_payload():
    print("=" * 75)
    print("🔬 Testing Step 5 Payload Delivery: params= vs data=")
    print("=" * 75)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        "Accept": "*/*",
    }

    async with AsyncSession(impersonate="chrome131") as s:
        # Step 1 & 2: Get page & register
        url_1 = f"{TEST_SITE}/my-account/add-payment-method/"
        r1 = await s.get(url_1, headers=headers)
        html_1 = r1.text

        reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
        if reg_match:
            reg_nonce = reg_match.group(1)
            fake_user = faker.user_name()[:10] + str(random.randint(100, 999))
            data_reg = {
                'email': faker.email(),
                'username': fake_user,
                'woocommerce-register-nonce': reg_nonce,
                'register': 'Register',
            }
            await s.post(f"{TEST_SITE}/my-account/", headers=headers, data=data_reg)
            r_auth = await s.get(url_1, headers=headers)
            html_1 = r_auth.text

        # Extract Nonce
        m = re.search(r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"', html_1)
        if not m:
            m = re.search(r'"_ajax_nonce"\s*:\s*"([^"]+)"', html_1)

        nonce = m.group(1) if m else "test_nonce"
        print(f"✅ Extracted Nonce: {nonce}")

        payload = {
            'wc-ajax': 'wc_stripe_create_and_confirm_setup_intent',
            'action': 'create_and_confirm_setup_intent',
            'wc-stripe-payment-method': 'pm_1234567890abcdef',
            'wc-stripe-payment-type': 'card',
            '_ajax_nonce': nonce,
        }

        # Test A: params= (query params only)
        r_params = await s.post(f"{TEST_SITE}/", headers=headers, params=payload)
        print(f"\nTest A (params=): Status {r_params.status_code}")
        print(f"Response: {r_params.text[:200]}")

        # Test B: data= (form body data + wc-ajax in params)
        r_data = await s.post(f"{TEST_SITE}/?wc-ajax=wc_stripe_create_and_confirm_setup_intent", headers=headers, data=payload)
        print(f"\nTest B (data=): Status {r_data.status_code}")
        print(f"Response: {r_data.text[:200]}")

if __name__ == "__main__":
    asyncio.run(test_step_5_payload())
