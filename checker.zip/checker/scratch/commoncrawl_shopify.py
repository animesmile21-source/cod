﻿"""
CommonCrawl CDX API - Get Shopify stores
FREE - No proxy, no auth, no API key needed!
CommonCrawl has indexed billions of pages including myshopify.com subdomains
"""
import asyncio, sys, aiohttp, json, re
sys.path.insert(0, r"c:\Users\rdx27\Desktop\all bots\checker")

OUTPUT = r"c:\Users\rdx27\Desktop\all bots\checker\shopify_sites_found.txt"
TARGET = 5000

# CommonCrawl indexes - latest ones (each has different crawl data)
CC_INDEXES = [
    "CC-MAIN-2025-18",
    "CC-MAIN-2025-13", 
    "CC-MAIN-2024-51",
    "CC-MAIN-2024-46",
    "CC-MAIN-2024-42",
    "CC-MAIN-2024-38",
    "CC-MAIN-2024-33",
    "CC-MAIN-2024-30",
    "CC-MAIN-2024-26",
    "CC-MAIN-2024-22",
]

UA = "Mozilla/5.0 (compatible; research-bot/1.0)"

async def fetch_cc_page(session, index_name, page, seen):
    """Fetch one page of CommonCrawl results for *.myshopify.com"""
    found = []
    url = f"https://index.commoncrawl.org/{index_name}-index"
    params = {
        "url": "*.myshopify.com/*",
        "output": "json",
        "limit": "1000",
        "page": str(page),
        "fields": "url",
        "filter": "=status:200",
    }
    try:
        async with session.get(url, params=params,
                               timeout=aiohttp.ClientTimeout(total=30),
                               headers={"User-Agent": UA},
                               ssl=True) as r:
            if r.status == 200:
                text = await r.text()
                if not text.strip():
                    return [], False  # No more pages
                
                for line in text.strip().split("\n"):
                    if not line.strip(): continue
                    try:
                        data = json.loads(line)
                        raw_url = data.get("url", "")
                        m = re.match(r"https?://([\w\-]+\.myshopify\.com)", raw_url, re.I)
                        if m:
                            base = f"https://{m.group(1).lower()}"
                            # Filter Shopify system domains
                            subdomain = m.group(1).lower().replace(".myshopify.com", "")
                            if subdomain in ("admin", "store", "adminconsole", "shop", "accounts", "help"):
                                continue
                            if base not in seen:
                                seen.add(base)
                                found.append(base)
                    except: pass
                
                has_more = len(text.strip().split("\n")) >= 100
                return found, has_more
            elif r.status == 404:
                return [], False
            else:
                return [], False
    except Exception as e:
        print(f"  CC error page {page}: {e}")
        return [], False

async def get_cc_page_count(session, index_name):
    """Get total number of pages available"""
    url = f"https://index.commoncrawl.org/{index_name}-index"
    params = {"url": "*.myshopify.com/*", "output": "json", "showNumPages": "true"}
    try:
        async with session.get(url, params=params,
                               timeout=aiohttp.ClientTimeout(total=15),
                               headers={"User-Agent": UA}, ssl=True) as r:
            if r.status == 200:
                data = await r.json(content_type=None)
                pages = data.get("pages", 0)
                blocks = data.get("pageSize", 0)
                return pages, blocks
    except Exception as e:
        print(f"  Page count error: {e}")
    return 0, 0

async def main():
    # Load existing URLs
    seen = set()
    try:
        with open(OUTPUT, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("http"):
                    seen.add(line)
        print(f"Loaded {len(seen)} existing URLs")
    except: pass

    all_new = []
    
    connector = aiohttp.TCPConnector(ssl=True, limit=5)
    async with aiohttp.ClientSession(connector=connector) as session:
        
        for idx_name in CC_INDEXES:
            if len(all_new) + len(seen) >= TARGET:
                break
                
            print(f"\n[CommonCrawl] Index: {idx_name}")
            
            # Get page count
            pages, _ = await get_cc_page_count(session, idx_name)
            print(f"  Total pages available: {pages}")
            
            if pages == 0:
                print(f"  Skipping (no data)")
                continue
            
            # Fetch pages
            pages_to_fetch = min(pages, 20)  # Max 20 pages per index (20k records)
            for page in range(pages_to_fetch):
                new_urls, has_more = await fetch_cc_page(session, idx_name, page, seen)
                all_new.extend(new_urls)
                
                # Save in real-time
                if new_urls:
                    with open(OUTPUT, "a", encoding="utf-8") as f:
                        for u in new_urls:
                            f.write(u + "\n")
                
                total = len(all_new) + len(seen) - len(seen)
                print(f"  Page {page}: +{len(new_urls)} new | Total new: {len(all_new)} | File total: {len(seen) + len(all_new)}")
                
                if not has_more:
                    break
                if len(all_new) + len(seen) >= TARGET:
                    break
                    
                await asyncio.sleep(0.5)  # Be nice to CommonCrawl
            
            await asyncio.sleep(2)

    print(f"\n{'='*60}")
    print(f"CommonCrawl fetch done!")
    print(f"New Shopify stores found: {len(all_new)}")
    print(f"Total in file: {len(seen) + len(all_new)}")
    if all_new:
        print(f"\nSample stores:")
        for u in all_new[:10]:
            print(f"  {u}")

asyncio.run(main())
