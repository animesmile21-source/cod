import sys, asyncio
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import os
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(ROOT, ".env"))
except Exception:
    pass

import database.db as db

async def main():
    await db.init_db()
    print("DB backend:", "TURSO" if db.USE_TURSO else "LOCAL SQLite")

    # Total count
    row = await db._db.execute("SELECT COUNT(*) FROM shopify_gates")
    total = row[0][0]
    print("Total gates:", total)

    row2 = await db._db.execute("SELECT COUNT(*) FROM shopify_gates WHERE is_active=1")
    active = row2[0][0]
    print("Active gates:", active)

    # Price distribution
    rows = await db._db.execute("""
        SELECT
            COUNT(*) as cnt,
            AVG(CAST(price AS REAL)) as avg_price,
            MIN(CAST(price AS REAL)) as min_price,
            MAX(CAST(price AS REAL)) as max_price
        FROM shopify_gates WHERE is_active=1
    """)
    r = rows[0]
    print("Avg price: $" + str(round(r[1] or 0, 2)))
    print("Min price: $" + str(r[2]))
    print("Max price: $" + str(r[3]))

    # Sample stores
    sample = await db._db.execute(
        "SELECT id, base_url, price, product_title FROM shopify_gates ORDER BY id DESC LIMIT 10"
    )
    print()
    print("Last 10 stores added:")
    for r in sample:
        print("  #" + str(r[0]) + " " + str(r[1]) + " | $" + str(r[2]) + " | " + str(r[3])[:30])

asyncio.run(main())
