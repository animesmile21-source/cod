import sqlite3

conn = sqlite3.connect("database/checker.db")
cur = conn.cursor()

# Create table
cur.execute("""
CREATE TABLE IF NOT EXISTS stripe_wc_gates (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    base_url      TEXT    NOT NULL UNIQUE,
    is_active     INTEGER NOT NULL DEFAULT 1,
    added_by      INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    fail_count    INTEGER DEFAULT 0,
    last_check    REAL    DEFAULT 0,
    created_at    REAL    DEFAULT (strftime('%s', 'now'))
)""")

# Seed defaults
cur.execute("INSERT OR IGNORE INTO stripe_wc_gates (base_url, is_active) VALUES ('https://ea-courses.com', 1)")
cur.execute("INSERT OR IGNORE INTO stripe_wc_gates (base_url, is_active) VALUES ('https://dilaboards.com', 1)")
conn.commit()

# Verify
cur.execute("SELECT id, base_url, is_active FROM stripe_wc_gates")
rows = cur.fetchall()
print("=== stripe_wc_gates ===")
for r in rows:
    print(f"  #{r[0]} | {r[1]} | active={r[2]}")

conn.close()
print("Done!")
