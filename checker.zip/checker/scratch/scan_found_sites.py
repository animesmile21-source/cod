"""
Scan all URLs in shopify_sites_found.txt using the real _scan_shopify_site function.
Saves:
  - shopify_scan_report.txt  -- full detailed report (working + failed)
  - shopify_working.txt      -- only working URLs (ready to /massaddshopify)
"""
import asyncio, sys, time, os
from datetime import datetime

# Force UTF-8 stdout so emojis don't crash on Windows cp1252
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, r"c:\Users\rdx27\Desktop\all bots\checker")

INPUT_FILE   = r"c:\Users\rdx27\Desktop\all bots\checker\shopify_sites_found.txt"
REPORT_FILE  = r"c:\Users\rdx27\Desktop\all bots\checker\shopify_scan_report.txt"
WORKING_FILE = r"c:\Users\rdx27\Desktop\all bots\checker\shopify_working.txt"
CONCURRENCY  = 12   # parallel workers

JUNK = {"admin.myshopify.com","store.myshopify.com","adminconsole.myshopify.com",
        "shop.myshopify.com","accounts.myshopify.com","new-ella.myshopify.com"}

async def main():
    # Read URLs
    urls = []
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line.startswith("http"):
                continue
            domain = line.replace("https://","").replace("http://","").lower()
            if domain in JUNK:
                continue
            urls.append(line)

    total = len(urls)
    print(f"Starting scan of {total} Shopify URLs")
    print(f"Concurrency: {CONCURRENCY} workers")
    print(f"Output: {REPORT_FILE}")
    print("=" * 65)

    # Init DB (needed for proxy pool)
    import database.db as db
    await db.init_db()
    from core.proxy_manager import refresh_proxy_pool, get_proxy_pool_size
    await refresh_proxy_pool()
    pool = get_proxy_pool_size()
    print(f"Proxy pool: {pool} proxies")

    # Import scan function
    from handlers.shopify_handler import _scan_shopify_site

    working = []
    failed  = []
    done    = [0]
    start   = time.monotonic()

    sem  = asyncio.Semaphore(CONCURRENCY)
    lock = asyncio.Lock()

    async def scan_one(url):
        async with sem:
            res = await _scan_shopify_site(url)
            sd  = res.get("scan_data", {})
            async with lock:
                done[0] += 1
                elapsed = time.monotonic() - start
                rate    = done[0] / elapsed if elapsed > 0 else 0
                eta     = (total - done[0]) / rate if rate > 0 else 0

                if res["status"] == "WORKING":
                    flag = "[WORKING]"
                    working.append({
                        "url":      res["url"],
                        "price":    res["price"],
                        "currency": res["currency"],
                        "product":  res["product_title"],
                        "checkout": res["checkout_type"],
                        "shop":     res["shop_domain"],
                        "vault":    f"{sd.get('vault_status','')} | {sd.get('vault_response','')[:60]}",
                        "card":     sd.get("card_test",""),
                        "delivery": sd.get("delivery_handle","")[:50],
                        "co_url":   sd.get("checkout_url",""),
                        "reason":   res["reason"],
                    })
                    flag = "[WORKING]"
                else:
                    failed.append({
                        "url":    res["url"],
                        "reason": res["reason"],
                        "vault":  f"{sd.get('vault_status','')} | {sd.get('vault_response','')[:40]}",
                        "card":   sd.get("card_test",""),
                    })
                    flag = f"[FAILED] {res['reason'][:50]}"

                print(f"[{done[0]:4d}/{total}] {flag}  |  {url[:55]}  ETA:{eta:.0f}s")

    await asyncio.gather(*[scan_one(u) for u in urls])

    elapsed = time.monotonic() - start
    print("\n" + "=" * 65)
    print(f"DONE in {elapsed:.0f}s")
    print(f"Working: {len(working)} / {total}")
    print(f"Failed:  {len(failed)} / {total}")

    # ── Write full report ──────────────────────────────────────────────────────
    lines = [
        "=" * 70,
        f"SHOPIFY SCAN REPORT — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Input: {INPUT_FILE}",
        f"Total: {total} | Working: {len(working)} | Failed: {len(failed)}",
        f"Time: {elapsed:.0f}s",
        "=" * 70,
        "",
        "━" * 70,
        f"✅ WORKING GATES ({len(working)})",
        "━" * 70,
    ]

    for r in working:
        lines += [
            "",
            f"URL      : {r['url']}",
            f"Price    : ${r['price']} {r['currency']}",
            f"Product  : {r['product']}",
            f"Shop     : {r['shop']}",
            f"Checkout : {r['checkout']}",
            f"CO URL   : {r['co_url']}",
            f"Vault    : {r['vault']}",
            f"Card Test: {r['card']}",
            f"Delivery : {r['delivery'] or 'N/A'}",
            f"Reason   : {r['reason']}",
            "-" * 60,
        ]

    lines += [
        "",
        "━" * 70,
        f"❌ FAILED SITES ({len(failed)})",
        "━" * 70,
    ]
    for r in failed:
        vault = f" | {r['vault']}" if r.get("vault") and r["vault"].strip("| ") else ""
        card  = f" | Card: {r['card']}" if r.get("card") and r["card"] != "pending" else ""
        lines.append(f"✗ {r['url']}  →  {r['reason']}{vault}{card}")

    lines += ["", "=" * 70, f"END — {len(working)}/{total} working", "=" * 70]

    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # ── Write working URLs only ────────────────────────────────────────────────
    with open(WORKING_FILE, "w", encoding="utf-8") as f:
        for r in working:
            f.write(r["url"] + "\n")

    print(f"\nFull report → {REPORT_FILE}")
    print(f"Working URLs → {WORKING_FILE}")
    print(f"\nSample working sites:")
    for r in working[:10]:
        print(f"  {r['url']}  ${r['price']}  [{r['card']}]")

asyncio.run(main())
