"""
Inspect registration form fields on https://dilaboards.com/my-account/
"""
import asyncio, sys, re
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from curl_cffi.requests import AsyncSession

TEST_SITE = "https://dilaboards.com"

async def inspect_wc_form():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
    }
    async with AsyncSession(impersonate="chrome131") as s:
        r = await s.get(f"{TEST_SITE}/my-account/", headers=headers)
        html = r.text

        print("=== Registration Form HTML ===")
        forms = re.findall(r'<form[^>]*register[^>]*>.*?</form>', html, re.DOTALL | re.IGNORECASE)
        if forms:
            for f in forms:
                print(f)
        else:
            print("No <form ... register> found. Searching all forms:")
            forms_all = re.findall(r'<form.*?</form>', html, re.DOTALL)
            for f in forms_all:
                print("FORM:")
                print(f[:400])
                print("-" * 50)

if __name__ == "__main__":
    asyncio.run(inspect_wc_form())
