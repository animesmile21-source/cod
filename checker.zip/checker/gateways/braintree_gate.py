"""
gateways/braintree_gate.py — Braintree CC Auth Checker (Secondary Gateway)
Uses Transaction.sale() with submit_for_settlement=False (auth only, no charge).
Good for: Cards that Stripe declines due to merchant restrictions.

VBV/Non-VBV:
  - processor_response_code '1000' → CHARGED (Non-VBV)
  - processor_response_code '2093' (3DS required) → VBV
  - avs_error_response_code → additional check
"""
import asyncio
import braintree
from braintree import BraintreeGateway, Configuration, Environment, Transaction

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
import config

# ── Braintree Response Code → Status mapping ──────────────────────────────────
BT_RESPONSE_MAP: dict[str, CCStatus] = {
    "1000": CCStatus.CHARGED,            # Approved
    "1001": CCStatus.CHARGED,            # Approved, partial
    "2000": CCStatus.DO_NOT_HONOR,       # Do Not Honor
    "2001": CCStatus.INSUFFICIENT,       # Insufficient Funds
    "2002": CCStatus.INSUFFICIENT,       # Limit Exceeded
    "2003": CCStatus.DO_NOT_HONOR,       # Cardholder Activity Limit
    "2004": CCStatus.EXPIRED,            # Expired Card
    "2005": CCStatus.INVALID,            # Invalid Credit Card Number
    "2006": CCStatus.EXPIRED,            # Invalid Expiry Date
    "2007": CCStatus.INVALID,            # No Account
    "2008": CCStatus.INVALID,            # Card Account Length Error
    "2009": CCStatus.INVALID,            # No Such Issuer
    "2010": CCStatus.DEAD,               # Card Issuer Declined CVV
    "2011": CCStatus.DO_NOT_HONOR,       # Voice Authorization Required
    "2012": CCStatus.PICKUP,             # Pickup Card
    "2013": CCStatus.PICKUP,             # Pickup Card, Special Conditions
    "2014": CCStatus.DO_NOT_HONOR,       # Pickup Card, Lost
    "2015": CCStatus.DO_NOT_HONOR,       # Pickup Card, Stolen
    "2016": CCStatus.DEAD,               # Duplicate Transaction
    "2017": CCStatus.DEAD,               # Cardholder Stopped Billing
    "2018": CCStatus.DEAD,               # Cardholder Stopped All Billing
    "2019": CCStatus.DEAD,               # Invalid Transaction
    "2020": CCStatus.DO_NOT_HONOR,       # Violation
    "2021": CCStatus.DO_NOT_HONOR,       # Security Violation
    "2022": CCStatus.DEAD,               # Lost or Stolen
    "2023": CCStatus.DEAD,               # No Such Transaction
    "2024": CCStatus.DEAD,               # Transaction Type Not Supported
    "2038": CCStatus.DO_NOT_HONOR,       # Do Not Honor
    "2041": CCStatus.DEAD,               # Declined — Call Issuer
    "2043": CCStatus.DEAD,               # Error, Do Not Retry
    "2044": CCStatus.DEAD,               # Declined
    "2046": CCStatus.DEAD,               # Declined
    "2047": CCStatus.PICKUP,             # Call Issuer, Pick Up Card
    "2048": CCStatus.INSUFFICIENT,       # Invalid Amount
    "2053": CCStatus.PICKUP,             # Card reported lost/stolen
    "2054": CCStatus.DEAD,               # Reversal Amount Does Not Match
    "2055": CCStatus.INVALID,            # Invalid Transaction Division Number
    "2057": CCStatus.DEAD,               # Issuer or Cardholder restricted
    "2060": CCStatus.DO_NOT_HONOR,       # Address Verification Failed
    "2061": CCStatus.DEAD,               # Invalid Transaction Amount
    "2062": CCStatus.INVALID,            # Invalid Tax Amount
    "2064": CCStatus.DEAD,               # Invalid Currency Code
    "2074": CCStatus.DEAD,               # Funding Declined
    "2075": CCStatus.DO_NOT_HONOR,       # PIN Tries Exceeded
    "2076": CCStatus.DEAD,               # Unsupported Feature
    "2077": CCStatus.DEAD,               # Unsupported Transaction
    "2079": CCStatus.INVALID,            # Already Reversed
    "2080": CCStatus.DEAD,               # Card Record Not Available
    "2081": CCStatus.DEAD,               # Crypto Box Offline
    "2082": CCStatus.DEAD,               # No Chequing Account
    "2083": CCStatus.DEAD,               # No Savings Account
    "2084": CCStatus.DEAD,               # Decline, Closed Account
    "2085": CCStatus.DEAD,               # PIN Change Required
    "2086": CCStatus.DEAD,               # PIN BLOCK Error
    "2087": CCStatus.DEAD,               # Payment Amount Limit Exceeded
    "2088": CCStatus.DEAD,               # Payment Amount Limit Exceeded
    "2089": CCStatus.DEAD,               # Not entitled to buy
    "2090": CCStatus.DEAD,               # No Universal Amount
    "2091": CCStatus.DO_NOT_HONOR,       # Declined
    "2092": CCStatus.DO_NOT_HONOR,       # Destination Not Available
    "2093": CCStatus.LIVE_VBV,           # 3DS Required
    "2094": CCStatus.DEAD,               # Application Blocked
    "2095": CCStatus.DEAD,               # Application Not Registered
    "2096": CCStatus.DEAD,               # Approval Does Not Fulfill
    "2097": CCStatus.DEAD,               # Activation Required
    "2098": CCStatus.DEAD,               # Agreement Error
    "2099": CCStatus.DEAD,               # Pin Not Changed
    "3000": CCStatus.ERROR,              # Gateway error
}


def _get_gateway() -> BraintreeGateway:
    """Create Braintree gateway instance."""
    if not all([config.BT_MERCHANT_ID, config.BT_PUBLIC_KEY, config.BT_PRIVATE_KEY]):
        raise ValueError("Braintree credentials not configured")
    return BraintreeGateway(
        Configuration(
            environment=Environment.Production,
            merchant_id=config.BT_MERCHANT_ID,
            public_key=config.BT_PUBLIC_KEY,
            private_key=config.BT_PRIVATE_KEY,
        )
    )


async def check_braintree(card: CardData) -> GatewayResult:
    """Braintree auth-only check (no charge)."""
    loop = asyncio.get_event_loop()
    try:
        gateway = _get_gateway()
    except ValueError as e:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="Braintree",
            message=str(e),
            raw_code="config_error",
        )

    def _sync_check():
        return gateway.transaction.sale({
            "amount": "0.01",
            "credit_card": {
                "number": card.number,
                "expiration_month": card.month,
                "expiration_year": card.year,
                "cvv": card.cvv,
            },
            "options": {
                "submit_for_settlement": False,   # Auth only, no charge
            },
        })

    try:
        result = await loop.run_in_executor(None, _sync_check)

        if result.is_success:
            txn = result.transaction
            proc_code = txn.processor_response_code or "1000"
            status = BT_RESPONSE_MAP.get(proc_code, CCStatus.CHARGED)
            is_vbv = status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS)
            return GatewayResult(
                status=status,
                gateway="Braintree",
                message=f"Auth {txn.processor_response_text} [{proc_code}]",
                raw_code=proc_code,
                is_vbv=is_vbv,
                is_non_vbv=not is_vbv and status == CCStatus.CHARGED,
            )

        # Failed transaction
        errors = result.errors.deep_errors
        if errors:
            first = errors[0]
            return GatewayResult(
                status=CCStatus.DEAD,
                gateway="Braintree",
                message=first.message,
                raw_code=str(first.code),
            )

        # Processor decline
        txn = result.transaction
        if txn:
            proc_code = txn.processor_response_code or ""
            proc_text = txn.processor_response_text or "Declined"
            status = BT_RESPONSE_MAP.get(proc_code, CCStatus.DEAD)
            is_vbv = status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS)
            return GatewayResult(
                status=status,
                gateway="Braintree",
                message=f"{proc_text} [{proc_code}]",
                raw_code=proc_code,
                is_vbv=is_vbv,
            )

        return GatewayResult(
            status=CCStatus.DEAD,
            gateway="Braintree",
            message="Unknown decline",
            raw_code="unknown",
        )

    except Exception as e:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="Braintree",
            message=f"Braintree error: {e}",
            raw_code="exception",
        )
