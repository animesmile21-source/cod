import asyncio, sys
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from gateways.stripe_wc_gate import check_stripe_wc_gate
from core.parser import CardData

async def test_gate_fix():
    print("=" * 75)
    print("🔬 Testing Fixed Stripe WC Gate on Real Site")
    print("=" * 75)
    
    card = CardData(number="4000000000000002", month="12", year="2028", cvv="123")
    res = await check_stripe_wc_gate(card)
    print(f"Status: {res.status}")
    print(f"Message: {res.message}")
    print(f"Raw Code: {res.raw_code}")

if __name__ == "__main__":
    asyncio.run(test_gate_fix())
