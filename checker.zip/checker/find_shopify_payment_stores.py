"""
find_shopify_payment_stores.py
Discovers Shopify stores that use Shopify Payments (not Stripe/Braintree)
by searching common Shopify store directories and testing them.

How Shopify Payments stores are identified:
  - checkout.pci.shopifyinc.com returns 200 + {"id": "..."} for vault
  - No Stripe pk_ keys in checkout HTML
  - delivery rates available for US
"""
import sys, os, asyncio, time, re, json, random
sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf8', buffering=1)

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(ROOT, ".env"))
except Exception:
    pass

import aiohttp
from aiohttp import CookieJar, ClientTimeout

TIMEOUT       = ClientTimeout(total=25)
VAULT_TIMEOUT = ClientTimeout(total=12)

BROWSER_HEADERS = {
    "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
}

# ── Known good seed stores (Shopify Payments confirmed) ─────────────────────
# These are stores whose Shopify myshopify subdomain we know use Shopify Payments
# We discover neighbors via myshopify.com sitemap / known patterns
SEED_STORES = [
    "https://checkout.brio4life.com",
    "https://www.dftba.com",
    "https://tentree.com",
    "https://hiutdenim.co.uk",
    "https://vanmoof.com",
    "https://kylie.com",
    "https://shop.taco.com",
    "https://mrporter.com",
    "https://allbirds.com",
    "https://ruggable.com",
    "https://chubbiesshorts.com",
    "https://puravidabracelets.com",
    "https://gymshark.com",
    "https://bombas.com",
    "https://untuckit.com",
    "https://shinesty.com",
    "https://ohpolly.com",
    "https://fashionnova.com",
    "https://goodr.com",
    "https://kotn.com",
    "https://therabody.com",
    "https://mejuri.com",
    "https://shop.lululemon.com",
    "https://polaroid.com",
    "https://shopcanadagoose.com",
    "https://moroccanoil.com",
    "https://ghdhair.com",
    "https://morphe.com",
    "https://analuisa.com",
    "https://shop.reebok.com",
    "https://us.pandora.net",
    "https://shop.harley-davidson.com",
    "https://burgerking.com",
    "https://taylorstitch.com",
    "https://shop.nba.com",
    "https://shop.mlb.com",
    "https://shop.nhl.com",
    "https://stadium.com",
    "https://princetonreview.com",
    "https://brooklinen.com",
    "https://parachutehome.com",
    "https://casper.com",
    "https://tuftandneedle.com",
    "https://puffy.com",
    "https://leesa.com",
    "https://saatva.com",
    "https://nectarsleep.com",
    "https://helix.sleep",
    "https://yogadesignlab.com",
    "https://manduka.com",
    "https://lululemon.com",
    "https://outdoor-voices.com",
    "https://vuori.com",
    "https://prAna.com",
    "https://icebreaker.com",
    "https://smartwool.com",
    "https://darn-tough.com",
    "https://farm-to-feet.com",
    "https://balega.com",
    "https://bombas.com",
    "https://dankeshoes.com",
    "https://sanuk.com",
    "https://olukai.com",
    "https://hoka.com",
    "https://shop.wolverine.com",
    "https://pikolinos.com",
    "https://shop.tods.com",
    "https://shop.jilsander.com",
    "https://shop.acnestudios.com",
    "https://shop.alexanderwang.com",
    "https://kith.com",
    "https://shop.supreme.com",
    "https://shop.palace.com",
    "https://shop.bape.com",
    "https://shop.apc.fr",
    "https://shop.ami.paris",
    "https://shop.jacquemus.com",
    "https://shop.isabel-marant.com",
    "https://shop.sezane.com",
    "https://shop.rouje.com",
    "https://shop.balzac-paris.com",
    "https://shop.andotherstories.com",
    "https://shop.cos.com",
    "https://monki.com",
    "https://weekday.com",
    "https://arket.com",
    "https://shop.uniqlo.com",
    "https://shop.muji.com",
    "https://shop.comme-des-garcons.com",
    "https://shop.yohji.com",
]


def pick_best_variant(products):
    best = None
    for p in products:
        for v in p.get("variants", []):
            if v.get("available") is False:
                continue
            try:
                price = float(v.get("price", "9999"))
            except Exception:
                continue
            if 0.50 <= price <= 15.0:
                if best is None or price < float(best["price"]):
                    best = {
                        "variant_id":    v["id"],
                        "price":         f"{price:.2f}",
                        "product_title": p["title"],
                        "currency":      "USD",
                    }
    return best


def extract_session_token(html):
    patterns = [
        r'name="serialized-sessionToken"\s+content="([^"]{20,})"',
        r'content="([^"]{20,})"\s+name="serialized-sessionToken"',
        r'"sessionToken"\s*:\s*"([^"]{20,})"',
    ]
    for pat in patterns:
        m = re.search(pat, html)
        if m:
            return m.group(1).strip('"')
    return ""


def extract_payment_method_id(html):
    m = re.search(r'paymentMethodIdentifier["\s:=]+"([a-f0-9]{32})"', html)
    return m.group(1) if m else "dc2c83c064fc75ebc5dfa2b5bee4f873"


def extract_unique_id(html):
    for pat in [
        r'/checkouts/cn/([a-zA-Z0-9]{16,})',
        r'"uniqueId"\s*:\s*"([^"]{10,})"',
    ]:
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return ""


async def test_store(url: str, sem: asyncio.Semaphore) -> dict:
    """Test if store uses Shopify Payments. Returns result dict."""
    import urllib.parse as _up

    base = url.rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base

    result = {"url": base, "status": "FAIL", "reason": "", "variant_id": None,
              "product_title": "", "price": "", "currency": "USD",
              "shop_domain": "", "shop_id": "", "checkout_type": "",
              "vault_ok": False, "scan_data": {}}

    async with sem:
        jar  = CookieJar(unsafe=True)
        conn = aiohttp.TCPConnector(ssl=False, limit=5, force_close=True)
        try:
            async with aiohttp.ClientSession(connector=conn, cookie_jar=jar, timeout=TIMEOUT) as s:

                # Homepage
                try:
                    async with s.get(base, headers=BROWSER_HEADERS, allow_redirects=True) as r:
                        hp = await r.text(errors="ignore")
                except Exception as e:
                    result["reason"] = f"Homepage: {str(e)[:40]}"
                    return result

                if not any(x in hp.lower() for x in ("cdn.shopify.com", "myshopify.com", "shopify.com/s/")):
                    result["reason"] = "Not Shopify"
                    return result

                # If store uses Stripe, skip
                if re.search(r'pk_live_[a-zA-Z0-9]{24,}', hp):
                    result["reason"] = "Uses Stripe (not Shopify Payments)"
                    return result

                m = re.search(r"([\w\-]+\.myshopify\.com)", hp)
                result["shop_domain"] = m.group(1) if m else ""
                m = re.search(r"shop(?:Id|_id)['\"\s:=]+(\d{5,12})", hp, re.I)
                result["shop_id"] = m.group(1) if m else ""

                # Products
                try:
                    async with s.get(base + "/products.json?limit=50",
                                     headers={**BROWSER_HEADERS, "Accept": "application/json"}) as r:
                        pj = await r.json(content_type=None)
                    products = pj.get("products", [])
                except Exception:
                    result["reason"] = "Products failed"
                    return result

                if not products:
                    result["reason"] = "No products"
                    return result

                variant = pick_best_variant(products)
                if not variant:
                    # Try any available variant under $50
                    for p in products:
                        for v in p.get("variants", []):
                            try:
                                price = float(v.get("price", "9999"))
                                if price <= 50:
                                    variant = {"variant_id": v["id"], "price": f"{price:.2f}",
                                               "product_title": p["title"], "currency": "USD"}
                                    break
                            except Exception:
                                pass
                        if variant:
                            break

                if not variant:
                    result["reason"] = "No usable variants"
                    return result

                result.update({"variant_id": variant["variant_id"],
                                "product_title": variant["product_title"],
                                "price": variant["price"],
                                "currency": variant["currency"]})

                # Cart add
                try:
                    async with s.post(
                        base + "/cart/add.js",
                        data=f"id={variant['variant_id']}&quantity=1",
                        headers={**BROWSER_HEADERS,
                                 "Content-Type": "application/x-www-form-urlencoded",
                                 "Accept": "application/json"},
                    ) as r:
                        if r.status not in (200, 201):
                            result["reason"] = f"Cart {r.status}"
                            return result
                except Exception as e:
                    result["reason"] = f"Cart: {str(e)[:40]}"
                    return result

                # Checkout via curl_cffi
                session_token = ""
                checkout_url  = ""
                checkout_html = ""
                try:
                    from curl_cffi.requests import AsyncSession as CurlSession
                    cookies_dict = {c.key: c.value for c in s.cookie_jar}
                    async with CurlSession(impersonate="chrome131", timeout=15) as curl:
                        for k, v in cookies_dict.items():
                            curl.cookies.set(k, v)
                        cr = await curl.get(
                            base + "/checkout",
                            headers={**BROWSER_HEADERS,
                                     "Accept": "text/html,application/xhtml+xml,*/*",
                                     "Referer": base + "/"},
                            allow_redirects=True,
                        )
                        checkout_url  = str(cr.url)
                        checkout_html = cr.text
                        # Sync cookies back
                        try:
                            s.cookie_jar.clear()
                            for k, v in curl.cookies.items():
                                try:
                                    s.cookie_jar.update_cookies({k: v})
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception as e:
                    result["reason"] = f"Checkout: {str(e)[:50]}"
                    return result

                session_token = extract_session_token(checkout_html)
                if not session_token:
                    result["reason"] = "No session token"
                    return result

                # Also reject if Stripe pk in checkout
                if re.search(r'pk_live_[a-zA-Z0-9]{24,}', checkout_html):
                    result["reason"] = "Uses Stripe gateway"
                    return result

                payment_method_id = extract_payment_method_id(checkout_html)
                unique_id         = extract_unique_id(checkout_html)
                layout            = "one-page"
                result["checkout_type"] = layout
                result["scan_data"]["payment_method_id"] = payment_method_id
                result["scan_data"]["checkout_url"]      = checkout_url

                # PCI Vault test
                try:
                    async with s.post(
                        "https://checkout.pci.shopifyinc.com/sessions",
                        json={"credit_card": {
                            "number": "4242424242424242",
                            "name": "John Doe",
                            "month": 12,
                            "year": 2028,
                            "verification_value": "123",
                            "payment_session_scope": result["shop_domain"] or base.replace("https://", ""),
                        }},
                        headers={
                            "Authorization": f'Bearer "{session_token}"',
                            "Content-Type":  "application/json",
                            "Accept":        "application/json",
                            "Origin":        "https://checkout.pci.shopifyinc.com",
                            "Referer":       checkout_url or base,
                            "User-Agent":    BROWSER_HEADERS["User-Agent"],
                        },
                        ssl=False, timeout=VAULT_TIMEOUT,
                    ) as r:
                        vault_status = r.status
                        vault_body   = await r.text(errors="ignore")
                except Exception as e:
                    result["reason"] = f"Vault: {str(e)[:40]}"
                    return result

                # 200 + id = Shopify Payments active and vault worked
                try:
                    vj = json.loads(vault_body)
                    vault_id = vj.get("id", "")
                    vault_ok = bool(vault_id)
                except Exception:
                    vault_ok = False
                    vault_id = ""

                if not vault_ok:
                    # 429 = rate limited (potentially valid, retry later)
                    if vault_status == 429:
                        result["reason"] = "Vault 429 (rate limited - retry later)"
                    else:
                        result["reason"] = f"Vault failed {vault_status} - not Shopify Payments"
                    return result

                result["vault_ok"] = True
                result["scan_data"]["vault_id"]     = vault_id[:40]
                result["scan_data"]["vault_status"] = vault_status

                # Delivery handle
                delivery_handle = ""
                try:
                    sf_ep  = base + "/api/2024-01/graphql.json"
                    sf_hdr = {**BROWSER_HEADERS, "Accept": "application/json",
                              "Content-Type": "application/json"}

                    cart_gid = ""
                    for cookie in s.cookie_jar:
                        if cookie.key == "cart":
                            val = _up.unquote(cookie.value)
                            if "?key=" in val:
                                cart_gid = f"gid://shopify/Cart/{val}"
                                break

                    if not cart_gid:
                        async with s.post(sf_ep, json={
                            "query": "mutation { cartCreate(input: {lines: [{merchandiseId: \"gid://shopify/ProductVariant/" + str(variant['variant_id']) + "\", quantity: 1}]}) { cart { id } } }"
                        }, headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=10)) as r:
                            try:
                                cj = await r.json(content_type=None)
                                cart_gid = (((cj.get("data") or {}).get("cartCreate") or {})
                                            .get("cart", {}).get("id", ""))
                            except Exception:
                                pass

                    if cart_gid:
                        async with s.post(sf_ep, json={
                            "query": "mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) { cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) { cart { deliveryGroups(first: 3) { nodes { deliveryOptions { handle title } } } } userErrors { message } } }",
                            "variables": {
                                "cartId": cart_gid,
                                "buyerIdentity": {
                                    "email": "john.doe@gmail.com",
                                    "countryCode": "US",
                                    "deliveryAddressPreferences": [{"deliveryAddress": {
                                        "firstName": "John", "lastName": "Doe",
                                        "address1": "123 Main St", "city": "Hudson",
                                        "province": "WY", "zip": "82515", "country": "US",
                                    }}]
                                }
                            }
                        }, headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=12)) as r:
                            try:
                                dj = await r.json(content_type=None)
                                nodes = (((dj.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                                         .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
                                if nodes:
                                    opts = nodes[0].get("deliveryOptions") or []
                                    if opts:
                                        rate_handle = opts[0].get("handle", "")
                                        delivery_handle = f"{unique_id}-{rate_handle}" if unique_id else rate_handle
                            except Exception:
                                pass
                except Exception as e:
                    result["scan_data"]["delivery_error"] = str(e)[:50]

                if not delivery_handle:
                    result["reason"] = "No US delivery option"
                    return result

                result["scan_data"]["delivery_handle"] = delivery_handle
                result["status"] = "WORKING"
                result["reason"] = f"Shopify Payments OK | ${result['price']} | Vault+Delivery confirmed"

        except asyncio.TimeoutError:
            result["reason"] = "Timeout"
        except Exception as e:
            result["reason"] = f"Error: {str(e)[:50]}"

    return result


async def main():
    print("=" * 65)
    print("  SHOPIFY PAYMENTS STORE FINDER")
    print("  Tests stores specifically for Shopify Payments (PCI Vault)")
    print("=" * 65)

    import database.db as db
    print("\n[1/3] Initializing DB...")
    await db.init_db()
    print("      DB ready.")

    urls = list(dict.fromkeys(SEED_STORES))
    total = len(urls)
    print(f"[2/3] Testing {total} seed stores...")
    print("[3/3] Scanning...\n")

    sem      = asyncio.Semaphore(10)
    working  = []
    failed   = []
    done_c   = [0]
    lock     = asyncio.Lock()
    start    = time.monotonic()

    async def do_scan(url):
        res = await test_store(url, sem)
        async with lock:
            done_c[0] += 1
            done = done_c[0]
            elapsed = time.monotonic() - start

            if res["status"] == "WORKING":
                try:
                    gate_id = await db.add_shopify_gate(
                        base_url      = res["url"],
                        variant_id    = res["variant_id"],
                        price         = res["price"],
                        product_title = res["product_title"],
                        shop_domain   = res["shop_domain"],
                        shop_id       = res["shop_id"],
                        currency      = res["currency"],
                        checkout_type = res["checkout_type"],
                        added_by      = 0,
                        scan_data     = res["scan_data"],
                    )
                    entry = f"#{gate_id} {res['url']} | ${res['price']} | {res['product_title'][:30]}"
                    working.append(entry)
                    print(f"  [{done:3d}/{total}] [OK]  {res['url'][:55]}")
                    print(f"              -> ${res['price']} | {res['product_title'][:40]}")
                except Exception as db_err:
                    print(f"  [{done:3d}/{total}] [DB!] {res['url'][:55]} -> DB error: {db_err}")
            else:
                failed.append(f"{res['url']} -> {res['reason']}")
                print(f"  [{done:3d}/{total}] [--]  {res['url'][:50]} | {res['reason'][:35]}")

    await asyncio.gather(*[do_scan(u) for u in urls])

    elapsed = time.monotonic() - start
    print()
    print("=" * 65)
    print(f"  COMPLETE in {elapsed:.1f}s")
    print(f"  Tested   : {total}")
    print(f"  [OK]     : {len(working)}")
    print(f"  [--]     : {len(failed)}")
    print("=" * 65)

    if working:
        print("\nWORKING GATES ADDED TO DB:")
        for w in working:
            print(f"  {w}")

    from collections import Counter
    reasons = Counter(f.split("->")[-1].strip()[:60] for f in failed)
    print("\nFAIL REASONS:")
    for r, c in reasons.most_common(10):
        print(f"  {c:3d}x  {r}")


if __name__ == "__main__":
    asyncio.run(main())
