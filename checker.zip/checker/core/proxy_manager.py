"""
core/proxy_manager.py — Proxy Pool Manager

Features:
- Proxy rotation (round-robin, fastest first)
- Test proxy via Shopify checkout URL (confirms Shopify-reachable)
- aiohttp connector builder with proxy auth
- Auto-mark dead proxies on repeated failures
- GitHub free proxy auto-fetcher (proxifly/free-proxy-list, every 30 min)
- mark_proxy_dead() for zero-card-waste retry in mass check

Formats supported:
  host:port
  host:port:user:pass
  socks5://host:port:user:pass
  http://user:pass@host:port
"""
import asyncio
import time
import logging
import itertools
from typing import Optional

import aiohttp
from aiohttp import ClientTimeout
from aiohttp_socks import ProxyConnector

logger = logging.getLogger("CC-Checker.Proxy")

TEST_URL     = "https://www.brio4life.com/checkout"
TEST_TIMEOUT = ClientTimeout(total=12)

# Round-robin state
_proxy_cycle = None
_proxy_list: list[dict] = []


def _build_proxy_url(proxy: dict) -> str:
    """Build proxy URL string from dict."""
    protocol = proxy.get("protocol", "http")
    host     = proxy["host"]
    port     = proxy["port"]
    user     = proxy.get("username", "")
    pwd      = proxy.get("password", "")

    if user and pwd:
        return f"{protocol}://{user}:{pwd}@{host}:{port}"
    return f"{protocol}://{host}:{port}"


def parse_proxy_string(proxy_str: str) -> Optional[dict]:
    """
    Parse proxy from ALL common string formats:

      user:pass@host:port                  ← instantproxies style ✅
      host:port                            ← simple ✅
      host:port:user:pass                  ← legacy ✅
      http://user:pass@host:port           ← URL style ✅
      socks5://user:pass@host:port         ← SOCKS5 ✅
      socks5://host:port                   ← SOCKS5 no auth ✅
    """
    proxy_str = proxy_str.strip()
    if not proxy_str:
        return None

    protocol = "http"

    # ── URL-style (has "://") ─────────────────────────────────────────────────
    if "://" in proxy_str:
        proto_part, remainder = proxy_str.split("://", 1)
        protocol = proto_part.lower()

        # Handle host:port:user:pass format within URL scheme (no @ but has 3+ colons)
        if remainder.count(":") >= 3 and "@" not in remainder:
            parts = remainder.split(":")
            # parts[0]=host, parts[1]=port, parts[2]=user, parts[3]=pass
            remainder = f"{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
            if len(parts) > 4:
                remainder += ":" + ":".join(parts[4:])

        if "@" in remainder:
            creds, hostport = remainder.rsplit("@", 1)
            user, pwd = (creds.split(":", 1) + [""])[:2] if ":" in creds else (creds, "")
        else:
            user, pwd = "", ""
            hostport = remainder

        if ":" not in hostport:
            return None
        host, port_str = hostport.rsplit(":", 1)

    # ── user:pass@host:port (NO "://" — instantproxies format) ───────────────
    elif "@" in proxy_str:
        creds_part, host_part = proxy_str.rsplit("@", 1)
        # creds_part = "user:pass"
        if ":" in creds_part:
            user, pwd = creds_part.split(":", 1)
        else:
            user, pwd = creds_part, ""
        # host_part = "host:port"
        if ":" not in host_part:
            return None
        host, port_str = host_part.rsplit(":", 1)

    # ── Plain formats: host:port or host:port:user:pass ───────────────────────
    else:
        parts = proxy_str.split(":")
        if len(parts) == 2:
            host, port_str = parts
            user, pwd = "", ""
        elif len(parts) >= 4:
            host = parts[0]
            port_str = parts[1]
            user = parts[2]
            pwd = parts[3]
        elif len(parts) == 3:
            host, port_str, user = parts
            pwd = ""
        else:
            return None

    # ── Validate ──────────────────────────────────────────────────────────────
    try:
        port = int(port_str.strip())
    except (ValueError, AttributeError):
        return None

    host = host.strip()
    if not host or not (1 <= port <= 65535):
        return None

    return {
        "host":     host,
        "port":     port,
        "username": (user or "").strip(),
        "password": (pwd or "").strip(),
        "protocol": protocol,
    }



async def test_proxy(proxy: dict) -> tuple[bool, int]:
    """
    Test if proxy works by fetching ipify.org.
    Returns (is_working, latency_ms).
    """
    proxy_url = _build_proxy_url(proxy)
    protocol  = proxy.get("protocol", "http")

    start = time.monotonic()
    try:
        if "socks" in protocol:
            connector = ProxyConnector.from_url(proxy_url, ssl=False)
        else:
            connector = aiohttp.TCPConnector(ssl=False)

        async with aiohttp.ClientSession(connector=connector) as session:
            kwargs = {}
            if "http" in protocol and "socks" not in protocol:
                kwargs["proxy"] = proxy_url

            async with session.get(
                TEST_URL,
                timeout=TEST_TIMEOUT,
                allow_redirects=True,
                headers={"User-Agent": "Mozilla/5.0 Chrome/120"},
                **kwargs
            ) as r:
                if r.status in (200, 301, 302):
                    # For Shopify checkouts, a 200/redirect means it loaded successfully (not blocked)
                    latency = int((time.monotonic() - start) * 1000)
                    return True, latency

    except Exception as e:
        logger.debug(f"Proxy test failed {proxy['host']}:{proxy['port']}: {e}")

    return False, 9999


def get_connector(proxy: dict) -> aiohttp.BaseConnector:
    """
    Build aiohttp connector for the given proxy.
    """
    proxy_url = _build_proxy_url(proxy)
    protocol  = proxy.get("protocol", "http")

    if "socks" in protocol:
        return ProxyConnector.from_url(proxy_url, ssl=False, limit=10)
    else:
        return aiohttp.TCPConnector(ssl=False, limit=10)


def get_proxy_kwargs(proxy: dict) -> dict:
    """
    Return extra kwargs to pass to aiohttp session.get()/post() for HTTP proxies.
    For SOCKS proxies, the connector handles routing (no extra kwargs needed).
    """
    protocol = proxy.get("protocol", "http")
    if "socks" in protocol:
        return {}
    return {"proxy": _build_proxy_url(proxy)}


async def refresh_proxy_pool():
    """Reload working proxies from DB into memory cache."""
    global _proxy_cycle, _proxy_list
    import database.db as db
    _proxy_list = await db.get_working_proxies()
    if _proxy_list:
        _proxy_cycle = itertools.cycle(_proxy_list)
        logger.info(f"Proxy pool loaded: {len(_proxy_list)} proxies")
    else:
        _proxy_cycle = None
        logger.info("No working proxies in pool")


def get_next_proxy() -> Optional[dict]:
    """Get next proxy from round-robin pool. Returns None if no proxies."""
    global _proxy_cycle
    if not _proxy_cycle:
        return None
    try:
        return next(_proxy_cycle)
    except StopIteration:
        return None


async def add_and_test_proxy(
    proxy_str: str,
    added_by: int = 0,
) -> tuple[bool, str, dict | None]:
    """
    Parse, test, and add proxy to DB.
    Returns (success, message, proxy_dict).
    """
    import database.db as db

    proxy = parse_proxy_string(proxy_str)
    if not proxy:
        return False, "❌ Invalid proxy format", None

    # Test the proxy
    logger.info(f"Testing proxy {proxy['host']}:{proxy['port']}...")
    working, latency = await test_proxy(proxy)

    if not working:
        return False, f"❌ Proxy dead — `{proxy['host']}:{proxy['port']}` timeout/refused", None

    # Save to DB
    pid = await db.add_proxy(
        host=proxy["host"],
        port=proxy["port"],
        username=proxy.get("username", ""),
        password=proxy.get("password", ""),
        protocol=proxy.get("protocol", "http"),
        latency_ms=latency,
        added_by=added_by,
    )
    await refresh_proxy_pool()

    msg = (
        f"✅ Proxy added!\n"
        f"🌐 `{proxy['host']}:{proxy['port']}`\n"
        f"🔌 Protocol: `{proxy['protocol']}`\n"
        f"⚡ Latency: `{latency}ms`\n"
        f"🆔 ID: `{pid}`"
    )
    return True, msg, proxy


def get_random_proxy() -> Optional[str]:
    """Get next proxy from round-robin pool formatted as a URL string."""
    proxy = get_next_proxy()
    if not proxy:
        return None
    return _build_proxy_url(proxy)


# ── Dead proxy tracking (in-memory, per-run) ──────────────────────────────────
# Proxies that fail during mass check are removed from rotation immediately.
# This ensures the NEXT card gets a fresh proxy, not a dead one.
_dead_proxy_keys: set[str] = set()  # "host:port" of confirmed dead proxies

# ── Segmented proxy pool ───────────────────────────────────────────────────────
# Used for dual-proxy architecture: each store gets workers from different segments
# so no single proxy ever hits the same store twice in parallel.
_proxy_segment_cycles: dict[int, "itertools.cycle"] = {}
_proxy_segments_n: int = 0  # number of segments currently initialized


def _proxy_key(proxy: dict) -> str:
    return f"{proxy['host']}:{proxy['port']}"


def get_proxy_pool_size() -> int:
    """Return number of alive proxies currently in the pool."""
    return len([p for p in _proxy_list if _proxy_key(p) not in _dead_proxy_keys])


def _ensure_segments(n_segments: int = 2):
    """Split alive proxy pool into n equal segments with independent cycles."""
    global _proxy_segment_cycles, _proxy_segments_n
    alive = [p for p in _proxy_list if _proxy_key(p) not in _dead_proxy_keys]
    if not alive:
        _proxy_segment_cycles = {}
        _proxy_segments_n = 0
        return
    seg_size = max(1, len(alive) // n_segments)
    _proxy_segment_cycles = {}
    for i in range(n_segments):
        start = i * seg_size
        end = (start + seg_size) if i < n_segments - 1 else len(alive)
        seg = alive[start:end]
        if seg:
            _proxy_segment_cycles[i] = itertools.cycle(seg)
    _proxy_segments_n = n_segments
    logger.info(f"Proxy segments: {n_segments} segments, {len(alive)} proxies total ({seg_size} per segment)")


def get_next_proxy_segment(segment: int) -> "Optional[dict]":
    """Get next proxy from a specific pool segment (0 = first half, 1 = second half).
    Falls back to global round-robin if segments not initialized."""
    if segment in _proxy_segment_cycles:
        try:
            return next(_proxy_segment_cycles[segment])
        except StopIteration:
            pass
    return get_next_proxy()  # fallback to global pool


def mark_proxy_dead(proxy: dict):
    """Mark a proxy as dead — it will be skipped in next get_next_proxy() call."""
    if proxy:
        key = _proxy_key(proxy)
        _dead_proxy_keys.add(key)
        logger.debug(f"Proxy marked dead: {key}")
        _rebuild_cycle_without_dead()


def clear_dead_proxies_cache():
    """Reset the temporary dead proxies list so we can retry them in a new session/check."""
    _dead_proxy_keys.clear()
    _rebuild_cycle_without_dead()
    logger.info("Temporary dead proxies cache cleared.")


def _rebuild_cycle_without_dead():
    """Remove dead proxies from rotation cycle (called after marking dead)."""
    global _proxy_cycle, _proxy_list
    alive = [p for p in _proxy_list if _proxy_key(p) not in _dead_proxy_keys]
    if alive:
        _proxy_cycle = itertools.cycle(alive)
    else:
        # Self-healing: if all proxies are marked dead, reset the cache instead of going direct IP
        logger.warning("All proxies in the pool were marked dead. Resetting dead proxy cache to avoid direct IP fallback.")
        _dead_proxy_keys.clear()
        _proxy_cycle = itertools.cycle(_proxy_list)
        alive = list(_proxy_list)

    # Rebuild segments too if they were initialized
    if _proxy_segments_n > 0:
        _ensure_segments(_proxy_segments_n)
    if len(alive) != len(_proxy_list):
        logger.info(f"Proxy pool: {len(alive)} alive / {len(_proxy_list)} total after removing dead")



# ── GitHub Free Proxy Auto-Fetcher ────────────────────────────────────────────
# Source: https://github.com/proxifly/free-proxy-list
# Raw URL: https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt
# Format: one proxy per line (http://ip:port or socks5://ip:port etc.)
# Refresh interval: every 30 minutes — tests against REAL Shopify endpoint

_GITHUB_PROXY_RAW_URL  = "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt"
_GITHUB_REFRESH_SECS   = 1800   # 30 min — proxy fetch/add cycle
_DAILY_HEALTH_SECS     = 86400  # 24 hours — full DB dead-proxy cleanup + owner notify
_SHOPIFY_PROBE_URL     = "https://mood.design/collections"
_GH_TEST_TIMEOUT       = ClientTimeout(total=8)
_GH_CONCURRENCY        = 80
_GH_MAX_TEST           = 500


_github_refresh_task: "asyncio.Task | None" = None


async def _probe_shopify(proxy: dict) -> tuple[bool, int]:
    """
    Test if proxy can reach Shopify. Returns (working, latency_ms).
    Uses GET /collections on a Shopify store — returns 200/301/302 for any working proxy.
    Even a 403 (Cloudflare bot block) means the proxy reached Shopify's servers.
    """
    url       = _SHOPIFY_PROBE_URL
    proxy_url = _build_proxy_url(proxy)
    protocol  = proxy.get("protocol", "http")
    start     = time.monotonic()
    try:
        if "socks" in protocol:
            connector = ProxyConnector.from_url(proxy_url, ssl=False)
            kwargs: dict = {}
        else:
            connector = aiohttp.TCPConnector(ssl=False, limit=1)
            kwargs = {"proxy": proxy_url}

        async with aiohttp.ClientSession(connector=connector, timeout=_GH_TEST_TIMEOUT) as s:
            async with s.get(
                url,
                headers={"User-Agent": "Mozilla/5.0 Chrome/131", "Accept": "text/html,*/*"},
                allow_redirects=False,  # Just need any response from Shopify network
                **kwargs,
            ) as r:
                # 200 = page loaded, 301/302 = redirect (normal), 403 = Cloudflare blocked (proxy alive!),
                # 404 = page not found (proxy alive!), 405 = method not allowed (proxy alive!)
                if r.status in (200, 201, 301, 302, 303, 403, 404, 405, 429):
                    return True, int((time.monotonic() - start) * 1000)
    except Exception:
        pass
    return False, 9999


async def fetch_github_proxies(
    save_to_db: bool = True,
    owner_id: int = 0,
    max_test: int = _GH_MAX_TEST,
) -> dict:
    """
    Download proxy list from GitHub, test against Shopify, save working ones to DB.
    
    Returns summary:
      { fetched, tested, working, saved }
    
    Can be called manually (e.g. via a bot /fetchproxies command) or
    runs automatically via start_github_proxy_refresher().
    """
    import database.db as db
    import random as _rnd

    summary = {"fetched": 0, "tested": 0, "working": 0, "saved": 0}

    # Step 1: Download
    logger.info("Fetching free proxy list from GitHub (proxifly)...")
    try:
        async with aiohttp.ClientSession(timeout=ClientTimeout(total=20)) as s:
            async with s.get(_GITHUB_PROXY_RAW_URL) as r:
                if r.status != 200:
                    logger.warning(f"GitHub proxy list HTTP {r.status}")
                    return summary
                raw = await r.text()
    except Exception as e:
        logger.warning(f"GitHub proxy list download failed: {e}")
        return summary

    # Step 2: Parse
    proxies = [parse_proxy_string(l.strip()) for l in raw.splitlines() if l.strip()]
    proxies = [p for p in proxies if p]
    summary["fetched"] = len(proxies)
    logger.info(f"Parsed {len(proxies)} proxies from GitHub")

    if not proxies:
        return summary

    # Shuffle + cap
    _rnd.shuffle(proxies)
    to_test = proxies[:max_test]
    summary["tested"] = len(to_test)

    # Step 3: Test concurrently
    sem     = asyncio.Semaphore(_GH_CONCURRENCY)
    working: list[tuple[dict, int]] = []

    async def _test_one(p: dict):
        async with sem:
            ok, lat = await _probe_shopify(p)
            if ok:
                working.append((p, lat))

    logger.info(f"Testing {len(to_test)} proxies against Shopify (concurrency={_GH_CONCURRENCY})...")
    await asyncio.gather(*(_test_one(p) for p in to_test), return_exceptions=True)

    summary["working"] = len(working)
    logger.info(f"GitHub proxy result: {len(working)}/{len(to_test)} working on Shopify")

    if not working or not save_to_db:
        await refresh_proxy_pool()
        return summary

    # Step 4: Save to DB (sorted by latency — fastest first)
    working.sort(key=lambda x: x[1])
    saved = 0
    for proxy, lat in working:
        try:
            pid = await db.add_proxy(
                host=proxy["host"],
                port=proxy["port"],
                username=proxy.get("username", ""),
                password=proxy.get("password", ""),
                protocol=proxy.get("protocol", "http"),
                latency_ms=lat,
                added_by=owner_id,
            )
            if pid:
                saved += 1
        except Exception as e:
            logger.debug(f"Proxy DB skip {proxy['host']}:{proxy['port']}: {e}")

    summary["saved"] = saved
    logger.info(f"Saved {saved} new working proxies to DB")

    # Step 5: Reload in-memory pool
    await refresh_proxy_pool()
    return summary


async def _remove_dead_proxies_from_db() -> int:
    """
    Test ALL proxies currently in DB against Shopify.
    Delete dead ones immediately from DB (not just in-memory).
    Called once per day.
    Returns count of removed proxies.
    """
    import database.db as db
    all_proxies = await db.get_working_proxies()
    if not all_proxies:
        return 0

    logger.info(f"[DailyHealthCheck] Testing {len(all_proxies)} DB proxies...")
    sem = asyncio.Semaphore(_GH_CONCURRENCY)
    dead_ids: list[int] = []

    async def _check_one(p: dict):
        async with sem:
            ok, _ = await _probe_shopify(p)
            if not ok:
                pid = p.get("id") or p.get("proxy_id")
                if pid:
                    dead_ids.append(int(pid))

    await asyncio.gather(*(_check_one(p) for p in all_proxies), return_exceptions=True)

    # Delete dead ones from DB
    removed = 0
    for pid in dead_ids:
        try:
            await db._db.execute("DELETE FROM proxies WHERE id=?", (pid,))
            removed += 1
        except Exception as e:
            logger.debug(f"Delete proxy {pid} error: {e}")

    if removed:
        await refresh_proxy_pool()
        logger.info(f"[DailyHealthCheck] Removed {removed}/{len(all_proxies)} dead proxies from DB")

    return removed


async def _github_proxy_loop(telegram_client=None, owner_id: int = 0):
    """Background task:
    - Every 30 min: fetch free proxies from GitHub, test, add new ones to DB.
    - Once per day: full health check — test ALL DB proxies, delete dead ones, notify owner ONCE.
    """
    _last_daily = 0.0   # timestamp of last daily health check

    while True:
        try:
            result = await fetch_github_proxies(save_to_db=True, owner_id=owner_id)
            pool_size = get_proxy_pool_size()
            logger.info(
                f"[AutoRefresh] fetched={result['fetched']} "
                f"working={result['working']} saved={result['saved']} "
                f"pool={pool_size}"
            )

            # ── Daily health check: remove dead proxies from DB + notify owner ──
            now_ts = time.monotonic()
            if now_ts - _last_daily >= _DAILY_HEALTH_SECS:
                _last_daily = now_ts
                removed = await _remove_dead_proxies_from_db()
                pool_size = get_proxy_pool_size()   # updated after removals

                if telegram_client and owner_id:
                    try:
                        from datetime import datetime
                        from pyrogram.enums import ParseMode
                        now_str = datetime.now().strftime("%d %b %Y %H:%M")
                        notif = (
                            f"🌐 <b>Daily Proxy Health Report</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"🕐 <b>Time:</b> <code>{now_str}</code>\n"
                            f"📥 <b>GitHub fetched:</b> <code>{result['fetched']:,}</code>\n"
                            f"✅ <b>New proxies added:</b> <code>{result['saved']}</code>\n"
                            f"🗑 <b>Dead proxies removed:</b> <code>{removed}</code>\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"🔥 <b>Active Pool:</b> <code>{pool_size} proxies</code>\n"
                            f"⏱ <b>Next report in:</b> <code>24 hours</code>"
                        )
                        await telegram_client.send_message(
                            chat_id=owner_id,
                            text=notif,
                            parse_mode=ParseMode.HTML,
                        )
                    except Exception as e:
                        logger.debug(f"[AutoRefresh] DM notify failed: {e}")
            # No notification for non-daily refreshes (silent)

        except Exception as e:
            logger.warning(f"[AutoRefresh] Error: {e}")
        await asyncio.sleep(_GITHUB_REFRESH_SECS)


def start_github_proxy_refresher(telegram_client=None, owner_id: int = 0):
    """
    Start the background GitHub proxy auto-refresh task.
    Call once on bot startup (after db.init_db()).
    Fetches + tests proxies every 30 min, keeps pool fresh automatically.
    
    Pass telegram_client + owner_id to get DM notifications after each refresh.
    """
    global _github_refresh_task
    if _github_refresh_task and not _github_refresh_task.done():
        logger.debug("GitHub proxy refresher already running")
        return
    _github_refresh_task = asyncio.create_task(
        _github_proxy_loop(telegram_client=telegram_client, owner_id=owner_id)
    )
    logger.info(f"GitHub proxy auto-refresher started (interval={_GITHUB_REFRESH_SECS}s, DM={'yes' if telegram_client else 'no'})")

