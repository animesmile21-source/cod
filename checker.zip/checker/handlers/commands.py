"""
handlers/commands.py — /start, /help, /stats, /gates, /id, /setcmds
Premium UI with stylish menus and inline buttons.
"""
import asyncio
import time as _time
from pyrogram import Client, filters, enums
from pyrogram.types import Message, BotCommand, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from datetime import datetime, timezone
import config
import database.db as db
from utils.formatter import format_bin_info
from core.bin_lookup import lookup_bin, BinInfo
from utils.error_handler import notify_owner_on_error

# ── Store health check: tracks dead URLs between command and button click ─────
_dead_store_cache: dict[int, list[str]] = {}  # user_id → list of dead base_urls


async def _has_permission(user_id: int) -> bool:
    """Check if user is owner or has any active (non-free) subscription plan."""
    if bool(config.OWNER_IDS) and user_id in config.OWNER_IDS:
        return True
    plan_info = await db.get_user_plan(user_id)
    return plan_info["plan"] not in ("free", None, "")


async def _admin_denied(msg: Message):
    await msg.reply(
        "🚫 **Access Denied!**\n\n"
        "This command requires a premium subscription.\n"
        "Redeem your key via: `/redeem KEY-PLAN-XXXX`",
        parse_mode=enums.ParseMode.MARKDOWN
    )


# ── BotFather command list (only user-visible commands) ──────────────────────
BOT_COMMANDS = [
    BotCommand("start",  "🚀 Start the bot"),
    BotCommand("redeem", "🎫 Redeem a subscription key"),
    BotCommand("status", "📊 Check your plan & stats"),
    BotCommand("st",     "🏦 Single check (Stripe-WC)"),
    BotCommand("mst",    "📂 Mass check (Stripe-WC)"),
    BotCommand("stscan", "🔭 Auto-discover Stripe-WC sites"),


]


def get_start_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Build start menu keyboard."""
    buttons = [
        [
            InlineKeyboardButton("⚡ Gates", callback_data="menu_gates"),
            InlineKeyboardButton("📊 Status", callback_data="menu_status"),
        ],
        [
            InlineKeyboardButton("ℹ️ About", callback_data="menu_about"),
            InlineKeyboardButton("💬 Support", url="https://t.me/yoursmileyt"),
        ],
    ]
    if user_id in config.OWNER_IDS:
        buttons.append([InlineKeyboardButton("👑 Owner Panel", callback_data="menu_owner")])
    return InlineKeyboardMarkup(buttons)


def register_commands(app: Client):

    @app.on_message(filters.command("start"))
    @notify_owner_on_error
    async def start_cmd(client: Client, msg: Message):
        user_id = msg.from_user.id

        # 1. Force subscribe check
        from handlers.checker import _check_force_sub, _send_force_sub_prompt
        joined, channel = await _check_force_sub(client, user_id)
        if not joined:
            await _send_force_sub_prompt(msg, channel)
            return

        await db.upsert_user(
            msg.from_user.id,
            msg.from_user.username or "",
            msg.from_user.first_name or "",
        )

        # Get plan badge for welcome message
        if user_id in config.OWNER_IDS:
            plan_badge = "👑 Owner"
        else:
            plan_info = await db.get_user_plan(user_id)
            plan = plan_info["plan"].upper()
            plan_badge = "🆓 Free" if plan == "FREE" else f"💎 {plan}"

        first_name = msg.from_user.first_name or "User"

        welcome_text = (
            f"<b>╔══════════════════════╗</b>\n"
            f"<b>   ⚡ CC CHECKER PRO ⚡   </b>\n"
            f"<b>╚══════════════════════╝</b>\n\n"
            f"<blockquote>"
            f"👤 <b>User:</b> {first_name}\n"
            f"🎫 <b>Plan:</b> <code>{plan_badge}</code>\n"
            f"🌐 <b>Gate:</b> <code>Shopify 300+</code>\n"
            f"🔐 <b>Mode:</b> <code>Private • Stealth</code>"
            f"</blockquote>\n\n"
            f"<b>🔥 Ultra-fast 2-stage pipeline</b>\n"
            f"<b>💎 Real bank-level card checking</b>\n"
            f"<b>🛡️ Stripe Radar bypass active</b>\n\n"
            f"<i>Select an option below 👇</i>"
        )
        await msg.reply(welcome_text, reply_markup=get_start_keyboard(user_id), parse_mode=enums.ParseMode.HTML)


    @app.on_callback_query(filters.create(lambda _, __, cb: cb.data and (
        cb.data.startswith("menu_") or
        cb.data.startswith("gk_p_") or
        cb.data.startswith("gkd|") or
        cb.data.startswith("gkc|")
    )))
    async def start_menu_callbacks(client: Client, cb):
        user_id = cb.from_user.id
        data = cb.data

        # Verify force subscribe before navigating menus (except about)
        if data not in ("menu_about",):
            from handlers.checker import _check_force_sub
            joined, _ = await _check_force_sub(client, user_id)
            if not joined:
                await cb.answer("❌ Please join the force sub channel first!", show_alert=True)
                return

        # ── Main menu ──────────────────────────────────────────────────────────
        if data == "menu_main":
            if user_id in config.OWNER_IDS:
                plan_badge = "👑 Owner"
            else:
                plan_info = await db.get_user_plan(user_id)
                plan = plan_info["plan"].upper()
                plan_badge = "🆓 Free" if plan == "FREE" else f"💎 {plan}"

            text = (
                f"<b>╔══════════════════════╗</b>\n"
                f"<b>   ⚡ CC CHECKER PRO ⚡   </b>\n"
                f"<b>╚══════════════════════╝</b>\n\n"
                f"<blockquote>"
                f"🎫 <b>Plan:</b> <code>{plan_badge}</code>\n"
                f"🌐 <b>Gate:</b> <code>Shopify 300+ stores</code>\n"
                f"🔐 <b>Mode:</b> <code>Private • Stealth</code>\n"
                f"🔥 <b>Engine:</b> <code>2-Stage Pipeline</code>"
                f"</blockquote>\n\n"
                f"<i>Choose an option below 👇</i>"
            )
            await cb.message.edit_text(text, reply_markup=get_start_keyboard(user_id), parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── About menu ─────────────────────────────────────────────────────────
        elif data == "menu_about":
            text = (
                f"<b>╔══════ ℹ️ ABOUT ══════╗</b>\n\n"
                f"<blockquote>"
                f"🤖 <b>Bot:</b> CC Checker Pro\n"
                f"🚀 <b>Version:</b> 3.2 — July 2026\n"
                f"👨‍💻 <b>Dev:</b> @yoursmileyt\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"⚡ <b>Engine:</b> 2-Stage Shopify Pipeline\n"
                f"🛡️ <b>Bypass:</b> Dynamic Radar Evasion\n"
                f"🌐 <b>Proxies:</b> GitHub Auto-Refresh (30min)\n"
                f"🎭 <b>Profiles:</b> Infinite Random Identities\n"
                f"🏪 <b>Stores:</b> 300+ Shopify gates\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"🔥 Built for speed. Built for accuracy."
                f"</blockquote>"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data="menu_main")]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Status menu (inline quick view) ────────────────────────────────────
        elif data == "menu_status":
            status = await db.get_user_full_status(user_id)
            plan = status["plan"].upper()
            is_owner_user = user_id in config.OWNER_IDS

            if is_owner_user:
                plan_badge = "👑 Owner"
                expiry_line = "♾️ Lifetime"
                cards_line = "∞ Unlimited"
            elif plan == "FREE":
                plan_badge = "🆓 Free"
                expiry_line = "❌ No Plan"
                cards_line = str(status["max_cards"])
            else:
                plan_badge = f"💎 {plan}"
                expiry_line = f"{status['remaining_days']}d remaining" if not status["is_expired"] else "⚠️ Expired"
                cards_line = str(status["max_cards"])

            hit_rate = "0%"
            if status['total_checks'] > 0:
                rate = (status['hits'] / status['total_checks']) * 100
                hit_rate = f"{rate:.1f}%"

            text = (
                f"<b>╔══════ 📊 STATUS ══════╗</b>\n\n"
                f"<blockquote>"
                f"🎫 <b>Plan:</b> <code>{plan_badge}</code>\n"
                f"⏳ <b>Expiry:</b> <code>{expiry_line}</code>\n"
                f"🃏 <b>Max Cards:</b> <code>{cards_line}</code>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📈 <b>Total Checks:</b> <code>{status['total_checks']:,}</code>\n"
                f"✅ <b>Hits Found:</b> <code>{status['hits']}</code>\n"
                f"🎯 <b>Hit Rate:</b> <code>{hit_rate}</code>"
                f"</blockquote>"
            )
            markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Refresh", callback_data="menu_status")],
                [InlineKeyboardButton("⬅️ Back", callback_data="menu_main")]
            ])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Gates menu ─────────────────────────────────────────────────────────
        elif data == "menu_gates":
            from core.proxy_manager import get_proxy_pool_size
            pool = get_proxy_pool_size()
            text = (
                f"<b>╔══════ ⚡ GATES ══════╗</b>\n\n"
                f"<blockquote>"
                f"🛒 <b>Shopify</b> — <code>Active ✅</code>\n"
                f"   └ 300+ stores in rotation\n"
                f"   └ 2-Stage pipeline (probe + submit)\n"
                f"   └ Dynamic Radar bypass\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"🌐 <b>Proxies:</b> <code>{pool} active</code>\n"
                f"🔄 <b>Auto-refresh:</b> <code>Every 30 min</code>\n"
                f"🎭 <b>Identities:</b> <code>∞ Random per check</code>"
                f"</blockquote>\n\n"
                f"<i>Select mode below 👇</i>"
            )
            markup = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("💳 Single Check", callback_data="menu_single_chk"),
                    InlineKeyboardButton("📦 Mass Check", callback_data="menu_mass_chk"),
                ],
                [InlineKeyboardButton("⬅️ Back", callback_data="menu_main")]
            ])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Shopify menu ───────────────────────────────────────────────────────
        elif data == "menu_shopify":
            text = (
                f"<b>🛒 𝗦𝗵𝗼𝗽𝗶𝗳𝘆 𝗚𝗮𝘁𝗲𝘄𝗮𝘆</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"⚡ Ultra-fast Shopify checking\n"
                f"🔄 300+ stores in auto-rotation\n"
                f"💎 Real charge attempt on live cards"
                f"</blockquote>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Choose your check mode:"
            )
            markup = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("💳 𝗦𝗶𝗻𝗴𝗹𝗲 𝗖𝗵𝗲𝗰𝗸", callback_data="menu_single_chk"),
                    InlineKeyboardButton("📦 𝗠𝗮𝘀𝘀 𝗖𝗵𝗲𝗰𝗸", callback_data="menu_mass_chk"),
                ],
                [InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸 𝘁𝗼 𝗚𝗮𝘁𝗲𝘀", callback_data="menu_gates")]
            ])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Single Check help ──────────────────────────────────────────────────
        elif data == "menu_single_chk":
            text = (
                f"<b>💳 𝗦𝗶𝗻𝗴𝗹𝗲 𝗖𝗵𝗲𝗰𝗸</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"📌 <b>Command:</b>\n"
                f"<code>/chk cc|mm|yy|cvv</code>\n\n"
                f"📌 <b>Example:</b>\n"
                f"<code>/chk 4111111111111111|12|2026|123</code>\n\n"
                f"📊 <b>Result Codes:</b>\n"
                f"✅ <code>Charged</code> — Live, Non-VBV\n"
                f"🔐 <code>Live VBV</code> — Live, 3DS required\n"
                f"⚠️ <code>Insufficient</code> — Live, no balance\n"
                f"❌ <code>Declined</code> — Dead"
                f"</blockquote>"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_shopify")]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Mass Check help ────────────────────────────────────────────────────
        elif data == "menu_mass_chk":
            text = (
                f"<b>📦 𝗠𝗮𝘀𝘀 𝗖𝗵𝗲𝗰𝗸</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"📌 <b>Method 1:</b>\n"
                f"Send <code>.txt</code> file with caption <code>/mchk</code>\n\n"
                f"📌 <b>Method 2:</b>\n"
                f"Reply to a <code>.txt</code> file with <code>/mchk</code>\n\n"
                f"📄 <b>Format:</b>\n"
                f"<code>4111111111111111|12|2026|123</code>\n\n"
                f"⚙️ <b>Limits:</b>\n"
                f"🆓 Free (Group): 500 cards\n"
                f"💎 Premium (DM): Your plan limit"
                f"</blockquote>"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_shopify")]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Owner settings panel ───────────────────────────────────────────────
        elif data == "menu_owner":
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only settings.", show_alert=True)
                return
            text = (
                f"<b>👑 𝗢𝘄𝗻𝗲𝗿 𝗣𝗮𝗻𝗲𝗹</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"🛡️ <b>Plan Commands:</b>\n"
                f"• <code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards&gt;</code>\n"
                f"• <code>/delplan &lt;name&gt;</code>\n\n"
                f"📢 <b>Setup Commands:</b>\n"
                f"• <code>/forcesub @channel</code>\n"
                f"• <code>/setgroup -100...</code>"
                f"</blockquote>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Choose an action:"
            )
            markup = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("🔑 𝗚𝗲𝗻 𝗞𝗲𝘆", callback_data="menu_genkey_help"),
                    InlineKeyboardButton("📋 𝗣𝗹𝗮𝗻𝘀", callback_data="menu_plans"),
                ],
                [
                    InlineKeyboardButton("📢 𝗙𝗼𝗿𝗰𝗲 𝗦𝘂𝗯", callback_data="menu_forcesub_help"),
                    InlineKeyboardButton("👥 𝗦𝗲𝘁 𝗚𝗿𝗼𝘂𝗽", callback_data="menu_setgroup_help"),
                ],
                [InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_main")]
            ])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Gen Key — plan selector ────────────────────────────────────────────
        elif data == "menu_genkey_help":
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only.", show_alert=True)
                return

            active_plans = await db.get_all_plans()

            text = (
                f"<b>🔑 𝗞𝗲𝘆 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗶𝗼𝗻 𝗣𝗮𝗻𝗲𝗹</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Select a subscription plan to generate keys for:"
            )

            buttons = []
            row = []
            for p in active_plans:
                p_name = p["plan_name"]
                if p_name != "free":
                    row.append(InlineKeyboardButton(
                        f"💎 {p_name.upper()} ({p['max_cards']} CC / {p['max_workers']}w)",
                        callback_data=f"gk_p_{p_name}"
                    ))
                    if len(row) == 2:
                        buttons.append(row)
                        row = []
            if row:
                buttons.append(row)

            if not buttons:
                text = (
                    f"<b>🔑 𝗞𝗲𝘆 𝗚𝗲𝗻 𝗣𝗮𝗻𝗲𝗹</b>\n\n"
                    f"⚠️ No plans configured yet!\n"
                    f"Use <code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards&gt;</code> to add plans first."
                )

            buttons.append([InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_owner")])
            markup = InlineKeyboardMarkup(buttons)
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── gk_p_<plan> — duration selector ───────────────────────────────────
        elif data.startswith("gk_p_"):
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only.", show_alert=True)
                return
            plan = data[5:]  # everything after "gk_p_"
            text = (
                f"<b>🔑 𝗞𝗲𝘆 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗶𝗼𝗻</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"💎 Plan: <code>{plan.upper()}</code>\n\n"
                f"Select key validity duration:"
            )
            markup = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("📅 1 Day", callback_data=f"gkd|{plan}|1"),
                    InlineKeyboardButton("📅 7 Days", callback_data=f"gkd|{plan}|7"),
                ],
                [
                    InlineKeyboardButton("📅 30 Days", callback_data=f"gkd|{plan}|30"),
                    InlineKeyboardButton("📅 365 Days", callback_data=f"gkd|{plan}|365"),
                ],
                [InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_genkey_help")]
            ])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── gkd|<plan>|<days> — count selector ───────────────────────────────
        elif data.startswith("gkd|"):
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only.", show_alert=True)
                return
            _, plan, days = data.split("|")
            text = (
                f"<b>🔑 𝗞𝗲𝘆 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗶𝗼𝗻</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"💎 Plan: <code>{plan.upper()}</code>\n"
                f"📅 Duration: <code>{days} Days</code>\n\n"
                f"Select number of keys to generate:"
            )
            markup = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("🔢 1 Key", callback_data=f"gkc|{plan}|{days}|1"),
                    InlineKeyboardButton("🔢 5 Keys", callback_data=f"gkc|{plan}|{days}|5"),
                ],
                [
                    InlineKeyboardButton("🔢 10 Keys", callback_data=f"gkc|{plan}|{days}|10"),
                    InlineKeyboardButton("🔢 50 Keys", callback_data=f"gkc|{plan}|{days}|50"),
                ],
                [InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data=f"gk_p_{plan}")]
            ])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── gkc|<plan>|<days>|<count> — generate! ─────────────────────────────
        elif data.startswith("gkc|"):
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only.", show_alert=True)
                return
            _, plan, days_str, count_str = data.split("|")
            days = int(days_str)
            count = int(count_str)

            import random, string
            generated = []
            for _ in range(count):
                random_str = "".join(random.choices(string.ascii_uppercase + string.digits, k=16))
                key_str = f"KEY-{plan.upper()}-{random_str}"
                generated.append({"key": key_str, "plan": plan, "days": days})

            await db.save_redeem_keys(generated)

            lines = [f"<code>{k['key']}</code>" for k in generated]
            text = (
                f"<b>🔑 𝗞𝗲𝘆𝘀 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗲𝗱!</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"💎 <b>Plan:</b> <code>{plan.upper()}</code>\n"
                f"📅 <b>Duration:</b> <code>{days} Days</code>\n"
                f"🔢 <b>Count:</b> <code>{count}</code>"
                f"</blockquote>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                + "\n".join(lines)
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("👑 𝗢𝘄𝗻𝗲𝗿 𝗣𝗮𝗻𝗲𝗹", callback_data="menu_owner")]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer("✅ Keys generated!", show_alert=True)

        # ── Force Sub help ─────────────────────────────────────────────────────
        elif data == "menu_forcesub_help":
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only.", show_alert=True)
                return
            text = (
                f"<b>📢 𝗙𝗼𝗿𝗰𝗲 𝗦𝘂𝗯𝘀𝗰𝗿𝗶𝗯𝗲</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"📌 <b>Enable:</b>\n"
                f"<code>/forcesub @channelusername</code>\n\n"
                f"📌 <b>Disable:</b>\n"
                f"<code>/forcesub off</code>\n\n"
                f"ℹ️ Users must join the channel before using the bot."
                f"</blockquote>"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_owner")]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Set Group help ─────────────────────────────────────────────────────
        elif data == "menu_setgroup_help":
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only.", show_alert=True)
                return
            text = (
                f"<b>👥 𝗦𝗲𝘁 𝗙𝗿𝗲𝗲 𝗚𝗿𝗼𝘂𝗽</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"📌 <b>Set Group:</b>\n"
                f"<code>/setgroup -1001234567890</code>\n\n"
                f"📌 <b>Disable:</b>\n"
                f"<code>/setgroup off</code>\n\n"
                f"ℹ️ Free users can check up to 500 cards in this group."
                f"</blockquote>"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_owner")]])
            await cb.message.edit_text(text, reply_markup=markup, parse_mode=enums.ParseMode.HTML)
            await cb.answer()

        # ── Plan Manager (inline from Owner Panel) ─────────────────────────────
        elif data == "menu_plans":
            if user_id not in config.OWNER_IDS:
                await cb.answer("❌ Owner only.", show_alert=True)
                return

            all_plans = await db.get_all_plans()
            if not all_plans:
                await cb.message.edit_text(
                    "<b>📋 𝗣𝗹𝗮𝗻 𝗠𝗮𝗻𝗮𝗴𝗲𝗿</b>\n"
                    "━━━━━━━━━━━━━━━━━━━━━━\n"
                    "⚠️ No plans configured.\n\n"
                    "Add one:\n<code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards&gt;</code>\n"
                    "Example: <code>/addplan pro 10 2000</code>",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_owner")]]),
                    parse_mode=enums.ParseMode.HTML
                )
                await cb.answer()
                return

            text = (
                "<b>📋 𝗣𝗹𝗮𝗻 𝗠𝗮𝗻𝗮𝗴𝗲𝗿</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n"
                "<blockquote>"
            )
            plan_buttons = []
            for p in all_plans:
                pname = p["plan_name"].upper()
                text += (
                    f"💎 <b>{pname}</b>\n"
                    f"   ⚙️ Workers: <code>{p['max_workers']}</code>  🃏 Cards: <code>{p['max_cards']}</code>\n"
                )
                row = [InlineKeyboardButton(f"✏️ {pname}", callback_data=f"plan_edit_{p['plan_name']}")]
                if p["plan_name"] != "free":
                    row.append(InlineKeyboardButton(f"🗑️ Del", callback_data=f"plan_del_{p['plan_name']}"))
                plan_buttons.append(row)

            text += "</blockquote>\n━━━━━━━━━━━━━━━━━━━━━━\n"
            text += "Add: <code>/addplan &lt;name&gt; &lt;workers&gt; &lt;cards&gt;</code>"

            plan_buttons.append([
                InlineKeyboardButton("➕ Add Plan", callback_data="plan_add_help"),
                InlineKeyboardButton("⬅️ 𝗕𝗮𝗰𝗸", callback_data="menu_owner"),
            ])

            await cb.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(plan_buttons),
                parse_mode=enums.ParseMode.HTML
            )
            await cb.answer()


    @app.on_message(filters.command("id"))
    @notify_owner_on_error
    async def id_cmd(client: Client, msg: Message):
        await msg.reply(
            f"👤 **Your Telegram ID:** `{msg.from_user.id}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("setcmds"))
    @notify_owner_on_error
    async def setcmds_cmd(client: Client, msg: Message):
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("❌ Owner only command.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        try:
            await client.set_bot_commands(BOT_COMMANDS)
            await msg.reply(
                f"✅ **Bot commands registered!**\n"
                f"**{len(BOT_COMMANDS)} commands** set in BotFather.",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
        except Exception as e:
            await msg.reply(f"❌ **Failed:** `{e}`", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("gates"))
    @notify_owner_on_error
    async def gates_cmd(client: Client, msg: Message):
        if not await _has_permission(msg.from_user.id):
            await _admin_denied(msg)
            return

        from gateways.router import get_active_gates
        scraped_count = await db.get_all_gates_count()
        scraped_status = f"✅ {scraped_count} gates" if scraped_count > 0 else "⚠️ None"

        try:
            shopify_data = await db.get_shopify_gates_count()
            shopify_count = shopify_data.get("total", 0)
            shopify_status = f"✅ {shopify_count} stores" if shopify_count > 0 else "⚠️ None"
        except Exception:
            shopify_status = "⚠️ Not initialized"

        stripe_status = f"✅ {len(config.STRIPE_PK_KEYS)} PK keys" if config.STRIPE_PK_KEYS else "⚠️ Not set"
        active_gates = get_active_gates()

        text = (
            f"<b>🔗 𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗚𝗮𝘁𝗲𝘄𝗮𝘆𝘀 𝗦𝘁𝗮𝘁𝘂𝘀</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<blockquote>"
            f"🛒 <b>Shopify</b> ➜ <code>{shopify_status}</code>\n"
            f"🎯 <b>Scraped Stripe</b> ➜ <code>{scraped_status}</code>\n"
            f"🟣 <b>Stripe</b> ➜ <code>{stripe_status}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⚡ <b>Active Gates:</b> <code>{len(active_gates)}</code>\n"
            f"🛡️ <b>VBV Detection:</b> <code>Active</code>\n"
            f"🔄 <b>Auto-Failover:</b> <code>Enabled</code>"
            f"</blockquote>"
        )
        await msg.reply(text, parse_mode=enums.ParseMode.HTML)

    @app.on_message(filters.command("stats"))
    @notify_owner_on_error
    async def stats_cmd(client: Client, msg: Message):
        if not await _has_permission(msg.from_user.id):
            await _admin_denied(msg)
            return
        user_stats = await db.get_user_stats(msg.from_user.id)
        global_stats = await db.get_global_stats()
        text = (
            f"<b>📊 𝗨𝘀𝗲𝗿 𝗦𝘁𝗮𝘁𝘀</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<blockquote>"
            f"📈 <b>Total Checks:</b> <code>{user_stats['total']}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌍 <b>Global Stats</b>\n"
            f"👥 Users: <code>{global_stats['users']}</code>\n"
            f"🔢 Total Checks: <code>{global_stats['total_checks']}</code>\n"
            f"✅ Live Found: <code>{global_stats['live']}</code>\n"
            f"❌ Dead: <code>{global_stats['dead']}</code>"
            f"</blockquote>"
        )
        await msg.reply(text, parse_mode=enums.ParseMode.HTML)

    @app.on_message(filters.command("bin"))
    @notify_owner_on_error
    async def bin_cmd(client: Client, msg: Message):
        if not await _has_permission(msg.from_user.id):
            await _admin_denied(msg)
            return
        parts = msg.text.split()
        if len(parts) < 2:
            await msg.reply("❌ Usage: `/bin 414720`", parse_mode=enums.ParseMode.MARKDOWN)
            return

        bin6 = parts[1][:6]
        if not bin6.isdigit() or len(bin6) < 6:
            await msg.reply("❌ Invalid BIN. Must be 6 digits.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        wait_msg = await msg.reply("🔍 Looking up BIN...", parse_mode=enums.ParseMode.MARKDOWN)
        info = await lookup_bin(bin6)

        if not info:
            await wait_msg.edit_text(f"❌ No info found for BIN `{bin6}`", parse_mode=enums.ParseMode.MARKDOWN)
            return

        await wait_msg.edit_text(format_bin_info(info), parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("fetchproxies"))
    @notify_owner_on_error
    async def fetchproxies_cmd(client: Client, msg: Message):
        """Manually trigger GitHub proxy fetch + test + save. Owner only."""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only command.</b>", parse_mode=enums.ParseMode.HTML)
            return

        wait = await msg.reply(
            "<b>🌐 Fetching proxies from GitHub...</b>\n"
            "<blockquote>⏳ Downloading proxifly/free-proxy-list\n"
            "🧪 Testing against Shopify (80 parallel)\n"
            "⏱ Usually takes 10-15 seconds...</blockquote>",
            parse_mode=enums.ParseMode.HTML
        )


    # ── /storecheck — Shopify Store Health Scanner (REAL CHECKOUT TEST) ─────────
    @app.on_message(filters.command("storecheck"))
    @notify_owner_on_error
    async def store_health_check_cmd(client: Client, msg: Message):
        """
        Owner-only: Tests EACH store with a REAL full checkout flow.
        Working = reached bank (any bank response, even decline)
        Dead    = failed before bank (cart/vault/session error)
        """
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("\U0001f6ab <b>Owner only command.</b>", parse_mode=enums.ParseMode.HTML)
            return

        wait = await msg.reply(
            "\U0001f50d <b>Shopify Store Health Scan</b>\n"
            "<i>Running real checkout test on each store...\n"
            "\u2705 Working = reached bank payment step\n"
            "\u274c Dead = failed before payment (cart/vault/session error)\n"
            "\u23f3 This takes 30-90s for large pools...</i>",
            parse_mode=enums.ParseMode.HTML
        )

        # Load all stores
        try:
            from gateways.shopify_gate import _get_stores
            stores = await _get_stores(force_reload=True)
        except Exception:
            stores = []
        if not stores:
            await wait.edit_text(
                "<b>\u26a0\ufe0f No stores found in database!</b>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        total = len(stores)
        sem = asyncio.Semaphore(20)  # 20 concurrent real checkout tests

        # INFRA error codes = store broken (flow didn't reach bank)
        DEAD_CODES = {
            "cart_error", "cart_exception", "checkout_exception",
            "vault_error", "vault_exception",
            "no_session_token", "no_checkout_id",
            "submit_exception", "poll_timeout",
            "throttled", "store_unavailable", "gql_error", "no_receipt",
        }
        # Product codes = store runs but product config wrong
        PARTIAL_CODES = {"no_delivery", "no_payment", "product_422"}

        async def _test_store_real(store: dict) -> dict:
            """Real test: run full checkout on this store with a test card."""
            url = store.get("base_url", "")
            t0 = _time.monotonic()
            try:
                async with sem:
                    from gateways.shopify_gate import check_shopify_on_store
                    from core.parser import parse_cc
                    test_card = parse_cc("4111111111111111|12|2027|123")
                    result = await asyncio.wait_for(
                        check_shopify_on_store(test_card, store, segment=0),
                        timeout=22.0
                    )
                    ms = int((_time.monotonic() - t0) * 1000)
                    raw = result.raw_code or ""
                    if raw in DEAD_CODES:
                        return {"url": url, "status": "dead",    "ms": ms, "code": raw}
                    elif raw in PARTIAL_CODES:
                        return {"url": url, "status": "partial", "ms": ms, "code": raw}
                    else:
                        return {"url": url, "status": "ok",      "ms": ms, "code": raw}
            except asyncio.TimeoutError:
                return {"url": url, "status": "dead", "ms": 22000, "code": "timeout"}
            except Exception as e:
                return {"url": url, "status": "dead", "ms": 0, "code": str(e)[:30]}

        # Run with progress updates
        done_count = 0
        results_list: list = []

        async def _run_all():
            nonlocal done_count
            tasks = [_test_store_real(s) for s in stores]
            for coro in asyncio.as_completed(tasks):
                r = await coro
                results_list.append(r)
                done_count += 1
                if done_count % 25 == 0:
                    try:
                        pct = int(done_count / total * 100)
                        await wait.edit_text(
                            f"\U0001f50d <b>Scanning... {done_count}/{total} stores ({pct}%)</b>\n"
                            f"<i>Real checkout test running on each store...</i>",
                            parse_mode=enums.ParseMode.HTML
                        )
                    except Exception:
                        pass

        await _run_all()

        ok      = [r for r in results_list if r["status"] == "ok"]
        partial = [r for r in results_list if r["status"] == "partial"]
        dead    = [r for r in results_list if r["status"] == "dead"]

        n_ok, n_partial, n_dead = len(ok), len(partial), len(dead)
        avg_ms = int(sum(r["ms"] for r in ok) / n_ok) if n_ok else 0

        uid = msg.from_user.id
        _dead_store_cache[uid]              = [r["url"] for r in dead]
        _dead_store_cache[f"{uid}_partial"] = [r["url"] for r in partial]

        dead_lines = "\n".join(
            f"  \u274c <code>{r['url'][:42]}</code> <i>[{r['code']}]</i>"
            for r in sorted(dead, key=lambda x: x.get("code",""))[:8]
        )
        if n_dead > 8:
            dead_lines += f"\n  <i>... and {n_dead - 8} more</i>"

        partial_lines = "\n".join(
            f"  \u26a0\ufe0f <code>{r['url'][:42]}</code> <i>[{r['code']}]</i>"
            for r in partial[:4]
        )
        if n_partial > 4:
            partial_lines += f"\n  <i>... and {n_partial - 4} more</i>"

        text = (
            f"<b>\U0001f3ea Shopify Store Health Report</b>\n"
            f"<i>(Real full-checkout test per store)</i>\n"
            f"<blockquote>"
            f"\U0001f4ca <b>Total Tested:</b> <code>{total}</code>\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
            f"\u2705 <b>Working:</b>  <code>{n_ok}</code>  <i>(reached bank step)</i>\n"
            f"\u26a0\ufe0f <b>Partial:</b>  <code>{n_partial}</code>  <i>(cart OK, no delivery/payment)</i>\n"
            f"\u274c <b>Dead:</b>     <code>{n_dead}</code>  <i>(failed before bank)</i>\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
            f"\u26a1 <b>Avg Time:</b> <code>{avg_ms}ms</code>"
            f"</blockquote>"
        )
        if dead_lines:
            text += f"\n\n<b>Dead Stores:</b>\n{dead_lines}"
        if partial_lines:
            text += f"\n\n<b>Partial Stores:</b>\n{partial_lines}"

        buttons = []
        if n_dead > 0:
            buttons.append([InlineKeyboardButton(
                f"\U0001f5d1 Remove {n_dead} Dead Stores",
                callback_data=f"srm_dead:{uid}"
            )])
        if n_partial > 0:
            buttons.append([InlineKeyboardButton(
                f"\u26a0\ufe0f Remove {n_partial} Partial Stores",
                callback_data=f"srm_partial:{uid}"
            )])
        buttons.append([InlineKeyboardButton(
            "\U0001f504 Re-Scan", callback_data=f"srm_rescan:{uid}"
        )])

        await wait.edit_text(
            text,
            parse_mode=enums.ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons) if buttons else None
        )

    # ── Callback: Remove dead stores ──────────────────────────────────────────
    @app.on_callback_query(filters.regex(r"^srm_dead:"))
    @notify_owner_on_error
    async def cb_remove_dead(client: Client, cb: CallbackQuery):
        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("Owner only!", show_alert=True); return
        uid = int(cb.data.split(":")[1])
        urls = _dead_store_cache.get(uid, [])
        if not urls:
            await cb.answer("Cache expired. Run /storecheck again.", show_alert=True); return
        await cb.answer(f"Removing {len(urls)} dead stores...")
        removed = 0
        for url in urls:
            try:
                await db.execute("DELETE FROM shopify_gates WHERE base_url=?", [url])
                removed += 1
            except Exception:
                pass
        try:
            import gateways.shopify_gate as _sg
            _sg._stores_cache = []
            _sg._stores_cache_ts = 0.0
        except Exception:
            pass
        _dead_store_cache.pop(uid, None)
        remain = await db.fetchone("SELECT COUNT(*) as c FROM shopify_gates WHERE is_active=1")
        remain_count = (remain or {}).get("c", "?")
        await cb.edit_message_text(
            f"<b>\u2705 Dead Stores Removed!</b>\n"
            f"<blockquote>"
            f"\U0001f5d1 <b>Removed:</b> <code>{removed}</code> dead stores\n"
            f"\U0001f3ea <b>Remaining Active:</b> <code>{remain_count}</code>\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
            f"<i>Pool cleaned! Run /storecheck to verify.</i>"
            f"</blockquote>",
            parse_mode=enums.ParseMode.HTML
        )

    # ── Callback: Remove partial stores ──────────────────────────────────────
    @app.on_callback_query(filters.regex(r"^srm_partial:"))
    @notify_owner_on_error
    async def cb_remove_partial(client: Client, cb: CallbackQuery):
        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("Owner only!", show_alert=True); return
        uid = int(cb.data.split(":")[1])
        partial_urls = _dead_store_cache.get(f"{uid}_partial", [])
        if not partial_urls:
            await cb.answer("No partial stores cached. Run /storecheck again.", show_alert=True); return
        await cb.answer(f"Removing {len(partial_urls)} partial stores...")
        removed = 0
        for url in partial_urls:
            try:
                await db.execute("DELETE FROM shopify_gates WHERE base_url=?", [url])
                removed += 1
            except Exception:
                pass
        try:
            import gateways.shopify_gate as _sg
            _sg._stores_cache = []
            _sg._stores_cache_ts = 0.0
        except Exception:
            pass
        _dead_store_cache.pop(f"{uid}_partial", None)
        await cb.edit_message_text(
            f"<b>\u2705 Partial Stores Removed!</b>\n"
            f"<blockquote>"
            f"\U0001f5d1 <b>Removed:</b> <code>{removed}</code> partial stores\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
            f"<i>Run /storecheck to verify pool.</i>"
            f"</blockquote>",
            parse_mode=enums.ParseMode.HTML
        )

    # ── Callback: Re-scan stores ──────────────────────────────────────────────
    @app.on_callback_query(filters.regex(r"^srm_rescan:"))
    @notify_owner_on_error
    async def cb_rescan(client: Client, cb: CallbackQuery):
        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("Owner only!", show_alert=True); return
        await cb.answer("Starting re-scan...")
        await cb.edit_message_text(
            "\U0001f50d <b>Re-scanning stores...</b>\n<i>Please wait...</i>",
            parse_mode=enums.ParseMode.HTML
        )
        await store_health_check_cmd(client, cb.message)

    @app.on_message(filters.command("kill"))
    @notify_owner_on_error
    async def kill_all_cmd(client: Client, msg: Message):
        """Owner-only: Kill ALL active mass check sessions across ALL users instantly."""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("\U0001f6ab <b>Owner only command.</b>", parse_mode=enums.ParseMode.HTML)
            return

        from handlers.checker import _active_checks, _stop_events, _active_tasks

        session_count = len(_active_checks)
        if session_count == 0:
            await msg.reply(
                "\u2139\ufe0f <b>No active checking sessions found.</b>\n<i>All clear!</i>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        task_count = 0
        for sess_key in list(_active_checks.keys()):
            _active_checks[sess_key] = False
            ev = _stop_events.get(sess_key)
            if ev:
                ev.set()
            tasks = _active_tasks.get(sess_key, [])
            task_count += sum(1 for t in tasks if not t.done() and t.cancel())

        await msg.reply(
            f"<b>\U0001f6d1 KILL ALL \u2014 Done!</b>\n"
            f"<blockquote>"
            f"\U0001f480 <b>Sessions killed:</b> <code>{session_count}</code>\n"
            f"\u2699\ufe0f <b>Tasks cancelled:</b> <code>{task_count}</code>\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
            f"<i>All users\' checks stopped. Result files will be sent automatically.</i>"
            f"</blockquote>",
            parse_mode=enums.ParseMode.HTML
        )

    # ── /add <country> — Generate random address via API ──────────────────────
    _COUNTRY_NAT_MAP = {
        # English names → API nat code + display name
        "usa": ("US", "United States"), "us": ("US", "United States"),
        "america": ("US", "United States"), "united states": ("US", "United States"),
        "canada": ("CA", "Canada"), "ca": ("CA", "Canada"),
        "uk": ("GB", "United Kingdom"), "gb": ("GB", "United Kingdom"),
        "england": ("GB", "United Kingdom"), "britain": ("GB", "United Kingdom"),
        "australia": ("AU", "Australia"), "au": ("AU", "Australia"),
        "germany": ("DE", "Germany"), "de": ("DE", "Germany"),
        "france": ("FR", "France"), "fr": ("FR", "France"),
        "india": ("IN", "India"), "in": ("IN", "India"),
        "brazil": ("BR", "Brazil"), "br": ("BR", "Brazil"),
        "spain": ("ES", "Spain"), "es": ("ES", "Spain"),
        "netherlands": ("NL", "Netherlands"), "nl": ("NL", "Netherlands"),
        "denmark": ("DK", "Denmark"), "dk": ("DK", "Denmark"),
        "finland": ("FI", "Finland"), "fi": ("FI", "Finland"),
        "norway": ("NO", "Norway"), "no": ("NO", "Norway"),
        "switzerland": ("CH", "Switzerland"), "ch": ("CH", "Switzerland"),
        "mexico": ("MX", "Mexico"), "mx": ("MX", "Mexico"),
        "new zealand": ("NZ", "New Zealand"), "nz": ("NZ", "New Zealand"),
        "turkey": ("TR", "Turkey"), "tr": ("TR", "Turkey"),
        "iran": ("IR", "Iran"), "ir": ("IR", "Iran"),
        "ukraine": ("UA", "Ukraine"), "ua": ("UA", "Ukraine"),
        "serbia": ("RS", "Serbia"), "rs": ("RS", "Serbia"),
    }

    @app.on_message(filters.command("add"))
    @notify_owner_on_error
    async def add_address_cmd(client: Client, msg: Message):
        """
        Generate a random address for the given country.
        Usage: /add usa  /add canada  /add uk  /add australia
        """
        import aiohttp
        from aiohttp import ClientTimeout

        parts = msg.text.strip().split(None, 1)
        country_input = parts[1].strip().lower() if len(parts) > 1 else ""

        if not country_input:
            supported = "\n".join([
                "🇺🇸 /add usa", "🇨🇦 /add canada", "🇬🇧 /add uk",
                "🇦🇺 /add australia", "🇩🇪 /add germany", "🇫🇷 /add france",
                "🇮🇳 /add india", "🇧🇷 /add brazil", "🇳🇱 /add netherlands",
                "🇳🇿 /add newzealand", "🇲🇽 /add mexico", "🇹🇷 /add turkey",
            ])
            await msg.reply(
                f"<b>🌍 Address Generator</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<b>Usage:</b> <code>/add [country]</code>\n\n"
                f"<b>Supported countries:</b>\n{supported}",
                parse_mode=enums.ParseMode.HTML,
            )
            return

        nat_info = _COUNTRY_NAT_MAP.get(country_input)
        if not nat_info:
            await msg.reply(
                f"❌ <b>Country not found:</b> <code>{country_input}</code>\n"
                f"Try: <code>/add usa</code>, <code>/add canada</code>, <code>/add uk</code>",
                parse_mode=enums.ParseMode.HTML,
            )
            return

        nat_code, country_name = nat_info

        wait_msg = await msg.reply(
            f"⏳ Fetching <b>{country_name}</b> address...",
            parse_mode=enums.ParseMode.HTML,
        )

        _API_URL = "https://key-blossom-hub.lovable.app/api/v1/randomuser"
        _API_KEY  = "ah_0a48a21f33ca413ab06e077e21e56cf5"

        user = None
        # Fetch enough to find a matching country (nat= param is unreliable)
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    _API_URL,
                    params={"results": "500", "api_key": _API_KEY},
                    timeout=ClientTimeout(total=20),
                    ssl=False,
                ) as r:
                    if r.status == 200:
                        data = await r.json(content_type=None)
                        for u in data.get("results", []):
                            loc = u.get("location", {})
                            if loc.get("country", "") == country_name:
                                user = u
                                break
        except Exception as e:
            await wait_msg.edit_text(f"❌ API Error: <code>{str(e)[:80]}</code>", parse_mode=enums.ParseMode.HTML)
            return

        if not user:
            await wait_msg.edit_text(
                f"❌ <b>No {country_name} user found in API response.</b>\n"
                f"Try again — API returns random data each time.",
                parse_mode=enums.ParseMode.HTML,
            )
            return

        # Extract all fields
        loc     = user.get("location", {})
        name    = user.get("name", {})
        login   = user.get("login", {})
        dob     = user.get("dob", {})
        reg     = user.get("registered", {})
        pic     = user.get("picture", {})
        street  = loc.get("street", {})
        coords  = loc.get("coordinates", {})
        tz      = loc.get("timezone", {})

        full_name = f"{name.get('first','')} {name.get('last','')}".strip()
        address1  = f"{street.get('number','')} {street.get('name','')}".strip()

        # Format DOB
        dob_date = dob.get("date", "")
        dob_str  = dob_date[:10] if dob_date else "N/A"
        age      = dob.get("age", "")

        reply = (
            f"<b>🌍 {country_name} Address</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>Name:</b> <code>{full_name}</code>\n"
            f"🚻 <b>Gender:</b> <code>{user.get('gender','').capitalize()}</code>\n"
            f"🎂 <b>DOB:</b> <code>{dob_str}</code> (Age: {age})\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📮 <b>Address:</b> <code>{address1}</code>\n"
            f"🏙️ <b>City:</b> <code>{loc.get('city','')}</code>\n"
            f"🗺️ <b>State/Province:</b> <code>{loc.get('state','')}</code>\n"
            f"🌐 <b>Country:</b> <code>{loc.get('country','')}</code>\n"
            f"📬 <b>Postcode/ZIP:</b> <code>{loc.get('postcode','')}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📧 <b>Email:</b> <code>{user.get('email','')}</code>\n"
            f"📱 <b>Phone:</b> <code>{user.get('phone','')}</code>\n"
            f"📲 <b>Cell:</b> <code>{user.get('cell','')}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🔑 <b>Username:</b> <code>{login.get('username','')}</code>\n"
            f"🔐 <b>Password:</b> <code>{login.get('password','')}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🪙 <b>ID Type:</b> <code>{user.get('id',{}).get('name','')}</code>\n"
            f"🔢 <b>ID Value:</b> <code>{user.get('id',{}).get('value','N/A')}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📅 <b>Registered:</b> <code>{reg.get('date','')[:10]}</code>\n"
            f"🌐 <b>Timezone:</b> <code>{tz.get('description','')}</code> ({tz.get('offset','')})\n"
            f"📍 <b>Coords:</b> <code>{coords.get('latitude','')}, {coords.get('longitude','')}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🖼 <b>Photo:</b> <a href=\"{pic.get('large','')}\">View Profile Picture</a>"
        )

        await wait_msg.edit_text(reply, parse_mode=enums.ParseMode.HTML,
                                 disable_web_page_preview=True)

