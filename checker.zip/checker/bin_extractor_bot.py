import os
import re
import asyncio
from pyrogram import Client, filters, enums
from pyrogram.types import Message

# ==================== CONFIGURATION ====================
# Put your dedicated bot token here
BOT_TOKEN = "7390006340:AAGhtpuwmvIWTlW-yLOI_WYsUq0rMu3bt9M"

# Default API credentials (extracted from your .env for plug-and-play)
API_ID = 27829715
API_HASH = "72e38250de2b0ae7dd9eb467ffa35c17"

# Target BINs to extract (Change or add more here)
TARGET_BINS = [
    "601100",
    # Add your targeted BINs
]
# =======================================================

# Using a completely separate session name to avoid conflicts with your main bot
app = Client(
    name="bin_extractor_session",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

# Card matching pattern: number|month|year|cvv
CC_PATTERN = re.compile(r'(\d{15,16})[|](\d{2})[|](\d{2,4})[|](\d{3,4})')

@app.on_message(filters.command("start"))
async def start_cmd(client: Client, message: Message):
    target_list = ", ".join(TARGET_BINS)
    await message.reply(
        "👋 <b>Welcome to Standalone BIN Extractor Bot!</b>\n\n"
        "📁 Send me any <code>.txt</code> file containing card logs.\n"
        f"🎯 I will extract cards starting with: <code>{target_list}</code>\n\n"
        "<i>(To change target BINs, edit the list at the top of the script file)</i>",
        parse_mode=enums.ParseMode.HTML
    )

@app.on_message(filters.document)
async def process_document(client: Client, message: Message):
    doc = message.document
    
    # Verify it is a text file
    if not (doc.file_name or "").lower().endswith(".txt"):
        await message.reply("❌ Please upload a valid <code>.txt</code> file.")
        return

    # Check for unconfigured token
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        await message.reply("⚠️ Please configure the <code>BOT_TOKEN</code> inside the script first!")
        return

    status = await message.reply("📥 <b>Downloading file...</b>", parse_mode=enums.ParseMode.HTML)
    
    downloaded_path = None
    output_path = None
    
    try:
        # Download file (Pyrogram handles large files up to 2GB easily)
        downloaded_path = await message.download()
        
        await status.edit_text("🔍 <b>Processing and extracting BINs...</b>", parse_mode=enums.ParseMode.HTML)
        
        matched_cards = []
        
        # Read and parse line by line (highly memory efficient for large files)
        with open(downloaded_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line_str = line.strip()
                match = CC_PATTERN.search(line_str)
                if match:
                    card_num = match.group(1)
                    # Check if card starts with target BINs
                    for target_bin in TARGET_BINS:
                        if card_num.startswith(target_bin):
                            full_card = f"{match.group(1)}|{match.group(2)}|{match.group(3)}|{match.group(4)}"
                            matched_cards.append(full_card)
                            break

        total_extracted = len(matched_cards)
        
        if total_extracted == 0:
            await status.edit_text("⚠️ <b>No cards found matching your target BINs.</b>", parse_mode=enums.ParseMode.HTML)
            return

        # Write output file
        output_path = f"extracted_{doc.file_name}"
        with open(output_path, "w", encoding="utf-8") as out:
            out.write("\n".join(matched_cards) + "\n")

        await status.edit_text("📤 <b>Uploading filtered file...</b>", parse_mode=enums.ParseMode.HTML)
        
        caption = (
            f"🎯 <b>BIN Extraction Complete!</b>\n\n"
            f"📄 <b>Source File:</b> <code>{doc.file_name}</code>\n"
            f"📋 <b>Target BINs:</b> <code>{', '.join(TARGET_BINS)}</code>\n"
            f"💳 <b>Extracted Cards:</b> <code>{total_extracted}</code>"
        )
        
        await message.reply_document(
            document=output_path,
            caption=caption,
            parse_mode=enums.ParseMode.HTML
        )
        await status.delete()

    except Exception as e:
        await message.reply(f"❌ <b>Error occurred:</b> <code>{e}</code>", parse_mode=enums.ParseMode.HTML)
    
    finally:
        # Clean up files from local disk
        if downloaded_path and os.path.exists(downloaded_path):
            try: os.remove(downloaded_path)
            except: pass
        if output_path and os.path.exists(output_path):
            try: os.remove(output_path)
            except: pass

if __name__ == "__main__":
    print("🚀 Standalone BIN Extractor Bot is starting...")
    app.run()
