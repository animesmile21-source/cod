import sys, asyncio
sys.stdout.reconfigure(encoding='utf-8')
import database.db as db

async def check():
    await db.init_db()
    count = await db.get_shopify_gates_count()
    print("Shopify gates in DB:", count)
    gates = await db.get_active_shopify_gates(limit=5)
    print("Sample gates:")
    for g in gates:
        print(" #" + str(g["id"]) + " " + g["base_url"] + " | $" + str(g["price"]))

asyncio.run(check())
