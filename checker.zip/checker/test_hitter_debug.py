"""
Debug: Test Stripe Hitter manually with live keys.
Run: python test_hitter_debug.py
Then enter your pk_live and pi_secret when prompted.
"""
import asyncio
import sys
import aiohttp

sys.path.insert(0, '.')
from gateways.stripe_gate import STRIPE_JS_HEADERS, TIMEOUT

async def test_create_pm(pk: str, card_num: str, exp_month: str, exp_year: str, cvv: str):
    print("\n[1] Creating PaymentMethod...")
    headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk}",
    }
    data = {
        "type": "card",
        "card[number]": card_num,
        "card[exp_month]": exp_month,
        "card[exp_year]": exp_year,
        "card[cvc]": cvv,
        "billing_details[name]": "John Doe",
        "billing_details[address][country]": "US",
        "billing_details[address][postal_code]": "10001",
    }
    async with aiohttp.ClientSession(timeout=TIMEOUT) as s:
        async with s.post(
            "https://api.stripe.com/v1/payment_methods",
            data=data, headers=headers, ssl=False
        ) as r:
            resp = await r.json(content_type=None)
    
    pm_id = resp.get("id", "")
    if pm_id:
        print(f"  -> PM Created: {pm_id}")
    else:
        err = resp.get("error", {})
        print(f"  -> PM FAILED: {err.get('message', str(resp)[:200])}")
        print(f"     Code: {err.get('code')} | Decline: {err.get('decline_code')}")
    return resp


async def test_confirm_pi(pk: str, pi_secret: str, pm_id: str):
    pi_id = pi_secret.split("_secret_")[0]
    is_setup = pi_secret.startswith("seti_")
    
    if is_setup:
        url = f"https://api.stripe.com/v1/setup_intents/{pi_id}/confirm"
        print(f"\n[2] Confirming SetupIntent: {pi_id[:30]}...")
    else:
        url = f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm"
        print(f"\n[2] Confirming PaymentIntent: {pi_id[:30]}...")

    headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk}",
    }
    data = {
        "client_secret": pi_secret,
        "payment_method": pm_id,
        "return_url": "https://stripe.com/return",
    }

    async with aiohttp.ClientSession(timeout=TIMEOUT) as s:
        async with s.post(url, data=data, headers=headers, ssl=False) as r:
            resp = await r.json(content_type=None)

    # Print full response
    status = resp.get("status", "")
    print(f"  -> HTTP Response received")
    print(f"  -> PI Status: {status}")
    
    if "error" in resp:
        err = resp["error"]
        print(f"  -> ERROR:")
        print(f"     type:         {err.get('type')}")
        print(f"     code:         {err.get('code')}")
        print(f"     decline_code: {err.get('decline_code')}")
        print(f"     message:      {err.get('message')}")
    elif status == "succeeded":
        amt = resp.get("amount", 0) / 100
        print(f"  -> SUCCESS! Charged ${amt:.2f}")
    elif status == "requires_action":
        action = resp.get("next_action", {})
        print(f"  -> 3DS Required: {action.get('type')}")
    elif status == "requires_payment_method":
        lpe = resp.get("last_payment_error", {})
        print(f"  -> Card Declined: {lpe.get('message')} | code: {lpe.get('decline_code')}")
    else:
        print(f"  -> Unknown status: {status}")
        print(f"     Full response: {str(resp)[:300]}")
    
    return resp


async def main():
    print("=" * 55)
    print("  Stripe Hitter Debug Tool")
    print("=" * 55)
    
    pk = input("\nEnter pk_live_... : ").strip()
    if not pk.startswith("pk_"):
        print("ERROR: Must start with pk_")
        return

    pi_secret = input("Enter pi_xxx_secret_xxx (or seti_xxx_secret_xxx) : ").strip()
    if "_secret_" not in pi_secret:
        print("ERROR: Not a valid client_secret format")
        return

    print("\nEnter a test card (or press Enter for default test card):")
    card = input("Card number [4242424242424242]: ").strip() or "4242424242424242"
    month = input("Exp month [12]: ").strip() or "12"
    year = input("Exp year [2026]: ").strip() or "2026"
    cvv = input("CVV [123]: ").strip() or "123"

    print("\n" + "=" * 55)
    
    # Step 1: Create PM
    pm_resp = await test_create_pm(pk, card, month, year, cvv)
    pm_id = pm_resp.get("id", "")
    
    if not pm_id:
        print("\n[!] PM creation failed - cannot proceed to confirm")
        return

    # Step 2: Confirm PI
    await test_confirm_pi(pk, pi_secret, pm_id)
    
    print("\n" + "=" * 55)
    print("Debug complete.")


asyncio.run(main())
