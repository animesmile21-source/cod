﻿"""
Scrape PublicWWW.com for Shopify stores
PublicWWW = source code search engine, finds sites with Shopify signatures
Free tier gives ~100-200 results per search
"""
import asyncio, sys, aiohttp, re
from urllib.parse import urlencode, unquote, urlparse
sys.path.insert(0, r"c:\Users\rdx27\Desktop\all bots\checker")

OUTPUT = r"c:\Users\rdx27\Desktop\all bots\checker\shopify_sites_found.txt"

SEARCHES = [
    '"cdn.shopify.com/s/files"',
    '"myshopify.com"',
    '"Shopify.theme.handle"',
    '"shopify_features"',
    '"ShopifyAnalytics"',
    '"Shopify.shop"',
]

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36"

async def scrape_publicwww(session, query, seen):
    found = []
    url = f"https://publicwww.com/websites/{urlencode({'q': query})[2:]}/"
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=20),
                               headers={"User-Agent": UA, "Accept": "text/html,*/*",
                                        "Accept-Language": "en-US,en;q=0.9"},
                               ssl=False, allow_redirects=True) as r:
            if r.status != 200:
                print(f"  PublicWWW status {r.status} for {query[:30]}")
                return []
            html = await r.text(errors="ignore")
            
            # Extract URLs from PublicWWW results
            # Format: <a href="/websites/domain.com/">domain.com</a>
            for m in re.finditer(r'href="/websites/([^/"]+\.[^/"]+)/"', html):
                domain = m.group(1).strip()
                if not domain or "publicwww" in domain: continue
                base = f"https://{domain}"
                if base not in seen:
                    seen.add(base)
                    found.append(base)
            
            # Also extract from result snippets
            for m in re.finditer(r'https?://([\w\-\.]+\.myshopify\.com)', html, re.I):
                base = f"https://{m.group(1).lower()}"
                if base not in seen and ".myshopify.com" in base:
                    seen.add(base)
                    found.append(base)
                    
            print(f"  PublicWWW '{query[:40]}' -> {len(found)} results | page size: {len(html)}")
    except Exception as e:
        print(f"  PublicWWW error: {e}")
    return found

async def scrape_builtwith(session, seen):
    """BuiltWith free API - Shopify technology list"""
    found = []
    try:
        # BuiltWith free lookup for Shopify
        url = "https://api.builtwith.com/free1/api.json?" + urlencode({
            "KEY": "free", "LOOKUP": "shopify.com"
        })
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15),
                               headers={"User-Agent": UA}, ssl=False) as r:
            if r.status == 200:
                import json
                data = await r.json(content_type=None)
                print(f"  BuiltWith response: {str(data)[:200]}")
    except Exception as e:
        print(f"  BuiltWith error: {e}")
    return found

async def scrape_storeleads(session, seen):
    """store-leads.com - Shopify store database"""
    found = []
    urls_to_try = [
        "https://store-leads.com/tech/shopify",
        "https://store-leads.com/api/v1/stores?platform=shopify&limit=100",
    ]
    for url in urls_to_try:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15),
                                   headers={"User-Agent": UA, "Accept": "application/json,text/html,*/*"},
                                   ssl=False, allow_redirects=True) as r:
                body = await r.text(errors="ignore")
                print(f"  store-leads [{url[-40:]}] status={r.status} size={len(body)}")
                
                # Try to extract domains
                for m in re.finditer(r'([\w\-]+\.myshopify\.com)', body, re.I):
                    base = f"https://{m.group(1).lower()}"
                    if base not in seen:
                        seen.add(base)
                        found.append(base)
                        
                for m in re.finditer(r'"domain"\s*:\s*"(https?://[^"]+)"', body):
                    base = m.group(1).rstrip("/")
                    if base not in seen:
                        seen.add(base)
                        found.append(base)
        except Exception as e:
            print(f"  store-leads error: {e}")
        await asyncio.sleep(2)
    return found

async def main():
    seen = set()
    # Load already found URLs
    try:
        with open(OUTPUT, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("http"):
                    seen.add(line)
        print(f"Loaded {len(seen)} existing URLs from file")
    except: pass

    all_new = []
    
    connector = aiohttp.TCPConnector(ssl=False, limit=3)
    async with aiohttp.ClientSession(connector=connector) as session:
        
        print("\n[1] Trying PublicWWW.com...")
        for q in SEARCHES:
            new = await scrape_publicwww(session, q, seen)
            all_new.extend(new)
            await asyncio.sleep(3)
        
        print("\n[2] Trying store-leads.com...")
        new = await scrape_storeleads(session, seen)
        all_new.extend(new)
        
        print("\n[3] Trying BuiltWith...")
        await scrape_builtwith(session, seen)

    # Append new URLs to file
    if all_new:
        with open(OUTPUT, "a", encoding="utf-8") as f:
            for u in all_new:
                f.write(u + "\n")
    
    print(f"\n{'='*50}")
    print(f"New URLs found: {len(all_new)}")
    print(f"Total in file: {len(seen) + len(all_new)}")
    for u in all_new[:20]:
        print(f"  {u}")

asyncio.run(main())
