"""
scan_shpoify.py — Bulk scan shpoify.txt and add ALL working stores to DB
Usage: python scan_shpoify.py [workers]
Default workers: 25
"""
import asyncio, sys, os, time
from datetime import datetime

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

INPUT_FILE   = "shpoify.txt"
RESULTS_FILE = "shpoify_scan_results.txt"
WORKERS      = int(sys.argv[1]) if len(sys.argv) > 1 else 25
OWNER_ID     = 0

# Colors
G = "\033[92m"; R = "\033[91m"; Y = "\033[93m"; C = "\033[96m"; B = "\033[1m"; X = "\033[0m"

# Load URLs
with open(INPUT_FILE, "r", encoding="utf-8") as f:
    raw_urls = [l.strip() for l in f if l.strip() and l.strip().startswith("http")]

# Remove already-in-DB URLs
print(f"{C}Loading DB to skip already-added stores...{X}")
import sqlite3
conn = sqlite3.connect("database/checker.db")
cur  = conn.cursor()
cur.execute("SELECT base_url FROM shopify_gates")
existing_db = {r[0].rstrip("/").lower() for r in cur.fetchall()}
conn.close()

urls = [u for u in raw_urls if u.rstrip("/").lower() not in existing_db]
skipped_already = len(raw_urls) - len(urls)

print(f"\n{C}{'='*60}{X}")
print(f"{B}  Shopify Bulk Scanner — shpoify.txt{X}")
print(f"{C}{'='*60}{X}")
print(f"  Total URLs   : {len(raw_urls)}")
print(f"  Already in DB: {skipped_already}")
print(f"  To scan      : {len(urls)}")
print(f"  Workers      : {WORKERS}")
print(f"{C}{'='*60}{X}\n")

if not urls:
    print(f"{Y}All URLs already in DB!{X}")
    sys.exit(0)

async def main():
    import config
    import database.db as db
    await db.init_db()

    from core.proxy_manager import refresh_proxy_pool
    await refresh_proxy_pool()

    from handlers.shopify_handler import _scan_shopify_site

    total      = len(urls)
    working    = []
    failed     = []
    done       = 0
    start_time = time.monotonic()
    sem        = asyncio.Semaphore(WORKERS)
    lock       = asyncio.Lock()

    async def scan_one(url: str):
        nonlocal done
        async with sem:
            try:
                res = await asyncio.wait_for(_scan_shopify_site(url), timeout=35.0)
            except asyncio.TimeoutError:
                res = {"status": "FAILED", "url": url, "reason": "Timeout"}
            except Exception as e:
                res = {"status": "FAILED", "url": url, "reason": str(e)[:80]}

            async with lock:
                done    += 1
                elapsed  = time.monotonic() - start_time
                rate     = done / elapsed if elapsed > 0 else 0.1
                eta      = (total - done) / rate
                eta_str  = f"{int(eta//60)}m{int(eta%60)}s"
                pct      = int(done / total * 100)
                bar      = "█" * int(pct/5) + "░" * (20 - int(pct/5))

                if res.get("status") == "WORKING":
                    try:
                        gate_id = await db.add_shopify_gate(
                            base_url      = res["url"],
                            variant_id    = res.get("variant_id", 0),
                            price         = res.get("price", "0"),
                            product_title = res.get("product_title", ""),
                            shop_domain   = res.get("shop_domain", ""),
                            shop_id       = res.get("shop_id", ""),
                            currency      = res.get("currency", "USD"),
                            checkout_type = res.get("checkout_type", "one-page"),
                            added_by      = OWNER_ID,
                            scan_data     = res.get("scan_data", {}),
                        )
                        try:
                            from gateways.shopify_gate import invalidate_stores_cache
                            invalidate_stores_cache()
                        except Exception:
                            pass
                        working.append({"gate_id": gate_id, **res})
                        print(f"\n  {G}✅ ADDED #{gate_id} | {res['url'][:55]} | ${res.get('price','?')}{X}")
                    except Exception as e:
                        working.append({"gate_id": "?", **res})
                        print(f"\n  {Y}✅ WORKING (DB err: {e}) | {res['url'][:55]}{X}")
                else:
                    failed.append({"url": url, "reason": res.get("reason", "?")[:60]})

                print(
                    f"\r  [{bar}] {pct:3d}% | {done}/{total} | "
                    f"{G}✅{len(working)}{X} {R}❌{len(failed)}{X} | ETA:{eta_str}   ",
                    end="", flush=True
                )

    await asyncio.gather(*[scan_one(url) for url in urls])
    print()  # newline

    # Summary
    elapsed_total = time.monotonic() - start_time
    print(f"\n{C}{'='*60}{X}")
    print(f"{B}  ✅ SCAN COMPLETE{X}")
    print(f"{C}{'='*60}{X}")
    print(f"  Scanned  : {total}")
    print(f"  Working  : {G}{len(working)}{X}")
    print(f"  Failed   : {R}{len(failed)}{X}")
    print(f"  Time     : {int(elapsed_total//60)}m {int(elapsed_total%60)}s")
    print(f"{C}{'='*60}{X}")

    if working:
        print(f"\n{G}  Working Gates:{X}")
        for w in working:
            print(f"    #{w.get('gate_id','?')} | {w['url']} | ${w.get('price','?')} | {w.get('checkout_type','')}")

    # Save report
    with open(RESULTS_FILE, "w", encoding="utf-8") as rf:
        rf.write(f"SCAN REPORT — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        rf.write(f"Input: {INPUT_FILE} | Scanned: {total} | Working: {len(working)} | Failed: {len(failed)}\n")
        rf.write("=" * 70 + "\n\n")
        rf.write(f"WORKING ({len(working)})\n" + "-"*70 + "\n")
        for w in working:
            rf.write(f"#{w.get('gate_id','?')} | {w['url']} | ${w.get('price','?')} | {w.get('checkout_type','')}\n")
        rf.write(f"\nFAILED ({len(failed)})\n" + "-"*70 + "\n")
        for fd in failed:
            rf.write(f"x {fd['url']}  ->  {fd['reason']}\n")

    print(f"\n  {C}Report: {RESULTS_FILE}{X}")


if __name__ == "__main__":
    asyncio.run(main())
