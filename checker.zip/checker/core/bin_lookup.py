"""
core/bin_lookup.py — BIN (Bank Identification Number) lookup
Multi-API fallback: binlist.net → bins.antipublic.cc → bincodes.com → local detection
Handles RuPay, UnionPay, Elo and other non-standard BINs.
"""
import asyncio
import aiohttp
import aiosqlite
import json
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class BinInfo:
    bin: str
    scheme: str         # visa / mastercard / amex / rupay etc.
    type: str           # debit / credit
    brand: str          # Visa / Classic / Gold etc.
    prepaid: bool
    country_name: str
    country_code: str
    country_flag: str
    bank_name: str
    vbv: bool           # True if VBV/3DS enrolled (based on BIN data)

    def flag_emoji(self) -> str:
        """Convert ISO country code to flag emoji."""
        if not self.country_code or len(self.country_code) != 2:
            return "🌐"
        # Regional Indicator Symbol Letters start at U+1F1E6 (for 'A')
        # U+1F1E6=A, U+1F1E7=B ... U+1F1EE=I, U+1F1F3=N -> IN = 🇮🇳
        return "".join(
            chr(0x1F1E6 + ord(c) - ord("A")) for c in self.country_code.upper()
        )


_CACHE: dict[str, Optional[BinInfo]] = {}
_DB_PATH = "database/checker.db"


# ── Local BIN prefix detection (RuPay, UnionPay, Elo etc.) ───────────────────
# Checked BEFORE API calls — avoids wrong data from binlist for Indian BINs
_LOCAL_BIN_PREFIXES = [
    # RuPay (India) — must be before Discover/Maestro as ranges overlap
    # Full RuPay ranges: 508xxx-509xxx, 606xxx-608xxx, 652xxx-654xxx, 817xxx
    (
        ("508", "509", "606", "607", "608",
         "652", "653", "654", "655", "817"),
        "RuPay", "India", "IN", "RuPay",
    ),
    # UnionPay (China) — 62x
    (("62",), "UnionPay", "China", "CN", "UnionPay"),
    # Amex
    (("34", "37"), "Amex", "Unknown", "", "American Express"),
    # JCB
    (("35",), "JCB", "Japan", "JP", "JCB"),
    # Diners
    (("300", "301", "302", "303", "304", "305", "36", "38"), "Diners", "Unknown", "", "Diners Club"),
    # Discover (non-RuPay 6x ranges)
    (("6011", "644", "645", "646", "647", "648", "649"), "Discover", "Unknown", "", "Discover"),
    # Maestro
    (("5018", "5020", "5038", "6304", "6759", "6761", "6762", "6763"), "Maestro", "Unknown", "", "Maestro"),
    # Visa (must be before Mastercard)
    (("4",), "Visa", "Unknown", "", "Visa"),
    # Mastercard
    (("51", "52", "53", "54", "55", "22", "23", "24", "25", "26", "27"), "Mastercard", "Unknown", "", "Mastercard"),
]


def _detect_local(bin6: str) -> Optional[dict]:
    """Detect card network from BIN prefix locally."""
    for prefixes, scheme, country_name, country_code, brand in _LOCAL_BIN_PREFIXES:
        for prefix in prefixes:
            if bin6.startswith(prefix):
                return {
                    "scheme": scheme,
                    "type": "Credit",
                    "brand": brand,
                    "country_name": country_name,
                    "country_code": country_code,
                    "bank_name": "Unknown",
                    "prepaid": False,
                }
    return None


async def _ensure_table(db: aiosqlite.Connection):
    await db.execute("""
        CREATE TABLE IF NOT EXISTS bin_cache (
            bin TEXT PRIMARY KEY,
            data TEXT,
            cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    await db.commit()


async def _get_from_db(bin6: str) -> Optional[BinInfo]:
    try:
        async with aiosqlite.connect(_DB_PATH) as db:
            await _ensure_table(db)
            async with db.execute(
                "SELECT data FROM bin_cache WHERE bin = ?", (bin6,)
            ) as cur:
                row = await cur.fetchone()
                if row:
                    d = json.loads(row[0])
                    return BinInfo(**d) if d else None
    except Exception:
        pass
    return None


async def _save_to_db(bin6: str, info: Optional[BinInfo]):
    try:
        async with aiosqlite.connect(_DB_PATH) as db:
            await _ensure_table(db)
            data = json.dumps(asdict(info)) if info else json.dumps(None)
            await db.execute(
                "INSERT OR REPLACE INTO bin_cache (bin, data) VALUES (?, ?)",
                (bin6, data)
            )
            await db.commit()
    except Exception:
        pass


def _make_bin_info(bin6: str, d: dict) -> BinInfo:
    """Build BinInfo from parsed dict."""
    scheme_raw = d.get("scheme") or d.get("brand") or "Unknown"
    scheme = scheme_raw.capitalize()  # visa→Visa, VISA→Visa, mastercard→Mastercard
    vbv    = scheme.lower() in ("visa", "mastercard", "amex", "rupay")
    # Normalize type: DEBIT→Debit, CREDIT→Credit, CLASSIC→Credit
    type_raw = (d.get("type") or "Unknown").capitalize()
    if type_raw.lower() in ("classic", "standard", "gold", "platinum", "signature"):
        type_raw = "Credit"   # level names → treat as Credit
    return BinInfo(
        bin=bin6,
        scheme=scheme,
        type=type_raw,
        brand=d.get("brand") or scheme,
        prepaid=bool(d.get("prepaid", False)),
        country_name=(d.get("country_name") or "").title() or "Unknown",
        country_code=d.get("country_code") or "",
        country_flag=d.get("country_flag") or "",  # flag_emoji() auto-generates from country_code
        bank_name=d.get("bank_name") or "Unknown",
        vbv=vbv,
    )


async def _lookup_binlist(session: aiohttp.ClientSession, bin6: str) -> Optional[dict]:
    """Try binlist.net API."""
    try:
        async with session.get(
            f"https://lookup.binlist.net/{bin6}",
            timeout=aiohttp.ClientTimeout(total=6),
            headers={"Accept-Version": "3", "User-Agent": "Mozilla/5.0"},
        ) as resp:
            if resp.status != 200:
                return None
            data = await resp.json(content_type=None)

            # binlist returns empty objects when BIN unknown — skip if no real data
            scheme = data.get("scheme", "")
            country = data.get("country", {})
            bank    = data.get("bank", {})
            if not scheme and not country.get("name") and not bank.get("name"):
                return None   # empty response — RuPay / unknown BIN

            return {
                "scheme":       data.get("scheme", ""),
                "type":         data.get("type", ""),
                "brand":        data.get("brand", ""),
                "prepaid":      data.get("prepaid", False),
                "country_name": country.get("name", ""),
                "country_code": country.get("alpha2", ""),
                "country_flag": country.get("emoji", ""),
                "bank_name":    bank.get("name", ""),
            }
    except Exception:
        return None


async def _lookup_antipublic(session: aiohttp.ClientSession, bin6: str) -> Optional[dict]:
    """Try bins.antipublic.cc API."""
    try:
        async with session.get(
            f"https://bins.antipublic.cc/bins/{bin6}",
            timeout=aiohttp.ClientTimeout(total=6),
            headers={"User-Agent": "Mozilla/5.0"},
        ) as resp:
            if resp.status != 200:
                return None
            raw = await resp.read()
            data = json.loads(raw.decode("utf-8", errors="replace"))

            brand        = data.get("brand", "") or data.get("scheme", "")
            country_code = data.get("country", "") or data.get("country_code", "")
            # antipublic has no 'scheme' field, brand IS the scheme (VISA / MASTERCARD)
            scheme = brand
            # antipublic returns UPPERCASE type (DEBIT/CREDIT) — normalize
            raw_type = data.get("type", "") or data.get("level", "")

            return {
                "scheme":       scheme,
                "type":         raw_type,
                "brand":        brand,
                "prepaid":      data.get("prepaid", False),
                "country_name": data.get("country_name", "") or data.get("country", ""),
                "country_code": country_code,
                "country_flag": data.get("country_flag", ""),  # ← USE API FLAG
                "bank_name":    data.get("bank", "") or data.get("bank_name", ""),
            }
    except Exception:
        return None


async def _lookup_bincodes(session: aiohttp.ClientSession, bin6: str) -> Optional[dict]:
    """Try bincodes.com API (free, no key needed)."""
    try:
        async with session.get(
            f"https://bincodes.com/api/bin/?api_key=free&bin={bin6}",
            timeout=aiohttp.ClientTimeout(total=6),
            headers={"User-Agent": "Mozilla/5.0"},
        ) as resp:
            if resp.status != 200:
                return None
            data = await resp.json(content_type=None)
            if not data or data.get("success") == "false" or data.get("code") == "error":
                return None

            return {
                "scheme":       data.get("scheme", "") or data.get("brand", ""),
                "type":         data.get("type", ""),
                "brand":        data.get("brand", ""),
                "prepaid":      False,
                "country_name": data.get("country", ""),
                "country_code": data.get("iso_a2", "") or data.get("country_code", ""),
                "country_flag": "",
                "bank_name":    data.get("bank", "") or data.get("bank_name", ""),
            }
    except Exception:
        return None


async def lookup_bin(bin6: str) -> Optional[BinInfo]:
    """
    Lookup BIN info with multi-API fallback + local detection.
    Priority: DB cache → binlist.net → antipublic → bincodes → local prefix detection

    Returns BinInfo (never None — falls back to local detection or minimal info).
    """
    bin6 = bin6[:6]

    # Memory cache
    if bin6 in _CACHE:
        return _CACHE[bin6]

    # DB cache
    cached = await _get_from_db(bin6)
    if cached is not None:
        _CACHE[bin6] = cached
        return cached

    info = None

    # Try local detection FIRST for known Indian/special BINs
    # This avoids wrong API data (binlist returns 'Diners' for RuPay 652xxx)
    local = _detect_local(bin6)
    if local and local.get("scheme") not in ("Visa", "Mastercard"):
        # For unambiguous networks (RuPay, UnionPay, Amex, JCB) use local directly
        # Still try APIs for bank name + country enrichment
        info = _make_bin_info(bin6, local)
        # Try APIs to enrich bank name only
        async with aiohttp.ClientSession() as session:
            enrich = await _lookup_antipublic(session, bin6)
            if not enrich:
                enrich = await _lookup_binlist(session, bin6)
            if enrich and enrich.get("bank_name") and enrich["bank_name"] != "Unknown":
                info.bank_name = enrich["bank_name"]
            if enrich and enrich.get("country_name") and enrich["country_name"] != "Unknown":
                if not info.country_name or info.country_name == "Unknown":
                    info.country_name = enrich["country_name"]
                    info.country_code = enrich.get("country_code", info.country_code)
        _CACHE[bin6] = info
        await _save_to_db(bin6, info)
        return info

    async with aiohttp.ClientSession() as session:
        # API 1: antipublic first (better Indian BIN coverage)
        data = await _lookup_antipublic(session, bin6)
        if data and (data.get("scheme") or data.get("country_name")):
            info = _make_bin_info(bin6, data)

        # API 2: binlist.net (fallback)
        if not info:
            data = await _lookup_binlist(session, bin6)
            if data and (data.get("scheme") or data.get("country_name")):
                info = _make_bin_info(bin6, data)

        # API 3: bincodes (last resort)
        if not info:
            data = await _lookup_bincodes(session, bin6)
            if data and (data.get("scheme") or data.get("country_name")):
                info = _make_bin_info(bin6, data)

    # Local prefix detection (always works as final fallback)
    if not info:
        local = _detect_local(bin6)
        if local:
            info = _make_bin_info(bin6, local)

    # Absolute fallback — at least show BIN
    if not info:
        info = BinInfo(
            bin=bin6,
            scheme="Unknown",
            type="Unknown",
            brand="Unknown",
            prepaid=False,
            country_name="Unknown",
            country_code="",
            country_flag="🌐",
            bank_name="Unknown",
            vbv=False,
        )

    _CACHE[bin6] = info
    await _save_to_db(bin6, info)
    return info
