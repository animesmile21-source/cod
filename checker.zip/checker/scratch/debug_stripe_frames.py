"""
scratch/debug_stripe_frames.py
Deep-dive: List ALL frames recursively + dump elements/sessions response
Goal: Find which frame has the actual card number input
"""
import asyncio, sys, re, json
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

CHECKOUT_URL = input("Fresh URL: ").strip().lstrip('\ufeff')


async def main():
    from playwright.async_api import async_playwright

    sessions_response = {}

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"]
        )
        ctx = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
            locale="en-US",
        )
        page = await ctx.new_page()

        async def on_resp(response):
            if "elements/sessions" in response.url:
                try:
                    body = await response.json()
                    sessions_response.update(body)
                    # Save full response
                    with open("scratch/elements_sessions_full.json", "w", encoding="utf-8") as f:
                        json.dump(body, f, indent=2)
                    print(f"  [elements/sessions] Saved full response → scratch/elements_sessions_full.json")
                    print(f"  Keys: {list(body.keys())}")
                    # Check for PI/SI data
                    for key in ["payment_intent", "setup_intent", "order", "intent"]:
                        if key in body:
                            print(f"  [{key}] = {json.dumps(body[key])[:200]}")
                except Exception as e:
                    print(f"  [elements/sessions] Error: {e}")

        page.on("response", on_resp)

        print(f"\nLoading: {CHECKOUT_URL[:60]}...")
        try:
            await page.goto(CHECKOUT_URL, wait_until="domcontentloaded", timeout=20000)
        except Exception as e:
            print(f"Nav error: {e}")
        await asyncio.sleep(5)

        # ── List ALL frames ──
        print(f"\n{'='*60}")
        print(f"ALL FRAMES ({len(page.frames)} total):")
        print(f"{'='*60}")

        card_frames = []
        for i, frame in enumerate(page.frames):
            furl = frame.url or "about:blank"
            fname = frame.name or "(no name)"

            try:
                inputs = await frame.eval_on_selector_all(
                    "input",
                    "els => els.map(e => ({type:e.type, name:e.name, id:e.id, placeholder:e.placeholder, autocomplete:e.autocomplete, 'aria-label':e.getAttribute('aria-label')}))"
                )
            except Exception:
                inputs = []

            has_card = any(
                any(x in str(inp).lower() for x in ["cardnumber", "cc-number", "card number", "1234"])
                for inp in inputs
            )
            has_exp = any(
                any(x in str(inp).lower() for x in ["exp", "mm/yy", "expiry", "cc-exp"])
                for inp in inputs
            )
            has_cvc = any(
                any(x in str(inp).lower() for x in ["cvc", "cvv", "security", "cc-csc"])
                for inp in inputs
            )

            # Print frame info
            marker = ""
            if has_card: marker += "💳 CARD "
            if has_exp: marker += "📅 EXP "
            if has_cvc: marker += "🔐 CVC "

            print(f"\nFrame[{i}] {marker}")
            print(f"  URL : {furl[:90]}")
            print(f"  Name: {fname}")
            if inputs:
                for inp in inputs:
                    print(f"  Input: {inp}")
            else:
                print(f"  Inputs: (none)")

            if has_card or has_exp or has_cvc:
                card_frames.append((i, frame, has_card, has_exp, has_cvc))

        print(f"\n{'='*60}")
        print(f"CARD-RELATED FRAMES: {len(card_frames)}")
        print(f"{'='*60}")
        for i, frame, hc, he, hcvc in card_frames:
            print(f"  Frame[{i}]: Card={hc} Exp={he} CVC={hcvc} → {(frame.url or '')[:60]}")

        # ── Try typing into the card frames ──
        print(f"\n{'='*60}")
        print("ATTEMPTING CARD FILL IN ALL CARD FRAMES:")
        print(f"{'='*60}")

        for i, frame, has_card, has_exp, has_cvc in card_frames:
            print(f"\nFrame[{i}]:")
            if has_card:
                try:
                    # Find first input
                    el = frame.locator("input").first
                    await el.click()
                    await asyncio.sleep(0.2)
                    await el.type("4242424242424242", delay=50)
                    print(f"  ✅ Typed card number!")
                except Exception as e:
                    print(f"  ❌ Card type failed: {e}")
            if has_exp:
                try:
                    inputs = frame.locator("input")
                    cnt = await inputs.count()
                    for j in range(cnt):
                        el = inputs.nth(j)
                        ph = await el.get_attribute("placeholder") or ""
                        ac = await el.get_attribute("autocomplete") or ""
                        if "mm" in ph.lower() or "exp" in ac.lower():
                            await el.click()
                            await el.type("12/30", delay=50)
                            print(f"  ✅ Typed expiry!")
                            break
                except Exception as e:
                    print(f"  ❌ Expiry type failed: {e}")
            if has_cvc:
                try:
                    inputs = frame.locator("input")
                    cnt = await inputs.count()
                    for j in range(cnt):
                        el = inputs.nth(j)
                        ph = await el.get_attribute("placeholder") or ""
                        ac = await el.get_attribute("autocomplete") or ""
                        if "cvc" in ph.lower() or "csc" in ac.lower() or "cvv" in ph.lower():
                            await el.click()
                            await el.type("123", delay=50)
                            print(f"  ✅ Typed CVC!")
                            break
                except Exception as e:
                    print(f"  ❌ CVC type failed: {e}")

        await asyncio.sleep(1)
        await page.screenshot(path="scratch/debug_frames.png")
        print("\n📸 scratch/debug_frames.png saved")

        await ctx.close()
        await browser.close()

    # Print key parts of elements/sessions
    print(f"\n{'='*60}")
    print("ELEMENTS/SESSIONS KEY DATA:")
    print(f"{'='*60}")
    for key in ["business_name", "merchant_currency", "amount_total",
                "payment_intent", "setup_intent", "order",
                "payment_method_types", "subscription"]:
        if key in sessions_response:
            val = sessions_response[key]
            print(f"  {key}: {json.dumps(val)[:300]}")


if __name__ == "__main__":
    asyncio.run(main())
