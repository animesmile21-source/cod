"""
Inspect registration & login behavior on https://ea-courses.com
"""
import asyncio, sys, re, random
sys.path.insert(0, ".")
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from curl_cffi.requests import AsyncSession
from faker import Faker
faker = Faker()

TEST_SITE = "https://ea-courses.com"

async def test_ea_courses_reg():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
    }
    async with AsyncSession(impersonate="chrome131") as s:
        r1 = await s.get(f"{TEST_SITE}/my-account/", headers=headers)
        html_1 = r1.text

        reg_match = re.search('name="woocommerce-register-nonce" value="(.*?)"', html_1)
        if not reg_match:
            print("❌ No register nonce on ea-courses.com")
            return

        reg_nonce = reg_match.group(1)
        fake_email = f"test_{random.randint(10000,99999)}@gmail.com"
        fake_pass = "StrongPass123!"

        data_reg = {
            'email': fake_email,
            'password': fake_pass,
            'woocommerce-register-nonce': reg_nonce,
            'register': 'Register',
        }
        r2 = await s.post(f"{TEST_SITE}/my-account/", headers=headers, data=data_reg)
        cookies = s.cookies.get_dict()
        logged_in = any("wordpress_logged_in" in k for k in cookies.keys())
        print(f"ea-courses Registration Logged In: {logged_in}")
        print(f"Cookies: {list(cookies.keys())}")

if __name__ == "__main__":
    asyncio.run(test_ea_courses_reg())
