"""
handlers/b3_handler.py — /b3 WooCommerce Braintree Gate Commands

Commands:
  /b3chk  <card>   — Single card check via B3 only (no Razorpay)
  /b3mchk          — Mass check .txt file via B3 only
  /b3site <url>    — Set target WooCommerce site
  /b3addpair       — Add a cookie pair (bot-guided, send 2 files)
  /b3pairs         — List all cookie pairs with status
  /b3delpair <id>  — Delete a cookie pair
  /b3status        — B3 gate status panel

Cookie format (Python dict):
  cookies = {
      'wordpress_logged_in_xxx': 'value...',
      ...
  }

How to get cookies:
  1. Go to site's /my-account/add-payment-method/ in browser
  2. Open DevTools → Application → Cookies
  3. Export as Python dict format
"""
import asyncio
import json
import os
import re
import tempfile
import time

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

import database.db as db
import config
from utils.error_handler import notify_owner_on_error
_active_b3_checks: dict[int, bool] = {}

from core.parser import parse_cc, parse_mass
from core.bin_lookup import lookup_bin
from gateways.b3_gate import check_b3_gate, _parse_response
from gateways.base import CCStatus, LIVE_STATUSES
from utils.formatter import format_single_result


def _is_admin(user_id: int) -> bool:
    return user_id in config.OWNER_IDS


async def _admin_denied(msg: Message):
    await msg.reply(
        "🚫 **Access Denied!**\n"
        "This bot is private — admin only.",
        parse_mode=enums.ParseMode.MARKDOWN
    )


def _parse_cookie_text(text: str) -> dict | None:
    """
    Parse cookie text into dict.
    Supports:
      - Python dict format: cookies = {'key': 'val', ...}
      - Raw dict:            {'key': 'val', ...}
      - JSON:                {"key": "val", ...}
    """
    text = text.strip()
    # Remove 'cookies = ' prefix if present
    if text.startswith("cookies"):
        text = re.sub(r'^cookies\s*=\s*', '', text, flags=re.IGNORECASE)

    # Try JSON parse first
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    # Try Python dict eval (safe-ish: only allows literals)
    try:
        import ast
        data = ast.literal_eval(text)
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    return None


# ── State machine for /b3addpair ───────────────────────────────────────────────
# user_id → {"step": "waiting_cookie1"|"waiting_cookie2", "pair_id": str, "cookie1": dict}
_addpair_state: dict[int, dict] = {}


@notify_owner_on_error
async def stop_b3mchk_callback(client: Client, cb):
    chat_id = int(cb.data.split("_")[-1])
    if cb.from_user.id not in config.OWNER_IDS:
        await cb.answer("❌ Owner/Admin only.", show_alert=True)
        return
    _active_b3_checks[chat_id] = False
    await cb.answer("🛑 B3 mass check stopping... Generating results file.", show_alert=True)


def register_b3(app: Client):
    @app.on_callback_query(filters.create(lambda _, __, cb: cb.data and cb.data.startswith("stop_b3mchk_")))
    async def _stop_b3mchk(client: Client, cb):
        await stop_b3mchk_callback(client, cb)

    # ── /b3status ──────────────────────────────────────────────────────────────
    @app.on_message(filters.command("b3status"))
    @notify_owner_on_error
    async def b3status_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        cfg = await db.b3_get_config()
        pairs = await db.b3_get_active_pairs()

        if not cfg or not cfg["site_url"]:
            site_txt = "⚠️ Not set — use `/b3site <url>`"
        else:
            from urllib.parse import urlparse
            domain = urlparse(cfg["site_url"]).netloc
            site_txt = f"✅ `{domain}`"

        pair_lines = ""
        for p in pairs:
            pair_lines += f"  • Pair `{p['pair_id']}` — Last used: `{p['last_used'] or 'Never'}`\n"

        hit_rate = ""
        if cfg and cfg["total_checked"] > 0:
            rate = round(cfg["total_live"] / cfg["total_checked"] * 100, 1)
            hit_rate = f"📈 **Hit Rate:** `{rate}%`\n"

        text = (
            f"🔵 **B3 WooCommerce Gate Status**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Site:** {site_txt}\n"
            f"🍪 **Cookie Pairs:** `{len(pairs)} active`\n"
            f"{pair_lines}"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 **Total Checked:** `{cfg['total_checked'] if cfg else 0}`\n"
            f"✅ **Total Live:** `{cfg['total_live'] if cfg else 0}`\n"
            f"{hit_rate}"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 `/b3site <url>` — Set site\n"
            f"💡 `/b3addpair` — Add cookie pair\n"
            f"💡 `/b3pairs` — List all pairs\n"
            f"💡 `/b3chk <card>` — Single check\n"
            f"💡 `/b3mchk` — Mass check .txt"
        )
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN)

    # ── /b3site ────────────────────────────────────────────────────────────────
    @app.on_message(filters.command("b3site"))
    @notify_owner_on_error
    async def b3site_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        parts = msg.text.split(maxsplit=1)
        if len(parts) < 2:
            await msg.reply(
                "❌ **Usage:** `/b3site https://www.calipercovers.com`\n\n"
                "The site must be a WooCommerce store with Braintree payment gateway.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        url = parts[1].strip().rstrip("/")
        if not url.startswith("http"):
            url = "https://" + url

        await db.b3_set_site(url)

        from urllib.parse import urlparse
        domain = urlparse(url).netloc
        await msg.reply(
            f"✅ **B3 Site Set!**\n\n"
            f"🌐 **Site:** `{domain}`\n"
            f"🔗 **Full URL:** `{url}`\n\n"
            f"Now add cookie pairs with `/b3addpair`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    # ── /b3pairs ───────────────────────────────────────────────────────────────
    @app.on_message(filters.command("b3pairs"))
    @notify_owner_on_error
    async def b3pairs_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        pairs = await db.b3_get_active_pairs()
        if not pairs:
            await msg.reply(
                "🍪 **No cookie pairs configured.**\n\n"
                "Use `/b3addpair` to add your first pair.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        lines = [f"🍪 **B3 Cookie Pairs** ({len(pairs)} total)\n━━━━━━━━━━━━━━━━━━━━━━"]
        for p in pairs:
            keys = len(json.loads(p["cookie1"]))
            lines.append(
                f"• **Pair `{p['pair_id']}`**\n"
                f"  Keys: `{keys}` | Added: `{p['added_at'][:10]}`\n"
                f"  Last used: `{p['last_used'] or 'Never'}`\n"
                f"  Delete: `/b3delpair {p['pair_id']}`"
            )

        await msg.reply("\n".join(lines), parse_mode=enums.ParseMode.MARKDOWN)

    # ── /b3delpair ─────────────────────────────────────────────────────────────
    @app.on_message(filters.command("b3delpair"))
    @notify_owner_on_error
    async def b3delpair_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        parts = msg.text.split()
        if len(parts) < 2:
            await msg.reply(
                "❌ **Usage:** `/b3delpair <pair_id>`\n"
                "Use `/b3pairs` to see pair IDs.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        pair_id = parts[1].strip()
        await db.b3_delete_pair(pair_id)
        await msg.reply(
            f"✅ **Cookie pair `{pair_id}` deleted.**\n"
            f"Use `/b3pairs` to see remaining pairs.",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    # ── /b3addpair — Multi-step cookie pair addition ───────────────────────────
    @app.on_message(filters.command("b3addpair"))
    @notify_owner_on_error
    async def b3addpair_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        # Generate pair ID from existing count
        pairs = await db.b3_get_active_pairs()
        next_id = str(len(pairs) + 1)

        _addpair_state[msg.from_user.id] = {
            "step":    "waiting_cookie1",
            "pair_id": next_id,
            "cookie1": None,
        }

        await msg.reply(
            f"🍪 **Adding Cookie Pair #{next_id}**\n\n"
            f"**Step 1/2:** Send `cookies_1` file\n\n"
            f"**Format accepted:**\n"
            f"• Python dict: `cookies = {{'key': 'value', ...}}`\n"
            f"• JSON: `{{\"key\": \"value\", ...}}`\n\n"
            f"📋 **How to get cookies:**\n"
            f"1. Open site `/my-account/add-payment-method/` in browser\n"
            f"2. DevTools → Application → Cookies\n"
            f"3. Export as dict or send the `.txt` file directly\n\n"
            f"_Send the file or paste the cookie text now..._\n"
            f"_(Send /cancel to abort)_",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("cancel"))
    async def cancel_cmd(client: Client, msg: Message):
        if msg.from_user.id in _addpair_state:
            del _addpair_state[msg.from_user.id]
            await msg.reply("❌ **Cancelled.**", parse_mode=enums.ParseMode.MARKDOWN)

    # Handle cookie file/text input for /b3addpair flow
    @app.on_message(filters.text | filters.document)
    async def handle_cookie_input(client: Client, msg: Message):
        from pyrogram import ContinuePropagation
        if not msg.from_user:
            raise ContinuePropagation  # channel/anonymous message — skip
        user_id = msg.from_user.id
        if user_id not in _addpair_state:
            raise ContinuePropagation


        state = _addpair_state[user_id]

        # Get content from file or text
        content = None
        if msg.document:
            tmp_path = None
            try:
                tmp_path = await client.download_media(msg.document)
                with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except Exception as e:
                await msg.reply(f"❌ Failed to read file: `{e}`", parse_mode=enums.ParseMode.MARKDOWN)
                return
            finally:
                if tmp_path and os.path.exists(tmp_path):
                    os.remove(tmp_path)
        elif msg.text and not msg.text.startswith("/"):
            content = msg.text

        if not content:
            return

        cookies = _parse_cookie_text(content)
        if not cookies:
            await msg.reply(
                "❌ **Could not parse cookies!**\n\n"
                "Expected format:\n"
                "```\ncookies = {\n    'key': 'value',\n    ...\n}\n```\n"
                "Or send the raw `.txt` file from B3 folder.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        if state["step"] == "waiting_cookie1":
            state["cookie1"] = cookies
            state["step"] = "waiting_cookie2"
            await msg.reply(
                f"✅ **Cookie 1 received!** ({len(cookies)} keys)\n\n"
                f"**Step 2/2:** Now send `cookies_2` file\n"
                f"_(same format, different session cookie)_",
                parse_mode=enums.ParseMode.MARKDOWN
            )

        elif state["step"] == "waiting_cookie2":
            pair_id = state["pair_id"]
            cookie1_json = json.dumps(state["cookie1"])
            cookie2_json = json.dumps(cookies)

            await db.b3_add_cookie_pair(pair_id, cookie1_json, cookie2_json)
            del _addpair_state[user_id]

            all_pairs = await db.b3_get_active_pairs()
            await msg.reply(
                f"✅ **Cookie Pair #{pair_id} Added!**\n\n"
                f"🍪 **Cookie 1:** `{len(state['cookie1'])} keys`\n"
                f"🍪 **Cookie 2:** `{len(cookies)} keys`\n"
                f"📊 **Total pairs:** `{len(all_pairs)}`\n\n"
                f"Use `/b3chk <card>` to test\n"
                f"Use `/b3mchk` for mass check",
                parse_mode=enums.ParseMode.MARKDOWN
            )

    # ── /b3chk — Single B3 Check ───────────────────────────────────────────────
    @app.on_message(filters.command("b3chk"))
    @notify_owner_on_error
    async def b3chk_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        parts = msg.text.strip().split(maxsplit=1)
        if len(parts) < 2:
            await msg.reply(
                "❌ **Usage:** `/b3chk 4111111111111111|12|2026|123`\n\n"
                "🔵 **B3 Braintree Gate** (WooCommerce cookies)\n"
                "• No Razorpay — B3 only\n"
                "• No charge on card ($0 soft auth)\n"
                "• Use `/b3status` to check gate config",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        from core.parser import parse_cc
        card = parse_cc(parts[1].strip())
        if not card:
            await msg.reply(
                "❌ **Invalid card format!**\n"
                "Use: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        if not await db.b3_is_configured():
            await msg.reply(
                "⚠️ **B3 Gate not configured!**\n\n"
                "1. `/b3site <url>` — Set WooCommerce site\n"
                "2. `/b3addpair` — Add cookie pair",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        wait_msg = await msg.reply(
            f"⏳ **B3 Checking...**\n`{card.number}|{card.month}|{card.year}|{card.cvv}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

        start = time.monotonic()
        result = await check_b3_gate(card)
        elapsed = time.monotonic() - start

        bin_info = await lookup_bin(card.bin)
        user_name = msg.from_user.username or msg.from_user.first_name or "user"
        text = format_single_result(card, result, bin_info, elapsed, username=user_name)

        # Append B3-specific info
        site = result.extra.get("site", "")
        pair = result.extra.get("pair_id", "")
        raw  = result.extra.get("raw_msg", "")
        if site or pair:
            text += f"\n🔵 B3 Site: `{site}` | Pair: `{pair}`"
        if raw and raw != result.message:
            text += f"\n📋 Raw: `{raw[:80]}`"

        await wait_msg.edit_text(text, parse_mode=enums.ParseMode.MARKDOWN)

        await db.log_check(
            user_id=msg.from_user.id,
            card_number=card.number,
            card_bin=card.bin,
            status=result.status.value,
            gateway=result.gateway,
            is_vbv=result.is_vbv,
            message=result.message,
        )

    # ── /b3mchk — Mass B3 Check ────────────────────────────────────────────────
    @app.on_message(
        filters.command("b3mchk") & (filters.document | filters.text)
    )
    @notify_owner_on_error
    async def b3mchk_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        if not await db.b3_is_configured():
            await msg.reply(
                "⚠️ **B3 Gate not configured!**\n\n"
                "1. `/b3site <url>` — Set WooCommerce site\n"
                "2. `/b3addpair` — Add cookie pair",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        doc_msg = None
        if msg.document:
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            doc_msg = msg.reply_to_message
        else:
            await msg.reply(
                "❌ **Usage:**\n"
                "• Send `.txt` file with caption `/b3mchk`\n"
                "• OR reply to `.txt` with `/b3mchk`\n\n"
                "📄 Each line: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        doc = doc_msg.document
        if not (doc.file_name or "").lower().endswith(".txt"):
            await msg.reply("❌ Only `.txt` files supported.")
            return

        if doc.file_size > 5_000_000:
            await msg.reply("❌ File too large. Max 5MB.")
            return

        wait_msg = await msg.reply("📥 **Downloading...**", parse_mode=enums.ParseMode.MARKDOWN)

        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as e:
            await wait_msg.edit_text(f"❌ Failed to read file: `{e}`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)

        cards = parse_mass(content)
        if not cards:
            await wait_msg.edit_text(
                "❌ No valid cards found.\nFormat: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        total = len(cards)

        # B3 workers — max 3 (WooCommerce sites rate-limit hard)
        workers = 3
        sem = asyncio.Semaphore(workers)
        lock = asyncio.Lock()

        done = live_count = dead_count = error_count = 0
        vbv_count = nonvbv_count = 0
        charged_results: list[dict] = []
        vbv_results: list[dict] = []
        dead_results: list[dict] = []
        error_results: list[dict] = []
        start = time.monotonic()
        last_edit_time = 0.0

        _active_b3_checks[msg.chat.id] = True
        stop_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🛑 STOP CHECKING 🛑", callback_data=f"stop_b3mchk_{msg.chat.id}")]
        ])

        await wait_msg.edit_text(
            f"🔵 **B3 Mass Check Started!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📋 **Cards:** `{total}`\n"
            f"⚙️ **Workers:** `{workers}` (B3 rate limit)\n"
            f"⏳ Checking...",
            parse_mode=enums.ParseMode.MARKDOWN,
            reply_markup=stop_markup
        )

        async def check_one_b3(card):
            nonlocal done, live_count, dead_count, error_count, vbv_count, nonvbv_count, last_edit_time

            if not _active_b3_checks.get(msg.chat.id, True):
                return

            async with sem:
                if not _active_b3_checks.get(msg.chat.id, True):
                    return
                t0 = time.monotonic()
                result = await check_b3_gate(card)
                elapsed = time.monotonic() - t0

                bin_info = await lookup_bin(card.bin)
                flag    = bin_info.flag_emoji()  if bin_info else "🌐"
                country = bin_info.country_name  if bin_info else "Unknown"
                bank    = bin_info.bank_name     if bin_info else "Unknown"
                scheme  = bin_info.scheme        if bin_info else "Unknown"
                ctype   = bin_info.type          if bin_info else ""
                full_type = f"{scheme} {ctype}".strip()

                is_live_card = False
                async with lock:
                    done += 1
                    current_done = done

                    item = {
                        "card":     f"{card.number}|{card.month}|{card.year}|{card.cvv}",
                        "gateway":  result.gateway,
                        "response": result.message[:80],
                        "scheme":   full_type,
                        "bank":     bank,
                        "country":  f"{flag} {country}",
                        "time":     f"{elapsed:.2f}s",
                        "pair":     result.extra.get("pair_id", "?"),
                        "amount":   "N/A",  # B3 is soft auth-only
                    }

                    if result.status == CCStatus.ERROR:
                        error_count += 1
                        error_results.append(item)
                    elif result.is_live:
                        live_count += 1
                        is_live_card = True
                        if result.is_vbv or result.status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS):
                            vbv_count += 1
                            item["tag"] = "🔐 VBV"
                            vbv_results.append(item)
                        else:
                            nonvbv_count += 1
                            item["tag"] = "✅ LIVE"
                            charged_results.append(item)
                    else:
                        dead_count += 1
                        dead_results.append(item)

                await db.log_check(
                    user_id=msg.from_user.id,
                    card_number=card.number,
                    card_bin=card.bin,
                    status=result.status.value,
                    gateway=result.gateway,
                    is_vbv=result.is_vbv,
                    message=result.message,
                )

                if is_live_card:
                    user_name = msg.from_user.username or msg.from_user.first_name or "user"
                    single_text = format_single_result(card, result, bin_info, elapsed, username=user_name)
                    single_text = f"🚨 **Instant Live Card (B3 Mass Check)!** 🚨\n\n" + single_text
                    
                    # Append B3-specific info
                    site = result.extra.get("site", "")
                    pair = result.extra.get("pair_id", "")
                    if site or pair:
                        single_text += f"\n🔵 B3 Site: `{site}` | Pair: `{pair}`"
                    
                    try:
                        instant_msg = await client.send_message(
                            chat_id=msg.chat.id,
                            text=single_text,
                            parse_mode=enums.ParseMode.MARKDOWN
                        )
                        await client.pin_chat_message(
                            chat_id=msg.chat.id,
                            message_id=instant_msg.id,
                            disable_notification=False
                        )
                    except Exception as e:
                        import logging
                        logging.getLogger("CC-Checker").error(f"Failed to send/pin instant B3 mass result: {e}")

                now = time.monotonic()
                if now - last_edit_time >= 2.0 or current_done == total:
                    last_edit_time = now
                    prog_text = (
                        f"🔵 **B3 Mass Check**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━━\n"
                        f"📊 `{current_done}/{total}`\n"
                        f"✅ **Live:** `{live_count}` | "
                        f"🔐 **VBV:** `{vbv_count}` | "
                        f"❌ **Dead:** `{dead_count}` | "
                        f"❓ **Error:** `{error_count}`"
                    )
                    try:
                        markup = stop_markup if _active_b3_checks.get(msg.chat.id, True) else None
                        await wait_msg.edit_text(prog_text, parse_mode=enums.ParseMode.MARKDOWN, reply_markup=markup)
                    except Exception:
                        pass

                # Progress update done — release semaphore before sleeping
            # Rate-limit delay OUTSIDE semaphore: other workers can run during this wait
            await asyncio.sleep(2)

        await asyncio.gather(*[check_one_b3(card) for card in cards], return_exceptions=True)

        was_stopped = not _active_b3_checks.pop(msg.chat.id, True)
        elapsed_total = time.monotonic() - start

        if was_stopped:
            summary = (
                f"🛑 **B3 Mass Check Stopped by User!**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 **Progress:** `{done}/{total}`\n"
                f"✅ **Live (Non-VBV):** `{nonvbv_count}`\n"
                f"🔐 **Live (VBV):** `{vbv_count}`\n"
                f"❌ **Dead:** `{dead_count}`\n"
                f"❓ **Error:** `{error_count}`\n"
                f"⏱️ **Time:** `{elapsed_total:.1f}s`"
            )
        else:
            summary = (
                f"🔵 **B3 Mass Check Complete!**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📋 **Total:** `{total}`\n"
                f"✅ **Live (Non-VBV):** `{nonvbv_count}`\n"
                f"🔐 **Live (VBV):** `{vbv_count}`\n"
                f"❌ **Dead:** `{dead_count}`\n"
                f"❓ **Error:** `{error_count}`\n"
                f"📈 **Hit Rate:** `{round(live_count/total*100,1) if total else 0}%`\n"
                f"⏱️ **Time:** `{elapsed_total:.1f}s`"
            )
        await wait_msg.edit_text(summary, parse_mode=enums.ParseMode.MARKDOWN)

        # ── Send results as .txt file ────────────────────────────────────────
        lines = [
            "=" * 60,
            "🔵 B3 BRAINTREE — MASS CHECK RESULTS" + (" (STOPPED BY USER)" if was_stopped else ""),
            f"📋 Total Checked: {done}/{total} | ✅ Live: {nonvbv_count} | 🔐 VBV: {vbv_count} | ❌ Dead: {dead_count} | ❓ Error: {error_count}",
            f"⚡ Workers: {workers} | ⏱️ Time: {elapsed_total:.1f}s",
            "=" * 60,
            "",
        ]

        if charged_results:
            lines.append(f"✅ CHARGE APPROVED ({len(charged_results)} cards)")
            lines.append("-" * 60)
            for r in charged_results:
                lines.append(f"{r['card']} | Status: {r['tag']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Pair: {r['pair']} | Time: {r['time']}")
            lines.append("")

        if vbv_results:
            lines.append(f"🔐 VBV / OTP REQUIRED ({len(vbv_results)} cards)")
            lines.append("-" * 60)
            for r in vbv_results:
                lines.append(f"{r['card']} | Status: {r['tag']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Pair: {r['pair']} | Time: {r['time']}")
            lines.append("")

        if dead_results:
            lines.append(f"❌ DEAD / DECLINED ({len(dead_results)} cards)")
            lines.append("-" * 60)
            for r in dead_results:
                lines.append(f"{r['card']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Pair: {r['pair']} | Time: {r['time']}")
            lines.append("")

        if error_results:
            lines.append(f"❓ ERRORS ({len(error_results)} cards)")
            lines.append("-" * 60)
            for r in error_results:
                lines.append(f"{r['card']} | Gate: {r['gateway']} | Response: {r['response']} | Pair: {r['pair']} | Time: {r['time']}")
            lines.append("")

        results_text = "\n".join(lines)
        tmp_file = tempfile.NamedTemporaryFile(
            mode="w", suffix="_b3_results.txt",
            delete=False, encoding="utf-8"
        )
        tmp_file.write(results_text)
        tmp_file.close()

        try:
            caption = (
                f"🔵 **B3 Mass Check Results" + (" (Stopped)" if was_stopped else "") + "**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"✅ **Live:** `{nonvbv_count}`\n"
                f"🔐 **VBV:** `{vbv_count}`\n"
                f"❌ **Dead:** `{dead_count}`\n"
                f"📋 **Checked:** `{done}/{total}` | ⏱️ `{elapsed_total:.1f}s`"
            )
            file_name_txt = f"b3_results_stopped_{done}of{total}.txt" if was_stopped else f"b3_results_{total}cards.txt"
            await client.send_document(
                msg.chat.id,
                tmp_file.name,
                caption=caption,
                parse_mode=enums.ParseMode.MARKDOWN,
                file_name=file_name_txt,
            )
        finally:
            os.unlink(tmp_file.name)
