"""
Stripe Hosted Checkout URL Scraper
Automatically finds and captures checkout.stripe.com URLs from real sites
Uses Playwright (headless browser) to trigger actual checkout flow

Requirements:
    pip install playwright
    python -m playwright install chromium
"""

import asyncio
import sys
import re
import json
import random
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

try:
    from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout
except ImportError:
    print("Installing playwright...")
    import subprocess
    subprocess.run([sys.executable, "-m", "pip", "install", "playwright"], check=True)
    subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
    from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout

# ─── Output file ───
OUTPUT_FILE = "stripe_checkout_urls.txt"

# ─── Target strategies ───
# These are known sites that redirect to checkout.stripe.com
GUMROAD_SEARCH_TERMS = [
    "https://gumroad.com/l/",  # Direct gumroad product links
]

KNOWN_STRIPE_CHECKOUT_SITES = [
    # Direct buy.stripe.com links - these open checkout.stripe.com directly
    # Format: (url, description)
    # Add any known buy.stripe.com links here
]


async def capture_stripe_url_from_page(page, site_url: str, timeout: int = 15000) -> str | None:
    """Navigate to a page and capture any checkout.stripe.com redirect"""
    captured_url = None

    def on_request(request):
        nonlocal captured_url
        url = request.url
        if "checkout.stripe.com/c/pay/cs_" in url:
            captured_url = url
            print(f"    [+] Captured Checkout URL!")

    def on_response(response):
        nonlocal captured_url
        url = response.url
        if "checkout.stripe.com/c/pay/cs_" in url:
            captured_url = url

    page.on("request", on_request)
    page.on("response", on_response)

    # Also intercept navigation
    async def on_frame_navigated(frame):
        nonlocal captured_url
        url = frame.url
        if "checkout.stripe.com/c/pay/cs_" in url:
            captured_url = url

    page.on("framenavigated", on_frame_navigated)

    try:
        await page.goto(site_url, wait_until="domcontentloaded", timeout=timeout)
        await asyncio.sleep(2)
    except Exception:
        pass

    return captured_url


async def try_gumroad_product(page, product_url: str) -> str | None:
    """Try to get Stripe checkout URL from a Gumroad product"""
    print(f"  Trying: {product_url}")
    captured_url = None

    def on_request(request):
        nonlocal captured_url
        if "checkout.stripe.com/c/pay/cs_" in request.url:
            captured_url = request.url
        # Also look for cs_live in response headers / redirects
        
    def on_frame_nav(frame):
        nonlocal captured_url
        if "checkout.stripe.com/c/pay/cs_" in frame.url:
            captured_url = frame.url

    page.on("request", on_request)
    page.on("framenavigated", on_frame_nav)

    try:
        await page.goto(product_url, wait_until="domcontentloaded", timeout=15000)
        await asyncio.sleep(2)

        # Look for "Buy" / "Get" / "I want this" button (Gumroad style)
        buy_selectors = [
            '[data-component="BuyButton"]',
            'button:has-text("Buy")',
            'button:has-text("Get")',
            'button:has-text("I want this")',
            'a:has-text("Buy")',
            'a:has-text("Get")',
            '.js-buy-button',
            '#buy-button',
            '[data-analytics-title="purchase"]',
        ]

        clicked = False
        for sel in buy_selectors:
            try:
                el = page.locator(sel).first
                if await el.is_visible(timeout=1500):
                    await el.click()
                    clicked = True
                    print(f"    Clicked: {sel}")
                    await asyncio.sleep(3)
                    break
            except Exception:
                continue

        if not clicked:
            print("    No buy button found")

        # Wait for possible redirect
        await asyncio.sleep(3)

        # Check current URL
        current = page.url
        if "checkout.stripe.com/c/pay/cs_" in current:
            captured_url = current

    except PlaywrightTimeout:
        print("    Timeout loading page")
    except Exception as e:
        print(f"    Error: {e}")
    finally:
        page.remove_listener("request", on_request)
        page.remove_listener("framenavigated", on_frame_nav)

    return captured_url


async def search_gumroad_for_products(page, query: str = "template") -> list[str]:
    """Search Gumroad for products to find checkout URLs"""
    products = []
    try:
        search_url = f"https://gumroad.com/discover?query={query}&sort=most_recent"
        await page.goto(search_url, wait_until="domcontentloaded", timeout=15000)
        await asyncio.sleep(3)

        # Get product links
        links = await page.eval_on_selector_all(
            'a[href*="/l/"]',
            'els => els.map(e => e.href)'
        )
        # Filter and deduplicate
        for link in links:
            if "gumroad.com/l/" in link and link not in products:
                products.append(link)
            if len(products) >= 10:
                break

        print(f"  Found {len(products)} Gumroad products")
    except Exception as e:
        print(f"  Search error: {e}")
    return products


async def try_buy_stripe_link(page, link: str) -> str | None:
    """Try a buy.stripe.com link directly"""
    print(f"  Trying buy.stripe.com: {link}")
    captured_url = None

    def on_nav(frame):
        nonlocal captured_url
        if "checkout.stripe.com/c/pay/cs_" in frame.url:
            captured_url = frame.url

    page.on("framenavigated", on_nav)

    try:
        await page.goto(link, wait_until="domcontentloaded", timeout=15000)
        await asyncio.sleep(3)
        current = page.url
        if "checkout.stripe.com/c/pay/cs_" in current:
            captured_url = current
    except Exception as e:
        print(f"    Error: {e}")
    finally:
        page.remove_listener("framenavigated", on_nav)

    return captured_url


async def find_stripe_checkout_urls(max_urls: int = 5):
    """Main function to find Stripe Checkout URLs"""
    print("=" * 65)
    print("  STRIPE CHECKOUT URL SCRAPER")
    print("  Capturing cs_live_... URLs from real sites")
    print("=" * 65)

    found_urls = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
            ]
        )
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 720},
            locale="en-US",
        )
        
        # ── Strategy 1: Search Gumroad ──
        print("\n[Strategy 1] Searching Gumroad for products...")
        page = await context.new_page()
        
        search_terms = ["icon pack", "resume template", "notion template", "ebook", "cheatsheet"]
        
        for term in search_terms:
            if len(found_urls) >= max_urls:
                break
            
            print(f"\n  Searching: '{term}'")
            products = await search_gumroad_for_products(page, term)
            
            for product_url in products[:3]:
                if len(found_urls) >= max_urls:
                    break
                
                page2 = await context.new_page()
                try:
                    url = await try_gumroad_product(page2, product_url)
                    if url:
                        found_urls.append(url)
                        print(f"\n  *** CAPTURED: {url[:80]}...")
                        
                        # Save to file
                        with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
                            f.write(f"{datetime.now()} | {url}\n")
                        
                        print(f"  Saved to {OUTPUT_FILE}")
                except Exception as e:
                    print(f"  Error on product: {e}")
                finally:
                    await page2.close()
                
                await asyncio.sleep(1)

        await page.close()

        # ── Strategy 2: Try known buy.stripe.com links ──
        if KNOWN_STRIPE_CHECKOUT_SITES and len(found_urls) < max_urls:
            print("\n[Strategy 2] Trying known Stripe buy links...")
            page3 = await context.new_page()
            for link, desc in KNOWN_STRIPE_CHECKOUT_SITES:
                print(f"  {desc}: {link}")
                url = await try_buy_stripe_link(page3, link)
                if url:
                    found_urls.append(url)
                    print(f"  *** CAPTURED: {url[:80]}...")
                    with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
                        f.write(f"{datetime.now()} | {url}\n")
            await page3.close()

        await context.close()
        await browser.close()

    print("\n" + "=" * 65)
    print(f"DONE — {len(found_urls)} Stripe Checkout URLs captured")
    print(f"Saved to: {OUTPUT_FILE}")
    print("=" * 65)
    
    for i, url in enumerate(found_urls, 1):
        print(f"\n[{i}] {url}")
    
    return found_urls


if __name__ == "__main__":
    asyncio.run(find_stripe_checkout_urls(max_urls=5))
